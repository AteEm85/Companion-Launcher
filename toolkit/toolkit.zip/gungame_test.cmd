@echo off
cd /d "%~dp0"
set BOT_GUNGAME=1
set PATHCHECK_IDLE_HOST=1
set PATHCHECK_WINDOWS=visible
set "PATHCHECK_TAGS=lv_nightmare|lv_easiest|lv_easiest"
".venv\Scripts\python.exe" -u pathcheck.py --keep --minutes 10 --no-global-kill --maps drygulch
exit
