@echo off
rem Builds BotLauncher.exe (next to this file) from launcher.py. Needs Python 3 with tkinter (the python.org installer has it).
rem Run it once; afterwards double-click BotLauncher.exe. Rebuild after changing launcher.py.
setlocal
cd /d "%~dp0"
rem The old BotLauncher.exe can't be replaced while it is running (that is the "Access is denied" error), so close it first.
taskkill /IM BotLauncher.exe /F >nul 2>&1
timeout /t 2 /nobreak >nul
rem A frozen BotLauncher.exe that started this passes on TCL_LIBRARY/TK_LIBRARY pointing into its temp folder, which is
rem gone once it closes. PyInstaller then decides Tcl/Tk is missing and leaves tkinter out of the exe, so drop them.
set "TCL_LIBRARY="
set "TK_LIBRARY="
set "B=%~dp0.build"
if not exist "%B%\Scripts\python.exe" (
    py -3 -m venv "%B%" 2>nul || python -m venv "%B%" || (echo Python 3 not found; install it from python.org & pause & exit /b 1)
)
"%B%\Scripts\python.exe" -c "import tkinter" || (echo This Python has no tkinter; reinstall Python from python.org with "tcl/tk" ticked & pause & exit /b 1)
"%B%\Scripts\python.exe" -m pip install -q --disable-pip-version-check pyinstaller || (echo could not install pyinstaller & pause & exit /b 1)
"%B%\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --icon "%~dp0launcher.ico" --name BotLauncher --distpath "%~dp0." --workpath "%B%\work" --specpath "%B%" launcher.py || (pause & exit /b 1)
echo.
echo Done: %~dp0BotLauncher.exe
pause
