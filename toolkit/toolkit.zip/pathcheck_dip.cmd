@echo off
rem 2-minute pathing check on The Dip (custom map). Close your own Outlaws window first.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u pathcheck.py --minutes 2 --maps TheDip1s
echo DONE> pathcheck_done.txt
