@echo off
rem Host-the-next-map test, round 2. This one DOES act on your game once (see hostnext2.py).
rem 1. Start Outlaws yourself and stay in the main menu.  2. Double-click this file.
rem 3. Host a LAN game (Deathmatch, time limit 1 minute) and play until it ends.
rem 4. Back in the main menu, do not touch anything: after 5 seconds it should host the next map by itself.
rem 5. If it stays in the menu, host the next map yourself from the menu. Then tell Claude what happened. The result is in state\hostnext2.txt.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u hostnext2.py %*
pause
