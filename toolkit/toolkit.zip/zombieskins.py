"""Zombie skins for the Horde: pale, sored skin and torn clothes on the six characters, and a zombie death sound for each.
The finished sprite files live in botctl\\zombie\\ (JAMES.SPX ...). 'on' copies them next to the game's .lab files,
'off' removes them again (anything that was there before is put back). Nothing inside the game's archives is touched.
Usage: python zombieskins.py on | off | status"""
import os, sys, shutil, json, time
HERE = os.path.dirname(os.path.abspath(__file__))
GAME = os.path.dirname(HERE)
SRC = os.path.join(HERE, "zombie")
KEEP = os.path.join(HERE, "zombie_orig")
STATE = os.path.join(HERE, "state", "zombie_installed.json")
LOG = os.path.join(HERE, "zombieskins_log.txt")

def log(*a):
    msg = " ".join(str(x) for x in a); print(msg)
    try:
        with open(LOG, "a") as f: f.write(time.strftime("%H:%M:%S ") + msg + "\n")
    except OSError: pass

def files():
    """The zombie sprites (.SPX) and the zombie death sounds (.WAV: one per character, e.g. JADIE.WAV) in zombie\\."""
    try: return sorted(n for n in os.listdir(SRC) if n.upper().endswith((".SPX", ".WAV")))
    except OSError: return []

def game_running():
    try:
        import subprocess
        out = subprocess.run(["tasklist"], capture_output=True, text=True,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout.lower()
        return "outlawsahom.exe" in out
    except Exception:
        return False

def watch():
    """Background helper: wait for the game to start, then for every game window to close, then remove the skins."""
    t0 = time.time()
    while not game_running() and time.time() - t0 < 600: time.sleep(3)
    while game_running(): time.sleep(5)
    time.sleep(3)
    while not off(): time.sleep(5)
    return True

def available(): return bool(files())

def installed():
    try:
        with open(STATE) as f: return json.load(f)
    except Exception: return None

def on():
    names = files()
    if not names: log("No zombie sprites found in", SRC); return False
    if installed(): log("Zombie skins already installed."); return True
    os.makedirs(KEEP, exist_ok=True); os.makedirs(os.path.dirname(STATE), exist_ok=True)
    done = {}
    for n in names:
        dst = os.path.join(GAME, n); had = os.path.exists(dst)
        if had: shutil.move(dst, os.path.join(KEEP, n))
        shutil.copyfile(os.path.join(SRC, n), dst)
        done[n] = had
    with open(STATE, "w") as f: json.dump(done, f)
    log("Zombie skins installed:", ", ".join(done)); return True

def off():
    st = installed()
    if st is None: log("Zombie skins are not installed."); return True
    for n, had in st.items():
        dst = os.path.join(GAME, n)
        try:
            if os.path.exists(dst): os.remove(dst)
            if had and os.path.exists(os.path.join(KEEP, n)): shutil.move(os.path.join(KEEP, n), dst)
        except OSError as e:
            log("Could not remove", n, "-", e); return False
    os.remove(STATE); log("Zombie skins removed."); return True

if __name__ == "__main__":
    c = sys.argv[1] if len(sys.argv) > 1 else "status"
    if c == "watch": sys.exit(0 if watch() else 1)
    if c == "on": sys.exit(0 if on() else 1)
    if c == "off":
        while not off():
            if "--wait" not in sys.argv: sys.exit(1)
            time.sleep(5)
        sys.exit(0)
    print("Zombie skins:", "installed" if installed() else "not installed", "| sprites available:", len(files()))
