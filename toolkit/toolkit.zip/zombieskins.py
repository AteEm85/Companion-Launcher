"""Zombie skins for the Horde: pale, sored skin and torn clothes on the six characters, and a zombie death sound for each.
The finished sprite files live in botctl\\zombie\\ (JAMES.SPX ...). 'on' packs them into one archive of our own that the
game loads (olremaster<N>.lab, see modlab.py), 'off' removes that archive again. The game's own archives are never touched.
The Christmas Horde uses the same archive with botctl\\christmas\\ instead (elves, Santa, their death sounds, jingling
footsteps and the Christmas tree): on(christmas=True).
Usage: python zombieskins.py on [christmas] | off | status"""
import os, sys, shutil, json, time
HERE = os.path.dirname(os.path.abspath(__file__))
GAME = os.path.dirname(HERE)
SRC = os.path.join(HERE, "zombie")
XMAS = os.path.join(HERE, "christmas")
XMAS_EXT = (".SPX", ".WAV", ".ITM", ".NWX", ".PCX", ".HDX", ".ATX", ".3DO")   # .ATX: the flashing wall lights
KEEP = os.path.join(HERE, "zombie_orig")
STATE = os.path.join(HERE, "state", "zombie_installed.json")
LOG = os.path.join(HERE, "zombieskins_log.txt")


def _xmas_skip(n):
    """Files in christmas\\ that are no longer used: the lit copies for outside walls only, the lights overlay, the bulb objects."""
    import re as _re
    u = n.upper()
    if _re.match(r"XL[HV]\d\d", u):                            # log-wall light copies: only the ones the maps use
        return u[:5] not in _xmas_used_lights()
    if u.endswith(".HDX") and u[:-4] + ".PCX" in _xmas_plain():  # old lit copies under the walls' own names: the
        return True                                              # walls flash (XFnn) now, so the plain name stays plain
    return bool(u.startswith(("XLT", "XLITE", "XMASLITE")) or _re.match(r"XMASL\d", u)
                or u in ("SANCHEZ.NWX", "SANCHEZ.SPX"))      # (Santa is SANTA.NWX/.SPX now: Sanchez stays Sanchez)


def _xmas_plain():
    try:
        import xmaslights as _xl
        return set(_xl.FLASH)
    except Exception:
        return set()


def _xmas_used_lights():
    """XLH01, XLV02, ...: the light copies christmas\\walls_extra.json points walls at."""
    import json as _json
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "christmas", "walls_extra.json")) as f:
            data = _json.load(f)
    except (OSError, ValueError):
        return set()
    return {str(e[2]).upper()[:5] for items in data.values() for e in items if e[2]}

def log(*a):
    msg = " ".join(str(x) for x in a); print(msg)
    try:
        with open(LOG, "a") as f: f.write(time.strftime("%H:%M:%S ") + msg + "\n")
    except OSError: pass

def files(christmas=False):
    """The zombie sprites (.SPX) and the zombie death sounds (.WAV: one per character, e.g. JADIE.WAV) in zombie\\, or
    the Christmas files in christmas\\."""
    src, ext = (XMAS, XMAS_EXT) if christmas else (SRC, (".SPX", ".WAV", ".NWX", ".ITM"))     # (.NWX/.ITM: Bob Graham's pumpkin head, the skeletons, the Halloween props)
    try: return sorted(n for n in os.listdir(src) if n.upper().endswith(ext) and os.path.isfile(os.path.join(src, n))
                       and not (christmas and _xmas_skip(n)))
    except OSError: return []

def game_running():
    try:
        import subprocess
        out = subprocess.run(["tasklist"], capture_output=True, text=True,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout.lower()
        return "outlawsahom.exe" in out
    except Exception:
        return False

def watch():
    """Background helper: wait for the game to start, then for every game window to close, then remove the skins."""
    t0 = time.time()
    while not game_running() and time.time() - t0 < 600: time.sleep(3)
    while True:                                                # (a game that opens again meanwhile - the next Co-op Mission's,
        while game_running(): time.sleep(5)                    #  or the launcher's next start - is waited out again)
        time.sleep(3)
        if game_running(): continue
        if off(): return True
        time.sleep(5)

def available(christmas=False):
    names = [n.upper() for n in files(christmas)]
    return bool(names) and (not christmas or "XMASTREE.ITM" in names and "SANTA.SPX" in names)   # (Santa: SANTA.SPX)

def installed():
    try:
        with open(STATE) as f: return json.load(f)
    except Exception: return None

def on(christmas=False):
    """Put the zombie skins and death sounds in (or the Christmas files), as ONE archive the game loads itself
    (modlab.py: olremaster<N>.lab). Loose files next to the game don't win on every PC; the archive does."""
    src = XMAS if christmas else SRC
    names = files(christmas)
    if not names: log("No sprites found in", src); return False
    sig = "|".join("%s:%d:%d" % (n, os.path.getsize(os.path.join(src, n)), int(os.path.getmtime(os.path.join(src, n)))) for n in names)
    st = installed()
    if st and st.get("_set", "zombie") == ("christmas" if christmas else "zombie") and st.get("_sig") == sig:
        log("Already installed."); return True
    if st and not off(): return False                           # another set, or the files changed since: build it again
    import modlab
    os.makedirs(os.path.dirname(STATE), exist_ok=True)
    try:
        path = modlab.build(GAME, [(n, os.path.join(src, n)) for n in names])
    except Exception as e:
        log("Could not build the zombie archive:", e); return False
    done = {n: "archive" for n in names}
    done["_archive"] = os.path.basename(path)
    done["_set"] = "christmas" if christmas else "zombie"
    done["_sig"] = sig
    with open(STATE, "w") as f: json.dump(done, f)
    log("Zombie skins installed (%s):" % os.path.basename(path), ", ".join(names)); return True

def off():
    st = installed()
    if st is None:
        try:                                                   # an archive of ours without a state file (cut short)
            import modlab
            if modlab.find_ours(GAME) and not modlab.remove(GAME): return False
        except Exception: pass
        log("Zombie skins are not installed."); return True
    import modlab
    if not modlab.remove(GAME):
        log("Could not remove the zombie archive (the game is still open?)"); return False
    for n, had in st.items():                                   # loose files from an older version of this script
        if n in ("_archive", "_set", "_sig") or had == "archive": continue
        dst = os.path.join(GAME, n)
        try:
            if os.path.exists(dst): os.remove(dst)
            if had and os.path.exists(os.path.join(KEEP, n)): shutil.move(os.path.join(KEEP, n), dst)
        except OSError as e:
            log("Could not remove", n, "-", e); return False
    os.remove(STATE); log("Zombie skins removed."); return True

if __name__ == "__main__":
    c = sys.argv[1] if len(sys.argv) > 1 else "status"
    if c == "watch": sys.exit(0 if watch() else 1)
    if c == "on": sys.exit(0 if on("christmas" in sys.argv[2:]) else 1)
    if c == "off":
        while not off():
            if "--wait" not in sys.argv: sys.exit(1)
            time.sleep(5)
        sys.exit(0)
    print("Zombie skins:", "installed" if installed() else "not installed", "| sprites available:", len(files()))
