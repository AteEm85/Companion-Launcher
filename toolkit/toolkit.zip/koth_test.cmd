@echo off
cd /d "%~dp0"
set HORDE_WINDOWS=visible
".venv\Scripts\python.exe" -u koth.py --map drygulch --bots 4 --minutes 8 --target 150
exit
