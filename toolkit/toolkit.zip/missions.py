"""Christmas Co-op Missions: short scripted missions on the Christmas maps for you and your friends (one team, the Survivors),
against ghost elves, with mini-bosses and Santa at the end of the last one. horde.py runs them (--mission <id>, or the mission
the launcher's Tools tab picked: state/next_mission.json).

The story: on Christmas Eve Santa has gone rogue. His elves have taken over the Christmas towns, the Nutcracker's toy army
has locked Mrs. Claus in the Sanctuary jail and Jack Frost has frozen Orleans. Win back Buckshotville, break Mrs. Claus out,
take the ice back from Jack Frost, then hold the Bunkers' crate yard until Santa himself comes for you.

Each mission is a list of steps, done one after the other:
  kills   kill n elves
  hold    stand inside the red square (box: x0, z0, x1, z1, marked out with red posts; y +-8 when given) for secs seconds in all
          (the clock only runs while one of you is in it)
  boss    a mini-boss joins (a tough ghost: hp x a normal one, Hell aim): kill it
  clones  "n" copies of a mini-boss ("boss": its arms and look) with little health ("hp"), all at once, named "name 1".. and
          coloured by "models" (one each); a killed one leaves the game; kill them all
Any step: "clear" (every enemy leaves first), "enemy" (only that kind of ordinary enemy), "presents" (a boss step: that many
exploding presents come with the boss)
  reach   get to every spot in "spots" (x, z[, y: on that floor]; within "r"), any order - or "pick" of a "pool" at random,
          each with a "pile" ghost on it that leaves when found, while the enemies keep coming
  tnt     a thrown stick of TNT has to go off inside the circle (the vault door)
  waves   waves of enemies: each wave's kills ("waves") with that many on the field ("field") at its level ("levels"); a rush of
          exploding presents opens every wave
  rescue  the hostage (a ghost who never fights) waits at `at`; reach her and she follows you; get her inside the circle `to`
  santa   Santa comes out (the Christmas Horde's Santa: a real bot with the Gatling and 10x health): kill him (no mission uses it
          now: Mission 4's Santa is a mini-boss throwing exploding presents)
Coordinates are the maps' own (x, z; y = floor height), picked from the map files (see the map pictures in the commit)."""

# The missions' ordinary enemies, in turn (horde.py add_bot): elves (the Christmas Horde's), little gingerbread men that only stab,
# evil snowmen throwing snowballs (a thrown knife's damage, no spin) and little nutcrackers with rifles. Every one a ghost; env: ghost.py's.
# (models: christmas\<NAME>.NWX/.SPX - a plain elf without them)
ENEMIES = [
    # (20 Nov, the user: elves start with single-barrel shotguns and use those; nutcrackers rifles; snowmen snowballs that knock
    #  you back like Jack Frost's; gingerbread men aggressive knifers)
    # (later the same day: elves only as Dr. Death's and James's elf, shotgun only - in close, where it hurts most)
    {"name": "Elf", "chars": ["drdeath", "james"],
     "env": {"GHOST_BOSS_ARMS": "sgun", "GHOST_PICKUPS": "0", "GHOST_KEEP": "8", "GHOST_RETREAT": "0"}},
    {"name": "Gingerbread", "char": "sanchez", "model": "gingmini.nwx",          # (drawn over Sanchez's frames)
     "env": {"GHOST_BOSS_ARMS": "stab", "GHOST_PICKUPS": "0", "GHOST_KEEP": "2", "GHOST_RETREAT": "0", "GHOST_STAMINA": "0"}},   # (straight at you, sprinting)
    {"name": "Snowman", "char": "bob", "model": "snowmanx.nwx",                   # (Bob's frames: Mary's played her own voice)
     "env": {"GHOST_BOSS_ARMS": "snowball", "GHOST_PICKUPS": "0", "GHOST_PROJ": "SNOWBL.3DO", "GHOST_PROJ_SPEED": "90",
             "GHOST_KEEP": "35", "GHOST_RETREAT": "18", "GHOST_KICK": "360",   # (23 Nov: about 30% of Jack Frost's 1200)
             }},
    {"name": "Nutcracker", "char": "bob", "model": "nutmini.nwx",        # (Bob's frames: his body)
     "env": {"GHOST_BOSS_ARMS": "rifle", "GHOST_PICKUPS": "0", "GHOST_KEEP": "80", "GHOST_RETREAT": "50", "GHOST_NOFLASH": "1"}},
]
# (20 Nov, the user) each mission's own enemy comes more often: every other one, the rest in turn
THEMED = {"siege": "Elf", "jailbreak": "Nutcracker", "frost": "Snowman", "showdown": "Gingerbread"}


def enemy_order(mission_id):
    """the order a mission's enemies join in: its own kind every other time, the others in turn between"""
    main = THEMED.get(mission_id)
    if not main:
        return list(ENEMIES)
    m_ = next(e for e in ENEMIES if e["name"] == main)
    out = []
    for e in ENEMIES:
        if e is not m_:
            out += [m_, e]
    return out


# An exploding present every PRESENT_EVERY seconds: it runs at the nearest player and blows up next to them (10 hearts close up, less
# further off), or blows up where it falls when it is shot dead
PRESENT_EVERY = 90.0
# One for every player in the mission each time, with Sanchez's multiplayer health,
# flat-out sprinting with no stamina, silent (no sounds of its own), no weapon at all.
# (drawn over Dr. Death's frames, so his body; 9.1 health with his 1.05 damage factor = Sanchez's 10 with his 1.15)
PRESENT = {"name": "Present", "char": "drdeath", "model": "giftman.nwx", "hp": 9.1,
           "env": {"GHOST_KAMIKAZE": "1", "GHOST_BOSS_ARMS": "fist", "GHOST_PICKUPS": "0", "GHOST_FEED": "0", "GHOST_KAMI_DMG": "20", "GHOST_STAMINA": "0",
                   "GHOST_NO_SPRINT": "0", "GHOST_SPEED_SCALE": "1", "GHOST_MOANS": ""}}

MINI_BOSSES = {
    # Mission 4's Santa (not the Christmas Horde's): a ghost of his own throwing exploding presents, faster than Sanchez's
    # dynamite and on a shorter fuse, never running out
    "santa": {"name": "Santa", "char": "sanchez", "hp": 200, "intro": "Santa Is Coming!", "speed": 1.05, "model": "santa.nwx",
              "arms": "dynamite", "gap": 1.2, "tnt_next": 1.2, "tnt_fuse": 2.4, "tnt_model": "GIFTBM.3DO", "clear": True,
              # (17 Nov: 200 health, his own presents don't hurt him, and a strong arm - twice a player's throw, out to 170 ft)
              "tnt_arm": 2.0, "tnt_self": 0, "tnt_range": 170,
              # (25 Nov, the user: as far as he wants, as long as no wall is in the way) out to 650 ft (as far as a ghost sees),
              #  with an arm four times a player's for the long ones - he only throws at someone he can see
              "tnt_arm": 4.0, "tnt_range": 650,
              # (18 Nov: he fell into Thud Tower's pit and was stuck there: the pit can't hurt him, he is put back up top)
              "pit_safe": 1,
              # (17 Nov: and a slow pistol in his other hand, firing between and during the throws: 3 a shot, about every 1.6 s)
              # (18 Nov, the user: about twice as fast - every 0.8 s)
              # (23 Nov, the user: a normal Sanchez speed - his pistol's own: a shot every 4 frames at 18 a second (0.22 s),
              #  six to a load, then about 1.6 s to reload)
              # (25 Nov, the user: his pistol shots sped up) a shot every 0.12 s, the reload 1.0 s
              "sidearm": "pistol", "side_gap": 0.12, "side_dmg": 3.0, "side_mag": 6, "side_reload": 1.0},
    "krampus": {"name": "Krampus", "char": "bob", "hp": 80, "intro": "Krampus Has Come For The Naughty!", "speed": 1.15,
                "model": "krampus.nwx",
                # Dr. Death's pistol (2.5 a shot), shooting ornaments
                "arms": "pistol", "dmg": 2.5, "snd": "ORNSHOT.WAV", "proj": "ORNAPJ.3DO", "kick": 1500},   # (20 Nov, the user: knock-back like Jack Frost's)          # (his own look: christmas\KRAMPUS.NWX/.SPX, fur, horns, a chain, red eyes)
    "nutcracker": {"name": "Nutcracker", "char": "bob", "hp": 90, "intro": "The Nutcracker General Has Arrived!", "speed": 0.95,
                   "model": "nutcrack.nwx",
                   "arms": "rifle", "snd": "CANESHOT.WAV", "proj": "CANEPJ.3DO",
                   # (25 Nov, the user: tougher, but not with Krampus's and Jack Frost's knock-back) three candy canes in a quick burst
                   #  (0.15 s apart), a 1.2 s pause, again; and at 2/3 and 1/3 of his health he calls 3 more toy soldiers each time
                   "gap": 0.15, "mag": 3, "reload": 1.2, "calls": [[0.66, 3], [0.33, 3]], "troops": "Nutcracker", "troop_model": "nutwhite.nwx", "call_banner": "The General Calls His Troops!"},      # a rifle shooting candy canes (20 Nov, the user: never reloads)      # (a toy soldier: christmas\NUTCRACK.NWX/.SPX)
    "jackfrost": {"name": "Jack Frost", "char": "bob", "hp": 110, "intro": "Jack Frost Nips At Your Nose!", "speed": 1.3,
                  "model": "jackfros.nwx",
                  "arms": "rifle", "snd": "SNOWSHOT.WAV", "proj": "SNOWBL.3DO", "proj_speed": 300,
                  "gap": 0.3, "mag": 40, "kick": 1200},   # (23 Nov, the user: 20% less knockback - was 1500)      # (17 Nov: too easy - snowballs three a second, 40 before a reload, and every hit knocks you back)      # a rifle shooting snowballs       # (icy, with an icicle crown: christmas\JACKFROS.NWX/.SPX)
    "gingerbread": {"name": "Gingerbread Man", "char": "bob", "hp": 100, "intro": "The Gingerbread Man Is Hungry!", "speed": 1.1,
                    "model": "gingerbr.nwx",
                    "arms": "dbsgun", "snd": "COOKSHOT.WAV", "proj": "COOKPJ.3DO", "proj_n": 2, "mag": 9999},   # (23 Nov, the user: never reloads)   # a double-barrel: two cookies a shot     # (a giant gingerbread man: christmas\GINGERBR.NWX/.SPX)
}

MISSIONS = [
    {"id": "siege", "n": 1, "title": "Silent Night Siege", "map": "civpow2",
     "brief": "Santa's rogue elves have overrun Buckshotville and hidden the town's presents. Drive them out, find the presents, then beat Krampus.",
     "steps": [
         {"type": "kills", "n": 8, "text": "Drive the elves out of Buckshotville", "elves": 4, "level": "easy"},
         # (20 Nov, the user: no hold step, and not more killing either - step 1 already clears the town) the elves hid three
         #  small piles of the stolen presents round town - never on the main street, never in the warehouse; somewhere else
         #  each time (3 of the "pool", at least 90 ft apart), each pile vanishing when a player gets to it (a still ghost
         #  with the pile's look, GIFTPILE). The pool, [x, z, floor]: upstairs in the west block's building (spiral stairs),
         #  inside the south-east building, two rooms of the east row, the building on the main street's west side (inside),
         #  upstairs in the south-east building (21 Nov: instead of the north-west field - too easy to see), out at the far south-west
         #  edge, the south-west lot, the west block's courtyard
         {"type": "reach", "pool": [[-195.0, -79.0, 17.0], [-10.0, -255.0, 0.0], [-12.0, -125.0, 5.0], [-12.0, -80.0, 5.0],
                                    [-111.0, -175.0, 4.0], [-305.0, -335.0, 0.0], [-15.0, -222.0, 17.0], [-240.0, -300.0, 0.0],
                                    [-200.0, -130.0, 2.0]],
          "pick": 3, "apart": 90, "pile": {"model": "giftpile.nwx", "name": "Present"}, "r": 8,
          "text": "Find the three piles of presents the elves hid round town", "got": "Presents Found!",
          "near": "No presents nearby - keep looking", "far": 50, "elves": 5, "level": "normal", "banner": "Find The Stolen Presents!",
          # then the last goal: the elves piled the rest of the presents in the warehouse - its gate opens from the switch on the upper ledge
          # (dead until the piles are found: MAP_TWEAKS); a player at the switch has the gate opened (a ghost visits "open_at")
          "then": {"at": [-116.5, -38.1], "r": 6, "y_min": 10, "open_at": [-78.13, 0.0, -44.19],
                   "text": "The presents are piled in the warehouse: press the switch on its upper ledge to open the gate",
                   "near": "The switch", "banner": "Open The Warehouse!", "done": "The Warehouse Is Open!",
                   "locked": "The switch won't work until all 3 piles are found"}},
         {"type": "boss", "boss": "krampus", "text": "Defeat Krampus", "elves": 3, "level": "normal"},
     ],
     "win": "Buckshotville Is Free!"},
    # (20 Nov, the user: Mission 2 moves to Sanctuary with Mission 3's old steps - break Mrs. Claus out and escort her - against
    #  the Nutcracker General, the Granary's toy army props spread over Sanctuary, and the dark misty night of the others
    #  instead of the icy look)
    {"id": "jailbreak", "n": 2, "title": "Jailbreak", "map": "town_2p",
     "brief": "The Nutcracker's toy army has locked Mrs. Claus in the Sheriff's office cell. Break her out, take her to the presents at the north end of town for her rifle, fight your way to the sleigh in the south, then beat the Nutcracker General.",
     "hostage": {"name": "Mrs. Claus", "char": "mary", "at": [223.5, 0.25, 372], "hp": 40, "model": "mrsclaus.nwx",
                 # (25 Nov, the user: at the pile of presents she takes a rifle and fires at the toy army, still following you;
                 #  christmas\MRSCLAUR: her look holding it, its firing frames too)
                 "rifle": True, "armed_model": "mrsclaur.nwx"},
     # (17 Nov: in the sheriff's office's single cell - the jail building's cells were too tight for her to get out of;
     #  christmas\MRSCLAUS.NWX/.SPX: a red velvet dress with white fur, an apron, white hair in a bun, spectacles)
     "steps": [
         {"type": "kills", "n": 10, "text": "Clear the toy army out of Sanctuary (Mrs. Claus's cell stays locked till then)", "elves": 5, "level": "normal"},
         # (Mrs. Claus is put in the jail when this step starts)
         # (17 Nov: the sleigh and reindeer wait in the field south of town, by the canyon wall)
         # (25 Nov, the user: first to a pile of presents on the far side of town from the sleigh - the north end - where she
         #  takes a rifle and fights beside you, then all the way back south to the sleigh)
         {"type": "rescue", "to": [225, 122], "r": 22, "text": "Her cell is open: find Mrs. Claus in the Sheriff's office cell", "unlock": True,
          "via": {"at": [240, 470], "r": 14, "text": "Take Mrs. Claus to the pile of presents at the north end of town",
                  "banner": "Mrs. Claus Has A Rifle!"},   # (the big pile of presents there: christmas\mission_props.json, PRESPILE as in Mission 1's warehouse)
          "text2": "Mrs. Claus is armed: get her to the reindeer sleigh in the field south of town",
          "elves": 5, "level": "normal", "banner": "Break Mrs. Claus Out!", "respawn": 10},
         {"type": "boss", "boss": "nutcracker", "text": "Defeat the Nutcracker General", "elves": 3, "level": "hard"},
     ],
     "win": "The Nutcracker General Is Beaten!"},
    # (20 Nov, the user: Mission 3 is Jack Frost's, on Orleans with its pools frozen over (icewater.py: ice with a hole in each),
    #  snowmen on the ice, the dark misty night of the others; the steps are new)
    {"id": "frost", "n": 3, "title": "Thin Ice", "map": "orleans",
     "brief": "Jack Frost has frozen Orleans solid and set his snowmen on the ice. Smash them, beat his ice clones, then put the real Jack Frost on ice.",
     "steps": [
         {"type": "kills", "n": 10, "text": "Defeat Jack Frost's henchmen guarding the frozen town", "elves": 5, "level": "normal"},
         # (20 Nov, the user: no hold step here - Jack Frost's clones: they fight like him (his snowball rifle, his knock-back),
         #  with less health than an ordinary enemy; kill them all and the real one comes. Later the same day: everything else
         #  leaves for them, all 4 at once, each its own colour, a killed one leaves the game; Jack Frost brings 3 snowmen and
         #  2 exploding presents)
         {"type": "clones", "boss": "jackfrost", "n": 4, "hp": 12, "kick": 720,   # (23 Nov: about 60% of Jack Frost's 1200)
          "name": "Frost Clone", "clear": True, "elves": 0,
          "models": ["frostred.nwx", "frostgrn.nwx", "frostwht.nwx", "frostblk.nwx"],      # (20 Nov, the user: red, green, white, black)
          "text": "Kill Jack Frost's clones", "level": "hard", "banner": "Jack Frost's Clones Attack!"},
         {"type": "boss", "boss": "jackfrost", "text": "Defeat Jack Frost", "elves": 3, "enemy": "Snowman", "presents": 2, "level": "hard"},
     ],
     "win": "Orleans Thaws Out!"},
    # (25 Nov, the user: Mission 4 moves from Thud Tower to Bunkers - hold the small yard on the ground where the crates are
    #  (the two crates you jump up to the ledge from), north of the middle of the map)
    {"id": "showdown", "n": 4, "title": "Showdown At The Bunkers", "map": "lilbatl",
     "brief": "Santa's sleigh is coming in over the Bunkers. Hold the ledge over the crate yard where he means to land, beat the Gingerbread Man, then face Santa.",
     "steps": [
         # (the yard: the open ground at -2, walled by the 13-high ledge, the two crates at its north end - on a crate counts too,
         #  up on the ledge doesn't. Was Thud Tower's walkway between the pits: [-646, 36, -639.4, 86], y 0.)
         # (25 Nov, the user: the yard was too small to hold with that many gingerbread men - up on the ledge instead) the wide west
         #  ledge over the yard, 13 up (sector 135): was the yard itself, [-478, -800, -450, -760] at -2
         {"type": "hold", "box": [-511, -793, -494, -766], "y": 13, "secs": 60,
          "text": "Hold the ledge over the crate yard where Santa means to land: stay between the red lines",
          "elves": 6, "level": "hard", "banner": "Hold The Ledge!"},
         # (25 Nov, the user: when the Gingerbread Man comes, everyone else leaves - just him and 4 gingerbread men)
         {"type": "boss", "boss": "gingerbread", "text": "Defeat the Gingerbread Man", "elves": 4, "level": "hard",
          "clear": True, "enemy": "Gingerbread"},
         {"type": "boss", "boss": "santa", "text": "Defeat Santa: watch out for his exploding presents!", "elves": 0, "level": "hard"},
     ],
     "win": "Christmas Is Saved!"},
]
BY_ID = {m["id"]: m for m in MISSIONS}

# Map changes for a mission's game only (darkitems.patch(mission=True) writes them as loose files and takes them away after):
#   lock_doors  these INF doors open only when a player (a ghost) walks INTO the door's own sector - "use" does nothing - and
#               then stay open (TERMINATE). Nobody can walk into shut bars, so they stay locked until a mission ghost is sent
#               through them (horde.py: the hostage's GHOST_UNLOCK, when her step starts).
#   no_enter    sectors the enemies may not walk or hop into (nav GHOST_NO_ENTER; they may still leave them)
#   no_starts   the map's spawn points (STARTPOS) at these x, z taken out (none inside the locked cells)
MAP_TWEAKS = {
    # (20 Nov: the two spawn points inside the stacked building on Orleans' frozen pool - ghosts put there ended up on its roof
    #  and kept going up and down instead of fighting)
    "orleans": {"no_starts": [[66.5, 220.06], [65.5, 196.55]],
                # (20 Nov, the user: enemies still got onto the big building on the ice and stayed there: its upper floor, roof,
                #  window ledges and the top of its stairs can't be entered - anyone already up there walks back down)
                "no_enter": [138, 157, 152, 83, 39, 37, 50, 68, 74, 77, 154, 155]},
    # (20 Nov, the user: Mission 1's warehouse - its gate shut, its switch on the upper ledge dead until the three trees are found;
    #  then a player at the switch has the gate opened: a ghost steps into the gate's sector, which runs it, horde.py "reach" step)
    "civpow2": {"lock_doors": ["GATE"], "dead_lines": ["SWITCH"],     # (dead until the 3 piles are found)
                # (20 Nov, the user: enemies got up on the long porch roof by the "Through to San Francisco" building and stayed
                #  there all game) the high ledges only a mission enemy's big hop reaches - no player can - are off limits: the
                #  porch roof (160), the long wall tops (161, 205), the rooftops and ledges 12-18 high a ghost hopped onto from the
                #  street; anyone already up there walks back down
                #  (21 Nov: still up there - the long balconies over the main street's porches, 182 east and 185 west, and the
                #  walkway 181 joining 185 to the west block, with their doorways 14, 18, 19, 21: stairs lead up, but no enemy
                #  goes there now either)
                "no_enter": [160, 161, 205, 187, 136, 15, 20, 26, 38, 118, 125, 115, 123, 138, 180, 97, 71, 85, 28,
                             182, 185, 181, 14, 18, 19, 21]},
    # (23 Nov, the user: every door in Mission 2's map gone except Mrs. Claus's cell) the courthouse's double doors and the
    # jail building's four cell doors start open and never move; only her cell (JAILDOOR01, the Sheriff's office) is locked.
    # (23 Nov, the user: her cell never opened) the door's centre is one of its bars - a hole in the door's sector - so the
    # hostage standing there never "entered" it: the point to step into is between two bars
    "town_2p": {"lock_doors": ["JAILDOOR01"],
                "open_doors": ["COURTHOUSEDOOR01", "COURTHOUSEDOOR02", "JAILDOOR02", "JAILDOOR03", "JAILDOOR04", "JAILDOOR05"],
                "door_centres": [[221.95, 364.6]],
                "no_starts": [[251.99, 366.13], [250.75, 329.5]],
                # (23 Nov, the user: enemies got stuck in the jail cell doors) the five cell doors (their slab sectors) are off
                # limits to the enemies - they never go into a cell; Mrs. Claus (GHOST_NO_ENTER "") still walks out of hers
                "no_enter": [38, 39, 40, 62, 64]},
}


def get(mid):
    return BY_ID.get(str(mid).lower()) or next((m for m in MISSIONS if str(m["n"]) == str(mid)), None)


def inside(pos, at, r, y=None):
    """pos (x, y, z) inside the circle at (x, z) with radius r (and within 8 of the height y, when given)"""
    import math
    if pos is None:
        return False
    if y is not None and abs(pos[1] - y) > 8.0:
        return False
    return math.hypot(pos[0] - at[0], pos[2] - at[1]) <= r


def in_box(pos, box, y=None):
    """pos (x, y, z) inside the rectangle box (x0, z0, x1, z1) (and within 8 of the height y, when given). y can be a
    pair [y at x0, y at x1] for a ramp: the height is then read off a straight line across the box."""
    if pos is None:
        return False
    if y is not None:
        if isinstance(y, (list, tuple)):
            t = (pos[0] - box[0]) / ((box[2] - box[0]) or 1.0)
            y = y[0] + (y[1] - y[0]) * min(1.0, max(0.0, t))
        if abs(pos[1] - y) > 8.0:
            return False
    return box[0] <= pos[0] <= box[2] and box[1] <= pos[2] <= box[3]


def box_distance(pos, box):
    import math
    dx = max(box[0] - pos[0], 0, pos[0] - box[2]); dz = max(box[1] - pos[2], 0, pos[2] - box[3])
    return math.hypot(dx, dz)


def unlocked(beaten):
    """the missions that can be played: Mission 1, and each one after a mission that has been beaten"""
    ok = []
    for m in MISSIONS:
        prev = next((x for x in MISSIONS if x["n"] == m["n"] - 1), None)
        if prev is None or prev["id"] in beaten or m["id"] in beaten:
            ok.append(m["id"])
    return ok


def label(m):
    return f"Mission {m['n']}: {m['title']}"
