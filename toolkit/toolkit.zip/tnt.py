"""TNT: how a thrown stick flies, and where to look to land one on a target.

From the exe (GOG RVAs; see Bots.md, "TNT"):
- Secondary fire lights the stick (Weapon_TNTHandler 0xda050, chor event at 0xda389). The projectile is spawned
  then and there, and its fuse (pdynam.itm LIFE, 4500 ms) runs from that moment (0xce490), not from the throw.
- Primary fire winds up (weapon action 1). Pressed during the lighting animation, it's queued and starts as soon as
  that ends (the TNT is a type-2 weapon, 0xdd150); letting go of secondary only cancels secondary's own request
  (0xdd46d), and the lighting (0xda389) doesn't care about it either. When the wind-up animation ends the weapon
  waits in action 5 and notes the time. Letting go throws, with power = clamp(seconds held in action 5, 0.5, 1.0)
  (0xda0a7). Under water the power is halved (0xdf004), but a stick can't be lit there anyway.
- The throw (0xdeea0 -> 0xcfe70): speed = power x RATE_1 (idynam.itm: 60), at least 10. Heading = the view heading
  (plus one auto-aim pass on the heading only). Pitch = view pitch + THROW_PITCH (35 deg), at most 60 deg. The
  thrower's own velocity (actor +0xB4..) is added. It starts at the thrower's x, z and 0.85 of its height.
- The blast (pdynam.itm: RADIUS 50, DAMAGE 12, 0xd12c0): full damage within 12.5, then ((50 - d) / 37.5)^2 of it,
  zero at 50, and only through a line-of-sight check. The thrower isn't spared (players have actor flag 0x10).
- It bounces (ALLOW_BOUNCE 1), so it can roll on after landing; the brain times the throw so the stick goes off
  soon after it lands.

Gravity isn't in the code we read: sectors say GRAVITY -60, so that's the default, and the brain measures it from
its own sticks in flight (Brain.watch_stick) and keeps the result in state/tnt.json.
"""
import json
import math
from pathlib import Path

FUSE = 4.5                 # seconds from lighting to the blast
SPEED = 60.0               # throw speed at full power (RATE_1)
MIN_SPEED = 10.0
THROW_PITCH = 35.0         # degrees added to the view pitch
MAX_LAUNCH = 60.0          # the launch pitch is capped here
LAUNCH_HEIGHT = 0.85       # of the thrower's height
FULL_POWER = 1.0           # seconds held after the wind-up for full power
MIN_POWER = 0.5
RADIUS = 50.0
FULL_RADIUS = RADIUS / 4
DAMAGE = 12.0
GRAVITY = 60.0             # units/s^2, from the sectors' GRAVITY -60; measured live when possible
STATE = Path(__file__).resolve().parent / "state" / "tnt.json"


def power(held):
    """Throw power after holding the wound-up throw for `held` seconds."""
    return min(1.0, max(MIN_POWER, held))


def damage(d):
    """Blast damage at distance d (before armour, and maybe halved: the hit is sent as a graze, unverified)."""
    if d < FULL_RADIUS:
        return DAMAGE
    if d >= RADIUS:
        return 0.0
    return DAMAGE * ((RADIUS - d) / (0.75 * RADIUS)) ** 2


def solve(origin, self_vel, goal, pw, g=GRAVITY, ceiling=None, flattest=True, descending=True, min_launch=-30.0):
    """Where to look to land a stick thrown with power `pw` at `goal`.

    origin: our {x, y, z} feet position plus "height"; self_vel: (vx, vy, vz), added to the throw; goal: the point
    to land on ({x, y, z}, y = the floor there). Returns {yaw, view_pitch, launch, flight, apex, x, z} (angles in
    degrees, yaw 0 = +z, increasing toward +x) or None when it's out of reach, or only reachable over the ceiling.
    With `flattest`, the flattest throw that gets there (shortest flight), else the highest. Without `descending`
    the stick may still be rising when it gets there (a point in the air to go off at, not a floor to land on).
    Launch angles start at `min_launch`."""
    speed = max(MIN_SPEED, SPEED * pw)
    x0, z0 = origin["x"], origin["z"]
    y0 = origin["y"] + LAUNCH_HEIGHT * origin.get("height", 6.0)
    dx, dz = goal["x"] - x0, goal["z"] - z0
    dist = math.hypot(dx, dz)
    if dist < 0.5:
        return None
    ux, uz = dx / dist, dz / dist                   # toward the goal
    rx, rz = uz, -ux                                # to its right (heading + 90 degrees)
    wx, wy, wz = self_vel
    w_par, w_perp = wx * ux + wz * uz, wx * rx + wz * rz

    def height_error(theta):
        """(height above the goal when we're over it, descending?, flight time, side share, vy0) or None."""
        s = speed * math.cos(math.radians(theta))
        if abs(w_perp) >= s:
            return None
        side = -w_perp / s                          # aim off to the side to cancel our sideways drift
        k = s * math.sqrt(1 - side * side) + w_par  # speed toward the goal
        if k <= 0.5:
            return None
        t = dist / k
        vy0 = speed * math.sin(math.radians(theta)) + wy
        return y0 + vy0 * t - g * t * t / 2 - goal["y"], vy0 - g * t <= 0, t, side, vy0

    # Scan launch angles: the stick is level with the goal, on the way down, where the height error crosses zero.
    found = []
    step = 0.5
    theta = min_launch
    prev = height_error(theta)
    while theta < MAX_LAUNCH:
        nxt_theta = min(MAX_LAUNCH, theta + step)
        nxt = height_error(nxt_theta)
        if prev and nxt and (prev[0] < 0) != (nxt[0] < 0):
            lo, hi = theta, nxt_theta
            for _ in range(20):
                mid = (lo + hi) / 2
                m = height_error(mid)
                if m is None:
                    break
                if (m[0] < 0) == (prev[0] < 0):
                    lo = mid
                else:
                    hi = mid
            r = height_error((lo + hi) / 2)
            if r and (r[1] or not descending):
                found.append(((lo + hi) / 2, r))
        prev, theta = nxt, nxt_theta
    for theta, (_, _, t, side, vy0) in (found if flattest else reversed(found)):
        apex = y0 + vy0 * vy0 / (2 * g) if vy0 > 0 else y0
        if ceiling is not None and apex > ceiling - 0.5:
            continue
        heading = math.degrees(math.atan2(ux, uz) + math.atan2(side, math.sqrt(1 - side * side)))
        return {"yaw": heading % 360, "view_pitch": theta - THROW_PITCH, "launch": theta, "flight": t, "apex": apex,
                "x": goal["x"], "z": goal["z"]}
    return None


def arc(origin, self_vel, sol, pw, n=12, g=GRAVITY):
    """Points (x, y, z) along a solution's flight, from just after the throw to just before landing."""
    speed = max(MIN_SPEED, SPEED * pw)
    th, yw = math.radians(sol["launch"]), math.radians(sol["yaw"])
    vx = speed * math.cos(th) * math.sin(yw) + self_vel[0]
    vy = speed * math.sin(th) + self_vel[1]
    vz = speed * math.cos(th) * math.cos(yw) + self_vel[2]
    x0, z0 = origin["x"], origin["z"]
    y0 = origin["y"] + LAUNCH_HEIGHT * origin.get("height", 6.0)
    for k in range(1, n - 1):
        t = sol["flight"] * k / n
        yield x0 + vx * t, y0 + vy * t - g * t * t / 2, z0 + vz * t


def reach(origin, self_vel, heading, pw, floor_y, g=GRAVITY, ceiling=None):
    """How far (flat) a stick goes at best, thrown along `heading` (degrees) with this power: the launch angle that
    carries farthest while staying under the ceiling. Returns (distance, launch angle)."""
    speed = max(MIN_SPEED, SPEED * pw)
    y0 = origin["y"] + LAUNCH_HEIGHT * origin.get("height", 6.0)
    hx, hz = math.sin(math.radians(heading)), math.cos(math.radians(heading))
    w_par = self_vel[0] * hx + self_vel[2] * hz
    best = (0.0, 0.0)
    for theta in range(-20, int(MAX_LAUNCH) + 1):
        vy0 = speed * math.sin(math.radians(theta)) + self_vel[1]
        if ceiling is not None and vy0 > 0 and y0 + vy0 * vy0 / (2 * g) > ceiling - 0.5:
            continue
        disc = vy0 * vy0 + 2 * g * (y0 - floor_y)
        if disc < 0:
            continue
        t = (vy0 + math.sqrt(disc)) / g
        d = (speed * math.cos(math.radians(theta)) + w_par) * t
        if d > best[0]:
            best = (d, float(theta))
    return best


def load_gravity():
    try:
        g = json.loads(STATE.read_text())["gravity"]
        return g if 10.0 < g < 300.0 else GRAVITY
    except (OSError, ValueError, KeyError, TypeError):
        return GRAVITY


def save_gravity(g):
    try:
        STATE.parent.mkdir(exist_ok=True)
        STATE.write_text(json.dumps({"gravity": round(g, 2)}))
    except OSError:
        pass
