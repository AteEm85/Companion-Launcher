@echo off
cd /d "%~dp0"
del gungame_done.txt >nul 2>&1
set BOT_GUNGAME=1
set BOT_GG_RANDOM=1
set BOT_GG_LAUNCH=test3
set PATHCHECK_IDLE_HOST=1
set PATHCHECK_WINDOWS=hidden
set "PATHCHECK_TAGS=lv_normal|lv_normal|lv_normal"
".venv\Scripts\python.exe" -u pathcheck.py --keep --minutes 10 --maps civpow2 > gungame_run.txt 2>&1
echo finished > gungame_done.txt
