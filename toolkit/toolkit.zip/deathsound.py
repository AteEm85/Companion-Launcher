"""A death sound in Survival: python deathsound.py <run id> <horde.py pid> <map>
Whenever the game's kill feed (read from the in-game observers' logs, horde_logs\\<map>_hd2.log / _hd3.log) reports that
someone died, sounds\\horde_death.wav plays, quietly. Stops when the match ends or horde.py does."""
import re
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

DEATH = [re.compile(p) for p in (
    r"^(?:.+) killed (.+)!$", r"^(?:.+) blew up (.+)!$", r"^(.+) died from a fall!$", r"^(.+) self-destructed!$",
    r"^(.+) committed suicide!$", r"^(.+) drowned!$", r"^(.+) got crushed!$", r"^(.+) got telefragged!$",
    r"^(.+) Got shot to death!$", r"^(.+) died!$", r"^(.+) blew up!$", r"^(?:.+) blew you up!$")]
FEED = re.compile(r"^FMT: G (.+)$")


def dying(text):
    return any(p.match(text) for p in DEATH)


def main():
    run = sys.argv[1] if len(sys.argv) > 1 else ""
    parent = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    level = sys.argv[3] if len(sys.argv) > 3 else ""
    import ambient
    import winsound
    wav = HERE / "sounds" / "horde_death.wav"
    if not wav.exists():
        return
    st = HERE / "state"
    stop, over, human = st / f"stop_{run}", st / f"music_stop_{run}", st / f"human_{run}.flag"
    logs = [HERE / "horde_logs" / f"{level}_{nm}.log" for nm in ("hd2", "hd3")]

    def done():
        return stop.exists() or over.exists() or (parent and not ambient.alive(parent))
    while not human.exists():
        if done():
            return
        time.sleep(0.5)
    pos = {}
    for lg in logs:                                    # only what happens from now on
        try:
            pos[lg] = lg.stat().st_size
        except OSError:
            pos[lg] = 0
    recent, last_play = {}, 0.0
    while not done():
        now = time.time()
        for lg in logs:
            try:
                size = lg.stat().st_size
                if size < pos[lg]:
                    pos[lg] = 0
                if size == pos[lg]:
                    continue
                with open(lg, "rb") as f:
                    f.seek(pos[lg])
                    chunk = f.read(size - pos[lg])
                pos[lg] = size
            except OSError:
                continue
            for line in chunk.decode("utf-8", "replace").splitlines():
                m = FEED.match(line.strip())
                if not m or not dying(m.group(1)):
                    continue
                text = m.group(1)
                if now - recent.get(text, 0.0) < 1.5:  # both observers see the same line
                    continue
                recent[text] = now
                if now - last_play > 0.3:
                    last_play = now
                    winsound.PlaySound(str(wav), winsound.SND_FILENAME | winsound.SND_ASYNC)
        recent = {k: v for k, v in recent.items() if now - v < 5.0}
        time.sleep(0.2)
    winsound.PlaySound(None, winsound.SND_PURGE)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
