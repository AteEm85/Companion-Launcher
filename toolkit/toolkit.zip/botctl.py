"""Drive one Outlaws Remastered instance by injecting SDL3 input (Frida). LAN games only.

    .\\bots sanchez mary bob --fight     # a tab per bot (Windows Terminal; --windows: a console each):
                                         # start (or find) its game copy, join, fight
    .\\bots sanchez mary bob --host --fight   # sanchez hosts a LAN lobby, mary and bob join it; sanchez stands
                                         # still until both are in (--wait-for N, --wait-max s, default 120)
    .\\bots sanchez mary --host --map fort --mode ctf --timelimit 15 --fight   # host settings: --map, --mode
                                         # (dm team ctf tag chicken doc), --timelimit, --fraglimit, --friendly-fire
    (A bot named after a character plays that character: sanchez james twofeathers drdeath bob mary.)
    .\\bots sanchez:red mary:blue bob:blue --host --mode ctf --fight   # teams; without :red/:blue they
                                         # alternate red, blue, red... With fight, bots press Join (Red/Blue)
                                         # in the lobby themselves.
    .\\bots Dennis:james:red Earl:mary:blue --host --mode ctf --fight   # name:character:team, any name;
                                         # the character and team tags can come in either order, or be left out
    .\\bots =T4H_WaRRioR:doc:red:sapper bob:sniper mary:brawler --fight   # a behaviour tag as well: sapper
                                         # (TNT first), sniper (rifle), brawler (knife, else fists, no guns),
                                         # pistolero (pistol), default (the standard bot)
    .\\bots sanchez:red mary:red bob:blue --host --mode ctf --fight --bench-turn 5   # in team games a bot on
                                         # the bigger team sits out (stays dead) to keep the teams even, humans
                                         # counted too; teammates take turns every --bench-turn minutes
                                         # (default 3, 0 = no turns). --no-bench turns it off.
    .\\bots sanchez                      # one bot in this console
    .\\bots "drdeath=Bot Dr. Death"      # name=display name; the default display name is "Bot Sanchez" etc.
    .\\bots =T4H_WaRRioR:doc:red =Noobke:james:blue --host --mode ctf --fight   # display name only: the
                                         # profile is named after it; tags may follow the display name too
    .\\bots sanchez --join 192.168.1.10  # join another host (default 127.0.0.1); --no-join stays in the menu
    .\\bots --list                       # running instances
    .\\bots --pid 1234                   # attach to a copy by pid
    .\\bots --pid 1234 --no-fake-focus   # only for a copy you play yourself
(bots.cmd runs this file with the .venv next to it.) A bot's game copy keeps running after 'quit', so running the
same command again re-attaches to it with fresh code; 'close' also ends the game copy.

Console commands (keys use the game's default binds: w/a/s/d, space, lctrl, mouse_left, ...):
    hold <key> <ms>      hold a key or mouse button for ms        e.g. hold w 1000
    tap <key>            press and release (100 ms)                e.g. tap space
    look <dx> [dy]       smooth turn: motion events of at most lookstep per frame   e.g. look 300
    lookstep <n>         turn speed for look, in mouse units per frame (default 15)
    motion <dx> [dy]     instant turn: one injected mouse-motion event
    fire [ms]            hold mouse_left (default 300 ms)
    square               walk a square: 4 x (forward 1 s, fire, turn 90 degrees)
    players              list player actors: position, heading, distance and bearing from us
    inv                  our inventory array as it is in memory (index, name, count), carried items, badge
    calibrate            measure heading units per mouse unit (depends on mouse sensitivity)
    turn <deg>           turn by degrees (positive = toward +x from +z, i.e. clockwise on the map)
    face [n]             turn to face player n from 'players' (default: nearest other player)
    fight [s]            run the bot brain (chase, aim, shoot) for s seconds, or until Ctrl+C
    focus on|off         fake window focus so an unfocused copy takes input (default on)
    maxplayers [n]       show the lobby size, or set it (like 'kexmultiplayer maxplayers n' in the game console)
    rehost [map] [mode] [minutes] [kills]   at the main menu after a match: host the next one in this copy
    rejoin [address]     at the main menu after a match: join the LAN game again (default: the --join address)
    stats                hook counters, seen event types, first real key event bytes
    quit                 detach; the game copy keeps running
    close                detach and end the game copy
"""
import argparse
import ctypes
import json
import math
import os
import re
import shutil
import subprocess
import sys
import threading
import types
import time
from ctypes import wintypes
from pathlib import Path

import frida

HERE = Path(__file__).resolve().parent
GAME_DIR = HERE.parent
GAME_EXE = GAME_DIR / "OutlawsAHOM.exe"
WT_WINDOW = "outlaws-bots"         # Windows Terminal window that gets one tab per bot
# Seconds from the host's window appearing until the others start, and between one joiner and the next. Joins get
# one try at startup, so too small a value leaves bots in the menu. Override with the environment variables
# BOTCTL_LOBBY_WAIT and BOTCTL_STAGGER (for example set BOTCTL_STAGGER=3 before launching) if bots miss the game.
HOST_LOBBY_WAIT = float(os.environ.get("BOTCTL_LOBBY_WAIT", 7.0))
JOIN_STAGGER = float(os.environ.get("BOTCTL_STAGGER", 2.0))
CMDLINE_MAX_PLAYERS = 8           # -maxplayers is clamped to 2-8 (0x23B9C9); more goes through the agent
PROFILES = HERE / "profiles"     # one -userpath per bot, so no bot ever runs on your own config and binds
sys.path.insert(0, str(HERE))      # find brain.py next to this file, however we were started
from bench import Bench  # noqa: E402
from brain import BEHAVIOURS, DIFFICULTY, DIFFICULTY_ALIASES, Brain, behaviour_skill  # noqa: E402
SCANCODE_MASK = 1 << 30

# SDL3 scancodes (SDL_scancode.h) and keycodes (SDL_keycode.h)
KEYS = {chr(c): (4 + c - ord("a"), c) for c in range(ord("a"), ord("z") + 1)}
KEYS.update({str(n): (30 + (n - 1) % 10, ord(str(n))) for n in range(10)})
KEYS.update({
    "space": (44, 0x20), "tab": (43, 0x09), "return": (40, 0x0D), "escape": (41, 0x1B),
    "lctrl": (224, SCANCODE_MASK | 224), "lshift": (225, SCANCODE_MASK | 225), "lalt": (226, SCANCODE_MASK | 226),
    "right": (79, SCANCODE_MASK | 79), "left": (80, SCANCODE_MASK | 80),
    "down": (81, SCANCODE_MASK | 81), "up": (82, SCANCODE_MASK | 82),
})
KEYS["backquote"] = (53, 0x60)          # with ctrl+alt it toggles the game console
KEYS.update({f"f{n}": (57 + n, SCANCODE_MASK | (57 + n)) for n in range(1, 11)})   # F1-F10: the quick taunts
BUTTONS = {"mouse_left": 1, "mouse_middle": 2, "mouse_right": 3}

# Headings are 14-bit: 16384 = 360 degrees, 0 faces +z, increasing toward +x.
FULL_TURN = 16384


def wrap(delta):
    """Shortest signed heading difference, in -8192..8191."""
    return (delta + FULL_TURN // 2) % FULL_TURN - FULL_TURN // 2


def bearing(src, dst):
    """Heading (14-bit) that points from src to dst."""
    return round(math.atan2(dst["x"] - src["x"], dst["z"] - src["z"]) / (2 * math.pi) * FULL_TURN) % FULL_TURN


class Bot:
    def __init__(self, script):
        self.api = script.exports_sync
        self.held = set()
        self.lock = threading.Lock()
        self.units_per_mouse = 3.0   # heading units per mouse unit at the default sensitivity; see calibrate()
        self.badges = []
        self.items = []
        self.marshall_law = True     # bots avoid the badge and the invisibility potion (--no-marshall-law: they take them)
        self.level_key = None
        self.game = None
        self.lobby = None
        self.all_players = []
        self.explosives = []
        self.lit = None
        self.self_state = None       # {health, inventory} from the last world(), even while dead

    def press(self, name, down):
        with self.lock:
            if name in BUTTONS:
                self.api.button(BUTTONS[name], down)
            elif name in KEYS:
                self.api.key(*KEYS[name], down)
            else:
                raise ValueError(f"unknown key {name!r}")
            (self.held.add if down else self.held.discard)(name)

    def type_text(self, text):
        """Text as typed (an SDL text input event), for the game console."""
        with self.lock:
            self.api.type_text(text)

    def hold(self, name, ms):
        self.press(name, True)
        time.sleep(ms / 1000)
        self.press(name, False)

    def close(self):
        """Let go of everything, give focus back, and remove all hooks. Call before detaching: unloading
        the agent while hooks are live crashed the game (a game thread can be inside our SDL_PollEvent
        replacement at that moment)."""
        try:
            self.release_all()
            self.api.set_fake_focus(False)   # queues FOCUS_LOST, so the copy goes back to its real state
            time.sleep(0.3)                  # let the game poll the release and focus events
            self.api.shutdown()
            time.sleep(0.5)                  # let any game thread still inside a hook leave it
        except frida.InvalidOperationError:
            pass                             # game already gone

    def release_all(self):
        for name in list(self.held):
            self.press(name, False)
        self.api.release()

    def host_next(self, level=None, mode=None, timelimit=None, fraglimit=None):
        """At the main menu after a match: set the next match's cvars and host a new LAN lobby in this same copy.
        mode is the game-mode number (MODES); None leaves a setting as it was. The outcome is printed by the agent."""
        for name, value in (("mp_levelName", level), ("mp_gamemode", mode), ("mp_timeToEnd", timelimit),
                            ("mp_killsToEnd", fraglimit)):
            if value is not None and not self.api.set_cvar(name, str(value)):
                raise RuntimeError(f"could not set {name}")
        return self.api.host_lobby()

    def join_next(self, address="127.0.0.1"):
        """At the main menu after a match: join the LAN game at address, like -join does at startup."""
        return self.api.join_lobby(address)

    def players(self):
        """(me, others sorted by distance). Raises RuntimeError when we have no live player actor,
        e.g. while dead; self.self_state still holds our health and inventory then."""
        w = self.api.world()
        self.self_state = w.get("self")
        self.lobby = w.get("lobby")         # {state, pick, mode}: state 8 = waiting in the lobby
        self.all_players = w.get("players") or []   # every live player actor, us included (also while dead)
        if not w["ok"]:
            raise RuntimeError(w["reason"])
        badges, items = w.get("badges", []), w.get("items", [])
        if self.marshall_law:
            # Marshall Law: the badge and the invisible cream (GPOTION) are to be avoided, never picked up.
            self.badges = badges + [i for i in items if "POTION" in i["name"]]
            self.items = [i for i in items if not "POTION" in i["name"]]
        else:
            self.badges = []                  # nothing to avoid: they are ordinary items (items.value)
            self.items = items + badges
        self.explosives = w.get("explosives", [])   # lit and thrown TNT sticks: {addr, x, y, z, vx, vy, vz, fuseAt}
        self.lit = w.get("lit")             # the stick lit in our hand, or None
        self.level_key = w.get("level")     # the game's level pointer: changes when the map changes
        self.game = w.get("game")           # {mode, teamDamage, ctf: {red/blue: {flag, base}} or None}
        me = next((p for p in w["players"] if p["local"]), None)
        if me is None:
            raise RuntimeError("no live player actor (dead?)")
        others = [p for p in w["players"] if not p["local"]]
        others.sort(key=lambda p: math.hypot(p["x"] - me["x"], p["z"] - me["z"]))
        return me, others

    def wait_turned(self, timeout=3.0):
        """Wait until the pending look has been sent, plus a few frames for the game to apply it."""
        end = time.time() + timeout
        while time.time() < end:
            look = self.api.stats()["pendingLook"]
            if look["dx"] == 0 and look["dy"] == 0:
                break
            time.sleep(0.02)
        time.sleep(0.1)

    def turn_units(self, delta):
        self.api.look(delta / self.units_per_mouse, 0)
        self.wait_turned()

    def calibrate(self, mouse=300):
        before = self.players()[0]["yaw"]
        self.api.look(mouse, 0)
        self.wait_turned()
        after = self.players()[0]["yaw"]
        moved = wrap(after - before)
        if moved == 0:
            raise RuntimeError("heading didn't change; is the bot copy in a match and alive?")
        self.units_per_mouse = moved / mouse
        self.turn_units(-moved)          # turn back
        return self.units_per_mouse

    def face(self, target):
        me, _ = self.players()
        self.turn_units(wrap(bearing(me, target) - me["yaw"]))

    def square(self):
        for _ in range(4):
            self.hold("w", 1000)
            self.hold("mouse_left", 300)
            self.turn_units(FULL_TURN // 4)


def list_instances(device):
    procs = [p for p in device.enumerate_processes() if p.name.lower() == "outlawsahom.exe"]
    for p in procs:
        cmd = command_line(p.pid)
        bot = next((d.name for d in PROFILES.glob("*") if started_for(cmd, d.name)), None)
        print(p.pid, p.name, f"(bot {bot})" if bot else "")
    return procs


# -- launching bot copies -----------------------------------------------------------------------------
_k32 = ctypes.WinDLL("kernel32", use_last_error=True)
_k32.OpenProcess.restype = wintypes.HANDLE
_k32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
_k32.CloseHandle.argtypes = (wintypes.HANDLE,)
_ntdll = ctypes.WinDLL("ntdll")
_ntdll.NtQueryInformationProcess.argtypes = (wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.ULONG,
                                             ctypes.POINTER(wintypes.ULONG))
_user32 = ctypes.WinDLL("user32")
_WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
_user32.EnumWindows.argtypes = (_WNDENUMPROC, wintypes.LPARAM)
_user32.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
_user32.IsWindowVisible.argtypes = (wintypes.HWND,)


def command_line(pid):
    """A process's command line (ProcessCommandLineInformation), or None if we can't read it."""
    handle = _k32.OpenProcess(0x1000, False, pid)            # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        return None
    try:
        buf, size = ctypes.create_string_buffer(0x8000), wintypes.ULONG()
        if _ntdll.NtQueryInformationProcess(handle, 60, buf, len(buf), ctypes.byref(size)) != 0:
            return None
        length = ctypes.c_ushort.from_buffer(buf).value          # UNICODE_STRING {Length, MaximumLength, Buffer}
        return ctypes.wstring_at(ctypes.c_void_p.from_buffer(buf, 8).value, length // 2)
    finally:
        _k32.CloseHandle(handle)


def has_window(pid):
    found = []
    def check(hwnd, _):
        owner = wintypes.DWORD()
        _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if owner.value == pid and _user32.IsWindowVisible(hwnd):
            found.append(hwnd)
            return False
        return True
    _user32.EnumWindows(_WNDENUMPROC(check), 0)
    return bool(found)


def started_for(cmd, name):
    """Whether a game command line has this bot's profile as -userpath."""
    cmd, path = (cmd or "").lower(), str(PROFILES / name).lower()
    at = cmd.find(path)
    return at >= 0 and cmd[at + len(path):at + len(path) + 1] in ('"', " ", "")


def find_bot_copy(device, name):
    """pid of a running game copy started for this bot (recognised by its -userpath), or None."""
    for p in device.enumerate_processes():
        if p.name.lower() == "outlawsahom.exe" and started_for(command_line(p.pid), name):
            return p.pid
    return None


# The keys the brain presses are the game's default binds, so every bot copy's config gets exactly these binds
# before it starts (a profile can pick up other binds, e.g. a player's own: mouse_left = BIG_FIRE and the like).
DEFAULT_BINDS = '''unbindall
bind tab "KEY_ORD_MAP"
bind space "KEY_ORD_JUMP"
bind quote "KEY_ORD_MAP_LAYER_UP"
bind minus "KEY_ORD_MAP_ZOOM_OUT"
bind period "KEY_ORD_MAP_LAYER_ALL"
bind 0 "KEY_ORD_DISARM"
bind 1 "KEY_ORD_WEAPON_1"
bind 2 "KEY_ORD_WEAPON_2"
bind 3 "KEY_ORD_WEAPON_3"
bind 4 "KEY_ORD_WEAPON_4"
bind 5 "KEY_ORD_WEAPON_5"
bind 6 "KEY_ORD_WEAPON_6"
bind 7 "KEY_ORD_WEAPON_7"
bind 8 "KEY_ORD_WEAPON_8"
bind 9 "KEY_ORD_WEAPON_9"
bind semicolon "KEY_ORD_MAP_LAYER_DOWN"
bind equals "KEY_ORD_MAP_ZOOM_IN"
bind a "KEY_ORD_STRAFE_LEFT"
bind d "KEY_ORD_STRAFE_RIGHT"
bind e "KEY_ORD_NUDGE"
bind f "KEY_ORD_USE"
bind g "KEY_ORD_DROP_ITEM"
bind q "KEY_ORD_LAMP_TOGGLE"
bind r "KEY_ORD_RELOAD"
bind s "KEY_ORD_BACKWARD"
bind t "KEY_ORD_CHAT"
bind v "KEY_ORD_PTT"
bind w "KEY_ORD_FORWARD"
bind x "KEY_ORD_TAUNTWHEEL"
bind y "KEY_ORD_FT_TOGGLE"
bind z "KEY_ORD_WEAPONWHEEL"
bind right "KEY_ORD_RIGHT"
bind left "KEY_ORD_LEFT"
bind kp_2 "KEY_ORD_MAP_PAN_DOWN"
bind kp_4 "KEY_ORD_MAP_PAN_LEFT"
bind kp_6 "KEY_ORD_MAP_PAN_RIGHT"
bind kp_8 "KEY_ORD_MAP_PAN_UP"
bind lctrl "KEY_ORD_CROUCH"
bind lshift "KEY_ORD_FAST"
bind lalt "KEY_ORD_SLOW"
bind rctrl "KEY_ORD_FREE_LOOK"
bind ralt "KEY_ORD_STRAFE_ON"
bind mouse_left "KEY_ORD_SMALL_FIRE"
bind mouse_middle "KEY_ORD_USE"
bind mouse_right "KEY_ORD_BIG_FIRE"
bind mouse_wheel_up "KEY_ORD_NEXT_WEAPON_UP"
bind mouse_wheel_down "KEY_ORD_NEXT_WEAPON_DOWN"
bind joy_0 "KEY_ORD_JUMP"
bind joy_1 "KEY_ORD_CROUCH_TOGGLE"
bind joy_2 "KEY_ORD_NUDGE"
bind joy_3 "KEY_ORD_MAP"
bind joy_4 "KEY_ORD_REMASTEREDMODE_TOGGLE"
bind joy_7 "KEY_ORD_FAST"
bind joy_8 "KEY_ORD_SCOPE"
bind joy_9 "KEY_ORD_WEAPONWHEEL"
bind joy_10 "KEY_ORD_RELOAD"
bind joy_11 "KEY_ORD_LAMP_TOGGLE"
bind joy_12 "KEY_ORD_USE"
bind joy_13 "KEY_ORD_NEXT_WEAPON_DOWN"
bind joy_14 "KEY_ORD_NEXT_WEAPON_UP"
bind joy_15 "KEY_ORD_BIG_FIRE"
bind joy_16 "KEY_ORD_SMALL_FIRE"
bind f1 "KEY_ORD_QUICK_TAUNT_1"
bind f2 "KEY_ORD_QUICK_TAUNT_2"
bind f3 "KEY_ORD_QUICK_TAUNT_3"
bind f4 "KEY_ORD_QUICK_TAUNT_4"
bind f5 "KEY_ORD_QUICK_TAUNT_5"
bind f6 "KEY_ORD_QUICK_TAUNT_6"
bind f7 "KEY_ORD_QUICK_TAUNT_7"
bind f8 "KEY_ORD_QUICK_TAUNT_8"
bind f9 "KEY_ORD_QUICK_TAUNT_9"
bind f10 "KEY_ORD_QUICK_TAUNT_10"'''


def ensure_default_binds(profile):
    """Rewrite the bind lines of profile/kexengine.cfg to DEFAULT_BINDS; the rest of the file is kept."""
    cfg = profile / "kexengine.cfg"
    keep, at = [], None
    try:
        for line in cfg.read_text(errors="replace").splitlines():
            if line.strip() == "unbindall" or line.startswith("bind "):
                if at is None:
                    at = len(keep)
                continue
            keep.append(line)
    except OSError:
        pass
    keep[at if at is not None else 0:at if at is not None else 0] = DEFAULT_BINDS.splitlines()
    try:
        cfg.write_text("\n".join(keep) + "\n")
    except OSError as e:
        print(f"could not set the default binds for {profile.name}: {e}")



EARLY_NAME_JS = '\n// Runs inside the game copy from before its first instruction (frida spawn): whatever name Steam reports for the\n// account, answer with this bot\'s name instead. Hooks ISteamFriends::GetPersonaName (slot 0) and, for our own\n// Steam id, GetFriendPersonaName (slot 7). Nothing calls into Steam from our own thread: the hooks go in when\n// the game itself asks Steam for its friends interface (SteamInternal_FindOrCreateUserInterface, or the\n// SteamAPI_SteamFriends_vNNN accessor), on the game\'s own thread.\nconst NAME = __NAME__;\nconst nameMem = Memory.allocUtf8String(NAME);\nconst patched = new Set();\nlet userIface = null;\nlet logged = 0;\nlet calls0 = 0;\nlet calls7 = 0;\nfunction note(m) { send({ kind: \'info\', message: \'persona: \' + m }); }\nfunction ownId() {\n  if (!userIface) return null;\n  try { return new NativeFunction(userIface.readPointer().add(2 * Process.pointerSize).readPointer(), \'uint64\', [\'pointer\'])(userIface).toString(); }\n  catch (err) { return null; }\n}\nfunction patchFriends(iface, how) {\n  if (iface.isNull()) return;\n  const vt = iface.readPointer();\n  const slot0 = vt.readPointer();\n  const slot7 = vt.add(7 * Process.pointerSize).readPointer();\n  if (!patched.has(slot0.toString())) {\n    patched.add(slot0.toString());\n    Interceptor.attach(slot0, { onLeave(ret) { if (calls0++ < 3) note(\'GetPersonaName was called\'); ret.replace(nameMem); } });\n    note(\'hooked GetPersonaName (\' + how + \')\');\n  }\n  if (!patched.has(slot7.toString())) {\n    patched.add(slot7.toString());\n    Interceptor.attach(slot7, {\n      onEnter(args) { const id = ownId(); this.mine = id !== null && args[1].toString() === ptr(id).toString(); if (calls7 < 6) { calls7++; note(\'GetFriendPersonaName called for \' + args[1] + \' (own id \' + id + \')\'); } },\n      onLeave(ret) { if (this.mine) { if (calls7++ < 3) note(\'GetFriendPersonaName(own id) was called\'); ret.replace(nameMem); } }\n    });\n    note(\'hooked GetFriendPersonaName for our own id (\' + how + \')\');\n  }\n}\nfunction attachAll(mod) {\n  for (const e of mod.enumerateExports()) {\n    if (/^SteamInternal_FindOrCreate(User|GameServer)Interface$/.test(e.name)) {\n      Interceptor.attach(e.address, {\n        onEnter(args) { try { this.ver = args[1].readUtf8String(); } catch (err) { this.ver = null; } },\n        onLeave(ret) {\n          if (!this.ver) return;\n          if (logged < 12) { logged++; note(\'game asked for \' + this.ver); }\n          if (this.ver.indexOf(\'SteamUser\') === 0 && !userIface && !ret.isNull()) userIface = ret;\n          if (this.ver.indexOf(\'SteamFriends\') === 0) patchFriends(ret, this.ver);\n        }\n      });\n      note(\'watching \' + e.name);\n    } else if (/^SteamAPI_SteamFriends_v\\d+$/.test(e.name)) {\n      Interceptor.attach(e.address, { onLeave(ret) { patchFriends(ret, e.name); } });\n      note(\'watching \' + e.name);\n    } else if (/^SteamAPI_SteamUser_v\\d+$/.test(e.name)) {\n      Interceptor.attach(e.address, { onLeave(ret) { if (!userIface && !ret.isNull()) userIface = ret; } });\n    } else if (/^SteamAPI_(Init|InitSafe|InitFlat)$/.test(e.name)) {\n      Interceptor.attach(e.address, { onEnter() { note(e.name + \' called\'); } });\n    }\n  }\n}\n// The Windows account name too: the game also has GetUserNameA/W in its imports.\nconst userHooked = {};\nfunction hookUserName() {\n  for (const [fn, wide] of [[\'GetUserNameA\', false], [\'GetUserNameW\', true]]) {\n    if (userHooked[fn]) continue;\n    let addr = null;\n    for (const m of [\'advapi32.dll\', \'sechost.dll\', \'kernelbase.dll\']) {\n      const mod = Process.findModuleByName(m);\n      if (mod) { try { addr = mod.getExportByName(fn); break; } catch (err) {} }\n    }\n    if (!addr) continue;\n    userHooked[fn] = true;\n    const mem = wide ? Memory.allocUtf16String(NAME) : Memory.allocUtf8String(NAME);\n    Interceptor.attach(addr, {\n      onEnter(args) { this.buf = args[0]; this.size = args[1]; },\n      onLeave(ret) {\n        try {\n          const room = this.size.readU32();\n          if (this.buf.isNull() || room < NAME.length + 1) return;\n          if (wide) this.buf.writeUtf16String(NAME); else this.buf.writeUtf8String(NAME);\n          this.size.writeU32(NAME.length + 1);\n          ret.replace(ptr(1));\n          if (calls7 + calls0 < 50) { calls7++; note(fn + \' answered with the bot name\'); }\n        } catch (err) {}\n      }\n    });\n    note(\'hooked \' + fn);\n  }\n}\nlet tries = 0;\nconst timer = setInterval(() => {\n  tries++;\n  const mod = Process.findModuleByName(\'steam_api64.dll\');\n  if (mod) {\n    clearInterval(timer);\n    attachAll(mod);\n    hookUserName();\n    setTimeout(hookUserName, 500);\n  } else if (tries > 6000) {\n    clearInterval(timer);\n    note(\'steam_api64.dll never showed up\');\n  }\n}, 2);\n\n// The game keeps each player\'s name as the "playername" entry of its player info (a function at exe+0x2aa2e0 of the\n// Steam build, called with the key and value as strings with the data pointer at +0x10 and the length at +0x18).\n// The name arrives from the PlayFab sign-in, whatever Steam is asked. The first name it sets is ours: swap in the\n// bot\'s name for the duration of every call that carries that name.\nconst INFO_RVA = 0x2aa2e0;\nconst INFO_PROLOGUE = \'48895c24084c894c242055565741544155415641\';\nlet infoHooked = false;\nlet firstName = null;\nlet infoSeen = 0;\nfunction hex(buf) { return Array.from(new Uint8Array(buf), b => (\'0\' + b.toString(16)).slice(-2)).join(\'\'); }\nfunction hookPlayerInfo() {\n  if (infoHooked) return true;\n  const addr = Process.mainModule.base.add(INFO_RVA);\n  let cur = \'\';\n  try { cur = hex(addr.readByteArray(20)); } catch (err) { return false; }\n  if (cur !== INFO_PROLOGUE) return false;\n  infoHooked = true;\n  Interceptor.attach(addr, {\n    onEnter(args) {\n      this.swapped = false;\n      try {\n        const key = args[2].add(0x10).readPointer().readCString();\n        if (infoSeen++ < 40) {\n          let shown = \'?\';\n          try { const l = args[3].add(0x18).readU64().toNumber(); if (l >= 0 && l < 200) shown = args[3].add(0x10).readPointer().readUtf8String(l); } catch (err) {}\n          note(\'player info: \' + key + \' = \' + shown);\n        }\n        if (key !== \'playername\') return;\n        const dp = args[3].add(0x10), lp = args[3].add(0x18);\n        const len = lp.readU64().toNumber();\n        if (len < 1 || len > 200) return;\n        const text = dp.readPointer().readUtf8String(len);\n        note(\'playername update: \' + text);\n        if (firstName === null) firstName = text;\n        if (text !== firstName || text === NAME) return;\n        this.dp = dp; this.lp = lp; this.origPtr = dp.readPointer(); this.origLen = len;\n        dp.writePointer(nameMem);\n        lp.writeU64(NAME.length);\n        this.swapped = true;\n      } catch (err) { if (infoSeen++ < 3) note(\'player info hook error: \' + err); }\n    },\n    onLeave() {\n      if (this.swapped) { this.dp.writePointer(this.origPtr); this.lp.writeU64(this.origLen); }\n    }\n  });\n  note(\'hooked the player info (playername) function\');\n  return true;\n}\nlet infoTries = 0;\nconst infoTimer = setInterval(() => {\n  infoTries++;\n  let ok = false;\n  try { ok = hookPlayerInfo(); } catch (err) { note(\'player info hook failed: \' + err); }\n  if (ok) clearInterval(infoTimer);\n  else if (infoTries > 4000) { clearInterval(infoTimer); note(\'the player info function never matched (a different game build?)\'); }\n}, 10);\n\n// Where the name really comes from: the player-info builder (exe+0x2a5260) asks the platform object (global at\n// exe+0xf38b08) for each user\'s name, a virtual call (vtable slot 9) that writes it into a string we get a pointer\n// to. Rewrite that string in place (strings keep a 16-byte buffer inline; the capacity is at +0x20).\nconst PLAT_GLOBAL_RVA = 0xf38b08;\nlet platHooked = false;\nlet platSeen = 0;\nfunction hookPlatformName() {\n  if (platHooked) return true;\n  const base = Process.mainModule.base;\n  const obj = base.add(PLAT_GLOBAL_RVA).readPointer();\n  if (obj.isNull()) return false;\n  const fn = obj.readPointer().add(0x48).readPointer();\n  if (fn.isNull()) return false;\n  platHooked = true;\n  Interceptor.attach(fn, {\n    onEnter(args) { this.out = args[1]; this.idx = args[2].toInt32(); },\n    onLeave() {\n      try {\n        const out = this.out;\n        const len = out.add(0x18).readU64().toNumber();\n        const cap = out.add(0x20).readU64().toNumber();\n        const dp = out.add(0x10).readPointer();\n        if (len < 1 || len > 200 || dp.isNull()) return;\n        const text = dp.readUtf8String(len);\n        if (platSeen++ < 12) note(\'platform name for user \' + this.idx + \': \' + text + \' (capacity \' + cap + \')\');\n        if (text === NAME) return;\n        const room = Math.min(NAME.length, cap > 0 && cap < 4096 ? cap : 15);\n        const bytes = NAME.substring(0, room);\n        dp.writeUtf8String(bytes);          // also writes the closing NUL\n        out.add(0x18).writeU64(bytes.length);\n        if (platSeen <= 12) note(\'  -> \' + bytes);\n      } catch (err) { if (platSeen++ < 12) note(\'platform name hook error: \' + err); }\n    }\n  });\n  note(\'hooked the platform name call\');\n  return true;\n}\nlet platTries = 0;\nconst platTimer = setInterval(() => {\n  platTries++;\n  let ok = false;\n  try { ok = hookPlatformName(); } catch (err) { if (platTries % 100 === 0) note(\'platform hook waiting: \' + err); }\n  if (ok) clearInterval(platTimer);\n  else if (platTries > 6000) { clearInterval(platTimer); note(\'the platform object never appeared\'); }\n}, 10);\n\n\n// Background: the bot\'s window never takes the foreground. It is created non-activating (WS_EX_NOACTIVATE),\n// shown without activating, and nothing the game or SDL does can raise it or give it the keyboard focus.\n// (Input still reaches the game: the agent fakes focus and injects events.)\nlet bgDone = false;\nfunction installBackground() {\n  if (bgDone) return true;\n  const u = Process.findModuleByName(\'user32.dll\');\n  if (!u) return false;\n  bgDone = true;\n  function ex(name) { try { return u.getExportByName(name); } catch (err) { return null; } }\n  // __WMODE__: \'hidden\' = no taskbar button or Alt-Tab entry (tool window) and placed far off screen,\n  // \'minimized\' = shown minimized, \'visible\' = a normal window, left in the background.\n  const WMODE = __WMODE__;\n  const OFF = ptr(\'0xffff8300\');                                           // -32000\n  const create = ex(\'CreateWindowExW\');\n  if (create) Interceptor.attach(create, { onEnter(args) {\n    let style = args[0].toUInt32() | 0x08000000;                           // WS_EX_NOACTIVATE\n    if (WMODE === \'hidden\') { style = (style | 0x80) & ~0x40000; args[4] = OFF; args[5] = OFF; }   // TOOLWINDOW, not APPWINDOW\n    args[0] = ptr(style);\n  } });\n  const show = ex(\'ShowWindow\');\n  if (show) Interceptor.attach(show, { onEnter(args) {\n    const c = args[1].toInt32();\n    if (c === 1 || c === 5 || c === 9 || c === 10 || c === 4) args[1] = ptr(WMODE === \'minimized\' ? 7 : 4);\n  } });\n  const pos = ex(\'SetWindowPos\');\n  if (pos) Interceptor.attach(pos, { onEnter(args) {\n    args[6] = ptr(args[6].toUInt32() | 0x10);                              // SWP_NOACTIVATE\n    if (WMODE === \'hidden\' && (args[6].toUInt32() & 0x2) === 0) { args[2] = OFF; args[3] = OFF; }   // unless SWP_NOMOVE\n  } });\n  for (const fn of [\'SetForegroundWindow\', \'SetFocus\', \'SetActiveWindow\', \'BringWindowToTop\', \'SwitchToThisWindow\']) {\n    const a = ex(fn);\n    if (a) Interceptor.replace(a, new NativeCallback(function () { return 1; }, \'int\', [\'pointer\', \'int\']));\n  }\n  note(\'background: windows stay in the background\');\n  return true;\n}\nlet bgTries = 0;\nconst bgTimer = setInterval(() => {\n  bgTries++;\n  let ok = false;\n  try { ok = installBackground(); } catch (err) { note(\'background hook failed: \' + err); ok = true; }\n  if (ok || bgTries > 6000) clearInterval(bgTimer);\n}, 2);\n'
_early_sessions = []                       # keep the early hook's session (and so its hooks) alive


def spawn_with_name(argv, env, display, window_mode="hidden"):
    """Start the game copy suspended, hook Steam's persona name in it, then let it run. Returns its pid."""
    device = frida.get_local_device()
    pid = device.spawn(argv, cwd=str(GAME_DIR), env=env)
    session = device.attach(pid)
    script = session.create_script(EARLY_NAME_JS.replace("__NAME__", json.dumps(display)).replace("__WMODE__", json.dumps(window_mode)))
    script.on("message", lambda m, _d: print(m["payload"]["message"]) if m.get("type") == "send"
              and isinstance(m.get("payload"), dict) and m["payload"].get("message") else
              (print("early name hook error:", m.get("description"), file=sys.stderr) if m.get("type") == "error" else None))
    script.load()
    _early_sessions.append((session, script))
    device.resume(pid)
    return pid



def launch(name, display, args, slot):
    """Start a game copy for this bot: its own profile folder and player name, windowed and small, LAN only.
    Returns the pid once its window is up (the agent hooks SDL, which the game sets up before that)."""
    (PROFILES / name).mkdir(parents=True, exist_ok=True)
    ensure_default_binds(PROFILES / name)
    width, height = (int(v) for v in args.size.lower().split("x"))
    # The bots make no sound at all: their copies can't mix into the audio of your own game.
    setvars = ["cl_fixedFPS", str(args.fps), "snd_musicvolume", "0",
               "snd_mastervolume", "0", "snd_volume", "0", "snd_tauntsvolume", "0", "snd_voicevolume", "0",
               "snd_movievolume", "0",
               "r_refraction", "0", "r_tinting", "0", "r_trueColor", "0", "r_remasteredmode", "0"]       # no music: the taunts get heard
    char = spec_tags(args.bots[0])[0] if args.bots else None
    char = char or args.char or character_for(name)
    if char:
        setvars += ["mp_defaultChar", str(char)]
    if args.host:
        setvars += host_setvars(args)
    argv = [str(GAME_EXE), "-netdriver", "lan", "-window", "-width", str(width), "-height", str(height),
            "-skipintromovies", "-userpath", str(PROFILES / name), "-setvar"] + setvars
    if slot is not None:                 # side by side, three per row
        argv += ["-xpos", str(10 + slot % 3 * (width + 20)), "-ypos", str(40 + slot // 3 * (height + 50))]
    if args.host:
        # Creates a LAN lobby at startup. -maxplayers only takes 2-8; a bigger lobby is set after attaching.
        argv += ["-host", "-maxplayers", str(min(args.maxplayers, CMDLINE_MAX_PLAYERS))]
        if args.private:
            argv.append("-private")      # the game's own private lobby (read next to -maxplayers at startup)
    elif args.join:
        argv += ["-join", args.join]     # joins that LAN game once the menu is up (see Bots.md)
    env = dict(os.environ, USERNAME=display)   # the player name when Galaxy isn't signed in
    if (GAME_DIR / "steam_api64.dll").exists():
        try:
            pid = spawn_with_name(argv, {"USERNAME": display}, display, args.window_mode)
            proc = types.SimpleNamespace(pid=pid, poll=lambda: None, returncode=None)
        except Exception as e:
            print(f"could not start it with the name hook ({e}); starting it normally")
            proc = None
    else:
        proc = None
    if proc is None:
        proc = subprocess.Popen(argv, cwd=GAME_DIR, env=env,
                                creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)
    print(f"started {display} (pid {proc.pid}), waiting for its window...")
    end = time.time() + 90
    while not has_window(proc.pid):
        if proc.poll() is not None:
            sys.exit(f"the game copy exited (code {proc.returncode})")
        if time.time() > end:
            sys.exit("no game window after 90 s")
        time.sleep(0.5)
    time.sleep(2.0)                      # let it finish setting up SDL input
    return proc.pid


# Lobby settings, as startup cvars (see Bots.md, "Map, mode and character from the command line").
# mp_defaultChar: the character menu's ol-char order.
CHARACTERS = {"sanchez": 1, "james": 2, "anderson": 2, "twofeathers": 3, "two": 3, "feathers": 3,
              "drdeath": 4, "doc": 4, "death": 4, "bob": 5, "mary": 6}
# mp_gamemode = the game-mode global (0xF071A4); the letters are the RCM file's MODES codes.
MODES = {"ctf": (1, "C"), "tag": (2, "T"), "chicken": (3, "K"), "doc": (4, "S"), "team": (5, "M"), "dm": (6, "D")}
# mp_levelName = an .rcm file's name without the extension. Empty: the host picks one itself.
MAPS = {"civpow2": "Buckshotville", "drygulch": "Dry Gulch", "fort": "The Fort", "granary": "The Granary",
        "hargrove": "Hargrove's Pattern Repair", "lilbatl": "Bunkers", "mltsimms": "Simms At Night",
        "orleans": "Orleans", "thudtowr": "Thud Tower", "town_2p": "Sanctuary", "wilderns": "Wilderness",
        "TheDip1s": "The Dip", "Stone": "Stone"}
# Every other map, from maps_data.json (written by mapscan.py: key, name, modes).
try:
    import json as _json
    for _m in _json.loads((Path(__file__).resolve().parent / "maps_data.json").read_text()):
        MAPS.setdefault(_m["key"], _m["name"])
except Exception:
    pass
try:                                            # maps mapbatch.py has installed for the moment
    for _m in _json.loads((Path(__file__).resolve().parent / "maps_extra.json").read_text()):
        MAPS.setdefault(_m["key"], _m["name"])
except Exception:
    pass


def character_for(name):
    """The character number for a bot named after one ('sanchez', 'drdeath', 'james2', ...), or None."""
    return CHARACTERS.get(re.sub(r"[\d_.-]+$", "", name).replace("_", "").replace("-", "").replace(".", ""))


def number_duplicates(specs):
    """Give bots that share a name their own numbers (and so their own profile and game copy):
    james:red james:blue -> james1:red james2:blue."""
    names = [split_name(s)[0] for s in specs]
    seen = {}
    out = []
    for spec, name in zip(specs, names):
        if names.count(name) == 1:
            out.append(spec)
            continue
        seen[name] = seen.get(name, 0) + 1
        rest = spec[spec.find(":"):] if ":" in spec.partition("=")[0] else spec[len(spec.partition("=")[0]):]
        out.append(f"{name}{seen[name]}{rest}")
    return out


# The named bots: (in-game name, behaviour in brain.py, characters it picks from, one chosen at random per start).
# Start them with bot1 .. bot7, or by name (dotard dtg_legend t4h_dingle t4h_ladyoutlaw wac_dirtyolero creature9
# noobke). The game keeps names to 15 characters.
PERSONAS = [
    ("Dotard", "dotard", ["james", "bob", "sanchez"]),
    ("DTG_Legend", "legend", ["sanchez"]),
    ("T4H_Dingle", "allrounder", ["drdeath", "mary", "bob", "sanchez"]),
    ("T4H_LadyOutlaw", "rifleman", ["james"]),
    ("WAC_Dirtyolero", "shotgunner", ["mary", "drdeath"]),
    ("creature9", "legend", ["sanchez"]),
    ("Noobke", "knifer", ["twofeathers"]),
    ("Bot 8", "default", ["sanchez", "james", "twofeathers", "drdeath", "bob", "mary"]),
    ("Bot 9", "default", ["sanchez", "james", "twofeathers", "drdeath", "bob", "mary"]),
    ("Bot 10", "default", ["sanchez", "james", "twofeathers", "drdeath", "bob", "mary"]),
]


# A different behaviour for a persona when it ends up with a given character.
PERSONA_BEHAVIOUR = {("WAC_Dirtyolero", "drdeath"): "shotgunner_doc"}


def apply_personas(specs):
    """'bot3' or 'dotard' (nothing else but :red/:blue) -> 'bot1:james:dotard=Dotard': the persona's profile, one of
    its characters, its behaviour and its name."""
    import random
    out = []
    for spec in specs:
        head, eq, _ = spec.partition("=")
        parts = head.split(":")
        key = parts[0].strip().lower()
        m = re.fullmatch(r"bot(\d+)", key)
        idx = int(m.group(1)) if m else next((n for n, p in enumerate(PERSONAS, 1) if p[0].lower() == key), None)
        if eq or idx is None or not 1 <= idx <= len(PERSONAS):
            out.append(spec)
            continue
        display, behaviour, chars = PERSONAS[idx - 1]
        char = random.choice(chars)
        behaviour = PERSONA_BEHAVIOUR.get((display, char), behaviour)
        tags = [t.strip().lower() for t in parts[1:] if t.strip().lower() in ("red", "blue")]
        out.append(":".join([f"bot{idx}", char, behaviour] + tags) + "=" + display)
    return out


# In-game names by bot position (bot1, bot2, ...); the game keeps names to 15 characters.
BOT_NAMES = ["Dotard", "DTG_Legend", "T4H_Dingle", "T4H_LadyOutlaw", "WAC_Dirtyolero", "creature9"]


def numbered_profiles(specs):
    """Several bots: give each its own profile folder bot1, bot2, ... (a bot with '=Display' keeps the profile
    it asked for). The character and tags are kept, and the in-game name stays what it would have been:
    sanchez:dynamiter x2 -> bot1:sanchez:dynamiter=Bot Sanchez 1, bot2:sanchez:dynamiter=Bot Sanchez 2."""
    out = []
    for i, spec in enumerate(specs, 1):
        head, eq, display = spec.partition("=")
        if eq:
            out.append(spec)
            continue
        name, display = split_name(spec)
        if i <= len(BOT_NAMES):
            display = BOT_NAMES[i - 1]
        tags = head.split(":")[1:]
        if spec_tags(spec)[0] is None and character_for(name):
            tags.insert(0, re.sub(r"[\d_.-]+$", "", name))          # the character the old name stood for
        out.append(":".join([f"bot{i}"] + tags) + "=" + display)
    return out


def map_modes(level):
    """The MODES letters of a map's .rcm file, or None if it can't be read."""
    import lvt
    loose = lvt.GAME_DIR / f"{level}.rcm"
    data = loose.read_bytes() if loose.exists() else lvt.read_from_labs(f"{level}.rcm")
    m = data and re.search(rb"MODES:\s*(\w+)", data)
    return m.group(1).decode().upper() if m else None


def check_host_settings(args):
    """Exit with a message if --map/--mode don't make sense, before any game copy starts."""
    if args.map and args.map not in MAPS:
        sys.exit(f"unknown map {args.map!r}; maps: " + ", ".join(f"{k} ({v})" for k, v in MAPS.items()))
    if args.map:
        modes = map_modes(args.map)
        if modes and MODES[args.mode][1] not in modes:
            have = [k for k, (_, letter) in MODES.items() if letter in modes]
            sys.exit(f"{MAPS[args.map]} doesn't support {args.mode}; it has: {', '.join(have)}")


def host_setvars(args):
    out = ["mp_gamemode", str(MODES[args.mode][0])]
    if args.map:
        out += ["mp_levelName", args.map]
    if args.timelimit is not None:
        out += ["mp_timeToEnd", str(args.timelimit)]
    if args.fraglimit is not None:
        out += ["mp_killsToEnd", str(args.fraglimit)]
    out += ["mp_friendlyFire", "1" if args.friendly_fire else "0"]
    if getattr(args, "gungame", False) or os.environ.get("BOT_GUNGAME"):
        out += ["mp_allowCheats", "1"]            # gun game: the all-weapons cheat (olpostal) has to work
    return out


def is_tag(tag):
    tag = tag.strip().lower()
    return tag in ("red", "blue") or tag in BEHAVIOURS or character_for(tag) is not None or is_weapon_tag(tag) \
        or is_diff_tag(tag) or is_lean_tag(tag)


def is_diff_tag(tag):
    """lv_easiest / lv_easy / lv_normal / lv_hard / lv_nightmare / lv_hell: the launcher's difficulty (lv_average is
    the old name of lv_easy)."""
    tag = tag.strip().lower()
    return tag.startswith("lv_") and (tag[3:] in DIFFICULTY or tag[3:] in DIFFICULTY_ALIASES)


def spec_difficulty(arg):
    for tag in arg.partition("=")[0].split(":")[1:]:
        if is_diff_tag(tag):
            return tag.strip().lower()[3:]
    return None


def is_lean_tag(tag):
    """lean_2 .. lean_6: the weapon slot this bot leans toward in this game (from the launcher)."""
    return re.fullmatch(r"lean_[2-6]", tag.strip().lower()) is not None


def spec_lean(arg):
    for tag in arg.partition("=")[0].split(":")[1:]:
        if is_lean_tag(tag):
            return int(tag.strip()[-1])
    return None


def is_weapon_tag(tag):
    """wp_1w2s3a...: weapon slot 1-9 followed by s(trong), a(verage) or w(eak), from the launcher."""
    return re.fullmatch(r"wp_(?:[1-9][saw])+", tag.strip().lower()) is not None


def spec_weapons(arg):
    """{slot: 's'|'a'|'w'} from a wp_ tag in 'name:...:wp_1w2s=Display', or None."""
    for tag in arg.partition("=")[0].split(":")[1:]:
        if is_weapon_tag(tag):
            return {int(a): b for a, b in re.findall(r"([1-9])([saw])", tag.strip().lower()[3:])}
    return None


def normalize_spec(arg):
    """Accept the tags after the display name too, and a display name alone:
    '=T4H_WaRRioR:doc:red' -> 't4h_warrior:doc:red=T4H_WaRRioR'. The profile name is then the display name
    in lower case, without characters a folder name can't have."""
    name_part, eq, display = arg.partition("=")
    if not eq:
        return arg
    parts = display.split(":")
    tags = []
    while len(parts) > 1 and is_tag(parts[-1]):
        tags.insert(0, parts.pop().strip())
    display = ":".join(parts).strip()
    if not name_part.partition(":")[0].strip():
        name = re.sub(r"[^a-z0-9_.-]", "", display.lower()).strip(".")
        if not name:
            sys.exit(f"{arg!r}: give a profile name before '=', e.g. dennis:james:red=Dennis")
        name_part = name + name_part             # keeps any ':tags' already there
    return ":".join([name_part] + tags) + "=" + display


def split_name(arg):
    """'sanchez' -> ('sanchez', 'Bot Sanchez'); 'drdeath:blue=Bot Dr. Death' -> ('drdeath', 'Bot Dr. Death')."""
    name, _, display = arg.partition("=")
    name = name.partition(":")[0].strip()
    base, number = re.match(r"(.*?)[_.-]*(\d*)$", name).groups()   # james2 -> "Bot James 2"
    return name.lower(), display.strip() or f"Bot {base.title()}{' ' + number if number else ''}"


def spec_tags(arg):
    """The (character, team, behaviour) in 'name[:character][:red|blue][:behaviour][=Display]', each None if not
    given. The tags after the name can come in any order: 'Dennis:james:red', 'Dennis:sapper:red', 'Dennis:mary'."""
    char = team = behaviour = None
    for tag in arg.partition("=")[0].split(":")[1:]:
        tag = tag.strip().lower()
        if tag in ("red", "blue"):
            team = tag
        elif tag in BEHAVIOURS:
            behaviour = tag
        elif character_for(tag):
            char = character_for(tag)
        elif is_weapon_tag(tag) or is_diff_tag(tag) or is_lean_tag(tag):
            pass
        elif tag:
            sys.exit(f"{arg!r}: {tag!r} after ':' must be red, blue, a character (sanchez james twofeathers drdeath "
                     f"bob mary) or a behaviour ({' '.join(BEHAVIOURS)})")
    return char, team, behaviour


def pid_alive(pid):
    import ctypes
    k32 = ctypes.windll.kernel32
    k32.OpenProcess.restype = ctypes.c_void_p
    h = k32.OpenProcess(0x1000, False, pid)             # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return False
    code = ctypes.c_ulong()
    ok = k32.GetExitCodeProcess(ctypes.c_void_p(h), ctypes.byref(code))
    k32.CloseHandle(ctypes.c_void_p(h))
    return bool(ok) and code.value == 259              # STILL_ACTIVE


def watch_game_copy(pid):
    """When this bot's game copy is gone (the game ended, or it was closed) end this process too, so its
    console closes with it (see --autoclose)."""
    def watch():
        gone = 0
        while True:
            time.sleep(2.0)
            gone = 0 if pid_alive(pid) else gone + 1
            if gone >= 2:
                print("the game copy is gone: closing")
                os._exit(0)
    threading.Thread(target=watch, daemon=True).start()


def spawn_consoles(device, args):
    """Several bots: one new console per bot, each running this script for one of them. With --host the
    first one hosts, and the others wait for its lobby and join it on this PC."""
    for i, arg in enumerate(args.bots):
        hosting = args.host and i == 0
        join = "127.0.0.1" if args.host else args.join
        cmd = [sys.executable, str(Path(__file__).resolve()), arg, "--slot", str(i), "--fps", str(args.fps),
               "--size", args.size] \
              + (["--host"] + host_args(args) + ["--wait-for", str(args.wait_for if args.wait_for is not None
                                                                else len(args.bots) - 1)]
                 if hosting else ["--join", join] if join else ["--no-join"]) \
              + (["--wait-for", str(args.wait_for), "--wait-max", str(args.wait_max)]
                 if (not hosting and args.wait_for is not None) else []) \
              + (["--fight"] if args.fight else []) \
              + (["--no-taunts"] if args.no_taunts else []) + (["--no-marshall-law"] if args.no_marshall_law else []) \
              + ["--window-mode", args.window_mode] \
              + (["--no-bench"] if args.no_bench else ["--bench-turn", str(args.bench_turn)])
        # cmd /k keeps the console open after botctl ends, so errors stay readable and Up+Enter restarts it.
        display = split_name(arg)[1]
        python = os.path.relpath(sys.executable, HERE) if Path(sys.executable).drive == HERE.drive else ""
        if args.tabs and not args.windows and shutil.which("wt") and python and " " not in python:
            # A tab in one Windows Terminal window. wt re-parses quotes, so the command has none of its own
            # beyond single-level ones around arguments with spaces: relative paths from the botctl folder.
            # ';' separates wt commands, so it is escaped.
            inner = subprocess.list2cmdline([python, "botctl.py"] + cmd[2:]).replace(";", "\\;")
            title = display.replace('"', "").replace(";", "\\;")
            subprocess.Popen(f'wt -w {WT_WINDOW} new-tab --title "{title}" -d "{HERE}" cmd /k {inner}')
            print(f"opened a tab for {display}")
        else:
            # A string, not a list: list2cmdline would escape the inner quotes as \" which cmd doesn't
            # understand. cmd /k strips the outer pair of quotes and runs the rest as typed.
            # Minimized and not activated, so nothing jumps in front of what you're doing (the taskbar has a
            # button per bot; click one to type commands in it).
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = 7                    # SW_SHOWMINNOACTIVE
            subprocess.Popen(f'cmd /k "{subprocess.list2cmdline(cmd)}"', cwd=HERE, startupinfo=si,
                             creationflags=subprocess.CREATE_NEW_CONSOLE)
            print(f"opened a console for {display}")
        if hosting:
            wait_for_lobby(device, split_name(arg)[0])
        else:
            time.sleep(JOIN_STAGGER)      # stagger the game starts a little


def host_args(args):
    """The hosting options, to pass on to the host's console."""
    out = ["--maxplayers", str(args.maxplayers), "--mode", args.mode]
    out += ["--map", args.map] if args.map else []
    out += ["--timelimit", str(args.timelimit)] if args.timelimit is not None else []
    out += ["--fraglimit", str(args.fraglimit)] if args.fraglimit is not None else []
    out += ["--wait-max", str(args.wait_max)]
    out += ["--gungame"] if args.gungame else []
    out += ["--private"] if args.private else []
    return out + (["--friendly-fire"] if args.friendly_fire else [])


def wait_for_lobby(device, name, timeout=120):
    """Wait until the hosting bot's game window is up, plus time to create the lobby."""
    print("waiting for the host's lobby...")
    end = time.time() + timeout
    while time.time() < end:
        pid = find_bot_copy(device, name)
        if pid and has_window(pid):
            time.sleep(HOST_LOBBY_WAIT)
            return
        time.sleep(1.0)
    print("the host's game window didn't come up; starting the others anyway")


class _Tee:
    """stdout/stderr that also writes to a file (flushed each time, so a crash or kill loses nothing)."""
    def __init__(self, stream, f):
        self.stream, self.f = stream, f

    def write(self, s):
        try:
            self.stream.write(s)
        except Exception:
            pass
        try:
            self.f.write(s)
            self.f.flush()
        except Exception:
            pass
        return len(s)

    def flush(self):
        try:
            self.stream.flush()
        except Exception:
            pass

    def __getattr__(self, name):
        return getattr(self.stream, name)


def tee_to_file(display):
    try:
        folder = Path(__file__).resolve().parent / "botlogs"
        folder.mkdir(exist_ok=True)
        safe = "".join(c if c.isalnum() or c in "-_ " else "_" for c in display).strip() or "bot"
        f = open(folder / f"{safe}.log", "w", encoding="utf-8", errors="replace")
        sys.stdout, sys.stderr = _Tee(sys.stdout, f), _Tee(sys.stderr, f)
    except Exception:
        pass


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("bots", nargs="*", help="bot names (profile folders), e.g. sanchez mary bob, each optionally "
                                            "followed by :character, :red/:blue and/or :behaviour, "
                                            "e.g. Dennis:james:red:sniper")
    ap.add_argument("--pid", type=int)
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--fight", action="store_true", help="start the brain right away")
    ap.add_argument("--windows", action="store_true",
                    help="several bots: a console window each instead of tabs in one Windows Terminal window")
    ap.add_argument("--join", default="127.0.0.1", help="LAN host address to join at startup (default: this PC)")
    ap.add_argument("--no-join", dest="join", action="store_const", const=None, help="stay in the menu")
    ap.add_argument("--host", action="store_true",
                    help="the (first) bot hosts a LAN lobby; with several bots the others join it")
    ap.add_argument("--private", action="store_true",
                    help="a private game when hosting: the game's own -private lobby, sized to the bots plus the "
                         "players --wait-for expects, so nobody else can see it or get in")
    ap.add_argument("--maxplayers", type=int, default=32,
                    help="lobby size when hosting (2-32, default 32); above 8 it's set like the console's "
                         "'kexmultiplayer maxplayers <n>' once the lobby is up")
    ap.add_argument("--map", type=lambda v: next((k for k in MAPS if k.lower() == v.strip().lower()), v.strip().lower()), help="map when hosting: " + ", ".join(MAPS) + " (default: the game picks)")
    ap.add_argument("--mode", type=str.lower, choices=list(MODES), default="dm", help="game mode when hosting")
    ap.add_argument("--timelimit", type=int, help="minutes when hosting (0-120)")
    ap.add_argument("--fraglimit", type=int, help="kills/score to end when hosting (0-100)")
    ap.add_argument("--friendly-fire", action="store_true", help="when hosting a team mode")
    ap.add_argument("--autoclose", action="store_true",
                    help="each bot's console closes by itself when its game copy ends (default: it stays open)")
    ap.add_argument("--wait-for", type=int,
                    help="when hosting with --fight: stand still until this many other players are in the match "
                         "(default: the number of other bots started with it; 0 = start right away)")
    ap.add_argument("--wait-max", type=float, default=120.0,
                    help="when hosting: start fighting after this many seconds even if not everyone joined")
    ap.add_argument("--tabs", action="store_true",
                    help="one Windows Terminal tab per bot (it takes the foreground when it opens) instead of "
                         "minimized consoles")
    ap.add_argument("--window-mode", choices=["hidden", "minimized", "visible"], default="hidden",
                    help="the bots' game windows: hidden (off screen, no taskbar button; default), minimized, or "
                         "visible (a normal window, left in the background)")
    ap.add_argument("--gungame", action="store_true",
                    help="gun game: one weapon at a time, a kill moves up the ladder (also BOT_GUNGAME=1)")
    ap.add_argument("--no-taunts", action="store_true", help="the bots don't taunt after a kill")
    ap.add_argument("--no-marshall-law", action="store_true",
                    help="the bots may pick up the badge and the invisible cream (POTION); by default (Marshall Law) "
                         "they stay well away from both")
    ap.add_argument("--no-bench", action="store_true",
                    help="team games: never sit out; by default a bot on the bigger team stays dead to even them")
    ap.add_argument("--bench-turn", type=float, default=3.0,
                    help="minutes a bot sits out before a teammate takes its place (default 3; 0 = no turns)")
    ap.add_argument("--team", type=str.lower, choices=["red", "blue"],
                    help="team for a single bot in team games (default: red; with several bots they alternate "
                         "red, blue, ... unless given as name:red / name:blue)")
    ap.add_argument("--behaviour", type=str.lower, choices=list(BEHAVIOURS),
                    help="behaviour for a single bot (default: name:behaviour, else default): " + ", ".join(BEHAVIOURS))
    ap.add_argument("--char", type=int, choices=range(1, 7),
                    help="character for a single bot: 1 Sanchez, 2 James, 3 Two Feathers, 4 Dr. Death, 5 Bob, "
                         "6 Mary (default: name:character, else from the bot's name)")
    ap.add_argument("--fps", type=int, default=60, help="cl_fixedFPS for a started copy")
    ap.add_argument("--size", default="320x180", help="window size for a started copy")
    ap.add_argument("--slot", type=int, help=argparse.SUPPRESS)   # window position, set for each console
    ap.add_argument("--no-fake-focus", action="store_true",
                    help="don't fake window focus; by default an unfocused bot copy is made to take input")
    args = ap.parse_args()
    args.bots = [normalize_spec(spec) for spec in args.bots]
    args.bots = apply_personas(args.bots)
    for spec in args.bots:
        spec_tags(spec)                  # check every bot's :tags before anything starts
    if args.host:
        check_host_settings(args)
        if args.map:
            os.environ.setdefault("BOT_MAP", args.map)      # the bots' map identification tries this one first
        if args.private and len(args.bots) > 1:          # (the console that hosts gets the size worked out here)
            wait = args.wait_for if args.wait_for is not None else len(args.bots) - 1
            args.maxplayers = max(2, wait + 1)            # the host bot, the bots that join it and the players it waits for
        if not 2 <= args.maxplayers <= 32:
            sys.exit("--maxplayers takes 2-32")

    device = frida.get_local_device()
    if len(args.bots) > 1:
        args.bots = number_duplicates(args.bots)
        args.bots = numbered_profiles(args.bots)
        spawn_consoles(device, args)
        return
    if args.bots:
        name, display = split_name(args.bots[0])
        _k32.SetConsoleTitleW(display)
        os.environ["BOT_DISPLAY"] = display
        os.environ["BOT_PROFILE"] = name         # the brain's state\session_<name>.json (next match, see Brain.session)
        tee_to_file(display)             # keep this bot's console text in botlogs\ for the bug capture
        args.pid = find_bot_copy(device, name)
        if args.pid:
            print(f"found {display}'s game copy (pid {args.pid})")
        else:
            args.pid = launch(name, display, args, args.slot)
    elif args.list or not args.pid:
        if not list_instances(device):
            print("no OutlawsAHOM.exe running")
        elif not args.list:
            print("pick one with --pid, or start a bot by name")
        return

    session = device.attach(args.pid)
    script = session.create_script((HERE / "input_agent.js").read_text())
    def on_message(m, _data):
        if m["type"] == "error":
            print("agent error:", m.get("stack") or m.get("description"), file=sys.stderr)
        elif m["type"] == "send":
            p = m["payload"]
            if p.get("kind") == "info":
                print(p["message"])
            elif p.get("kind") == "warning":
                print("agent warning:", p["message"], file=sys.stderr)
            elif p.get("kind") == "hook_error":
                print(f"agent: {p['hook']} hook failed, now passing through to SDL:\n{p['error']}", file=sys.stderr)
            else:
                print("agent:", p)

    script.on("message", on_message)
    try:
        script.load()
    except frida.core.RPCException as e:
        sys.exit(f"agent failed to load: {e}\n"
                 f"Is another botctl already attached to pid {args.pid}? Close it first.")
    bot = Bot(script)
    bot.marshall_law = not args.no_marshall_law
    bot.hosting = bool(args.host)            # the brain's status file says so (rotation.py: who hosts the next map)
    # Our name in the sit-out roster (bench.py), unique among the bots on this PC.
    bench_name = (split_name(args.bots[0])[0] or split_name(args.bots[0])[1]) if args.bots else f"pid{args.pid}"
    # Team for team games, picked in the lobby: name:red/blue, --team, else alternate by launch order.
    bot.team_pref = (args.team or (spec_tags(args.bots[0])[1] if args.bots else None)
                     or ("blue" if (args.slot or 0) % 2 else "red"))
    # Behaviour: name:behaviour, --behaviour, else the default bot.
    behaviour = (spec_tags(args.bots[0])[2] if args.bots else None) or args.behaviour or "default"
    bot.api.set_fake_focus(not args.no_fake_focus)
    if args.bots and not _early_sessions:                # the in-game name, whatever Steam says the account is called
        try:
            print("name:", bot.api.set_persona(split_name(args.bots[0])[1]))
        except Exception as e:
            print(f"could not set the in-game name: {e}")
    if args.host and args.maxplayers > CMDLINE_MAX_PLAYERS:
        bot.api.set_max_players(args.maxplayers)     # applied once the lobby exists; prints the outcome
    print(f"attached to {args.pid} ({behaviour} bot). Type 'help' for commands.")

    queued = ["fight"] if args.fight else []
    # The host's first fight waits for the others to join; a later 'fight' typed by hand doesn't.
    wait_for = args.wait_for if (args.host or args.wait_for is not None) else None
    end_game = False
    try:
        while True:
            try:
                line = queued.pop(0).split() if queued else input("bot> ").split()
            except EOFError:
                break
            if not line:
                continue
            cmd, rest = line[0], line[1:]
            try:
                if cmd == "quit":
                    break
                elif cmd == "close":
                    end_game = True
                    break
                elif cmd == "help":
                    print(__doc__)
                elif cmd == "findname":
                    for hit in bot.api.find_text(" ".join(rest), 40):
                        print("  ", hit)
                elif cmd == "hold":
                    bot.hold(rest[0], int(rest[1]))
                elif cmd == "tap":
                    bot.hold(rest[0], 100)
                elif cmd == "fire":
                    bot.hold("mouse_left", int(rest[0]) if rest else 300)
                elif cmd == "look":
                    bot.api.look(float(rest[0]), float(rest[1]) if len(rest) > 1 else 0.0)
                elif cmd == "lookstep":
                    print("look step:", bot.api.set_look_step(float(rest[0])))
                elif cmd == "motion":
                    bot.api.motion(float(rest[0]), float(rest[1]) if len(rest) > 1 else 0.0)
                elif cmd == "square":
                    bot.square()
                elif cmd == "focus":
                    print("fake focus:", bot.api.set_fake_focus(rest[0] == "on"))
                elif cmd == "players":
                    me, others = bot.players()
                    print(f"  me   pos=({me['x']:8.2f},{me['y']:7.2f},{me['z']:8.2f}) "
                          f"heading={me['yaw'] * 360 / FULL_TURN:6.1f} deg health={me.get('health')} "
                          f"team={me.get('team')} carries={me.get('carries')}")
                    print(f"       game: {bot.game}  lobby: {bot.lobby}")
                    inv = me.get("inventory") or {"slot": None, "weapons": []}
                    print("       weapons: " + ", ".join(
                        f"{'*' if w['slot'] == inv['slot'] else ''}{w['slot']}:{w['name']}"
                        + (f" {w['loaded']}/{w['capacity']}+{w['reserve']}" if w["ammo"] else "")
                        for w in inv["weapons"]))
                    for i, p in enumerate(others):
                        d = math.hypot(p["x"] - me["x"], p["z"] - me["z"])
                        rel = wrap(bearing(me, p) - me["yaw"]) * 360 / FULL_TURN
                        print(f"  [{i}]  pos=({p['x']:8.2f},{p['y']:7.2f},{p['z']:8.2f}) "
                              f"heading={p['yaw'] * 360 / FULL_TURN:6.1f} deg  dist={d:7.1f}  "
                              f"{'right' if rel > 0 else 'left'} {abs(rel):5.1f} deg  "
                              f"{'DEAD' if p['dead'] else 'alive'} visible={p.get('visible')} "
                              f"team={p.get('team')} carries={p.get('carries')}")
                elif cmd == "inv":
                    try:
                        bot.players()
                    except RuntimeError:
                        pass                    # dead or no actor: self_state still has the inventory
                    inv = (bot.self_state or {}).get("inventory")
                    if not inv:
                        print("no inventory (not in a match?)")
                    else:
                        for s in inv.get("slots") or []:
                            print(f"  [{s['i']:2}] {s['name']!r:24} count={s['count']}")
                        print(f"  carried: {inv.get('carried')}")
                        print(f"  hasBadge={inv.get('hasBadge')} armor={inv.get('armor')} slot={inv.get('slot')}")
                elif cmd == "calibrate":
                    print(f"heading units per mouse unit: {bot.calibrate():.3f}")
                elif cmd == "turn":
                    bot.turn_units(float(rest[0]) / 360 * FULL_TURN)
                elif cmd == "face":
                    _, others = bot.players()
                    if not others:
                        print("no other players found")
                    else:
                        bot.face(others[int(rest[0]) if rest else 0])
                elif cmd == "fight":
                    print("fighting; Ctrl+C to stop")
                    try:
                        bench = None if args.no_bench else Bench(bench_name, turn=args.bench_turn * 60)
                        skill = behaviour_skill(behaviour, spec_weapons(args.bots[0]) if args.bots else None,
                                                spec_difficulty(args.bots[0]) if args.bots else None)
                        skill.lean = spec_lean(args.bots[0]) if args.bots else None
                        brain = Brain(bot, skill=skill,
                                      wait_for=wait_for,
                                      wait_max=args.wait_max, bench=bench, taunts=not args.no_taunts)
                        brain.gg = bool(args.gungame or os.environ.get("BOT_GUNGAME"))
                        brain.stats_obs = bool(args.host and (args.slot or 0) == 0) or bool(os.environ.get("BOT_STATS_OBS"))      # launcher stats: the host watches
                        brain.char_num = ((spec_tags(args.bots[0])[0] if args.bots else None) or args.char
                                          or character_for(bench_name))
                        wait_for = None
                        brain.run(float(rest[0]) if rest else None)
                    except KeyboardInterrupt:
                        pass
                    print("stopped")
                elif cmd == "rehost":
                    level = next((k for k in MAPS if k.lower() == rest[0].lower()), None) if rest else None
                    if rest and level is None:
                        print(f"unknown map {rest[0]!r}")
                        continue
                    mode = MODES[rest[1].lower()][0] if len(rest) > 1 else None
                    print("requested" if bot.host_next(level, mode, int(rest[2]) if len(rest) > 2 else None,
                                                       int(rest[3]) if len(rest) > 3 else None) else "not possible here")
                elif cmd == "rejoin":
                    print("requested" if bot.join_next(rest[0] if rest else (args.join or "127.0.0.1"))
                          else "not possible here")
                elif cmd == "maxplayers":
                    if rest:
                        bot.api.set_max_players(int(rest[0]))
                        print("requested; applied once this copy hosts a lobby")
                    else:
                        print(bot.api.max_players())
                elif cmd == "stats":
                    print(json.dumps(bot.api.stats(), indent=2))
                else:
                    print("unknown command; type 'help'")
            except (IndexError, ValueError, RuntimeError) as e:
                print("error:", e)
    except KeyboardInterrupt:
        pass
    finally:
        bot.close()
        session.detach()
        if end_game:
            subprocess.run(["taskkill", "/pid", str(args.pid)], capture_output=True)  # asks the window to close
            time.sleep(3.0)
            subprocess.run(["taskkill", "/f", "/pid", str(args.pid)], capture_output=True)
            print("game copy closed")


if __name__ == "__main__":
    main()
