"""A small pure-Python Zstandard decoder (RFC 8878), for the game's compressed messages (body "7f 00" + a zstd frame).

The ghosts run on the bots' Python (3.13 on Windows: no zstd in the standard library, no extra packages), and the host sends
some of what they need compressed: the map's item list at join (rifles, shotguns, canteens...). Frames that need a dictionary
are not supported (decompress() raises ValueError for them, and for anything malformed).

decompress(data) -> bytes   (data starts with the frame's magic 28 b5 2f fd; trailing bytes after the frame are ignored)
"""


class ZstdError(ValueError):
    pass


# ---------------------------------------------------------------- bit readers
class _BackBits:
    """Reads a bitstream backwards (FSE / Huffman streams): starts after the final 1 bit of the last byte."""
    def __init__(self, data):
        if not data or data[-1] == 0:
            raise ZstdError("bad bitstream end")
        self.v = int.from_bytes(data, "little")
        self.pos = len(data) * 8 - (8 - data[-1].bit_length()) - 1      # bits left to read
    def read(self, n):
        if n == 0:
            return 0
        self.pos -= n
        if self.pos >= 0:
            return (self.v >> self.pos) & ((1 << n) - 1)
        # past the start: the missing low bits read as zero
        sh = -self.pos
        val = (self.v & ((1 << (n - sh)) - 1)) << sh if n - sh > 0 else 0
        return val
    def peek(self, n):
        p = self.pos - n
        if p >= 0:
            return (self.v >> p) & ((1 << n) - 1)
        sh = -p
        return ((self.v & ((1 << (n - sh)) - 1)) << sh) if n - sh > 0 else 0
    def skip(self, n):
        self.pos -= n


# ---------------------------------------------------------------- FSE
def _fse_read_dist(data, pos, max_sym):
    """an FSE table description (normalized counts), as zstd's FSE_readNCount; returns (accuracy_log, counts, new_pos)"""
    bitpos = pos * 8
    def look(n):
        b = bitpos >> 3
        return (int.from_bytes(data[b:b + 8], "little") >> (bitpos & 7)) & ((1 << n) - 1)
    acc = look(4) + 5; bitpos += 4
    if acc > 15: raise ZstdError("FSE accuracy too high")
    size = 1 << acc; remaining = size + 1; threshold = size; nbits = acc + 1
    counts = []; prev0 = False
    while remaining > 1 and len(counts) <= max_sym:
        if prev0:
            while look(16) == 0xFFFF:
                counts.extend([0] * 24); bitpos += 16
            while look(2) == 3:
                counts.extend([0] * 3); bitpos += 2
            counts.extend([0] * look(2)); bitpos += 2
            if len(counts) > max_sym: break
        mx = (2 * threshold - 1) - remaining
        v = look(nbits)
        if (v & (threshold - 1)) < mx:
            c = v & (threshold - 1); bitpos += nbits - 1
        else:
            c = v & (2 * threshold - 1)
            if c >= threshold: c -= mx
            bitpos += nbits
        c -= 1
        remaining -= -c if c < 0 else c
        counts.append(c); prev0 = (c == 0)
        while remaining < threshold:
            nbits -= 1; threshold >>= 1
    if remaining != 1 or len(counts) > max_sym + 1:
        raise ZstdError("bad FSE table")
    return acc, counts, (bitpos + 7) >> 3


def _fse_build(acc, counts):
    """decoding table: list of (symbol, nbits, baseline)"""
    size = 1 << acc
    sym = [0] * size
    high = size - 1
    for s, c in enumerate(counts):
        if c == -1:
            sym[high] = s; high -= 1
    step = (size >> 1) + (size >> 3) + 3
    mask = size - 1
    p = 0
    for s, c in enumerate(counts):
        for _ in range(max(c, 0)):
            sym[p] = s
            p = (p + step) & mask
            while p > high:
                p = (p + step) & mask
    nxt = [1 if c == -1 else c for c in counts] + [0] * (len(counts) and 0)
    table = []
    for i in range(size):
        s = sym[i]
        n = nxt[s]; nxt[s] += 1
        nb = acc - (n.bit_length() - 1)
        table.append((s, nb, (n << nb) - size))
    return table, acc


# predefined distributions (RFC 8878 3.1.1.3.2.2)
_LL_DEF = [4, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 1, 1, 1, 1, 1, -1, -1, -1, -1]
_ML_DEF = [1, 4, 3, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1]
_OF_DEF = [1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1]
_LL_BASE = list(range(16)) + [16, 18, 20, 22, 24, 28, 32, 40, 48, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536]
_LL_BITS = [0] * 16 + [1, 1, 1, 1, 2, 2, 3, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
_ML_BASE = list(range(3, 35)) + [35, 37, 39, 41, 43, 47, 51, 59, 67, 83, 99, 131, 259, 515, 1027, 2051, 4099, 8195, 16387, 32771, 65539]
_ML_BITS = [0] * 32 + [1, 1, 1, 1, 2, 2, 3, 3, 4, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
_PREDEF = {}


def _predef(kind):
    if kind not in _PREDEF:
        acc, counts = {"ll": (6, _LL_DEF), "ml": (6, _ML_DEF), "of": (5, _OF_DEF)}[kind]
        _PREDEF[kind] = _fse_build(acc, counts)
    return _PREDEF[kind]


# ---------------------------------------------------------------- Huffman
def _huf_from_weights(weights):
    """weights of symbols 0..n-2 (the last symbol's is implied): decoding table indexed by the next max_bits bits"""
    total = sum(1 << (w - 1) for w in weights if w)
    if total == 0: raise ZstdError("bad Huffman weights")
    max_bits = total.bit_length()
    left = (1 << max_bits) - total
    if left == 0 or left & (left - 1): raise ZstdError("bad Huffman weights")
    weights = list(weights) + [left.bit_length()]
    if max_bits > 11: raise ZstdError("Huffman codes too long")
    size = 1 << max_bits; table = [None] * size; pos = 0
    for w in range(1, max_bits + 1):
        span = 1 << (w - 1)
        for sym, ws in enumerate(weights):
            if ws == w:
                e = (sym, max_bits + 1 - w)
                for k in range(pos, pos + span): table[k] = e
                pos += span
    if pos != size: raise ZstdError("bad Huffman table")
    return table, max_bits


def _huf_read_table(data, pos):
    """the Huffman tree description at data[pos]: returns ((table, max_bits), new_pos)"""
    hb = data[pos]; pos += 1
    if hb < 128:                                          # FSE-compressed weights
        end = pos + hb
        acc, counts, p2 = _fse_read_dist(data, pos, 255)
        table, acc = _fse_build(acc, counts)
        br = _BackBits(data[p2:end])
        s1 = br.read(acc); s2 = br.read(acc)
        weights = []
        while len(weights) < 255:
            sym, nb, base = table[s1]; weights.append(sym); s1 = base + br.read(nb)
            if br.pos < 0: weights.append(table[s2][0]); break
            sym, nb, base = table[s2]; weights.append(sym); s2 = base + br.read(nb)
            if br.pos < 0: weights.append(table[s1][0]); break
        return _huf_from_weights(weights), end
    n = hb - 127
    raw = data[pos:pos + (n + 1) // 2]
    weights = []
    for i in range(n):
        b = raw[i // 2]
        weights.append(b >> 4 if i % 2 == 0 else b & 15)
    return _huf_from_weights(weights), pos + (n + 1) // 2


def _huf_decode_stream(data, huf, count):
    table, mb = huf
    br = _BackBits(data)
    out = bytearray()
    for _ in range(count):
        s, nb = table[br.peek(mb)]
        br.skip(nb)
        out.append(s)
    return out


# ---------------------------------------------------------------- frame / blocks
class _State:
    def __init__(self):
        self.huf = None
        self.tables = {"ll": None, "of": None, "ml": None}
        self.rep = [1, 4, 8]


def _literals(data, pos, st):
    b0 = data[pos]
    ltype = b0 & 3; sf = (b0 >> 2) & 3
    if ltype in (0, 1):                                   # raw / RLE
        if sf in (0, 2):
            size = b0 >> 3; pos += 1
        elif sf == 1:
            size = (b0 >> 4) + (data[pos + 1] << 4); pos += 2
        else:
            size = (b0 >> 4) + (data[pos + 1] << 4) + (data[pos + 2] << 12); pos += 3
        if ltype == 0:
            return bytes(data[pos:pos + size]), pos + size
        return bytes([data[pos]]) * size, pos + 1
    # compressed / treeless
    if sf in (0, 1):
        v = int.from_bytes(data[pos:pos + 3], "little"); hl = 3
        regen = (v >> 4) & 0x3FF; comp = (v >> 14) & 0x3FF; streams = 1 if sf == 0 else 4
    elif sf == 2:
        v = int.from_bytes(data[pos:pos + 4], "little"); hl = 4
        regen = (v >> 4) & 0x3FFF; comp = (v >> 18) & 0x3FFF; streams = 4
    else:
        v = int.from_bytes(data[pos:pos + 5], "little"); hl = 5
        regen = (v >> 4) & 0x3FFFF; comp = (v >> 22) & 0x3FFFF; streams = 4
    pos += hl
    end = pos + comp
    if ltype == 2:
        st.huf, pos = _huf_read_table(data, pos)
    elif st.huf is None:
        raise ZstdError("treeless literals without a table")
    if streams == 1:
        return bytes(_huf_decode_stream(data[pos:end], st.huf, regen)), end
    s1, s2, s3 = (int.from_bytes(data[pos + i:pos + i + 2], "little") for i in (0, 2, 4))
    pos += 6
    seg = (regen + 3) // 4
    sizes = [seg, seg, seg, regen - 3 * seg]
    bounds = [pos, pos + s1, pos + s1 + s2, pos + s1 + s2 + s3, end]
    out = bytearray()
    for k in range(4):
        out += _huf_decode_stream(data[bounds[k]:bounds[k + 1]], st.huf, sizes[k])
    return bytes(out), end


def _seq_table(data, pos, mode, kind, st, max_sym):
    if mode == 0:
        st.tables[kind] = _predef(kind)
    elif mode == 1:
        st.tables[kind] = ([(data[pos], 0, 0)], 0); pos += 1
    elif mode == 2:
        acc, counts, pos = _fse_read_dist(data, pos, max_sym)
        st.tables[kind] = _fse_build(acc, counts)
    elif st.tables[kind] is None:
        raise ZstdError("repeat table without one")
    return pos


def _sequences(data, pos, end, st, lits, out):
    n = data[pos]
    if n == 0:
        out += lits; return
    if n < 128:
        pos += 1
    elif n < 255:
        n = ((n - 128) << 8) + data[pos + 1]; pos += 2
    else:
        n = data[pos + 1] + (data[pos + 2] << 8) + 0x7F00; pos += 3
    modes = data[pos]; pos += 1
    pos = _seq_table(data, pos, (modes >> 6) & 3, "ll", st, 35)
    pos = _seq_table(data, pos, (modes >> 4) & 3, "of", st, 31)
    pos = _seq_table(data, pos, (modes >> 2) & 3, "ml", st, 52)
    (llt, lla), (oft, ofa), (mlt, mla) = st.tables["ll"], st.tables["of"], st.tables["ml"]
    br = _BackBits(data[pos:end])
    sll = br.read(lla); sof = br.read(ofa); sml = br.read(mla)
    lp = 0; rep = st.rep
    for i in range(n):
        ofc = oft[sof][0]; mlc = mlt[sml][0]; llc = llt[sll][0]
        offv = (1 << ofc) + br.read(ofc)
        ml = _ML_BASE[mlc] + br.read(_ML_BITS[mlc])
        ll = _LL_BASE[llc] + br.read(_LL_BITS[llc])
        if offv > 3:
            off = offv - 3; rep[:] = [off, rep[0], rep[1]]
        else:
            idx = offv - 1 + (1 if ll == 0 else 0)          # (literal length 0 shifts the repeat codes by one)
            if idx == 0:
                off = rep[0]
            elif idx == 3:
                off = rep[0] - 1
                if off == 0:
                    raise ZstdError("bad repeat offset")
                rep[:] = [off, rep[0], rep[1]]
            else:
                off = rep[idx]
                if idx == 1:
                    rep[:] = [off, rep[0], rep[2]]
                else:
                    rep[:] = [off, rep[0], rep[1]]
        out += lits[lp:lp + ll]; lp += ll
        if off > len(out):
            raise ZstdError("offset before the start (a dictionary frame?)")
        start = len(out) - off
        if off >= ml:
            out += out[start:start + ml]
        else:
            for k in range(ml):
                out.append(out[start + k])
        if i < n - 1:                                      # state updates: literal lengths, match lengths, offsets
            s, nb, base = llt[sll]; sll = base + br.read(nb)
            s, nb, base = mlt[sml]; sml = base + br.read(nb)
            s, nb, base = oft[sof]; sof = base + br.read(nb)
    out += lits[lp:]


def decompress(data):
    data = bytes(data)
    if data[:4] != b"\x28\xb5\x2f\xfd":
        raise ZstdError("not a zstd frame")
    fhd = data[4]; pos = 5
    fcs_flag = fhd >> 6; single = (fhd >> 5) & 1; dict_flag = fhd & 3
    if not single:
        pos += 1                                           # window descriptor
    if dict_flag:
        did = int.from_bytes(data[pos:pos + (1, 2, 4)[dict_flag - 1]], "little")
        pos += (1, 2, 4)[dict_flag - 1]
        if did:
            raise ZstdError("needs a dictionary")
    fcs_len = (1 if single else 0, 2, 4, 8)[fcs_flag]
    pos += fcs_len
    out = bytearray(); st = _State()
    while True:
        h = int.from_bytes(data[pos:pos + 3], "little"); pos += 3
        last = h & 1; btype = (h >> 1) & 3; bsize = h >> 3
        if btype == 0:
            out += data[pos:pos + bsize]; pos += bsize
        elif btype == 1:
            out += bytes([data[pos]]) * bsize; pos += 1
        elif btype == 2:
            end = pos + bsize
            lits, p2 = _literals(data, pos, st)
            _sequences(data, p2, end, st, lits, out)
            pos = end
        else:
            raise ZstdError("reserved block type")
        if last:
            break
    return bytes(out)
