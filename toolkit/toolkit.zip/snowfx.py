"""Falling snow over the game (the Christmas Horde): soft, see-through snowflakes in three depths, drifting in the wind.
A per-pixel-alpha layered window (Win32, standard library only: ctypes), click-through and never focused, that sits
on top of the game. Near flakes are bigger, softer (out of focus) and faster; far ones small, faint and slow; some
are little clumps, the fast near ones a touch motion-blurred.
  run(should_stop)   blocks until should_stop() is true (call it from its own thread: it has its own window)
Used by snow.py (the host's own game) and by the Outlaws Companion (joined games)."""
import ctypes
import math
import random
import time
from ctypes import wintypes as W

FPS = 30
DENSITY = 115                      # flakes on a 1920x1080 screen (scaled with the screen's area)

u32 = ctypes.windll.user32 if hasattr(ctypes, "windll") else None
g32 = ctypes.windll.gdi32 if u32 else None
k32 = ctypes.windll.kernel32 if u32 else None
msimg = ctypes.windll.msimg32 if u32 else None

LRESULT = ctypes.c_ssize_t
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, W.HWND, W.UINT, W.WPARAM, W.LPARAM) if u32 else None


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", W.DWORD), ("biWidth", W.LONG), ("biHeight", W.LONG), ("biPlanes", W.WORD),
                ("biBitCount", W.WORD), ("biCompression", W.DWORD), ("biSizeImage", W.DWORD),
                ("biXPelsPerMeter", W.LONG), ("biYPelsPerMeter", W.LONG), ("biClrUsed", W.DWORD), ("biClrImportant", W.DWORD)]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", W.DWORD * 3)]


class BLENDFUNCTION(ctypes.Structure):
    _fields_ = [("BlendOp", ctypes.c_ubyte), ("BlendFlags", ctypes.c_ubyte), ("SourceConstantAlpha", ctypes.c_ubyte),
                ("AlphaFormat", ctypes.c_ubyte)]


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [("cbSize", W.UINT), ("style", W.UINT), ("lpfnWndProc", ctypes.c_void_p), ("cbClsExtra", ctypes.c_int),
                ("cbWndExtra", ctypes.c_int), ("hInstance", W.HINSTANCE), ("hIcon", W.HICON), ("hCursor", W.HANDLE),
                ("hbrBackground", W.HBRUSH), ("lpszMenuName", W.LPCWSTR), ("lpszClassName", W.LPCWSTR), ("hIconSm", W.HICON)]


def _setup():
    u32.DefWindowProcW.restype = LRESULT
    u32.DefWindowProcW.argtypes = [W.HWND, W.UINT, W.WPARAM, W.LPARAM]
    u32.CreateWindowExW.restype = W.HWND
    u32.CreateWindowExW.argtypes = [W.DWORD, W.LPCWSTR, W.LPCWSTR, W.DWORD, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, W.HWND, W.HMENU, W.HINSTANCE, W.LPVOID]
    u32.RegisterClassExW.argtypes = [ctypes.POINTER(WNDCLASSEXW)]
    u32.GetDC.restype = W.HDC; u32.GetDC.argtypes = [W.HWND]
    u32.ReleaseDC.argtypes = [W.HWND, W.HDC]
    u32.UpdateLayeredWindow.argtypes = [W.HWND, W.HDC, ctypes.POINTER(W.POINT), ctypes.POINTER(W.SIZE), W.HDC,
                                        ctypes.POINTER(W.POINT), W.COLORREF, ctypes.POINTER(BLENDFUNCTION), W.DWORD]
    u32.ShowWindow.argtypes = [W.HWND, ctypes.c_int]
    u32.SetWindowPos.argtypes = [W.HWND, W.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, W.UINT]
    u32.DestroyWindow.argtypes = [W.HWND]
    u32.PeekMessageW.argtypes = [ctypes.POINTER(W.MSG), W.HWND, W.UINT, W.UINT, W.UINT]
    u32.TranslateMessage.argtypes = [ctypes.POINTER(W.MSG)]
    u32.DispatchMessageW.argtypes = [ctypes.POINTER(W.MSG)]
    u32.GetForegroundWindow.restype = W.HWND
    g32.CreateCompatibleDC.restype = W.HDC; g32.CreateCompatibleDC.argtypes = [W.HDC]
    g32.CreateDIBSection.restype = W.HBITMAP
    g32.CreateDIBSection.argtypes = [W.HDC, ctypes.POINTER(BITMAPINFO), W.UINT, ctypes.POINTER(ctypes.c_void_p), W.HANDLE, W.DWORD]
    g32.SelectObject.restype = W.HGDIOBJ; g32.SelectObject.argtypes = [W.HDC, W.HGDIOBJ]
    g32.DeleteObject.argtypes = [W.HGDIOBJ]
    g32.DeleteDC.argtypes = [W.HDC]
    msimg.AlphaBlend.argtypes = [W.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, W.HDC, ctypes.c_int,
                                 ctypes.c_int, ctypes.c_int, ctypes.c_int, BLENDFUNCTION]
    k32.GetModuleHandleW.restype = W.HMODULE; k32.GetModuleHandleW.argtypes = [W.LPCWSTR]


def _dib(dc, w, h):
    bi = BITMAPINFO()
    bi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bi.bmiHeader.biWidth, bi.bmiHeader.biHeight = w, -h          # top-down
    bi.bmiHeader.biPlanes, bi.bmiHeader.biBitCount = 1, 32
    bits = ctypes.c_void_p()
    hbm = g32.CreateDIBSection(dc, ctypes.byref(bi), 0, ctypes.byref(bits), None, 0)
    return hbm, bits


def _flake_pixels(size, kind, rng):
    """Premultiplied BGRA bytes of one snowflake sprite (size x size), fading to nothing well inside its edges.
    dot: a small soft flake; clump: a few lumps stuck together; streak: a fast near flake, motion-blurred;
    bokeh: a big out-of-focus flake right in front of the camera (a soft, faint disc)."""
    c = (size - 1) / 2.0
    blobs = [(c, c, size * 0.17, 1.0)]
    if kind == "clump":
        blobs = [(c + rng.uniform(-1, 1) * size * 0.11, c + rng.uniform(-1, 1) * size * 0.11, size * rng.uniform(0.09, 0.13),
                  rng.uniform(0.75, 1.0)) for _ in range(5)]
    stretch = 1.7 if kind == "streak" else 1.0
    buf = bytearray(size * size * 4)
    tint = rng.uniform(0, 1)
    for y in range(size):
        for x in range(size):
            dxc, dyc = (x - c) / (c + 0.5), (y - c) / (c + 0.5)
            edge = max(0.0, 1.0 - (dxc * dxc + dyc * dyc)) ** 1.5     # 0 at the sprite's rim: no square edges
            if kind == "bokeh":
                r = math.hypot(dxc, dyc)
                a = 0.55 * max(0.0, min(1.0, (0.86 - r) / 0.22)) * (0.85 + 0.15 * (1 - r))
            else:
                a = 0.0
                for bx, by, rr, s in blobs:
                    dx, dy = (x - bx), (y - by) / stretch
                    a += s * math.exp(-(dx * dx + dy * dy) / (2 * rr * rr))
                a = min(1.0, a * 1.15) * edge
            if a < 0.01:
                continue
            A = int(255 * a)
            g = min(255, int(248 + 6 * tint)); rd = min(255, int(240 + 12 * tint))
            i = (y * size + x) * 4
            buf[i:i + 4] = bytes((255 * A // 255, g * A // 255, rd * A // 255, A))
    return bytes(buf)


def run(should_stop, focus_hwnd=None):
    """Snow until should_stop() is true. focus_hwnd: the game window, handed the focus back should we ever take it."""
    if not u32:
        return
    _setup()
    try:                                                           # real pixels on a scaled (125%, 150%) display
        u32.SetThreadDpiAwarenessContext.restype = ctypes.c_void_p
        u32.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))      # per-monitor aware v2 (Windows 10+)
    except Exception:
        pass
    rng = random.Random()
    SW, SH = u32.GetSystemMetrics(0), u32.GetSystemMetrics(1)
    hinst = k32.GetModuleHandleW(None)
    proc = WNDPROC(lambda h, m, wp, lp: u32.DefWindowProcW(h, m, wp, lp))
    cls = WNDCLASSEXW()
    cls.cbSize = ctypes.sizeof(WNDCLASSEXW)
    cls.lpfnWndProc = ctypes.cast(proc, ctypes.c_void_p)
    cls.hInstance = hinst
    cls.lpszClassName = "OutlawsSnowFx%d" % rng.randrange(1 << 30)
    u32.RegisterClassExW(ctypes.byref(cls))
    ex = 0x00080000 | 0x00000020 | 0x00000080 | 0x08000000 | 0x00000008   # LAYERED TRANSPARENT TOOLWINDOW NOACTIVATE TOPMOST
    hwnd = u32.CreateWindowExW(ex, cls.lpszClassName, "snow", 0x80000000, 0, 0, SW, SH, None, None, hinst, None)
    if not hwnd:
        return
    screen = u32.GetDC(None)
    mem = g32.CreateCompatibleDC(screen)
    hbm, bits = _dib(screen, SW, SH)
    old = g32.SelectObject(mem, hbm)
    nbytes = SW * SH * 4

    # sprite sheet: one small DIB per flake variant
    sprites = []
    for size, kind in [(6, "dot"), (7, "dot"), (9, "dot"), (10, "dot"), (12, "dot"), (14, "clump"), (15, "dot"),
                       (18, "clump"), (20, "clump"), (22, "streak"), (24, "clump"), (28, "streak"), (30, "clump"),
                       (38, "bokeh"), (48, "bokeh")]:
        dc = g32.CreateCompatibleDC(screen)
        sb, sbits = _dib(screen, size, size)
        g32.SelectObject(dc, sb)
        px = _flake_pixels(size, kind, rng)
        ctypes.memmove(sbits, px, len(px))
        sprites.append((size, dc, sb))

    def new_flake(y=None):
        depth = rng.random() ** 1.4                                  # most flakes far away
        if depth < 0.55: k = rng.randrange(0, 4)
        elif depth < 0.85: k = rng.randrange(3, 8)
        elif depth < 0.985: k = rng.randrange(7, 13)
        else: k = rng.randrange(13, len(sprites))                    # now and then one drifts right past the camera
        return dict(x=rng.uniform(-40, SW + 40), y=rng.uniform(-SH, SH) if y is None else y, k=k,
                    vy=(28 + 120 * depth) * SH / 1080 * rng.uniform(0.8, 1.2), depth=depth,
                    sway=rng.uniform(6, 30) * (0.3 + depth), ph=rng.uniform(0, 6.3), w=rng.uniform(0.4, 1.4),
                    alpha=int(110 + 120 * (1 - abs(depth - 0.6))) if depth < 0.9 else int(150 + 60 * rng.random()))

    flakes = [new_flake() for _ in range(int(DENSITY * SW * SH / (1920 * 1080)))]
    wind, wind_to = 0.0, rng.uniform(-25, 25)
    pt0, sz, ptw = W.POINT(0, 0), W.SIZE(SW, SH), W.POINT(0, 0)
    bf_out = BLENDFUNCTION(0, 0, 255, 1)
    u32.ShowWindow(hwnd, 4)                                            # SW_SHOWNOACTIVATE
    u32.SetWindowPos(hwnd, W.HWND(-1), 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)
    msg = W.MSG()
    last = time.time()
    fg0 = focus_hwnd or u32.GetForegroundWindow()
    try:
        while not should_stop():
            while u32.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
                u32.TranslateMessage(ctypes.byref(msg)); u32.DispatchMessageW(ctypes.byref(msg))
            now = time.time(); dt = min(0.1, now - last); last = now
            wind += (wind_to - wind) * 0.01
            if rng.random() < 0.003: wind_to = rng.uniform(-35, 35)        # gusts
            ctypes.memset(bits, 0, nbytes)
            for f in flakes:
                f["y"] += f["vy"] * dt
                f["ph"] += f["w"] * dt
                f["x"] += wind * (0.4 + f["depth"]) * dt
                if f["y"] > SH + 20:
                    f.update(new_flake(y=-rng.uniform(10, 80)))
                if f["x"] < -60: f["x"] += SW + 120
                elif f["x"] > SW + 60: f["x"] -= SW + 120
                size, dc, _sb = sprites[f["k"]]
                x = int(f["x"] + math.sin(f["ph"]) * f["sway"]) - size // 2
                y = int(f["y"]) - size // 2
                if x + size < 0 or y + size < 0 or x >= SW or y >= SH:
                    continue
                msimg.AlphaBlend(mem, x, y, size, size, dc, 0, 0, size, size, BLENDFUNCTION(0, 0, f["alpha"], 1))
            u32.UpdateLayeredWindow(hwnd, screen, ctypes.byref(pt0), ctypes.byref(sz), mem, ctypes.byref(ptw), 0,
                                    ctypes.byref(bf_out), 2)
            try:
                if fg0 and u32.GetForegroundWindow() == hwnd: u32.SetForegroundWindow(fg0)
            except Exception:
                pass
            spare = 1.0 / FPS - (time.time() - now)
            if spare > 0: time.sleep(spare)
    finally:
        u32.DestroyWindow(hwnd)
        g32.SelectObject(mem, old); g32.DeleteObject(hbm); g32.DeleteDC(mem)
        for _s, dc, sb in sprites:
            g32.DeleteDC(dc); g32.DeleteObject(sb)
        u32.ReleaseDC(None, screen)
