"""Pathing check: plays bots alone on each map and reports where they got stuck.

    pathcheck.cmd                      every map, 4 minutes each
    pathcheck.cmd --minutes 2 --maps hargrove fort
    pathcheck.cmd --report-only        just rebuild the report from the data already collected

Close your own Outlaws window first: the script ends every OutlawsAHOM.exe between maps.
Results: pathcheck_report.txt (read this) and pathcheck_data.csv (every stuck event: map, bot, time, kind, x, y, z).
The x/z values are the game's world coordinates, the same ones the bots print in their logs.
"""
import argparse
import os
import collections
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE / "pathcheck_data.csv"
REPORT = HERE / "pathcheck_report.txt"
LOGS = HERE / "pathcheck_logs"
BOTS = ["pc1:james", "pc2:mary", "pc3:bob"]
CELL = 8.0                                  # stuck events within this many units count as one place


def run_quiet(*cmd):
    subprocess.run(list(cmd), capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


GLOBAL_KILL = True      # --lane runs set this False: they must only end their own games


def kill_everything(procs, logs=()):
    for p in procs:
        run_quiet("taskkill", "/PID", str(p.pid), "/T", "/F")
    for path in logs:                           # the game copies, from "started NAME (pid N)" in each bot's log
        try:
            for pid in re.findall(r"\(pid (\d+)\)", Path(path).read_text(errors="replace")):
                run_quiet("taskkill", "/PID", pid, "/F")
        except OSError:
            pass
    if GLOBAL_KILL:
        run_quiet("taskkill", "/IM", "OutlawsAHOM.exe", "/F")


def pump(p, path):
    with open(path, "w", errors="replace") as f:
        for line in p.stdout:
            f.write(line)
            f.flush()


def play_map(level, mode, minutes, env, lane=0):
    LOGS.mkdir(exist_ok=True)
    procs = []
    bots = [f"pc{lane * 3 + i + 1}:{b.split(':')[1]}" for i, b in enumerate(BOTS)]     # own names = own profile folders
    idle_host = bool(os.environ.get("PATHCHECK_IDLE_HOST"))      # gun game: a host copy that doesn't play
    if idle_host:
        bots = [f"pc{lane * 3 + 4}:{BOTS[0].split(':')[1]}"] + bots
    logs = [LOGS / f"{level}_{b.split(':')[0]}.log" for b in bots]
    tags = [t for t in os.environ.get("PATHCHECK_TAGS", "").split("|") if t]      # per joining bot: "nightmare:lv_nightmare|lv_easiest|lv_easiest"
    for k, t in enumerate(tags):
        j = k + (1 if idle_host else 0)
        if j < len(bots):
            bots[j] = bots[j] + ":" + t

    def start(i, host):
        cmd = [sys.executable, "-u", str(HERE / "botctl.py"), bots[i], "--slot", str(i), "--fps", "60",
               "--size", "320x180"] + ([] if idle_host and host else ["--fight"]) + ["--no-taunts", "--window-mode", os.environ.get("PATHCHECK_WINDOWS", "hidden"), "--no-bench"]
        if host:
            cmd += ["--host", "--map", level, "--mode", mode, "--wait-for", "0"]
        else:
            cmd += ["--join", "127.0.0.1"]
        e = dict(env, BOT_TAG=bots[i].split(":")[0], PYTHONUNBUFFERED="1")
        if bots[i].split(":")[0] in os.environ.get("PATHCHECK_NOSTATS", "").split(","):
            e.pop("BOT_STATS_PLAYER", None)          # this bot stands in for the human (it publishes no position)
        p = subprocess.Popen(cmd, cwd=str(HERE), env=e, stdin=subprocess.PIPE if idle_host and host else None, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        threading.Thread(target=pump, args=(p, LOGS / f"{level}_{bots[i].split(':')[0]}.log"), daemon=True).start()
        procs.append(p)
        return p

    try:
        host = start(0, True)
        log0 = logs[0]
        end = time.time() + 150
        while time.time() < end and host.poll() is None:          # the host's lobby is up once it has attached
            time.sleep(2)
            try:
                if "attached to" in log0.read_text(errors="replace"):
                    break
            except OSError:
                pass
        if host.poll() is not None:
            print(f"  the host bot exited early (see {log0.name})")
            return False
        time.sleep(12)
        for i in range(1, len(bots)):
            start(i, False)
            time.sleep(8)
        print(f"  {len(bots)} bots playing for {minutes} min...")
        end = time.time() + minutes * 60
        while time.time() < end:
            time.sleep(5)
        return True
    finally:
        kill_everything(procs, logs)
        time.sleep(4)


def build_report():
    rows = []
    if DATA.exists():
        for line in DATA.read_text().splitlines():
            parts = line.split(",")
            if len(parts) == 7:
                try:
                    rows.append((parts[0], parts[1], float(parts[2]), parts[3], float(parts[4]), float(parts[5]),
                                 float(parts[6])))
                except ValueError:
                    pass
    out = ["Pathing check report", "=" * 20, "",
           "Each place is where bots stopped making progress (stuck) or gave up on a route (give-up).",
           "Coordinates are world x, y (height), z. Give-ups are the strongest signal: a route the map data says is",
           "open but the bot could not get through.", ""]
    by_map = collections.defaultdict(list)
    for r in rows:
        by_map[r[0]].append(r)
    if not by_map:
        out.append("No stuck events were recorded.")
    for level in sorted(by_map):
        cells = collections.defaultdict(list)
        for r in by_map[level]:
            cells[(round(r[4] / CELL), round(r[6] / CELL))].append(r)
        ranked = sorted(cells.values(), key=lambda c: (-sum(1 for r in c if r[3].startswith("giveup")), -len(c)))
        out.append(f"{level}: {len(by_map[level])} events in {len(cells)} places")
        for c in ranked[:12]:
            n_give = sum(1 for r in c if r[3].startswith("giveup"))
            xs = sorted(r[4] for r in c)
            ys = sorted(r[5] for r in c if r[5])
            zs = sorted(r[6] for r in c)
            med = lambda v: v[len(v) // 2]
            who = len({r[1] for r in c})
            out.append(f"   x={med(xs):7.1f}  z={med(zs):7.1f}  y={med(ys) if ys else float('nan'):6.1f}   "
                       f"{len(c)} times ({n_give} give-ups), {who} bot(s)")
        out.append("")
    try:
        REPORT.write_text("\n".join(out))
    except OSError:
        pass                                            # another lane is writing it
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--minutes", type=float, default=4.0, help="per map (default 4)")
    ap.add_argument("--maps", nargs="*", help="maps to check (default: every standard map)")
    ap.add_argument("--report-only", action="store_true")
    ap.add_argument("--keep", action="store_true", help="keep data from earlier runs (default: start fresh)")
    ap.add_argument("--maps-file", help="a text file with one map key per line (instead of --maps)")
    ap.add_argument("--lane", type=int, default=0, help="which of several runs sharing this PC (own bot names); lane > 0 never ends other games")
    ap.add_argument("--no-global-kill", action="store_true", help="end only this run's own games, not every OutlawsAHOM.exe")
    ap.add_argument("--resume", action="store_true", help="skip maps already listed in sweep_done.txt (implies --keep)")
    args = ap.parse_args()
    global GLOBAL_KILL
    GLOBAL_KILL = not (args.no_global_kill or args.lane > 0)
    if args.report_only:
        print(build_report())
        return
    sys.path.insert(0, str(HERE))
    from botctl import MAPS, MODES, map_modes
    maps = args.maps or list(MAPS)
    if args.maps_file:
        maps = [l.strip() for l in Path(args.maps_file).read_text().splitlines() if l.strip()]
    done_file = HERE / "sweep_done.txt"
    if args.resume:
        args.keep = True
        have = set(done_file.read_text().split()) if done_file.exists() else set()
        maps = [m for m in maps if m not in have]
    for m in maps:
        if m not in MAPS:
            if args.maps_file:
                print(f"skipping unknown map {m!r}")
                continue
            sys.exit(f"unknown map {m!r}; maps: {', '.join(MAPS)}")
    maps = [m for m in maps if m in MAPS]
    if not args.keep and DATA.exists():
        DATA.unlink()
    if GLOBAL_KILL:
        print("Close your own Outlaws window now: it gets ended between maps.")
    for k, level in enumerate(maps, 1):
        modes = map_modes(level)
        mode = next((name for name in ("dm", "team", "ctf", "doc", "tag", "chicken")
                     if not modes or MODES[name][1] in modes), "dm")
        print(f"[{k}/{len(maps)}] {MAPS[level]} ({level}, {mode})")
        import os
        env = dict(os.environ, BOT_STUCK_LOG=str(DATA), BOT_MAP=level, BOT_NO_GATLING="1")
        t0 = time.time()
        ok = play_map(level, mode, args.minutes, env, args.lane)
        try:
            build_report()                              # so a partial run still leaves a report
        except OSError:
            pass                                        # another lane has the file open
        with open(done_file, "a") as f:
            f.write(f"{level}\n")
        with open(HERE / "sweep_log.txt", "a") as f:
            f.write(f"{level} {mode} {'ok' if ok else 'FAILED to start'} {time.time() - t0:.0f}s\n")
    print()
    print(build_report())
    print(f"\nSaved to {REPORT}")


if __name__ == "__main__":
    main()
