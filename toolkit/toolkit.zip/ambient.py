"""Creepy background loop for Survival: python ambient.py <run id> <horde.py pid> [wav]
Plays sounds\\horde_ambient.wav over and over (its own mixer, so game sounds and the thunder play on top of it) until
horde.py writes state\\stop_<run id> or ends. The file is a synthesised dark drone with wind, distant bells and creaks."""
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def alive(pid):
    try:
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)        # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(h)
        return code.value == 259                                          # STILL_ACTIVE
    except Exception:
        return True


def note(msg):
    """A line in horde_logs\\music_log.txt, so a run shows when the music started and why it stopped."""
    try:
        with open(HERE / "horde_logs" / "music_log.txt", "a") as f:
            f.write(time.strftime("%H:%M:%S ") + msg + "\n")
    except OSError:
        pass


def main():
    run = sys.argv[1] if len(sys.argv) > 1 else ""
    parent = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    wav = Path(sys.argv[3]) if len(sys.argv) > 3 else HERE / "sounds" / "horde_ambient.wav"
    if not wav.exists():
        return
    import winsound
    stop = HERE / "state" / f"stop_{run}"
    over = HERE / "state" / f"music_stop_{run}"               # written by horde.py when the match ends (scoreboard)
    human = HERE / "state" / f"human_{run}.flag"             # written by the host bot when a player is on the Survivors team
    fade = wav.with_name(wav.stem + "_fadein15.wav")
    length = 0.0
    try:                                                      # a copy whose first 15 seconds rise from silence (made once, while we wait)
        import array
        import wave
        with wave.open(str(wav), "rb") as src:
            prm = src.getparams()
            length = prm.nframes / float(prm.framerate)
            if not fade.exists() or fade.stat().st_mtime < wav.stat().st_mtime:
                if prm.sampwidth == 2:
                    a = array.array("h")
                    a.frombytes(src.readframes(prm.nframes))
                    ramp = int(15.0 * prm.framerate)
                    ch = prm.nchannels
                    for i in range(min(ramp, prm.nframes)):
                        g = (i / ramp) ** 2                   # starts at silence, rises slowly, then faster
                        for c in range(ch):
                            a[i * ch + c] = int(a[i * ch + c] * g)
                    with wave.open(str(fade), "wb") as dst:
                        dst.setparams(prm)
                        dst.writeframes(a.tobytes())
                else:
                    length = 0.0
    except Exception:
        length = 0.0
    while not human.exists():                                 # no music until then
        if stop.exists() or over.exists() or (parent and not alive(parent)):
            return
        time.sleep(0.5)
    began = time.time()
    if length and fade.exists():                              # fade in once, then the plain loop carries on
        winsound.PlaySound(str(fade), winsound.SND_FILENAME | winsound.SND_ASYNC)
        note("music started (fading in)")
    else:
        winsound.PlaySound(str(wav), winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP)
        note("music started")
        length = 0.0
    try:
        while not stop.exists() and not over.exists() and (not parent or alive(parent)):
            if length and time.time() - began >= length - 0.05:
                winsound.PlaySound(str(wav), winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP)
                length = 0.0
            time.sleep(0.05 if length else 1.0)
    finally:
        winsound.PlaySound(None, winsound.SND_PURGE)
        note("music stopped (" + ("match over" if over.exists() else "game ended" if stop.exists() else "horde.py gone") + ")")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
