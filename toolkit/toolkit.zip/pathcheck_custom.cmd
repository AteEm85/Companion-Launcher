@echo off
rem 2-minute pathing check on the custom maps from the pathing pass (Beer for my Horses ... Tortilla Flats).
rem Close your own Outlaws window first. Results: pathcheck_report.txt. Leave it running; pathcheck_done.txt appears at the end.
cd /d "%~dp0"
del pathcheck_done.txt >nul 2>&1
".venv\Scripts\python.exe" -u pathcheck.py --minutes 2 --maps beerforh Mud2 Boxyard bridged Cwbys2 deadwcty deadwmod dookes Dust grannys hasselt Jalapeno junction ESTATE loonytun man2man Nacho Nuketown OlMexico pineflat Prair2s Tequila Vodka texcajun Volcano Volcano2 Tortilla > pathcheck_run.txt 2>&1
echo finished > pathcheck_done.txt
