"""The launcher's Tools tab: the online games list, saved setups, a health check, the host PC's status, problem reports
and the match history.

launcher.py loads this file from disk every time it starts (its _disk helper), so a change here needs no rebuild of
BotLauncher.exe. Only the standard library is used, and only modules launcher.py imports too (a built exe carries
nothing else). If anything here fails, the launcher itself keeps working: every call from it goes through App.tool().

  Online games     the games hosted online right now (onlinegames.py asks the game's online service)
  Saved setups     whole-launcher presets (every tab's settings) in launcher_setups.json; loading one restarts the launcher
  Health check     the things that have stopped games before (sound device, Steam, the bots' Python, stale launcher ...)
  Host PC          another PC at home running the Map Rotation as a host server answers on port 8790: what it is doing,
                   whether its files match this PC's, its match history and a problem report
  Problem report   one zip with the logs, settings, a screenshot and the health check (reports\\problem_<time>.zip)
  Match history    who won each ghost match (kills, deaths, best streak), from the ghost players' logs
"""
import datetime
import hashlib
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tkinter import messagebox, simpledialog, ttk
from urllib.parse import parse_qs, quote, urlparse

HOST_PORT = 8790                 # the host PC's status answers here (TCP), and "is a host there?" broadcasts (UDP); not 8765/8766: modserver.py has those
HELLO, HERE_I_AM = b"OUTLAWS_HOST?", b"OUTLAWS_HOST "
SETUP_SLOTS = 12
HISTORY_KEEP = 300
ARCHIVE_KEEP = 60                # matches whose ghost logs are kept (GhostLogs\archive; ~16 hours of a rotation, the text logs are small)
KEY_FILES = ["launcher.py", "launchertools.py", "botctl.py", "brain.py", "rotation.py", "ghost.py", "fighter.py", "nav.py",
             "horde.py", "input_agent.js", "lobbysize.py"]
NEEDED_FILES = ["botctl.py", "brain.py", "input_agent.js", "bots.cmd", "rotation.py", "ghost.py", "fighter.py", "nav.py",
                "ghostscript2.json", "maps_data.json", "requirements.txt"]
KILL_RE = re.compile(r"^kill message sent: \$\$(\d+)\$\$(.*?)\$\$(?:(.*?)\$\$)?\s*$")
PLAYER_IN_RE = re.compile(r"^a player is in \((.*)\): fighting")
OK, NOTE, BAD = "ok", "note", "bad"


def _ps(command, timeout=25):
    """Run a PowerShell one-liner; its output, or None when it can't be asked (not Windows, an error, too slow)."""
    if os.name != "nt":
        return None
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", command], capture_output=True, text=True,
                           timeout=timeout, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.SubprocessError):
        return None
    return r.stdout if r.returncode == 0 else None


def _tail(path, limit):
    """The last `limit` bytes of a file (all of it when smaller)."""
    with open(path, "rb") as f:
        f.seek(0, 2)
        size = f.tell()
        f.seek(max(0, size - limit))
        data = f.read()
    return (b"[... the first %d bytes are left out ...]\n" % (size - limit) if size > limit else b"") + data


def _when(t):
    return datetime.datetime.fromtimestamp(t).strftime("%b %d, %I:%M %p").replace(" 0", " ")


def local_ips():
    """This PC's IPv4 addresses on its networks (not 127.x)."""
    out = []
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if not ip.startswith("127.") and ip not in out:
                out.append(ip)
    except OSError:
        pass
    try:                                                   # (the address the default route uses, if the name lookup missed it)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.168.255.255", 9))
        ip = s.getsockname()[0]
        s.close()
        if not ip.startswith("127.") and ip not in out:
            out.insert(0, ip)
    except OSError:
        pass
    return out


def score_table(events, ghost_names):
    """[(time, how, killer, victim)] in order -> rows [{name, kills, deaths, streak, ghost}] best first.
    how: 'kill' / 'tnt' / 'self'. Only ghost players report their deaths, so deaths is None for everyone else."""
    ghosts = set(ghost_names)
    rows, run = {}, {}
    def row(name):
        if name not in rows:
            rows[name] = {"name": name, "kills": 0, "deaths": 0, "suicides": 0, "streak": 0, "ghost": name in ghosts}
            run[name] = 0
        return rows[name]
    for _t, how, killer, victim in sorted(events, key=lambda e: e[0]):
        v = row(victim)
        v["deaths"] += 1
        run[victim] = 0
        if how == "self" or killer == victim:
            v["suicides"] += 1
            continue
        k = row(killer)
        k["kills"] += 1
        run[killer] += 1
        k["streak"] = max(k["streak"], run[killer])
    for r in rows.values():
        if not r["ghost"]:
            r["deaths"] = None                             # (a real player's or a bot's deaths never reach a ghost's log)
    return sorted(rows.values(), key=lambda r: (-r["kills"], r["deaths"] if r["deaths"] is not None else 0, r["name"].lower()))


def _disk_mod(here, name):
    """a helper module from its .py file in botctl (the built launcher carries no copy of these: they are new)"""
    import importlib.util
    p = Path(here) / f"{name}.py"
    if not p.exists():
        return None
    if str(here) not in sys.path:
        sys.path.insert(0, str(here))
    spec = importlib.util.spec_from_file_location(name, str(p))
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


class Tools:
    def __init__(self, app, saved):
        self.app = app
        self.L = sys.modules[type(app).__module__]          # launcher.py's own names (HERE, MAPS, bot_game_pids ...)
        self.HERE = Path(self.L.HERE)
        self.t0 = time.time()
        self.cfg_file = self.HERE / "tools_settings.json"
        self.setups_file = self.HERE / "launcher_setups.json"
        self.history_file = self.HERE / "match_history.json"
        self.cfg = self._read(self.cfg_file, {})
        self.setups = self._read(self.setups_file, [])
        if not isinstance(self.setups, list):
            self.setups = []
        self.health_last, self.health_at = [], 0.0
        self.match, self.match_lock = None, threading.Lock()
        self.cur_map, self.cur_map_at, self.maps_played = "", 0.0, 0
        self.players_in, self.ghosts_fighting = [], 0
        self.copies, self.copies_at = None, 0.0
        self.server = None
        self._sha_cache = {}
        self.build(saved)
        tab = saved.get("_open_tab")                        # (a setup that was just loaded: back to the tab it was saved on)
        if isinstance(tab, int):
            try: app.nb.select(tab)
            except Exception: pass
        app.after(4000, lambda: self.health_run(quiet=True))
        self.status_page()
        app.after(3000, self.mission_chain)
        app.after(5000, self.mods_watch)

    def start_mission(self, mid, chained=False):
        """Set the Game Modes tab up for a Co-op Mission (Christmas Survival Horde, ghosts, its map) and launch it; horde.py
        reads the mission from state/next_mission.json."""
        app = self.app
        self.cleanup_cancel()
        try:
            ms = sys.modules.get("missions") or _disk_mod(self.HERE, "missions")
            m = ms.get(mid)
            if not m:
                return False
            (self.HERE / "state").mkdir(exist_ok=True)
            (self.HERE / "state" / "next_mission.json").write_text(json.dumps({"id": m["id"], "t": time.time()}))
            app.gm_mode.set("Survival Horde")
            app.gm_hmode.set("Christmas")
            for var, val in (("gm_opp", "Ghosts"), ("gm_ranked", False), ("gm_classic", False)):
                try: getattr(app, var).set(val)
                except Exception: pass
            app.gm_map.set(self.map_label(m["map"]))
            app.say(f"starting {ms.label(m)} on {self.map_label(m['map'])}")
            self.hud_watch()
            # (21 Nov, the user: the next mission never came - Windows' "allow" prompt for turning ZeroTier on sat hidden
            #  behind the game. A mission that follows another skips the ZeroTier check: the first one did it already.)
            app.launch_mode(zt_ok=chained)
            return True
        except Exception as e:
            try: messagebox.showerror("Christmas Missions", f"Could not start the mission: {e}")
            except Exception: pass
            return False

    def hud_watch(self):
        """(24 Nov, the user: a friend got no step text and no banners) a PC whose bots' Python has no tkinter can't open
        tierhud.py's windows, so horde.py asks for them here (state/hud_request_<run>.txt, holding its pid) and the
        launcher shows them itself: tierhud.in_launcher, as windows of its own. Polls once a second, one watcher."""
        if getattr(self, "_hud_watching", False):
            return
        self._hud_watching = True
        app, st = self.app, self.HERE / "state"

        def poll():
            try:
                for f in st.glob("hud_request_*.txt"):
                    run = f.stem[len("hud_request_"):]
                    try: pid = int(f.read_text().strip() or 0)
                    except (OSError, ValueError): pid = 0
                    try: f.unlink()
                    except OSError: pass
                    th = sys.modules.get("tierhud") or _disk_mod(self.HERE, "tierhud")
                    th.in_launcher(app, run, pid)
                    try: app.say("the mission text and banners: shown by the launcher (this PC's Python has no tkinter)")
                    except Exception: pass
            except Exception as e:
                try: app.say(f"mission text: {e}")
                except Exception: pass
            app.after(1000, poll)
        poll()

    # ---- the Christmas Missions' files for a new player -------------------------------------------------------------------
    # (24 Nov, the user: a new player who clicks Start Missions gets every file the missions need, from GitHub, if any are
    #  missing.) The art, sounds and music in botctl\christmas\ are too big for the launcher's own repo (and it is
    #  private), so make_xmas_pack.py packs them into the public Bot-Launcher-Files repo (its main branch, zips under 100 MB):
    #  christmas_files.json lists every file (size, sha256, which zip part holds it). Only the parts holding missing files
    #  are fetched, each checked against its sha256, and only the missing files are unpacked.
    XMAS_FILES_URL = "https://raw.githubusercontent.com/AteEm85/Bot-Launcher-Files/main/"

    def _xmas_get(self, name, dest=None, progress=None, size=None):
        """a file from the Bot-Launcher-Files repo. Into dest: (25 Nov, a friend's "came down damaged") a dropped connection
        no longer leaves a cut-short file - it picks up where it stopped (an HTTP range), up to 6 tries, until all `size`
        bytes are there"""
        if dest is None:
            req = urllib.request.Request(self.XMAS_FILES_URL + name, headers={"User-Agent": "OutlawsBotLauncher"})
            with urllib.request.urlopen(req, timeout=8) as r:
                return r.read()
        dest = Path(dest)
        try: dest.unlink()
        except OSError: pass
        last = None
        for attempt in range(6):
            have = dest.stat().st_size if dest.exists() else 0
            if size and have >= size:
                break
            hdr = {"User-Agent": "OutlawsBotLauncher", "Cache-Control": "no-cache"}
            if have: hdr["Range"] = f"bytes={have}-"
            try:
                req = urllib.request.Request(self.XMAS_FILES_URL + name, headers=hdr)
                with urllib.request.urlopen(req, timeout=60) as r:
                    if have and getattr(r, "status", 200) != 206:      # (the server sent it all again: start over)
                        have = 0
                    with open(dest, "ab" if have else "wb") as f:
                        got = have
                        for blk in iter(lambda: r.read(1 << 16), b""):
                            f.write(blk); got += len(blk)
                            if progress and got % (1 << 20) < len(blk): progress(got)     # (about once a megabyte)
                if not size:
                    return None
            except Exception as e:
                last = e
                time.sleep(2 + attempt * 2)
        if size and (not dest.exists() or dest.stat().st_size != size):
            raise RuntimeError(f"{name}: the download kept stopping ({last or 'cut short'})")
        return None

    def mission_files_missing(self, man):
        """[(rel path, size, sha, part)] of the manifest's files not on this PC (absent, another size, or (25 Nov) the same size
        but other contents - Mrs. Claus redrawn is byte for byte as big as before). Each file's sha256 is worked out once and
        kept in state\\mod_files_sha.json with its size and time, so later checks only hash a file that changed."""
        import hashlib
        cp = self.HERE / "state" / "mod_files_sha.json"
        try: cache = json.loads(cp.read_text())
        except (OSError, ValueError): cache = {}
        out, dirty = [], False
        for rel, (size, sha, part) in man.get("files", {}).items():
            p = self.HERE.joinpath(*rel.split("/"))
            try:
                stt = p.stat() if p.is_file() else None
            except OSError:
                stt = None
            if stt is None or stt.st_size != size:
                out.append((rel, size, sha, part)); continue
            c = cache.get(rel)
            if not (c and c[1] == stt.st_size and abs(c[2] - stt.st_mtime) < 0.01):
                h = hashlib.sha256()
                try:
                    with p.open("rb") as f:
                        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
                except OSError:
                    out.append((rel, size, sha, part)); continue
                c = cache[rel] = [h.hexdigest(), stt.st_size, stt.st_mtime]; dirty = True
            if c[0] != sha:
                out.append((rel, size, sha, part))
        if dirty:
            try:
                cp.parent.mkdir(exist_ok=True); cp.write_text(json.dumps(cache))
            except OSError:
                pass
        return out

    def ensure_mission_files(self, then):
        self.ensure_files("christmas", then)

    MOD_SETS = {"christmas": "Christmas Missions", "zombie": "Zombie Horde"}

    def ensure_files(self, set_, then):
        """Check (and if needed fetch) one set of mod files - "christmas" or "zombie" (25 Nov: the zombie skins too, so
        Delete Mods from PC can take them) - then call then(), on the launcher's own thread. Offline or no list on
        GitHub: then() straight away (a PC that has the files plays as before)."""
        app = self.app
        what = self.MOD_SETS.get(set_, set_)
        try:
            man = json.loads(self._xmas_get(f"{set_}_files.json"))
        except Exception as e:
            try: app.say(f"{what} files: could not check GitHub ({e}) - going on with what this PC has")
            except Exception: pass
            then(); return
        if not (self.HERE / "state" / "mod_files_sha.json").exists():
            try: app.say(f"{what} files: checking the files on this PC (the first time takes a little while)..."); app.update_idletasks()
            except Exception: pass
        missing = self.mission_files_missing(man)
        if not missing:
            then(); return
        parts = sorted({m[3] for m in missing})
        pinfo = {i + 1: p for i, p in enumerate(man.get("parts", []))}
        total = sum(pinfo[k]["size"] for k in parts if k in pinfo) or 1
        w = tk.Toplevel(app)
        w.title(what)
        w.transient(app); w.resizable(False, False)
        ttk.Label(w, text=f"Getting the {what} files ({len(missing)} missing on this PC)...",
                  wraplength=420).pack(padx=16, pady=(14, 6), anchor="w")
        bar = ttk.Progressbar(w, length=420, maximum=total)
        bar.pack(padx=16, pady=4)
        txt = tk.StringVar(value="starting...")
        ttk.Label(w, textvariable=txt).pack(padx=16, pady=(0, 14), anchor="w")
        w.protocol("WM_DELETE_WINDOW", lambda: None)          # (closes itself when done)
        done_mb = [0]

        def ui(fn):
            try: app.after(0, fn)
            except Exception: pass

        def work():
            dl = self.HERE / "_xmas_dl"
            err = None
            try:
                dl.mkdir(exist_ok=True)
                want = {m[0] for m in missing}
                for k in parts:
                    info = pinfo.get(k)
                    if not info:
                        raise RuntimeError(f"part {k} is not in the list on GitHub")
                    zp = dl / info["name"]
                    base = done_mb[0]
                    def prog(got, base=base):
                        ui(lambda: (bar.configure(value=base + got),
                                    txt.set(f"{(base + got) / 1e6:.0f} of {total / 1e6:.0f} MB")))
                    for t_ in range(2):                    # (damaged after all: once more from the start)
                        self._xmas_get(info["name"], zp, prog, size=info.get("size"))
                        h = hashlib.sha256()
                        with open(zp, "rb") as f:
                            for blk in iter(lambda: f.read(1 << 20), b""): h.update(blk)
                        if h.hexdigest() == info["sha256"]:
                            break
                        if t_:
                            raise RuntimeError(f"{info['name']} came down damaged twice - try again")
                    ui(lambda: txt.set("unpacking..."))
                    with zipfile.ZipFile(zp) as z:
                        for n in z.namelist():
                            if n in want:
                                dest = self.HERE.joinpath(*n.split("/"))
                                dest.parent.mkdir(parents=True, exist_ok=True)
                                tmp = dest.with_name(dest.name + ".part")
                                with z.open(n) as src, open(tmp, "wb") as out:
                                    shutil.copyfileobj(src, out)
                                os.replace(tmp, dest)
                    try: zp.unlink()
                    except OSError: pass
                    done_mb[0] += info["size"]
            except Exception as e:
                err = e
            def finish():
                try: w.destroy()
                except Exception: pass
                left = self.mission_files_missing(man)
                if err or left:
                    messagebox.showerror(what,
                                         f"Could not get all of the {what} files ({len(left)} still missing).\n\n{err or ''}\n\n"
                                         "Check the internet connection and click Start again.")
                    return
                try: app.say(f"{what} files: {len(missing)} downloaded from GitHub")
                except Exception: pass
                then()
            ui(finish)

        threading.Thread(target=work, daemon=True).start()

    def cleanup_cancel(self):
        """a new game mode is starting: a mods cleanup still waiting for the last game to close must not run under it"""
        p = getattr(self, "_cleanup_p", None)
        if p is not None and p.poll() is None:
            try: p.kill()
            except Exception: pass
        self._cleanup_p = None

    def mods_watch(self):
        """(25 Nov, the user: after the Christmas Missions, a Horde game and so on, take the mods off by themselves, so the game
        loads normally for online games) Once a game mode has ended - and no next mission is on its way - mods_off.cmd's
        cleanup runs in the background (companionhost.py --cleanup): it waits until every game window is closed, then
        puts the game folder back (team colours and the winter look, elf / zombie skins, the changed map files). A new
        launch stops a cleanup that is still waiting. Looks every 2 seconds."""
        app = self.app
        if getattr(app, "server_mode", False) or getattr(app, "rotation_args", None):
            app.after(5000, self.mods_watch); return          # (a host server / the Map Rotation: map after map, left as it is)
        try:
            p = getattr(app, "bots_proc", None)
            if p is not None and p is not getattr(self, "_watched_p", None) and p.poll() is None:
                self._watched_p, self._watched_done = p, False
                self.cleanup_cancel()
            w = getattr(self, "_watched_p", None)
            if w is not None and not self._watched_done and w.poll() is not None:
                self._watched_done = True
                chain = (self.HERE / "state" / "mission_chain.json").exists() or time.time() - getattr(self, "_chaining", 0) < 120
                if not chain:
                    py = self.HERE / ".venv" / "Scripts" / "python.exe"
                    if py.exists() and (self.HERE / "companionhost.py").exists():
                        self._cleanup_p = subprocess.Popen([str(py), str(self.HERE / "companionhost.py"), "--cleanup"], cwd=str(self.HERE),
                                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=0x08000000)
                        app.say("the game mode has ended: the mods come out of the game folder once the game is closed")
        except Exception:
            pass
        app.after(2000, self.mods_watch)

    def mark_won(self):
        """state/mission_won.json: a mission was just won with another to come - follow.py holds the score screen 5 s"""
        try:
            (self.HERE / "state" / "mission_won.json").write_text(json.dumps({"t": time.time()}))
        except OSError:
            pass

    def mission_chain(self):
        """A Co-op Mission won: horde.py leaves state/mission_chain.json naming the next one. Once that game mode has
        finished, everything is closed and the next mission loads by itself (a look every 2 seconds)."""
        f = self.HERE / "state" / "mission_chain.json"
        try:
            if f.exists():
                job = json.loads(f.read_text())
                p = getattr(self.app, "bots_proc", None)
                if job.get("next") and getattr(self, "_notice_for", None) != job.get("t"):
                    self._notice_for = job.get("t")
                    self.app.after(4000, lambda t0=time.time(): self.loading_notice(t0))
                    self.mark_won()
                if time.time() - float(job.get("t", 0)) > 900:
                    f.unlink()
                elif (p is None or p.poll() is not None) and job.get("seamless") and (self.HERE / "state" / "chain_host.json").exists():
                    # (19 Nov) the host bot and your game stay: the next mission's horde.py hosts its map in the host's own game
                    # and your game follows by itself (follow.py) - nothing is closed or restarted
                    f.unlink()
                    nxt = job.get("next")
                    self.app.say(f"mission complete! the next mission loads in a moment, in the same game: {job.get('label', nxt)}")
                    self.app.seamless_next = True
                    self._chaining = time.time()
                    self.app.after(100, lambda: self.start_mission(nxt, chained=True))
                elif p is None or p.poll() is not None:
                    f.unlink()
                    nxt = job.get("next")
                    self.app.say(f"mission complete! the next mission loads in 10 seconds: {job.get('label', nxt)}")
                    self._chaining = time.time()
                    def work():
                        time.sleep(4)
                        self.app.cancel = True                 # (your game's watcher lets go; it looks every 2 seconds)
                        try: self.app.kill_all()
                        except Exception: pass
                        time.sleep(6)
                        self.app.after(0, lambda: self.start_mission(nxt, chained=True))
                    threading.Thread(target=work, daemon=True).start()
        except (OSError, ValueError):
            pass
        self.app.after(1000, self.mission_chain)          # (23 Nov: every second - the next mission as soon as it can)

    def mode_launch(self):
        app = self.app
        self.cleanup_cancel()
        try:
            args = app.mode_args()
        except Exception:
            args = []
        if args[:1] == ["horde.py"]:
            self.ensure_files("christmas" if "--christmas" in args else "zombie", app.launch_mode)
        else:
            app.launch_mode()

    # ---- the Online tab: find the LAN games (the hosting PC, a Horde game, a Christmas Mission) and join one ----------------
    # (25 Nov, the user) Search for games: ZeroTier first (installed, on, joined), then the same question the game's
    # Multiplayer > LAN screen asks (lanscan.py), out over every network at once; a list of the games, their real players
    # (bots and ghosts left out) and whether there is room; Join checks the game once more, puts in the host's mods (Horde,
    # Christmas: from the host's launcher, as the Companion does), starts your game, which joins it by itself, and takes the
    # mods out again when your game closes.
    def online_build(self):
        app, L = self.app, self.L
        PARCH = getattr(L, "PARCH", "#f3e6c8")
        f = tk.Frame(app.nb, bg=PARCH)
        try: app.nb.insert(2, f, text="  Online  ")
        except Exception: app.nb.add(f, text="  Online  ")
        self.on_frame = f
        # (25 Nov, the user: a character pick at the top right of this tab) the same choice as the Game Modes tab's "Your
        # character": picking here sets that one too, so it is kept with the launcher's settings
        cf = ttk.Frame(f)
        cf.pack(fill="x", padx=12, pady=(10, 0))
        try: chars = list(app.gm_char.cget("values"))
        except Exception: chars = []
        self.on_char = ttk.Combobox(cf, values=chars, state="readonly", width=16)
        try: self.on_char.set(app.gm_char.get())
        except Exception: pass
        self.on_char.pack(side="right")
        ttk.Label(cf, text="Your character").pack(side="right", padx=(0, 8))
        def char_picked(_e=None):
            try: app.gm_char.set(self.on_char.get()); app.save()
            except Exception: pass
        self.on_char.bind("<<ComboboxSelected>>", char_picked)
        f.bind("<Visibility>", lambda e: self.on_char.set(app.gm_char.get()) if hasattr(app, "gm_char") else None)
        box = ttk.LabelFrame(f, text="LAN games (home network and ZeroTier)")
        box.pack(fill="both", expand=True, padx=12, pady=(6, 6))
        top = ttk.Frame(box)
        top.pack(fill="x", padx=8, pady=6)
        self.on_search_btn = ttk.Button(top, text="Search for games", command=self.online_search, width=22)
        self.on_search_btn.pack(side="left")
        self.on_msg = tk.StringVar(value="Press Search for games: it makes sure ZeroTier is on, then looks for every hosted game.")
        ttk.Label(top, textvariable=self.on_msg, wraplength=560, justify="left").pack(side="left", padx=12)
        cols = ("Game", "Map", "Players", "Room", "Host")
        self.on_tree = ttk.Treeview(box, columns=cols, show="headings", height=10, selectmode="browse")
        for c, wd in zip(cols, (260, 200, 90, 110, 200)):
            self.on_tree.heading(c, text=c)
            self.on_tree.column(c, width=wd, anchor="center" if c in ("Players", "Room") else "w")
        self.on_tree.pack(fill="both", expand=True, padx=8, pady=(0, 6))
        bot = ttk.Frame(box)
        bot.pack(fill="x", padx=8, pady=(0, 8))
        self.on_join_btn = ttk.Button(bot, text="Join", command=self.online_join, width=16, state="disabled")
        self.on_join_btn.pack(side="left")
        # (25 Nov, from the old Companion) the host's director camera: its live overhead view, in the web browser
        self.on_watch_btn = ttk.Button(bot, text="Watch live (director cam)", command=self.online_watch, width=26, state="disabled")
        if not getattr(self.L, "COMPANION", False):     # (25 Nov, the user: no director cam on the Companion)
            self.on_watch_btn.pack(side="left", padx=(10, 0))
        def picked(_e=None):
            on = "normal" if self.on_tree.selection() else "disabled"
            self.on_join_btn.configure(state=on); self.on_watch_btn.configure(state=on)
        self.on_tree.bind("<<TreeviewSelect>>", picked)
        self.on_tree.bind("<Double-1>", lambda e: self.online_join())
        self.on_games = {}

    def _lanscan(self):
        return sys.modules.get("lanscan") or _disk_mod(self.HERE, "lanscan")

    def online_say(self, text):
        try: self.app.after(0, lambda: self.on_msg.set(text))
        except Exception: pass

    def online_search(self):
        """(25 Nov, the user: every Search asked Windows' "allow Command Prompt to make changes") ZeroTier is checked without
        asking first - running, with an address on its network: nothing to do. Only when it isn't does the launcher's own
        ZeroTier setup run (that is what needs the Windows prompt: installing, starting or joining)."""
        self.on_search_btn.configure(state="disabled", text="Searching...")
        self.online_say("Checking ZeroTier...")
        def after_zt():
            self.bg(self.online_search_work)
        def check():
            ok = False
            try: ok = self.L.zt_state() == "on" and bool(self.L.zerotier_ip())
            except Exception: pass
            if ok:
                after_zt(); return
            def setup():
                try: self.app.zt_then(after_zt)
                except Exception: after_zt()
            self.app.after(0, setup)
        self.bg(check)

    def online_search_work(self):
        ls = self._lanscan()
        self.online_say("Looking for games on the home network and ZeroTier...")
        extra = [a for a in [str(self.cfg.get("host", "")).strip()] + list(self.cfg.get("online_seen", [])) if a]
        try:
            found = ls.scan(extra=extra, timeout=3.0)
        except Exception as e:
            found = {}; self.online_say(f"Could not search: {e}")
        if found:
            seen = [ip for ip in found] + [ip for ip in self.cfg.get("online_seen", []) if ip not in found]
            self.cfg["online_seen"] = seen[:12]; self.save_cfg()
        def show():
            self.on_tree.delete(*self.on_tree.get_children())
            self.on_games = {}
            for ip, g in sorted(found.items(), key=lambda kv: kv[1].get("name", "")):
                title, mp, real, room, most = ls.describe(g, self.map_label)
                iid = self.on_tree.insert("", "end", values=(title, mp, f"{real}/{most}" if most else str(real),
                                                             "Room to join" if room else "Full", f"{g.get('name', '?')} ({ip})"))
                self.on_games[iid] = ip
            self.on_search_btn.configure(state="normal", text="Search for games")
            self.on_join_btn.configure(state="disabled")
            self.on_msg.set(f"{len(found)} game(s) found." if found else
                            "No games found. Is the host's game running? Search again in a moment (a lost answer is common over ZeroTier).")
        self.app.after(0, show)

    def save_cfg(self):
        try: self._write(self.cfg_file, self.cfg)
        except Exception: pass

    def online_watch(self):
        """the picked game's director camera (the host's statuspage.py, port 8791): follows the best fight by itself"""
        sel = self.on_tree.selection()
        if not sel or sel[0] not in self.on_games:
            return
        ip = self.on_games[sel[0]]
        def work():
            import urllib.request, webbrowser
            url = f"http://{ip}:8791/director"
            try:
                urllib.request.urlopen(url, timeout=5).read(64)
            except Exception:
                self.online_say(f"The host at {ip} has no director cam (its launcher isn't running one)."); return
            self.online_say("Opening the director cam in your web browser.")
            webbrowser.open(url)
        self.bg(work)

    def keep_joined_match(self, b):
        """(25 Nov, the user: no MATCH OVER card, but the stats kept) a joined game's final scoreboard, kept quietly in
        stats\\joined_matches.json (the last 200) for the stats"""
        p = self.HERE / "stats" / "joined_matches.json"
        try: hist = json.loads(p.read_text())
        except (OSError, ValueError): hist = []
        if not isinstance(hist, list): hist = []
        hist.append({k: b.get(k) for k in ("t", "map", "mode", "tier", "rows", "summary", "began")})
        try:
            p.parent.mkdir(exist_ok=True); p.write_text(json.dumps(hist[-200:]))
        except OSError:
            pass

    def online_join(self):
        sel = self.on_tree.selection()
        if not sel or sel[0] not in self.on_games:
            return
        ip = self.on_games[sel[0]]
        if self.L.own_game_pids():
            messagebox.showinfo("Join", "Your game is already open. Close it first, then press Join.")
            return
        self.on_join_btn.configure(state="disabled")
        self.online_say(f"Checking the game at {ip} once more...")
        self.cleanup_cancel()
        self.bg(lambda: self.online_join_work(ip))

    def online_join_work(self, ip):
        app, L, ls = self.app, self.L, self._lanscan()
        def fail(msg):
            self.online_say(msg)
            app.after(0, lambda: self.on_join_btn.configure(state="normal"))
        try:
            g = ls.scan(only=ip, timeout=2.5).get(ip)
        except Exception:
            g = None
        if not g:
            return fail("That game didn't answer: it may have ended. Search again.")
        title, mp, real, room, most = ls.describe(g, self.map_label)
        if not room:
            return fail(f"{title} is full ({real}/{most} players). Try again later.")
        info = g.get("info") or {}
        horde = info.get("mode") in ("horde", "dark")
        local = ip.startswith("127.") or ip in {a for a, _b in ls.networks()}
        mods_in = False
        if horde and not local:
            try:
                mods_in = self.online_mods(ip, info)
            except Exception as e:
                self.online_say(f"Couldn't get the host's mods ({e}); joining without them.")
        try:
            char = self.on_char.get() or app.gm_char.get()
        except Exception:
            char = None
        cmd = L.join_command(char, getattr(app, "screen_value", None), horde)
        cmd = [ip if c == "127.0.0.1" else c for c in cmd]
        try:
            game = subprocess.Popen(cmd, cwd=str(L.GAME_DIR))
        except OSError as e:
            if mods_in: self.online_mods_off()
            return fail(f"Could not start your game: {e}")
        if horde and (self.HERE / "autojoin.py").exists():       # (a Horde or a mission: your team is picked for you)
            py = self.HERE / ".venv" / "Scripts" / "python.exe"
            try:
                subprocess.Popen([str(py), "-u", str(self.HERE / "autojoin.py"), str(game.pid), "red", str(self.HERE / "horde_logs" / "autojoin_log.txt")],
                                 cwd=str(self.HERE), creationflags=0x08000000)
            except OSError:
                pass
        self.online_say(f"Your game is starting and joins {title} on {mp} by itself.")
        app.after(0, lambda: self.on_join_btn.configure(state="normal"))
        if horde:
            self.bg(lambda: self.remote_hud(ip, game, info))
        game.wait()
        try: (self.HERE / "state" / "stop_net").write_text("closed")           # (the steps, the banners and the music end)
        except OSError: pass
        if mods_in:
            self.online_mods_off()
            self.online_say("Your game closed: the host's mods are out of the game folder again.")

    def remote_hud(self, ip, game, info):
        """(25 Nov, the user: joining a modded game through the Online tab, also the mission's steps on the side of the screen,
        the banners, the music and the carry-over to the next mission) The host's launcher tells its game's state
        (modserver /horde.json); it is copied into this PC's state files as the run "net", and the same windows as on
        the host show it (tierhud, here in the launcher), the music plays (ambient.py), a "Loading the next mission"
        strip shows between missions, and follow.py takes your game into the next mission's lobby."""
        import urllib.request
        st = self.HERE / "state"
        st.mkdir(exist_ok=True)
        for n in ("stop_net", "music_stop_net", "human_net.flag", "obj_net.txt", "banner_net.txt", "tier_net.txt", "bosshp_net.txt"):
            try: (st / n).unlink()
            except OSError: pass
        py = self.HERE / ".venv" / "Scripts" / "python.exe"
        ms = info.get("mission")
        if ms or info.get("christmas"):
            try: self.ensure_files("christmas", lambda: None)
            except Exception: pass
        if (self.HERE / "follow.py").exists():                            # (the next mission: your game goes there by itself)
            try:
                subprocess.Popen([str(py), "-u", str(self.HERE / "follow.py"), str(game.pid), "red", str(self.HERE / "horde_logs" / "follow_log.txt")],
                                 cwd=str(self.HERE), creationflags=0x08000000)
            except OSError:
                pass
        wav = (self.HERE / "christmas" / "music" / ("mission_ambient.wav" if ms else "christmas_ambient.wav")) if (ms or info.get("christmas")) \
            else self.HERE / "sounds" / "horde_ambient.wav"
        try: self.app.after(0, lambda: (sys.modules.get("tierhud") or _disk_mod(self.HERE, "tierhud")).in_launcher(self.app, "net", 0))
        except Exception: pass
        t0, music, lob_t, notice, fails = time.time(), False, None, [None], 0
        extras, steps, kept, live_t = False, False, set(), 0.0
        xmas = bool(info.get("christmas"))
        def side(script, *args):
            if (self.HERE / script).exists():
                try: subprocess.Popen([str(py), str(self.HERE / script), "net", str(game.pid), *args], cwd=str(self.HERE), creationflags=0x08000000)
                except OSError: pass
        while game.poll() is None:
            time.sleep(0.5)
            if time.time() - live_t > 5:                                  # the match's end: its scoreboard kept for the stats
                live_t = time.time()
                try:
                    b = json.loads(urllib.request.urlopen(f"http://{ip}:8791/live.json", timeout=3).read()) or {}
                    if b.get("final"):
                        key = (b.get("map"), b.get("began"), int(b.get("t") or 0) // 60)
                        if key not in kept:
                            kept.add(key); self.keep_joined_match(b)
                except Exception:
                    pass
            try:
                h = json.loads(urllib.request.urlopen(f"http://{ip}:8765/horde.json", timeout=4).read()); fails = 0
            except Exception:
                fails += 1
                if fails > 120: break                                     # (an old host launcher: nothing to show)
                continue
            sa = h.get("santa")                                           # Santa's booming footsteps: where he is, by this PC's clock
            if sa and "x" in sa:
                try:
                    (st / "santa_net.json").write_text(json.dumps(dict(sa, t=time.time() - float(sa.get("age") or 0))))
                except (OSError, ValueError):
                    pass
                if not steps:
                    steps = True; side("santasteps.py")
            if not extras and (st / "human_net.flag").exists():           # (25 Nov, from the old Companion) the welcome title, the storm
                extras = True
                if ms:
                    side("welcome.py", "christmas", ms.get("label") or "Christmas Mission")
                elif xmas:
                    side("welcome.py", "christmas")
                else:
                    side("welcome.py"); side("storm.py")
            for key, fn in (("obj", "obj_net.txt"), ("banner", "banner_net.txt"), ("tier", "tier_net.txt"), ("bosshp", "bosshp_net.txt")):
                try:
                    v = h.get(key) or ""
                    p_ = st / fn
                    if (p_.read_text() if p_.exists() else "") != v: p_.write_text(v)
                except OSError:
                    pass
            if not (st / "human_net.flag").exists() and time.time() - t0 > 20 and (h.get("obj") or h.get("tier")):
                try: (st / "human_net.flag").write_text("in")          # (you are in: the windows open now)
                except OSError: pass
            if not music and (st / "human_net.flag").exists() and wav.exists() and (self.HERE / "ambient.py").exists():
                music = True
                try:
                    subprocess.Popen([str(py), str(self.HERE / "ambient.py"), "net", str(game.pid), str(wav)], cwd=str(self.HERE), creationflags=0x08000000)
                except OSError:
                    pass
            nx = h.get("next") or {}
            if nx and notice[0] != nx.get("t"):                        # a mission won with another to come: "Loading the next mission"
                notice[0] = nx.get("t"); obj0 = h.get("obj"); self.mark_won()
                def finished(t1=time.time(), o=obj0):
                    try: cur = (st / "obj_net.txt").read_text()
                    except OSError: cur = o
                    return time.time() - t1 > 180 or cur != o or game.poll() is not None
                try: self.app.after(4000, lambda f_=finished: (sys.modules.get("tierhud") or _disk_mod(self.HERE, "tierhud")).loading_notice(self.app, f_))
                except Exception: pass
            lob = h.get("lobby") or {}
            if lob.get("t") and lob.get("t") != lob_t:
                first = lob_t is None
                lob_t = lob.get("t")
                if not first and time.time() - t0 > 30:                   # (the first one is the lobby you joined: no follow)
                    try:                                                  # follow.py goes by this PC's clock: now, the host's address
                        (st / "next_lobby.json").write_text(json.dumps({"t": time.time(), "address": ip, "map": lob.get("map"), "team": "red"}))
                    except OSError:
                        pass
        for n in ("stop_net", "music_stop_net"):                          # (the welcome, storm, Santa's steps and the music stop)
            try: (st / n).write_text("over")
            except OSError: pass

    def online_mods(self, ip, info):
        """the host's mods for a Horde / Christmas game, as the Companion gets them: its launcher's list (modserver, port 8765),
        each file checked, put in with the Companion's own journal (so either app can always take them out), then the look"""
        comp = sys.modules.get("companion") or _disk_mod(self.HERE, "companion")
        import tempfile, urllib.request
        base = f"http://{ip}:{getattr(comp, 'PORT', 8765)}"
        man = json.loads(urllib.request.urlopen(base + "/manifest.json", timeout=30).read())
        game = str(self.L.GAME_DIR)
        tmp = tempfile.mkdtemp(prefix="outlaws_join_")
        items, archived = [], []
        # (25 Nov, the user: compare the host's files with this PC's own, so the same ones aren't fetched again) the skins and art
        #  go into an archive, so they were fetched every join (over a gigabyte for a Christmas Mission): now a file this PC
        #  already has in christmas\ (or zombie\) with the host's sha256 is taken from there. Each file's sha256 is worked out
        #  once and kept in state\mod_files_sha.json with its size and time, as mission_files_missing does.
        cp_ = self.HERE / "state" / "mod_files_sha.json"
        try: cache_ = json.loads(cp_.read_text())
        except (OSError, ValueError): cache_ = {}
        dirty_ = [False]
        def local_copy(rel, want):
            p_ = self.HERE.joinpath(*rel.split("/"))
            try: st_ = p_.stat()
            except OSError: return None
            c_ = cache_.get(rel)
            if not (c_ and c_[1] == st_.st_size and abs(c_[2] - st_.st_mtime) < 0.01):
                try: c_ = cache_[rel] = [comp.sha256(str(p_)), st_.st_size, st_.st_mtime]; dirty_[0] = True
                except OSError: return None
            return str(p_) if c_[0] == want else None
        kept_ = 0
        try:
            for mod in man.get("mods", []):
                into = mod.get("id") == "zombie_skins"
                for fl in mod.get("files", []):
                    dest = fl.get("dest", "")
                    if not comp.safe_dest(dest):
                        continue
                    cur = os.path.join(game, dest)
                    if not into and os.path.exists(cur) and comp.sha256(cur) == fl["sha256"]:
                        kept_ += 1
                        continue
                    if into:
                        src_ = "christmas" if "/christmas/" in fl.get("url", "") else "zombie"
                        mine_ = local_copy(f"{src_}/{os.path.basename(dest)}", fl["sha256"])
                        if mine_:
                            archived.append((dest, mine_)); kept_ += 1
                            continue
                    p = os.path.join(tmp, dest)
                    self.online_say(f"Getting the host's mods: {mod.get('title', '')} ({dest})...")
                    with urllib.request.urlopen(base + fl["url"], timeout=60) as r, open(p, "wb") as out:
                        shutil.copyfileobj(r, out)
                    if comp.sha256(p) != fl["sha256"]:
                        raise RuntimeError(f"{dest} came down damaged")
                    (archived if into else items).append((dest, p))
            if dirty_[0]:
                try: cp_.parent.mkdir(exist_ok=True); cp_.write_text(json.dumps(cache_))
                except OSError: pass
            if kept_: self.online_say(f"Getting the host's mods: {kept_} files were the same as yours, so they weren't downloaded")
            if archived: comp.install_archive(game, archived)
            if items: comp.install_files(game, items)
            import teamcolors
            ms = info.get("mission")
            zombies = bool(archived)
            teamcolors.set_theme("on", quiet=True,
                                 neutral=("grinch_plain" if ms else "grinch" if info.get("christmas") else "horde") if zombies else False,
                                 dark=("winter_night" if ms else "winter") if info.get("christmas") or ms else ("flash" if info.get("mode") == "dark" else True))
            self._join_mods = True
            return True
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def online_mods_off(self):
        try:
            comp = sys.modules.get("companion") or _disk_mod(self.HERE, "companion")
            for _ in range(10):
                if comp.restore_files(): break
                time.sleep(3)
        except Exception:
            pass
        try:
            import teamcolors
            for _ in range(10):
                if teamcolors.set_theme("off", quiet=True): break
                time.sleep(3)
        except Exception:
            pass
        self._join_mods = False

    def mods_files(self):
        """the big downloaded mod files on this PC: the Christmas Missions' art, sounds and music and the zombie skins (25 Nov)
        - the lists on GitHub, or failing that the files zombieskins.py installs, christmas\\music\\*.wav and zombie\\*.
        The small .json data stays."""
        rel = []
        for set_ in self.MOD_SETS:
            try:
                rel += [r for r in json.loads(self._xmas_get(f"{set_}_files.json")).get("files", {}) if not r.lower().endswith(".json")]
                continue
            except Exception:
                pass
            if set_ == "christmas":
                try:
                    zs = sys.modules.get("zombieskins") or _disk_mod(self.HERE, "zombieskins")
                    rel += ["christmas/" + n for n in zs.files(True)]
                except Exception:
                    pass
                mus = self.HERE / "christmas" / "music"
                if mus.is_dir():
                    rel += ["christmas/music/" + p.name for p in mus.glob("*.wav")]
            else:
                z = self.HERE / "zombie"
                if z.is_dir():
                    rel += ["zombie/" + p.name for p in z.iterdir() if p.is_file() and not p.name.lower().endswith(".json")]
        out = []
        for r in rel:
            p = self.HERE.joinpath(*r.split("/"))
            if p.is_file() and p not in out:
                out.append(p)
        return out

    def mods_delete(self):
        """(25 Nov) Delete Mods from PC: close the game, take every mod out of the game folder (mods_off.cmd's cleanup:
        team colours and the winter look, elf and zombie skins, the changed map files) and delete the Christmas Missions'
        downloaded files. Start Missions fetches them again when they are wanted."""
        app = self.app
        p = getattr(app, "bots_proc", None)
        if p is not None and p.poll() is None:
            messagebox.showinfo("Delete Mods from PC", "A game mode is running. Stop it first (Close all game windows), then try again.")
            return
        files = self.mods_files()
        size = sum(f.stat().st_size for f in files if f.exists())
        if not messagebox.askyesno("Delete Mods from PC",
                                   "Are you sure you want to remove all mods from your PC?\n\n"
                                   "This closes the game, takes every mod out of the game folder and deletes the Christmas "
                                   f"Missions and Zombie Horde files ({size / 1e9:.1f} GB).\n\nThey download again by themselves "
                                   "the next time you start a Christmas Mission or a Survival Horde game.", icon="warning", default="no"):
            return
        app.say("deleting the mods from this PC...")

        def work():
            subprocess.run(["taskkill", "/IM", "OutlawsAHOM.exe", "/F"], capture_output=True, creationflags=0x08000000)
            time.sleep(3)
            py = self.HERE / ".venv" / "Scripts" / "python.exe"
            ok = True
            try:
                r = subprocess.run([str(py) if py.exists() else "python", str(self.HERE / "companionhost.py"), "--cleanup"],
                                   cwd=str(self.HERE), capture_output=True, timeout=300, creationflags=0x08000000)
                ok = r.returncode == 0
            except Exception:
                ok = False
            gone, freed = 0, 0
            for f in files:
                try:
                    n = f.stat().st_size; f.unlink(); gone += 1; freed += n
                except OSError:
                    pass
            for d in ("_xmas_dl", "_xmas_pack"):
                shutil.rmtree(self.HERE / d, ignore_errors=True)
            def done():
                msg = (f"Removed {gone} mod files ({freed / 1e9:.1f} GB)" + (" and took the mods out of the game folder." if ok else
                       ".\n\nThe game folder could not be fully put back - run mods_off.cmd in the botctl folder to finish."))
                app.say("Delete Mods from PC: " + msg.replace("\n\n", " "))
                messagebox.showinfo("Delete Mods from PC", msg)
            app.after(0, done)
        threading.Thread(target=work, daemon=True).start()

    def loading_notice(self, t0):
        """(25 Nov, the user: after the boss, "Loading next mission, please don't exit the game") shown over the game from a
        few seconds after a mission is won (the win banner first) until you are in the next one - a new human flag - or
        3 minutes have passed (tierhud.loading_notice)"""
        st = self.HERE / "state"
        chk = {"t": 0.0, "gone": False}

        def game_gone():
            """(25 Nov, the user: it stayed on the desktop after Outlaws was closed before the next mission loaded) no
            OutlawsAHOM.exe running any more: checked every 3 s"""
            if time.time() - chk["t"] >= 3.0:
                chk["t"] = time.time()
                try:
                    out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq OutlawsAHOM.exe", "/NH"], capture_output=True, text=True,
                                         timeout=10, creationflags=0x08000000).stdout.lower()
                    chk["gone"] = "outlawsahom.exe" not in out
                except Exception:
                    chk["gone"] = False
            return chk["gone"]

        def finished():
            if time.time() - t0 > 180 or game_gone():
                return True
            try:
                return any(h.stat().st_mtime > t0 + 2 for h in st.glob("human_*.flag"))
            except OSError:
                return False
        try:
            th = sys.modules.get("tierhud") or _disk_mod(self.HERE, "tierhud")
            th.loading_notice(self.app, finished)
        except Exception as e:
            try: self.app.say(f"loading message: {e}")
            except Exception: pass

    def status_page(self):
        """the server status page for friends' phones (statuspage.py, port 8791: home network and ZeroTier)"""
        try:
            sp = _disk_mod(self.HERE, "statuspage")
            if sp and sp.start(self.HERE):
                zt = None
                try: zt = self.L.zerotier_ip()
                except Exception: pass
                where = f"http://{zt}:{sp.PORT}/" if zt else (sp.addresses() or [f"port {sp.PORT}"])[0]
                self.app.say(f"server status page for friends' phones: {where}")
        except Exception as e:
            try: self.app.say(f"status page: could not start ({e})")
            except Exception: pass

    def live_write(self, m, final=False):
        """the Map Rotation / ghost game's live scoreboard (livestats.py) to state/live_rotation.json: the status page and
        the companion app show it"""
        try:
            ls = sys.modules.get("livestats") or _disk_mod(self.HERE, "livestats")
            folder = self.HERE / "GhostLogs"
            texts = []
            for f in sorted(folder.glob("ghost_*.txt")):
                try:
                    with open(f, "rb") as fh:
                        fh.seek(m["start_offsets"].get(f.name, 0) if f.stat().st_size >= m["start_offsets"].get(f.name, 0) else 0)
                        texts.append(fh.read().decode("utf-8", errors="replace"))
                except OSError:
                    continue
            board = ls.build_texts(texts, ghost_names=m["ghosts"], mode=self.mode_label(m["mode"]) or m["source"], map_name=m["map"])
            board.update(final=final, began=m["t0"], source=m["source"])
            ls.write(board, self.HERE / "state" / "live_rotation.json")
            return board
        except Exception:
            return None

    # ---- Christmas Co-op Missions (missions.py, run by horde.py) ------------------------------------------------------------
    def missions_window(self):
        """Pick a mission: it starts as a Christmas Survival Horde game with ghost elves on the mission's map; horde.py reads the
        pick from state/next_mission.json. Friends join with the companion as for any Horde game."""
        app, L = self.app, self.L
        try:
            ms = _disk_mod(self.HERE, "missions")
        except Exception as e:
            messagebox.showerror("Christmas Missions", f"missions.py could not be read: {e}")
            return
        if ms is None:
            messagebox.showerror("Christmas Missions", "missions.py is not in the botctl folder.")
            return
        w = tk.Toplevel(app)
        w.title("Christmas Missions")
        w.configure(bg=getattr(L, "PARCH", "#f3ead2"))
        w.transient(app)
        ttk.Label(w, text="Santa has gone rogue on Christmas Eve. Play these with friends (they join with the companion app).",
                  wraplength=560).pack(anchor="w", padx=14, pady=(12, 6))
        try:
            beaten = set(json.loads((self.HERE / "state" / "missions_progress.json").read_text()).get("beaten", []))
        except (OSError, ValueError, AttributeError):
            beaten = set()
        # (23 Nov, the user: a "Start Missions" button that starts at Mission 1, and below it every mission beaten so far,
        #  each one to start from - the missions after it then follow by themselves as usual)
        # (21 Nov, the user: a place to choose your character before starting) the same choice as the Game Modes tab's
        # "Your character" - picking here sets that one too, so it is kept with the launcher's settings
        cf = ttk.Frame(w)
        cf.pack(fill="x", padx=14, pady=(4, 0))
        ttk.Label(cf, text="Your character").pack(side="left")
        try: chars = list(app.gm_char.cget("values"))
        except Exception: chars = []
        ch_ = ttk.Combobox(cf, values=chars, state="readonly", width=16)
        try: ch_.set(app.gm_char.get())
        except Exception: pass
        ch_.pack(side="left", padx=8)
        def char_picked(_e=None):
            try: app.gm_char.set(ch_.get()); app.save()
            except Exception: pass
        ch_.bind("<<ComboboxSelected>>", char_picked)

        # (25 Nov, the user: a difficulty slider - the missions as they are sit 3/4 of the way up; all the way up is 25% harder,
        #  all the way down 75% easier: the enemies' and bosses' aim, pace and strafing) kept in state\mission_difficulty.json,
        #  which horde.py reads when each mission starts (so it holds for the missions that follow too)
        dp = self.HERE / "state" / "mission_difficulty.json"
        try: pos0 = int(json.loads(dp.read_text()).get("slider", 75))
        except (OSError, ValueError, AttributeError): pos0 = 75
        df = ttk.Frame(w)
        df.pack(fill="x", padx=14, pady=(10, 0))
        ttk.Label(df, text="Difficulty").pack(side="left")
        ttk.Label(df, text="Easier", foreground="#6b5a3e").pack(side="left", padx=(10, 4))
        dv = tk.IntVar(value=max(0, min(100, pos0)))
        dtxt = ttk.Label(df, width=24)
        def dmult(v):
            return 1.0 + (v - 75) / 25 * 0.25 if v >= 75 else 0.25 + v / 75 * 0.75
        def dshow(*_a):
            v = int(round(float(dv.get()))); m_ = dmult(v)
            dtxt.configure(text="Normal (as designed)" if v == 75 else f"{m_:.0%} of normal" + (" - harder" if m_ > 1 else " - easier"))
        def dsave(*_a):
            v = int(round(float(dv.get()))); dv.set(v); dshow()
            try:
                dp.parent.mkdir(exist_ok=True); dp.write_text(json.dumps({"slider": v, "mult": round(dmult(v), 3)}))
            except OSError:
                pass
        sc_ = ttk.Scale(df, from_=0, to=100, orient="horizontal", length=260, variable=dv, command=lambda _v: dshow())
        sc_.pack(side="left")
        sc_.bind("<ButtonRelease-1>", dsave); sc_.bind("<KeyRelease>", dsave)
        ttk.Label(df, text="Harder", foreground="#6b5a3e").pack(side="left", padx=(4, 10))
        ttk.Button(df, text="Normal", width=8, command=lambda: (dv.set(75), dsave())).pack(side="left", padx=(0, 8))
        dtxt.pack(side="left")
        dshow()

        def go(mid):
            dsave()
            if not ms.get(mid):
                return
            char_picked()
            w.destroy()
            # (25 Nov, the user) any Outlaws already open is closed first and started fresh: the game reads the missions' map
            #  changes (the red squares, the presents, the lights) only when it starts, so one left open showed the old ones
            def fresh():
                def running():
                    try:
                        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq OutlawsAHOM.exe", "/NH"], capture_output=True, text=True,
                                             timeout=15, creationflags=0x08000000).stdout.lower()
                        return "outlawsahom.exe" in out
                    except Exception:
                        return False
                self._chaining = time.time()              # (the mods stay in: the mission puts them right back)
                if running():
                    self.ui(lambda: app.say("closing Outlaws first, so the mission's map changes load with a fresh start..."))
                    try: app.kill_all()
                    except Exception as e_:
                        self.ui(lambda: app.say(f"could not close Outlaws ({e_}): close it yourself if the map looks old"))
                    end = time.time() + 20
                    while running() and time.time() < end:
                        time.sleep(0.5)
                    time.sleep(1.0)
                self.ui(lambda: self.ensure_mission_files(lambda: self.start_mission(mid)))     # (a new player: the missions' files first)
            self.bg(fresh)
        first = ms.MISSIONS[0]
        sf = ttk.Frame(w)
        sf.pack(fill="x", padx=14, pady=(12, 4))
        ttk.Button(sf, text="Start Missions", command=lambda: go(first["id"])).pack(side="left", ipadx=14, ipady=4)
        ttk.Label(sf, text=f"from the beginning: {ms.label(first)} ({self.map_label(first['map'])}), then each one after it",
                  foreground="#6b5a3e").pack(side="left", padx=10)

        ttk.Separator(w).pack(fill="x", padx=14, pady=(10, 6))
        ttk.Label(w, text="Start from a mission you have unlocked", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=14)
        # (25 Nov, the user: beating a mission unlocks starting at the next one - Mission 1 beaten: Mission 2 to start at, and so on.
        #  Mission 1 itself is not listed: Start Missions is that.)
        done_ = [m for k_, m in enumerate(ms.MISSIONS) if k_ > 0 and (m["id"] in beaten or ms.MISSIONS[k_ - 1]["id"] in beaten)]
        if not done_:
            ttk.Label(w, text="None yet - beat Mission 1 and you can start at Mission 2 from here, and so on.", foreground="#6b5a3e").pack(anchor="w", padx=14, pady=(2, 4))
        for m in done_:
            f = ttk.Frame(w)
            f.pack(fill="x", padx=14, pady=3)
            ttk.Button(f, text="Start here", command=lambda mid=m["id"]: go(mid)).pack(side="left", anchor="n")
            tf = ttk.Frame(f)
            tf.pack(side="left", fill="x", padx=(10, 0))
            ttk.Label(tf, text=f"{ms.label(m)}  ({self.map_label(m['map'])})" + ("  \u2714 beaten" if m["id"] in beaten else "  - unlocked")).pack(anchor="w")
            ttk.Label(tf, text=m["brief"], wraplength=480, foreground="#6b5a3e").pack(anchor="w")

        b = ttk.Frame(w)
        b.pack(fill="x", padx=14, pady=(10, 12))
        ttk.Button(b, text="Close", command=w.destroy).pack(side="left")

    # ---- small helpers ---------------------------------------------------------------------------------------------
    @staticmethod
    def _read(path, default):
        try:
            return json.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return default

    @staticmethod
    def _write(path, data):
        tmp = Path(str(path) + ".tmp")
        tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
        os.replace(tmp, path)

    def ui(self, fn):
        """Run fn on the window's own thread (workers must not touch the widgets)."""
        try:
            self.app.after(0, fn)
        except Exception:
            pass

    def bg(self, fn):
        threading.Thread(target=fn, daemon=True).start()

    def map_label(self, key):
        return next((l for l, k in self.L.MAPS if k == key), key or "?")

    def mode_label(self, key):
        return next((l for l, k in self.L.MODES if k == key), key or "")

    def sha(self, name):
        p = self.HERE / name
        try:
            st = p.stat()
        except OSError:
            return None
        sig = (st.st_mtime_ns, st.st_size)
        hit = self._sha_cache.get(name)
        if not hit or hit[0] != sig:
            try:
                hit = (sig, hashlib.sha256(p.read_bytes()).hexdigest())
            except OSError:
                return None
            self._sha_cache[name] = hit
        return hit[1]

    # ---- the tab ---------------------------------------------------------------------------------------------------
    def build(self, saved):
        app, g = self.app, self.app.tl
        pad = dict(padx=8, pady=4)
        L = self.L
        mono = app.zfont("Consolas", 9)
        # (13 Nov: the launcher's clean look. This file is read from disk by whichever BotLauncher.exe is there, so it still
        #  works with an older launcher that has no "?" hints, no FIELD colour and the old tabs.)
        FIELD, EDGE = getattr(L, "FIELD", "#fbf5e3"), getattr(L, "EDGE", L.LEATHER)
        new = hasattr(app, "hint")
        def hint(parent, text):
            """the "?" with its text (new launcher), or nothing"""
            if not new:
                return None
            h = app.hint(parent, text)
            return h
        def text_box(parent, height):
            return tk.Text(parent, height=height, width=112, state="disabled", bg=FIELD, fg=L.INK, relief="flat", wrap="word",
                           font=mono, highlightthickness=1 if new else 0, highlightbackground=EDGE, highlightcolor=EDGE, padx=6, pady=4)

        # (25 Nov) the Game Modes tab's LAUNCH GAME MODE: a Survival Horde game first gets the mod files this PC is missing
        #  (Christmas or zombie: ensure_files), then launches as before
        try:
            for b_, t_ in getattr(app, "launch_btns", []):
                if t_ == "LAUNCH GAME MODE":
                    b_.configure(command=self.mode_launch)
        except Exception:
            pass
        try:                                                 # (25 Nov, the user) the Game Modes tab is called Custom Games now (launcher.py
            app.nb.tab(app.gm, text="  Custom Games  ")      #  too; this renames it in a launcher built before that)
        except Exception:
            pass
        try:
            self.online_build()
        except Exception as e:
            try: app.say(f"Online tab: {e}")
            except Exception: pass
        # -- online games: the game's own Multiplayer > Online > Join Game list (onlinegames.py)
        box = ttk.LabelFrame(g, text="Online games")
        box.grid(row=0, column=0, sticky="ew", padx=12, pady=(10, 4))
        top = ttk.Frame(box)
        top.grid(row=0, column=0, sticky="w")
        self.online_btn = ttk.Button(top, text="Check online games", command=self.online_check, width=22)
        self.online_btn.pack(side="left", **pad)
        h = hint(top, "The games people are hosting online right now: the same list as Multiplayer > Online > Join Game in the "
                      "game. Steam must be running and signed in on this PC (it is asked once a day; your own game does not "
                      "have to be open).")
        if h: h.pack(side="left")
        self.online_auto = tk.BooleanVar(value=bool(self.cfg.get("online_auto", False)))
        ttk.Checkbutton(top, text="Keep checking every minute", variable=self.online_auto, command=self.online_auto_set).pack(side="left", padx=(18, 0))
        # (24 Nov, the user: the missions button is on the Game Modes tab now: launcher.py)
        ttk.Button(top, text="Director cam", command=lambda: __import__("webbrowser").open("http://127.0.0.1:8791/director")).pack(side="right", padx=(4, 0))
        self.online_sum = tk.StringVar(value="Not checked yet.")
        ttk.Label(top, textvariable=self.online_sum, wraplength=430, justify="left").pack(side="left", padx=12)
        cols = ("Host", "Map", "Mode", "Players", "Limits", "Region")
        self.online_tree = ttk.Treeview(box, columns=cols, show="headings", height=3, selectmode="none")
        for c, wd in zip(cols, (170, 190, 160, 70, 120, 90)):
            self.online_tree.heading(c, text=c)
            self.online_tree.column(c, width=wd, anchor="center" if c == "Players" else "w")
        self.online_tree.grid(row=1, column=0, sticky="w", padx=8, pady=(0, 6))
        self.online_busy = False
        if self.online_auto.get():
            app.after(6000, self.online_tick)

        box = ttk.LabelFrame(g, text="Saved setups" if new else "Saved setups (every tab's settings under one name)")
        box.grid(row=1, column=0, sticky="ew", padx=12, pady=4)
        self.setup_list = tk.Listbox(box, height=4, width=44, exportselection=False, activestyle="none", bg=FIELD,
                                     fg=L.INK, selectbackground=getattr(L, "RUST", L.LEATHER) if new else L.LEATHER,
                                     selectforeground="white", relief="flat", highlightthickness=1 if new else 0,
                                     highlightbackground=EDGE, highlightcolor=EDGE, font=app.zfont("Segoe UI", 10))
        self.setup_list.grid(row=0, column=0, rowspan=3, padx=8, pady=6)
        ttk.Button(box, text="Save current settings", command=self.setup_save, width=22).grid(row=0, column=1, sticky="w", **pad)
        self.setup_load_btn = ttk.Button(box, text="Load", command=self.setup_load, width=10, state="disabled")
        self.setup_load_btn.grid(row=1, column=1, sticky="w", **pad)
        self.setup_del_btn = ttk.Button(box, text="Delete", command=self.setup_delete, width=10, state="disabled")
        self.setup_del_btn.grid(row=2, column=1, sticky="w", **pad)
        about = ("A setup keeps every tab's settings under one name. Set the tabs up the way you like, then save. Loading a setup "
                 "restarts the launcher (a few seconds) with everything as it was saved; press the Launch button after.")
        h = hint(box, about)
        if h: h.grid(row=0, column=2, sticky="w", **pad)
        else: ttk.Label(box, wraplength=330, justify="left", text=about).grid(row=0, column=2, rowspan=3, sticky="w", **pad)
        self.setup_list.bind("<<ListboxSelect>>", lambda e: self.setup_buttons())
        self.setup_show()

        box = ttk.LabelFrame(g, text="Health check")
        box.grid(row=2, column=0, sticky="ew", padx=12, pady=4)
        top = ttk.Frame(box)
        top.grid(row=0, column=0, sticky="w")
        self.health_btn = ttk.Button(top, text="Run health check", command=self.health_run, width=22)
        self.health_btn.pack(side="left", **pad)
        self.health_sum = tk.StringVar(value="Checks the things that have stopped games before.")
        ttk.Label(top, textvariable=self.health_sum).pack(side="left", padx=8)
        self.health_text = text_box(box, 6)
        self.health_text.grid(row=1, column=0, padx=8, pady=(0, 6))
        self.health_text.tag_configure(BAD, foreground="#a01010")
        self.health_text.tag_configure(NOTE, foreground="#8a5a00")
        self.health_text.tag_configure(OK, foreground="#2c6b1e")

        box = ttk.LabelFrame(g, text="Host PC" if new else "Host PC (another PC at home that runs the Map Rotation as a host server)")
        box.grid(row=3, column=0, sticky="ew", padx=12, pady=4)
        top = ttk.Frame(box)
        top.grid(row=0, column=0, sticky="w")
        ttk.Label(top, text="Its address").pack(side="left", padx=(8, 4), pady=4)
        self.host = tk.StringVar(value=str(self.cfg.get("host", "")))
        ttk.Entry(top, textvariable=self.host, width=16).pack(side="left")
        ttk.Button(top, text="Find", command=self.host_find, width=7).pack(side="left", padx=(6, 0))
        ttk.Button(top, text="Check now", command=self.host_check, width=11).pack(side="left", padx=(6, 0))
        ttk.Button(top, text="Send update", command=self.host_update, width=12).pack(side="left", padx=(18, 0))
        ttk.Button(top, text="Get its problem report", command=self.host_report, width=22).pack(side="left", padx=(6, 0))
        h = hint(top, "Another PC at home that runs the Map Rotation as a host server. Type its address (or press Find), then "
                      "Check now: what it is doing and whether its files match this PC's. Leave the address empty to see this PC.")
        if h: h.pack(side="left", padx=(10, 0))
        self.host_text = text_box(box, 5)
        self.host_text.grid(row=1, column=0, padx=8, pady=(2, 6))
        self.host_text.tag_configure(BAD, foreground="#a01010")
        self.host_text.tag_configure(NOTE, foreground="#8a5a00")
        self.host_show([(NOTE, "Type the host PC's address (or press Find), then Check now. Leave it empty to see this PC.")])

        box = ttk.LabelFrame(g, text="Problem report and match history")
        box.grid(row=4, column=0, sticky="ew", padx=12, pady=(4, 46))      # (room under it for the Update Launcher button)
        ttk.Button(box, text="Make a problem report", command=self.report_click, width=22).grid(row=0, column=0, **pad)
        ttk.Button(box, text="Match history", command=self.show_history, width=16).grid(row=0, column=1, **pad)
        # (25 Nov, the user: a Delete Mods from PC button - the mods are large - with an "are you sure" box first)
        ttk.Button(box, text="Delete Mods from PC", command=self.mods_delete, width=20).grid(row=0, column=4, sticky="e", padx=(16, 8), pady=4)
        about = ("A problem report is one zip file with this PC's logs, settings and a screenshot of every monitor (and the host PC's too, "
                 "when its address is filled in above).")
        h = hint(box, about)
        if h: h.grid(row=0, column=2, sticky="w", padx=(4, 8))
        self.report_note = tk.StringVar(value="" if new else about)
        ttk.Label(box, textvariable=self.report_note, wraplength=470, justify="left").grid(row=0, column=3, sticky="w", **pad)

    # ---- online games ------------------------------------------------------------------------------------------------
    def online_fetch(self):
        """Ask onlinegames.py (run with the bots' Python, so Steam is never held by the launcher itself)."""
        script = self.HERE / "onlinegames.py"
        if not script.exists():
            return {"ok": False, "error": "onlinegames.py is not next to the launcher."}
        try:
            p = subprocess.run([self.L.venv_py(), str(script)], cwd=str(self.HERE), capture_output=True, text=True, timeout=75,
                               creationflags=getattr(self.L, "NO_WINDOW", 0))
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "No answer after 75 seconds (is this PC online?)."}
        except OSError as e:
            return {"ok": False, "error": f"Could not start the check: {e}"}
        out = [ln for ln in (p.stdout or "").splitlines() if ln.strip().startswith("{")]
        if out:
            try:
                return json.loads(out[-1])
            except ValueError:
                pass
        err = [ln for ln in (p.stderr or "").splitlines() if ln.strip()]
        return {"ok": False, "error": (err[-1][:200] if err else "The check gave no answer.")}

    def online_check(self, quiet=False):
        if self.online_busy:
            return
        self.online_busy = True
        try:
            self.online_btn.configure(state="disabled")
            if not quiet:
                self.online_sum.set("Checking...")
        except tk.TclError:
            pass
        def work():
            res = self.online_fetch()
            def show():
                self.online_busy = False
                try:
                    self.online_btn.configure(state="normal")
                    self.online_show(res)
                except tk.TclError:
                    pass
            self.ui(show)
        self.bg(work)

    def online_show(self, res):
        tree = self.online_tree
        tree.delete(*tree.get_children())
        when = time.strftime("%H:%M")
        if not res.get("ok"):
            self.online_sum.set(str(res.get("error") or "The check failed."))
            return
        games = res.get("games") or []
        for gm in games:
            tree.insert("", "end", values=(gm.get("host", "?"), gm.get("map", "?"), gm.get("mode", "?"),
                                           f"{gm.get('players', '?')}/{gm.get('max', '?')}", gm.get("limits", ""), gm.get("region", "")))
        n = len(games)
        self.online_sum.set(f"{n} game{'s' if n != 1 else ''} hosted online (checked {when})." if n else f"No games are hosted online right now (checked {when}).")
        seen = getattr(self, "online_seen", None)
        hosts = {(gm.get("host"), gm.get("map")) for gm in games}
        if seen is not None:                                 # (keep checking is on: a game that was not there a minute ago)
            for host, mp in sorted(hosts - seen, key=str):
                try: self.app.say(f"online: {host} is hosting {mp}")
                except Exception: pass
        self.online_seen = hosts

    def online_auto_set(self):
        self.cfg["online_auto"] = bool(self.online_auto.get())
        try:
            self._write(self.cfg_file, self.cfg)
        except OSError:
            pass
        if self.online_auto.get():
            self.online_tick()

    def online_tick(self):
        """Keep checking every minute while the box is ticked (one timer at a time)."""
        if not self.online_auto.get() or getattr(self, "online_timer", False):
            return
        self.online_check(quiet=True)
        self.online_timer = True
        def again():
            self.online_timer = False
            self.online_tick()
        try:
            self.app.after(60000, again)
        except Exception:
            self.online_timer = False

    # ---- which tab a saved setup belongs to ------------------------------------------------------------------------
    def tab_frames(self):
        app = self.app
        return {"play": app.body, "bots": getattr(app, "bt", None), "ghosts": getattr(app, "gh", None),
                "modes": getattr(app, "gm", None), "rotation": getattr(app, "rot", None)}

    def tab_key(self):
        """The open tab, by name (the tabs' order changed on 13 Nov, so a number says nothing)."""
        try:
            cur = str(self.app.nb.select())
            for k, f in self.tab_frames().items():
                if f is not None and str(f) == cur:
                    return k
        except Exception:
            pass
        return "play"

    @staticmethod
    def entry_key(s):
        """A saved setup's tab: its name, or (setups from before 13 Nov) the old tab number: 1 game modes, 2 rotation, 3 ghosts."""
        return s.get("tab_key") or {1: "modes", 2: "rotation", 3: "ghosts"}.get(s.get("tab", 0), "play")

    def text_set(self, widget, lines):
        """lines: [(tag, text)] into a read-only Text."""
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        for tag, text in lines:
            if tag in (OK, NOTE, BAD):
                widget.insert("end", text.rstrip("\n") + "\n", tag)
            else:
                widget.insert("end", text.rstrip("\n") + "\n")
        widget.configure(state="disabled")

    # ---- saved setups ----------------------------------------------------------------------------------------------
    def setup_show(self, select=None):
        self.setup_list.delete(0, "end")
        for s in self.setups:
            self.setup_list.insert("end", f"{s.get('name', 'Setup')}   ({s.get('about', '')})" if s.get("about") else s.get("name", "Setup"))
        if select is not None and 0 <= select < len(self.setups):
            self.setup_list.selection_set(select)
        self.setup_buttons()

    def setup_chosen(self):
        sel = self.setup_list.curselection()
        return sel[0] if sel and sel[0] < len(self.setups) else None

    def setup_buttons(self):
        state = "normal" if self.setup_chosen() is not None else "disabled"
        self.setup_load_btn.configure(state=state)
        self.setup_del_btn.configure(state=state)

    def setup_about(self, data, tab):
        """A few words on what a setup starts, from the tab it was saved on (its name; an old launcher's tab number)."""
        try:
            tab = {"rotation": 2, "modes": 1, "ghosts": 3}.get(tab, tab)
            who = data.get("play_who")
            if tab not in (1, 2) and who:                    # (the Play tab: bots, ghosts or both in one game)
                bots, ghosts = f"{data.get('count')} bots", f"{data.get('ghost_count')} ghosts"
                players = ghosts if who == "Ghosts" else bots + (f" + {ghosts}" if who != "Bots" else "")
                return f"{players} on {data.get('map')}, {data.get('mode')}"
            if tab == 2:
                r = data.get("rotation", {})
                who = f"{r.get('ghosts')} ghosts, {r.get('ghost_diff')}" if r.get("who") == "Ghosts" and r.get("net") != "Online game" else "bots"
                return f"Map Rotation: {len(r.get('entries', []))} maps, {'online' if r.get('net') == 'Online game' else who}"
            if tab == 1:
                m = data.get("modes", {})
                return f"{m.get('mode', 'Game mode')}: {m.get('map', '')}".strip(": ")
            if tab == 3:
                gg = data.get("ghost_game", {})
                return f"Ghosts: {data.get('ghost_count')} on {gg.get('map', '')}"
            return f"Bots: {data.get('count')} on {data.get('map')}, {data.get('mode')}"
        except Exception:
            return ""

    def setup_save(self):
        app = self.app
        k = self.setup_chosen()
        old = self.setups[k] if k is not None else None
        if old is None and len(self.setups) >= SETUP_SLOTS:
            messagebox.showinfo("Saved setups", f"All {SETUP_SLOTS} places are used. Click one in the list to replace it, or delete one first.")
            return
        name = simpledialog.askstring("Save setup", "Name for this setup:" if old is None else f"Replace \"{old.get('name')}\"? Name:",
                                      initialvalue=(old or {}).get("name", ""), parent=app)
        if not name or not name.strip():
            return
        data = app.snapshot()
        key = self.tab_key()                                 # (saved while on Stats or Tools: the first tab is the one to open)
        if hasattr(app, "who") and key in ("bots", "ghosts"):
            key = "play"                                     # (the new launcher: those two only set the players up; Play starts the game)
        tab = {"modes": 1, "rotation": 2, "ghosts": 3}.get(key, 0)      # (the old tab number too, for an older launcher)
        entry = {"name": name.strip()[:28], "saved": time.time(), "tab": tab, "tab_key": key, "about": self.setup_about(data, key), "data": data}
        if old is None:
            self.setups.append(entry)
            k = len(self.setups) - 1
        else:
            self.setups[k] = entry
        try:
            self._write(self.setups_file, self.setups)
        except OSError as e:
            messagebox.showerror("Saved setups", f"Could not write {self.setups_file.name}:\n{e}")
            return
        self.setup_show(k)
        app.say(f"saved setup: {entry['name']}")

    def setup_delete(self):
        k = self.setup_chosen()
        if k is None or not messagebox.askyesno("Saved setups", f"Delete \"{self.setups[k].get('name')}\"?"):
            return
        del self.setups[k]
        try:
            self._write(self.setups_file, self.setups)
        except OSError:
            pass
        self.setup_show()

    def setup_load(self):
        app, L = self.app, self.L
        k = self.setup_chosen()
        if k is None:
            return
        s = self.setups[k]
        if getattr(app, "launching", False) or getattr(app, "ghost_procs", None):
            messagebox.showinfo("Saved setups", "A game is starting or running. Press \"Close all game windows\" first, then load the setup.")
            return
        if not messagebox.askyesno("Saved setups", f"Load \"{s.get('name')}\"?\n\nThe launcher restarts with every tab set as it was "
                                   "when this was saved. What is set now is replaced (save it as a setup first to keep it)."):
            return
        data = dict(s.get("data") or {})
        now = app.snapshot()
        for keep in ("stats_player", "zt_network", "zt_ip", "zt_users", "screen_mode", "screen_v2"):   # yours on this PC, not the setup's
            if keep in now:
                data[keep] = now[keep]
        key = self.entry_key(s)
        if hasattr(app, "who"):
            # A setup from before the Play tab: its game was a Bots Setup game, or (saved on the old Ghosts tab) a ghost game
            # with that tab's own map and mode. Say which, so the new launcher does not have to guess.
            if "play_who" not in data:
                gg = data.get("ghost_game") or {}
                if key == "ghosts" and gg:
                    data.update(play_who="Ghosts", map=gg.get("map", data.get("map")), mode=gg.get("mode", data.get("mode")),
                                fraglimit=gg.get("frag", ""), timelimit=gg.get("time", ""), private=bool(gg.get("private", False)))
                else:
                    data["play_who"] = "Bots"
            if key in ("ghosts", "bots"):
                key = "play"
        try:
            data["_open_tab"] = int(app.nb.index(self.tab_frames().get(key) or app.body))
        except Exception:
            data["_open_tab"] = s.get("tab", 0)
        try:
            L.SETTINGS.write_text(json.dumps(data, indent=1))
        except OSError as e:
            messagebox.showerror("Saved setups", f"Could not write the settings:\n{e}")
            return
        # A built exe points TCL/TK and its own unpack folder at files that go away when it closes: the new one must not inherit them.
        env = {k_: v for k_, v in os.environ.items() if k_ not in ("TCL_LIBRARY", "TK_LIBRARY", "_MEIPASS2") and not k_.startswith("_PYI")}
        env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
        cmd = [sys.executable] if getattr(sys, "frozen", False) else [sys.executable, str(self.HERE / "launcher.py")]
        try:
            if os.name == "nt":
                subprocess.Popen(["cmd", "/c", "start", "", "/D", str(self.HERE)] + cmd, cwd=str(self.HERE), env=env,
                                 creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
            else:
                subprocess.Popen(cmd, cwd=str(self.HERE), env=env)
        except OSError as e:
            messagebox.showerror("Saved setups", f"The setup is saved as the launcher's settings, but the launcher could not restart itself:\n{e}\n\nClose it and open it again.")
        app.save = lambda: None                              # (closing must not write the old settings back over the setup)
        app.close()

    # ---- health check ----------------------------------------------------------------------------------------------
    def health(self):
        """[(level, text)]: OK / NOTE / BAD lines in plain words. Slow (asks Windows several things): call it off the UI thread."""
        app, L, HERE = self.app, self.L, self.HERE
        out = []
        add = lambda level, text: out.append((level, text))
        game = Path(L.GAME_EXE)
        if game.exists():
            add(OK, f"The game is where it should be ({game.name}).")
        else:
            add(BAD, f"The game was not found: {game}. The botctl folder must sit inside the game's folder.")
        if not (game.parent / "steam_appid.txt").exists():
            add(NOTE, "steam_appid.txt is missing from the game's folder. Bots still start, but a game copy can get restarted through Steam. "
                      "It is a text file holding just the number 3366780.")
        missing = [n for n in NEEDED_FILES if not (HERE / n).exists()]
        if missing:
            add(BAD, "Tool files are missing from the botctl folder: " + ", ".join(missing) + ".")
        else:
            add(OK, "All the tool files are in the botctl folder.")
        venv = HERE / ".venv" / "Scripts" / "python.exe"
        if venv.exists():
            want = ""
            try:
                want = re.search(r"frida==([\w.]+)", (HERE / "requirements.txt").read_text()).group(1)
            except (OSError, AttributeError):
                pass
            try:
                r = subprocess.run([str(venv), "-c", "import frida; print(frida.__version__)"], capture_output=True, text=True, timeout=60,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                have = r.stdout.strip() if r.returncode == 0 else None
            except (OSError, subprocess.SubprocessError):
                have = None
            if not have:
                add(BAD, "The bots' Python can't load Frida (what lets the bots drive the game). Delete the .venv folder in botctl and start a game: it is made again.")
            elif want and have != want:
                add(NOTE, f"The bots' Frida is version {have}; this version of the tools expects {want}. Delete the .venv folder in botctl to have it made again.")
            else:
                add(OK, f"The bots' Python and Frida ({have}) are ready.")
        elif shutil.which("py") or shutil.which("python"):
            add(NOTE, "The bots' Python (.venv) is not made yet. It is made the first time bots start, which takes a few minutes.")
        else:
            add(BAD, "Python is not installed (or not on PATH), so bots and ghosts can't start. Install Python 3 from python.org and tick \"Add python.exe to PATH\".")
        built = self.built_state()
        if built is False:
            add(NOTE, "launcher.py is newer than this launcher window. Press Update Launcher to use the newest version.")
        elif built is True:
            add(OK, "This launcher is built from the newest launcher.py.")
        n = _ps("(Get-CimInstance Win32_SoundDevice | Measure-Object).Count")
        if n is not None and n.strip().isdigit():
            if int(n.strip()) == 0:
                add(BAD, "This PC has no sound device. The game freezes when a map loads without one. Plug in speakers or headphones, or install "
                         "a virtual sound card (VB-CABLE works).")
            else:
                add(OK, "A sound device is present (the game needs one, even when muted).")
        gpu = _ps("(Get-CimInstance Win32_VideoController).Name -join '|'")
        if gpu is not None:
            names = [x.strip() for x in gpu.strip().split("|") if x.strip()]
            real = [x for x in names if not re.search(r"basic (display|render)|remote|virtual|qxl|red hat|vmware|virtualbox|hyper-v", x, re.I)]
            if real:
                add(OK, "Graphics card: " + ", ".join(real) + ".")
            else:
                add(NOTE, "No real graphics card (" + (", ".join(names) or "none") + "). That is fine for a host-only PC: tick Host server on the "
                          "Map Rotation tab, which makes the host's game use Windows' software drawing. Playing on this PC will be very slow.")
        st = _ps("(Get-Process steam -ErrorAction SilentlyContinue | Measure-Object).Count")
        if st is not None and st.strip().isdigit():
            if int(st.strip()) == 0:
                add(NOTE, "Steam is not running. Start Steam and sign in before starting a game.")
            else:
                add(OK, "Steam is running.")
        try:
            free = shutil.disk_usage(str(HERE)).free / 2 ** 30
            add(NOTE if free < 3 else OK, f"Free disk space on the game's drive: {free:.0f} GB" + (" (low: bots write logs and each bot keeps its own profile)." if free < 3 else "."))
        except OSError:
            pass
        ram = _ps("$o = Get-CimInstance Win32_OperatingSystem; '{0}|{1}' -f [math]::Round($o.FreePhysicalMemory/1MB,1), [math]::Round($o.TotalVisibleMemorySize/1MB,1)")
        if ram and "|" in ram:
            try:
                free_gb, total_gb = (float(x.replace(",", ".")) for x in ram.strip().split("|"))
                add(NOTE if free_gb < 2 else OK, f"Memory: {free_gb:.1f} GB free of {total_gb:.0f} GB" + (" (low: close other programs, or use ghosts, which need far less than bots)." if free_gb < 2 else "."))
            except ValueError:
                pass
        pids = L.bot_game_pids()
        if pids is not None:
            self.copies, self.copies_at = len(pids), time.time()
            if pids and not (getattr(app, "launching", False) or getattr(app, "ghost_procs", None) or getattr(app, "server_mode", False)):
                add(NOTE, f"{len(pids)} bot game cop{'y is' if len(pids) == 1 else 'ies are'} running. If no game should be on, press \"Close all game windows\".")
        try:
            boot = Path(L.STARTUP_CMD).exists() and bool(os.environ.get("APPDATA"))
        except Exception:
            boot = False
        if boot:
            entries = getattr(app, "rot_entries", [])
            if not entries:
                add(BAD, "Host server is ticked, but the Map Rotation list is empty: nothing will be hosted. Add maps on the Map Rotation tab.")
            elif app.rot_net.get() == "Online game" and any(not str(e.get("timelimit") or "").strip() for e in entries):
                add(BAD, "Host server, online: every map on the Map Rotation list needs Minutes, or its match never ends.")
            else:
                who = f"{app.rot_gh_n.get()} ghosts ({app.rot_gh_diff.get()})" if app.rot_who.get() == "Ghosts" and app.rot_net.get() != "Online game" else "bots" if app.rot_net.get() != "Online game" else "no bots"
                add(OK, f"Host server is on: {len(entries)} map(s), {app.rot_net.get()}, {who}. It starts when Windows starts.")
            try:
                text = Path(L.STARTUP_CMD).read_text(errors="replace")
                m = re.search(r'start "" "?([^"\r\n]+?\.exe)"?', text)
                if m and not Path(m.group(1)).exists():
                    add(BAD, f"Host server starts {m.group(1)}, which is not there any more. Untick and tick Host server again on the Map Rotation tab.")
            except OSError:
                pass
        ips = local_ips()
        if ips:
            add(OK, "This PC's address on the home network: " + ", ".join(ips) + ".")
        return out

    def built_state(self):
        """True: this exe was built from the launcher.py on disk; False: launcher.py changed since; None: can't tell."""
        if not getattr(sys, "frozen", False):
            return None
        try:
            built = [ln.strip().lower() for ln in (self.HERE / ".build" / "built.sha").read_text().splitlines() if ln.strip()]
        except OSError:
            return None
        now = self.sha("launcher.py")
        return None if not built or not now else built[0] == now

    def health_run(self, quiet=False):
        """The button (shows everything) and the quiet check a few seconds after the launcher opens (speaks only of problems)."""
        if getattr(self, "_health_busy", False):
            return
        self._health_busy = True
        if not quiet:
            self.health_btn.configure(state="disabled")
            self.health_sum.set("Checking...")
        def work():
            try:
                res = self.health()
            except Exception as e:
                res = [(BAD, f"The health check itself failed: {e}")]
            self.health_last, self.health_at = res, time.time()
            bad = [t for lv, t in res if lv == BAD]
            notes = [t for lv, t in res if lv == NOTE]
            word = {OK: "OK      ", NOTE: "NOTE    ", BAD: "PROBLEM "}
            lines = [(lv, word[lv] + t) for lv in (BAD, NOTE, OK) for l2, t in res if l2 == lv]
            summary = (f"{len(bad)} problem(s) to fix" if bad else "No problems found") + (f", {len(notes)} note(s)" if notes else "") + f"  (checked {time.strftime('%I:%M %p').lstrip('0')})"
            def show():
                self._health_busy = False
                self.health_btn.configure(state="normal")
                self.health_sum.set(summary)
                self.text_set(self.health_text, lines)
            self.ui(show)
            if quiet and bad:
                self.app.say(f"health check: {len(bad)} problem(s) found. See the Tools tab. First one: {bad[0]}")
            note = getattr(self.app, "auto_note", None)
            if note and bad:
                for t in bad:
                    note("health check problem: " + t)
        self.bg(work)

    # ---- match history (from the ghost players' logs) -------------------------------------------------------------------
    def marker(self, m):
        """rotation.py's markers, for the status: which map is on."""
        if m.startswith("@map "):
            self.cur_map, self.cur_map_at = m.split(None, 1)[1].strip(), time.time()
            self.maps_played += 1
            # A Map Rotation hosted from here without its user playing (the always-on PC, started by hand rather than by
            # Windows sign-in): answer the other PC's Host PC box too. (10 Nov: the host PC's launcher had been restarted by
            # hand, so the status server, which only host server mode started, was off and the box timed out.)
            try:
                you = self.app.rot_you.get()
            except Exception:
                you = True
            if self.server is None and not you:
                self.serve(lambda msg: self.app.say(msg))
        elif m == "@match-over":
            self.cur_map_at = 0.0

    def match_begin(self, ghost_names):
        """Ghost players are about to join a game: follow their logs until they leave (match_end)."""
        app = self.app
        self.match_end()
        key, mode, source = "", "", "Ghosts"
        try:
            if getattr(app, "rot_ghosts", False):
                key, source = getattr(app, "ghost_rot_level", "") or "", "Map Rotation"
                mode = next((e.get("mode", "") for e in getattr(app, "rot_entries", []) if e.get("map") == key), "")
            elif getattr(app, "ghost_hosted", False):
                gg = getattr(app, "ghost_game", None) or {}
                key, mode, source = gg.get("map", ""), gg.get("mode", ""), "Ghosts"
            else:
                cfg = app.settings()
                key, mode, source = cfg.get("map", ""), cfg.get("mode", ""), "Bots + ghosts"
        except Exception:
            pass
        folder = self.HERE / "GhostLogs"
        offsets = {}
        for f in folder.glob("ghost_*.txt"):                 # (what is in the logs now is the game before this one)
            try: offsets[f.name] = f.stat().st_size
            except OSError: pass
        m = {"t0": time.time(), "map": key, "mode": mode, "source": source, "ghosts": list(ghost_names), "events": [],
             "start_offsets": dict(offsets), "offsets": offsets, "carry": {}, "players": {}, "fighting": set()}
        with self.match_lock:
            self.match = m
        self.players_in = []
        def follow():
            n = 0
            while self.match is m:
                self.match_read(m)
                n += 1
                if n % 2 == 0:
                    self.live_write(m)
                time.sleep(1.0)
        self.bg(follow)

    def match_read(self, m):
        """Read what the ghosts have logged since the last look."""
        folder = self.HERE / "GhostLogs"
        with self.match_lock:
            for f in sorted(folder.glob("ghost_*.txt")):
                try:
                    size = f.stat().st_size
                    off = m["offsets"].get(f.name, 0)
                    if size < off:
                        off = 0                              # the log was started again: this game's
                    if size == off:
                        continue
                    with open(f, "rb") as fh:
                        fh.seek(off)
                        data = fh.read()
                    m["offsets"][f.name] = off + len(data)
                except OSError:
                    continue
                text = m["carry"].pop(f.name, "") + data.decode("utf-8", errors="replace")
                lines = text.split("\n")
                if lines and lines[-1]:
                    m["carry"][f.name] = lines[-1]            # half a line: the rest comes next time
                now = time.time()
                for line in lines[:-1]:
                    line = line.rstrip("\r")
                    k = KILL_RE.match(line)
                    if k:
                        code, a, b = k.group(1), (k.group(2) or "").rstrip("_").strip(), (k.group(3) or "").rstrip("_").strip()
                        if code == "20059" or not b:
                            m["events"].append((now, "self", a, a))
                        else:
                            m["events"].append((now, "tnt" if code == "20061" else "kill", a, b))
                        continue
                    p = PLAYER_IN_RE.match(line)
                    if p:
                        m["players"][p.group(1)] = now
                        m["fighting"].add(f.name)
                    elif line.startswith("no players yet besides the host"):
                        m["fighting"].discard(f.name)
            self.players_in = sorted(m["players"]) if m["fighting"] else []
            self.ghosts_fighting = len(m["fighting"])

    def match_end(self):
        """The ghosts left (the match is over, or the game was closed): work out the table and keep it."""
        m = self.match
        if m is None:
            return
        self.match_read(m)
        with self.match_lock:
            if self.match is m:
                self.match = None
        self.players_in, self.ghosts_fighting = [], 0
        t1 = time.time()
        if not m["events"] and t1 - m["t0"] < 90:            # (ghosts that were stopped before anything happened)
            return
        board = self.live_write(m, final=True)          # (before archive_logs: the logs are still in place)
        self.archive_logs(m)
        rows = score_table(m["events"], m["ghosts"])
        entry = {"t0": m["t0"], "t1": t1, "map": m["map"], "mode": m["mode"], "source": m["source"],
                 "winner": rows[0]["name"] if rows and rows[0]["kills"] > 0 else "", "kills": sum(r["kills"] for r in rows),
                 "players": sorted(m["players"]), "rows": rows}
        if board:
            entry["summary"] = board.get("summary") or {}
            entry["board"] = board.get("rows") or []
            try:
                ls = sys.modules.get("livestats")
                if ls:
                    ls.save_summary(board, self.HERE / "state" / "match_summaries.json")
            except Exception:
                pass
        hist = self._read(self.history_file, [])
        if not isinstance(hist, list):
            hist = []
        hist.append(entry)
        try:
            self._write(self.history_file, hist[-HISTORY_KEEP:])
        except OSError as e:
            self.app.say(f"match history: could not save ({e})")
            return
        if entry["winner"]:
            top = rows[0]
            self.app.say(f"match over on {self.map_label(m['map'])}: {top['name']} won with {top['kills']} kills"
                         + (f" (best streak {top['streak']})" if top["streak"] > 1 else ""))
        try:                                                 # the end-of-match summary (livestats.py): MVP, most kills, streak, best shot
            ls = sys.modules.get("livestats")
            if board and ls:
                for k_, v_ in ls.summary_lines(board):
                    self.app.say(f"  {k_}: {v_}")
        except Exception:
            pass

    def archive_logs(self, m):
        """Copy this match's ghost logs to GhostLogs\\archive\\<time>_<map> before the next map's ghosts start them again from
        empty (a problem noticed late could not be looked into: its logs were gone). The last ARCHIVE_KEEP matches stay, the big
        recordings (.jsonl) only for the newest two."""
        src = self.HERE / "GhostLogs"
        dest = src / "archive" / (time.strftime("%Y-%m-%d_%H%M%S", time.localtime(m["t0"])) + "_" + re.sub(r"[^A-Za-z0-9_-]", "", m["map"] or "map"))
        files = [f for f in list(src.glob("ghost_*.txt")) + list(src.glob("ghost_lan*.jsonl")) if f.is_file()]
        try:                                                 # (taken at once, on this thread: the files are reopened seconds from now)
            dest.mkdir(parents=True, exist_ok=True)
            for f in files:
                try: os.replace(f, dest / f.name) if f.suffix == ".jsonl" else shutil.copy2(f, dest / f.name)
                except OSError:
                    try: shutil.copy2(f, dest / f.name)
                    except OSError: pass
            olds = sorted((d for d in (src / "archive").iterdir() if d.is_dir()), key=lambda d: d.name, reverse=True)
            for i, d in enumerate(olds):
                if i >= ARCHIVE_KEEP:
                    shutil.rmtree(d, ignore_errors=True)
                elif i >= 2:
                    for f in d.glob("*.jsonl"):
                        try: f.unlink()
                        except OSError: pass
        except OSError as e:
            self.app.say(f"ghost logs: could not keep this match's ({e})")

    def history(self):
        hist = self._read(self.history_file, [])
        return hist if isinstance(hist, list) else []

    def show_history(self):
        """The Match history window (Stats tab and Tools tab buttons)."""
        app, L = self.app, self.L
        old = getattr(self, "hist_win", None)
        try:
            if old is not None and old.winfo_exists():
                old.lift()
                return
        except tk.TclError:
            pass
        w = self.hist_win = tk.Toplevel(app)
        w.title("Match history")
        w.configure(bg=L.PARCH)
        top = ttk.Frame(w)
        top.grid(row=0, column=0, sticky="w", padx=10, pady=(10, 4))
        ttk.Label(top, text="Matches from").pack(side="left")
        src = ttk.Combobox(top, values=["This PC", "The host PC"], state="readonly", width=14)
        src.set("The host PC" if self.host.get().strip() and not self.history() else "This PC")
        src.pack(side="left", padx=8)
        note = tk.StringVar()
        ttk.Button(top, text="Refresh", command=lambda: load()).pack(side="left")
        ttk.Label(top, textvariable=note).pack(side="left", padx=10)
        cols = ("When", "Map", "Mode", "Minutes", "Winner", "Kills", "From")
        tree = ttk.Treeview(w, columns=cols, show="headings", height=10, selectmode="browse")
        for c, wd in zip(cols, (140, 170, 130, 70, 150, 60, 110)):
            tree.heading(c, text=c)
            tree.column(c, width=wd, anchor="w" if c in ("When", "Map", "Mode", "Winner", "From") else "center")
        tree.grid(row=1, column=0, padx=10, pady=4)
        pcols = ("Player", "Kills", "Deaths", "Best streak", "Kind")
        ptree = ttk.Treeview(w, columns=pcols, show="headings", height=10)
        for c, wd in zip(pcols, (220, 80, 80, 100, 120)):
            ptree.heading(c, text=c)
            ptree.column(c, width=wd, anchor="w" if c in ("Player", "Kind") else "center")
        ptree.grid(row=2, column=0, padx=10, pady=4, sticky="w")
        about = ("Matches with ghost players are saved here when the ghosts leave (the end of a map, or when the game is closed). "
                 "Kills are counted from the ghosts' own death messages, so a kill on a ghost always counts. Deaths show only for "
                 "ghosts for now: when a real player or a bot dies it is not written anywhere the launcher can read yet.")
        if hasattr(app, "hint"):
            app.hint(top, about).pack(side="left", padx=(0, 6))
            ttk.Frame(w, height=8).grid(row=3, column=0)
        else:
            ttk.Label(w, wraplength=800, justify="left", text=about).grid(row=3, column=0, sticky="w", padx=10, pady=(2, 10))
        shown = []

        def fill(hist, msg):
            shown[:] = list(reversed(hist))
            tree.delete(*tree.get_children())
            ptree.delete(*ptree.get_children())
            for i, e in enumerate(shown):
                mins = max(0, round((e.get("t1", 0) - e.get("t0", 0)) / 60))
                tree.insert("", "end", iid=str(i), values=(_when(e.get("t0", 0)), self.map_label(e.get("map")), self.mode_label(e.get("mode")),
                                                           mins, e.get("winner") or "-", e.get("kills", 0), e.get("source", "")))
            note.set(msg if msg else f"{len(shown)} match(es)" if shown else "No matches saved yet.")
            if shown:
                tree.selection_set("0")
                pick()

        def pick(_e=None):
            sel = tree.selection()
            ptree.delete(*ptree.get_children())
            if not sel:
                return
            e = shown[int(sel[0])]
            real = set(e.get("players") or [])
            for r in e.get("rows", []):
                kind = "Ghost" if r.get("ghost") else "Player" if r.get("name") in real else "Player or bot"
                ptree.insert("", "end", values=(r.get("name"), r.get("kills"), "-" if r.get("deaths") is None else r.get("deaths"),
                                                r.get("streak"), kind))

        def load():
            if src.get() == "This PC":
                fill(self.history(), "")
                return
            host = self.host.get().strip()
            if not host:
                fill([], "Type the host PC's address on the Tools tab first.")
                return
            note.set("Asking the host PC...")
            def work():
                try:
                    hist = json.loads(self.fetch(host, "/history", 15).decode("utf-8"))
                    self.ui(lambda: fill(hist if isinstance(hist, list) else [], ""))
                except Exception as e:
                    self.ui(lambda: fill([], f"Could not reach the host PC at {host} ({e})."))
            self.bg(work)
        tree.bind("<<TreeviewSelect>>", pick)
        src.bind("<<ComboboxSelected>>", lambda e: load())
        load()

    # ---- status: this PC's, and the host PC's over the home network ------------------------------------------------------
    def status(self):
        """What this launcher is doing, as plain data (the host PC sends this to whoever asks on the home network)."""
        app = self.app
        if time.time() - self.copies_at > 45:                # (asking Windows takes a second or two: not on every request)
            self.copies_at = time.time()
            def ask():
                pids = self.L.bot_game_pids()
                if pids is not None:
                    self.copies = len(pids)
            self.bg(ask)
        procs = [p for p in getattr(app, "ghost_procs", []) or [] if p.poll() is None]
        m = self.match
        rot = None
        try:
            rot = {"net": app.rot_net.get(), "who": app.rot_who.get(), "maps": len(app.rot_entries), "ghosts": int(app.rot_gh_n.get()),
                   "ghost_diff": app.rot_gh_diff.get(), "loop": bool(app.rot_loop.get())}
        except Exception:
            pass
        top = []
        if m is not None:
            with self.match_lock:
                top = [(r["name"], r["kills"]) for r in score_table(m["events"], m["ghosts"])[:3] if r["kills"]]
        return {
            "pc": socket.gethostname(), "time": time.time(), "up": time.time() - self.t0,
            "server_mode": bool(getattr(app, "server_mode", False)), "launching": bool(getattr(app, "launching", False)),
            "rotation_on": bool(getattr(app, "rotation_args", None)), "rotation": rot,
            "map": self.cur_map, "map_since": self.cur_map_at, "maps_played": self.maps_played,
            "ghosts_running": len(procs), "ghosts_fighting": self.ghosts_fighting, "players": list(self.players_in),
            "match_top": top, "copies": self.copies,
            "files": {n: (self.sha(n) or "")[:16] for n in KEY_FILES}, "built": self.built_state(),
            "problems": [t for lv, t in self.health_last if lv == BAD], "health_at": self.health_at,
            "log": list(getattr(app, "recent", []))[-10:],
        }

    def status_lines(self, s, where):
        """A status as lines for the Host PC box."""
        out = []
        up = int(s.get("up", 0))
        out.append((None, f"{s.get('pc', '?')} ({where}): the launcher has been open {up // 3600} h {up % 3600 // 60} min"
                    + (", in host server mode." if s.get("server_mode") else ".")))
        rot = s.get("rotation") or {}
        if s.get("launching") and not s.get("map"):
            out.append((NOTE, "A game is starting right now."))
        if s.get("rotation_on") or s.get("map"):
            who = (f"{rot.get('ghosts')} ghosts, {rot.get('ghost_diff')}" if rot.get("who") == "Ghosts" and rot.get("net") != "Online game"
                   else "online, no bots" if rot.get("net") == "Online game" else "bots")
            line = f"Map Rotation ({rot.get('net', '?')}, {who}, {rot.get('maps', '?')} maps on the list)."
            if s.get("map"):
                line += f" On now: {self.map_label(s['map'])}"
                if s.get("map_since"):
                    line += f", {max(0, int((s.get('time', 0) - s['map_since']) / 60))} min in"
                else:
                    line += " (between maps)"
                line += f". Maps hosted so far: {s.get('maps_played', 0)}."
            out.append((None, line))
        elif not s.get("launching"):
            out.append((NOTE if s.get("server_mode") else None, "No Map Rotation is running" + (" yet (a host server waits 90 seconds after Windows starts)." if s.get("server_mode") else ".")))
        g = s.get("ghosts_running", 0)
        if g or s.get("players"):
            players = ", ".join(s.get("players") or [])
            out.append((None, f"Ghost players in the game: {g}. " + (f"Real players in: {players}." if players else
                        "No real player is in" + (", so the ghosts are standing still." if rot.get("who") == "Ghosts" else "."))))
        if s.get("match_top"):
            out.append((None, "This map so far: " + ", ".join(f"{n} {k}" for n, k in s["match_top"]) + " kills."))
        if s.get("copies") is not None:
            out.append((None, f"Game copies running on it: {s['copies']}."))
        if s.get("built") is False:
            out.append((NOTE, "Its launcher window is older than its launcher.py: it needs a rebuild (get_update does that) or Update Launcher."))
        for t in s.get("problems") or []:
            out.append((BAD, "Problem there: " + t))
        return out

    def host_show(self, lines):
        self.text_set(self.host_text, lines)

    def fetch(self, host, path, timeout=8):
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))       # the home network: never through a proxy
        with opener.open(f"http://{host}:{HOST_PORT}{path}", timeout=timeout) as r:
            return r.read()

    def host_save(self):
        self.cfg["host"] = self.host.get().strip()
        try:
            self._write(self.cfg_file, self.cfg)
        except OSError:
            pass

    def host_check(self):
        host = self.host.get().strip()
        self.host_save()
        if not host:
            self.host_show(self.status_lines(self.status(), "this PC") + [(NOTE, "(No host address typed: this is this PC's own status.)")])
            return
        self.host_show([(None, f"Asking {host}...")])
        def work():
            try:
                s = json.loads(self.fetch(host, "/status").decode("utf-8"))
            except Exception as e:
                lines = [(BAD, f"Could not reach a host server at {host} ({e})."),
                         (None, "Is that PC on and signed in? A host server waits 90 seconds after Windows starts before it does anything."),
                         (None, "Its launcher must be running in host server mode (Host server ticked on its Map Rotation tab, then Windows restarted), "
                                "and be this version or newer (Send update)."),
                         (None, "The first time, Windows Firewall on that PC asks whether BotLauncher may be reached: answer Allow (Private networks).")]
                self.ui(lambda: self.host_show(lines))
                return
            lines = self.status_lines(s, host)
            mine = {n: (self.sha(n) or "")[:16] for n in KEY_FILES}
            theirs = s.get("files") or {}
            diff = [n for n in KEY_FILES if mine.get(n) and theirs.get(n) != mine[n]]
            if diff:
                lines.append((NOTE, f"{len(diff)} tool file(s) there differ from this PC's ({', '.join(diff)}). Press Send update, then run get_update on that PC."))
            else:
                lines.append((OK, "Its tool files are the same as this PC's."))
            if s.get("log"):
                lines.append((None, "Its last messages:"))
                lines += [(None, "   " + str(t)[:200]) for t in s["log"][-5:]]
            self.ui(lambda: self.host_show(lines))
        self.bg(work)

    def host_find(self):
        """Ask the home network whether a host server is there (it answers a broadcast)."""
        self.host_show([(None, "Looking for a host server on the home network...")])
        def work():
            found = []
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                s.settimeout(0.5)
                mine = local_ips()
                targets = {"255.255.255.255"} | {ip.rsplit(".", 1)[0] + ".255" for ip in mine}
                for _ in range(2):
                    for t in targets:
                        try: s.sendto(HELLO, (t, HOST_PORT))
                        except OSError: pass
                    end = time.time() + 1.2
                    while time.time() < end:
                        try:
                            data, addr = s.recvfrom(2048)
                        except OSError:
                            continue
                        if data.startswith(HERE_I_AM) and addr[0] not in mine and addr[0] not in [f[0] for f in found]:
                            found.append((addr[0], data[len(HERE_I_AM):].decode("utf-8", errors="replace").strip()))
                    if found:
                        break
                s.close()
            except OSError as e:
                self.ui(lambda: self.host_show([(BAD, f"Could not search the network: {e}")]))
                return
            def show():
                if not found:
                    self.host_show([(NOTE, "No host server answered. It must be on, with its launcher in host server mode and this version or newer."),
                                    (None, "You can also type its address by hand: on that PC, the health check's last line shows it.")])
                    return
                self.host.set(found[0][0])
                self.host_save()
                self.host_check()
            self.ui(show)
        self.bg(work)

    def host_update(self):
        """Start share_files.cmd (hands the tool files to the other PC's get_update.cmd), if this PC has it."""
        script = self.HERE / "share_files.cmd"
        if not script.exists():
            messagebox.showinfo("Send update", "share_files.cmd is not in the botctl folder on this PC.\n\nIt is the small helper that hands "
                                "this PC's tool files to another PC at home.")
            return
        try:
            subprocess.Popen(["cmd", "/c", "start", "Sharing bot files", "/D", str(self.HERE), str(script)], cwd=str(self.HERE),
                             creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except OSError as e:
            messagebox.showerror("Send update", f"Could not start the sharing window:\n{e}")
            return
        self.app.say("sharing this PC's tool files: now double-click get_update.cmd in the botctl folder on the other PC")
        self.host_show([(None, "The sharing window is open on this PC."),
                        (None, "Now, on the host PC, double-click get_update.cmd in its botctl folder. It copies what changed and rebuilds its launcher if needed."),
                        (None, "The sharing window closes by itself when the host PC is done. Then press Check now.")])

    def host_report(self):
        host = self.host.get().strip()
        if not host:
            messagebox.showinfo("Host PC", "Type the host PC's address first (or press Find).")
            return
        self.host_save()
        note = simpledialog.askstring("Host PC's problem report", "In a few words, what went wrong? (You can leave this empty.)", parent=self.app)
        if note is None:
            return
        self.host_show([(None, f"Asking {host} to make a problem report (up to a minute)...")])
        def work():
            try:
                data = self.fetch(host, "/report?note=" + quote(note.strip()[:300]), 180)
                folder = self.HERE / "reports"
                folder.mkdir(exist_ok=True)
                out = folder / f"host_problem_{time.strftime('%Y-%m-%d_%H%M%S')}.zip"
                out.write_bytes(data)
            except Exception as e:
                self.ui(lambda: self.host_show([(BAD, f"Could not get a problem report from {host} ({e}).")]))
                return
            self.ui(lambda: self.host_show([(OK, f"The host PC's problem report is saved on this PC: reports\\{out.name} ({len(data) // 1024} KB)."),
                                            (None, "A folder window shows it. Attach that file to your message.")]))
            self.reveal(out)
        self.bg(work)

    def serve(self, note=None):
        """Host server mode: answer status / history / problem report requests from PCs on the same home network."""
        if self.server is not None:
            return
        tools = self

        nets_cache = [0.0, set()]

        def allowed(ip):
            if ip.startswith("127."):
                return True
            if time.time() - nets_cache[0] > 60:             # (looked up at most once a minute)
                try:
                    zt = tools.L.zerotier_ip()
                except Exception:
                    zt = None
                nets_cache[:] = [time.time(), {a.rsplit(".", 1)[0] for a in local_ips() if a != zt}]   # the home network only: not the friends' ZeroTier one
            return ip.rsplit(".", 1)[0] in nets_cache[1]

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def reply(self, data, ctype="application/json", code=200):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                if not allowed(self.client_address[0]):
                    return self.reply(b"not from this network", "text/plain", 403)
                path = urlparse(self.path).path
                try:
                    if path == "/status":
                        return self.reply(json.dumps(tools.status()).encode("utf-8"))
                    if path == "/history":
                        return self.reply(json.dumps(tools.history()).encode("utf-8"))
                    if path == "/report":
                        said = (parse_qs(urlparse(self.path).query).get("note") or [""])[0]
                        out = tools.report_make((said + "  " if said else "") + f"(asked for by {self.client_address[0]})", shot=True)
                        return self.reply(out.read_bytes(), "application/zip")
                except Exception as e:
                    return self.reply(f"error: {e}".encode("utf-8", errors="replace"), "text/plain", 500)
                self.reply(b"not found", "text/plain", 404)
        try:
            self.server = ThreadingHTTPServer(("0.0.0.0", HOST_PORT), Handler)
        except OSError as e:
            if note: note(f"status for other PCs is off: port {HOST_PORT} could not be opened ({e})")
            return
        self.bg(self.server.serve_forever)

        def hello():                                         # "is a host there?" broadcasts from the Tools tab's Find button
            try:
                u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                u.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                u.bind(("0.0.0.0", HOST_PORT))
            except OSError:
                return
            while True:
                try:
                    data, addr = u.recvfrom(256)
                    if data.startswith(HELLO) and allowed(addr[0]):
                        u.sendto(HERE_I_AM + socket.gethostname().encode("utf-8", errors="replace"), addr)
                except OSError:
                    time.sleep(1)
        self.bg(hello)
        if note: note(f"other PCs on the home network can ask this one how it is doing (port {HOST_PORT}; the Tools tab's Host PC box)")

    # ---- problem report --------------------------------------------------------------------------------------------
    def report_make(self, note="", shot=True):
        """One zip with everything worth sending about a problem; returns its path. Slow: call it off the UI thread."""
        app, HERE = self.app, self.HERE
        folder = HERE / "reports"
        folder.mkdir(exist_ok=True)
        stamp = time.strftime("%Y-%m-%d_%H%M%S")
        out = folder / f"problem_{stamp}.zip"
        budget = [60 * 2 ** 20]                               # the whole zip's uncompressed allowance

        def add_file(z, path, arc, limit):
            try:
                if not path.is_file():
                    return
                data = _tail(path, min(limit, max(0, budget[0])))
                budget[0] -= len(data)
                z.writestr(arc, data)
            except OSError:
                pass
        try:
            health = self.health()
            self.health_last, self.health_at = health, time.time()
        except Exception as e:
            health = [(BAD, f"health check failed: {e}")]
        lines = [f"Problem report {stamp}", "=" * 60, "", "What went wrong (as typed): " + (note or "(nothing typed)"), "",
                 f"PC: {socket.gethostname()}   Windows: {platform.platform()}", f"Launcher: {'built exe' if getattr(sys, 'frozen', False) else 'run from launcher.py'}"
                 f"   folder: {HERE}", f"Addresses: {', '.join(local_ips())}", "", "Health check:"]
        lines += [f"  [{lv.upper()}] {t}" for lv, t in health]
        lines += ["", "Tool files (changed, size, fingerprint):"]
        for n in KEY_FILES + ["BotLauncher.exe", "build_exe.cmd", "bots.cmd"]:
            p = HERE / n
            try:
                st = p.stat()
                lines.append(f"  {n:22} {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(st.st_mtime))} {st.st_size:>10} {(self.sha(n) or '')[:16] if st.st_size < 5 * 2 ** 20 else ''}")
            except OSError:
                lines.append(f"  {n:22} MISSING")
        try:
            lines += ["", "Status:", json.dumps(self.status(), indent=1)]
        except Exception as e:
            lines += ["", f"Status: unavailable ({e})"]
        lines += ["", "The launcher's own messages (newest last):", "-" * 60] + list(getattr(app, "recent", []))[-500:]
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("summary.txt", "\n".join(lines) + "\n")
            try:
                import bugshot
                z.writestr("system.txt", bugshot.build_report(stamp))
                if shot and os.name == "nt":
                    z.writestr("screenshot.png", bugshot.screenshot_png())
            except Exception as e:
                z.writestr("system.txt", f"unavailable: {e}\n")
            for name in ("launcher_settings.json", "rotation.txt", "ghost_options.json", "match_history.json",
                         "tools_settings.json", "relay_settings.json"):
                add_file(z, HERE / name, name, 2 * 2 ** 20)
            for p in sorted(HERE.glob("*_log.txt")):
                add_file(z, p, p.name, 2 * 2 ** 20)
            day = time.time() - 86400
            def recent(folder_, pattern, keep):
                try:
                    fs = [f for f in (HERE / folder_).glob(pattern) if f.is_file()]
                    return sorted(fs, key=lambda f: f.stat().st_mtime, reverse=True)[:keep]
                except OSError:
                    return []
            for p in recent("GhostLogs", "*.txt", 40):
                add_file(z, p, f"GhostLogs/{p.name}", 4 * 2 ** 20)
            for p in recent("botlogs", "*.log", 30):
                add_file(z, p, f"botlogs/{p.name}", 3 * 2 ** 20)
            for p in recent("state", "*", 80):
                add_file(z, p, f"state/{p.name}", 256 * 1024)
            for p in recent("horde_logs", "*.txt", 6):
                add_file(z, p, f"horde_logs/{p.name}", 2 * 2 ** 20)
            for p in recent("profiles", "*/kexengine.log", 4):
                add_file(z, p, f"profiles/{p.parent.name}/kexengine.log", 2 ** 20)
            add_file(z, Path.home() / "Saved Games" / "Nightdive Studios" / "Outlaws EX" / "kexengine.log", "my_game/kexengine.log", 2 ** 20)
            for p in recent("screenshots", "bug_*", 4):
                if p.stat().st_mtime > day:
                    add_file(z, p, f"screenshots/{p.name}", 12 * 2 ** 20)
            try:
                arch = sorted((d for d in (HERE / "GhostLogs" / "archive").iterdir() if d.is_dir()), key=lambda d: d.name, reverse=True)
            except OSError:
                arch = []
            # the two matches before this one, and (14 Nov: a player's report came 7 hours late, its logs long gone) every match of
            # the last day that had a real player in it ("a player is in" in a ghost's log), newest first, up to 12
            def _had_player(d):
                try: return any(b"a player is in (" in t or re.search(rb"players in the game: (?!nobody)", t) for t in (p.read_bytes() for p in d.glob("ghost_*.txt")))
                except OSError: return False
            arch = arch[:2] + [d for d in arch[2:] if d.stat().st_mtime > day and _had_player(d)][:12]
            for d in arch:                                    # the matches before this one (their ghosts' logs)
                for p in sorted(d.glob("*.txt")):
                    add_file(z, p, f"GhostLogs/archive/{d.name}/{p.name}", 2 * 2 ** 20)
            for p in recent("GhostLogs", "*.jsonl", 30):          # the ghosts' detailed recordings: newest first, while there is room
                if p.stat().st_mtime > day and budget[0] > 8 * 2 ** 20:
                    add_file(z, p, f"GhostLogs/{p.name}", 4 * 2 ** 20)
            for d in arch[:1]:                                # and the last finished match's recordings, while there is room
                for p in sorted(d.glob("*.jsonl")):
                    if budget[0] > 8 * 2 ** 20:
                        add_file(z, p, f"GhostLogs/archive/{d.name}/{p.name}", 3 * 2 ** 20)
        return out

    def reveal(self, path):
        """Open a folder window with the file selected."""
        try:
            if os.name == "nt":
                subprocess.Popen(["explorer", "/select,", str(path)])
        except OSError:
            pass

    def report_click(self):
        note = simpledialog.askstring("Problem report", "In a few words, what went wrong? (You can leave this empty.)", parent=self.app)
        if note is None:
            return
        host = self.host.get().strip()
        self.report_note.set("Making the report (up to a minute)..." + (" The host PC's comes too." if host else ""))
        def work():
            try:
                out = self.report_make(note.strip(), shot=True)
                msg = f"Saved: reports\\{out.name} ({out.stat().st_size // 1024} KB)."
                self.app.say(f"problem report saved: reports\\{out.name}")
            except Exception as e:
                out, msg = None, f"This PC's report could not be made: {e}."
            if host:                                         # the game's ghosts run on the host PC: its logs are the ones that matter
                try:
                    data = self.fetch(host, "/report?note=" + quote(note.strip()[:300]), 180)
                    hout = self.HERE / "reports" / f"host_problem_{time.strftime('%Y-%m-%d_%H%M%S')}.zip"
                    hout.parent.mkdir(exist_ok=True)
                    hout.write_bytes(data)
                    msg += f" The host PC's: reports\\{hout.name} ({len(data) // 1024} KB). Send both files."
                    self.app.say(f"the host PC's problem report saved: reports\\{hout.name}")
                    out = out or hout
                except Exception as e:
                    msg += f" The host PC at {host} could not be asked for its report ({e})."
            if out is not None:
                self.reveal(out)
            self.ui(lambda: self.report_note.set(msg))
        self.bg(work)
