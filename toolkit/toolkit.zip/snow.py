"""Falling snow for the Christmas Horde: python snow.py <run id> <horde.py pid>
Once a player is on the Survivors team, snow drifts down over the screen (snowfx.py: a click-through, per-pixel
see-through window on top of the game that never takes the focus). Stops when horde.py writes state\\stop_<run id>, the match is over, or
horde.py ends. snow.run(stop_check) is also used by the Outlaws Companion for joined games."""
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))



def run(should_stop, focus_hwnd=None):
    """Snow until should_stop() is true (snowfx.py: soft flakes in three depths, wind gusts)."""
    import snowfx
    snowfx.run(should_stop, focus_hwnd)


def main():
    run_id = sys.argv[1] if len(sys.argv) > 1 else ""
    parent = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    import ambient                                           # (alive())
    stop = HERE / "state" / f"stop_{run_id}"
    human = HERE / "state" / f"human_{run_id}.flag"
    over = HERE / "state" / f"music_stop_{run_id}"
    while not human.exists():
        if stop.exists() or (parent and not ambient.alive(parent)):
            return
        time.sleep(0.5)
    run(lambda: stop.exists() or over.exists() or (parent and not ambient.alive(parent)))


if __name__ == "__main__":
    main()
