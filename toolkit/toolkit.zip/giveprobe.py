"""Probe: give IBPLATE once (the game picks the inventory slot) and show every inventory slot before and after."""
import sys, time
from pathlib import Path
import frida
HERE = Path(__file__).resolve().parent
dev = frida.get_local_device()
pids = [p.pid for p in dev.enumerate_processes() if p.name.lower() == "outlawsahom.exe"]
pid = int(sys.argv[1]) if len(sys.argv) > 1 else (pids[0] if len(pids) == 1 else None)
if not pid:
    sys.exit(f"pass the game's pid: {pids}")
s = dev.attach(pid)
sc = s.create_script((HERE / "input_agent.js").read_text())
sc.on("message", lambda m, d: None)
sc.load()
api = sc.exports_sync
out = open(HERE / "giveprobe_log.txt", "a", encoding="utf-8")
def say(t):
    print(t, flush=True); out.write(t + "\n"); out.flush()
def show(tag):
    inv = ((api.world().get("self") or {}).get("inventory")) or {}
    say(f"{tag}: armor={inv.get('armor')} carried={inv.get('carried')}")
    say("   slots: " + ", ".join(f"{x['i']}={x['name']}x{x['count']}" for x in inv.get("slots", [])))
show("before")
r = api.give(["IBPLATE"])
say(f"give IBPLATE -> {r}")
time.sleep(1.0)
show("after one IBPLATE")
r = api.give(["IBPLATE"])
say(f"give IBPLATE again -> {r}")
time.sleep(1.0)
show("after two")
try:
    api.shutdown(); time.sleep(0.5); s.detach()
except Exception:
    pass
