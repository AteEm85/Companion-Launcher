"""Juggernaut / Infection for the human player: keep your game dressed for your role.

  python rolesplayer.py <launcher pid>

Attaches the bot agent to the one OutlawsAHOM.exe that isn't a bot, reads state/roles.json (kept by the hosting bot,
see roles.py) and, when your name (BOT_STATS_PLAYER, the Stats tab) holds a role,
  - Juggernaut: when you are the one, hands you 150 armour, every weapon, 7 TNT, 6 knives and 2 med bags, and shows
                who the Juggernaut is, how far and which way, on screen (ggbanner.py),
  - infected:   takes every gun away, leaves you the knife and fists, and makes you run faster.
Infection needs the player name on the Stats tab. Leaves your game alone again when the launcher closes or the game does.
Log: rolesplayer_log.txt"""
import os
import sys
import time
from pathlib import Path

import frida

import gungame
import roles
from ggplayer import alive, human_pid

HERE = Path(__file__).resolve().parent
LOG = HERE / "rolesplayer_log.txt"


def log(msg):
    try:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S ") + msg + "\n")
    except OSError:
        pass


EYE_ABOVE_FEET = float(os.environ.get("BOT_JUG_EYE", "5.0"))      # guesses; tune if the marker sits too high or low
HEAD_ABOVE_FEET = float(os.environ.get("BOT_JUG_HEAD", "7.6"))


class Player:
    def __init__(self, api):
        self.api = api
        self.role = None
        self.last = {"poll": 0.0, "give": 0.0, "key": 0.0, "strip": 0.0}
        self.speed = 1.0
        self.first = True
        self.boom_seen = None

    def tap(self, digit):
        sc, kc = 30 + (digit - 1) % 10, ord(str(digit))
        self.api.key(sc, kc, True)
        time.sleep(0.06)
        self.api.key(sc, kc, False)

    def set_speed(self, mult):
        if mult != self.speed:
            try:
                if self.api.set_speed(mult):
                    self.speed = mult
                    log(f"walking speed x{mult:g}")
            except Exception as e:
                log(f"could not set the speed: {e}")

    def step(self, now):
        if now - self.last["poll"] > 0.5:
            self.last["poll"] = now
            st = roles.read()
            role = "inf" if (roles.MODE == "inf" and roles.is_infected(st, roles.HUMAN)) else None
            if roles.MODE == "jug" and roles.is_juggernaut(st, roles.HUMAN):
                role = "jug"
            elif roles.MODE == "pot" and st and roles.HUMAN and st.get("holder") == roles.HUMAN:
                role = "pot"
            if roles.MODE == "pot" and st and roles.HUMAN:       # the fuse ran out on you: your game copy takes your health to 0
                if self.boom_seen is None:
                    self.boom_seen = st.get("boom", 0)
                if st.get("boom_name") == roles.HUMAN and st.get("boom", 0) != self.boom_seen:
                    self.boom_seen = st.get("boom", 0)
                    log(f"the potato blew up on you: {self.api.kill_self()}")
                elif st.get("boom_name") == roles.HUMAN:
                    self.boom_seen = st.get("boom", 0)
            if role != self.role:
                self.role = role
                self.last["give"] = 0.0
                self.first = True
                log(f"you are now {role or 'a plain player'}")
                self.set_speed(roles.INFECTED_SPEED if role == "inf" else 1.0)
        w = self.api.world()
        me = (w or {}).get("self") or {}
        if roles.MODE in ("jug", "pot") and w and w.get("ok"):
            try:                                                # tell the overlay who it is, how far, which way (and the fuse), every tick
                players = w.get("players") or []
                mine = next((p for p in players if p.get("local")), None)
                if now - self.last.get("state", 0.0) > 0.3:      # who it is: from the files, a few times a second
                    self.last["state"] = now
                    self.st = roles.read()
                    self.addr_who = None
                st = getattr(self, "st", None)
                key = "jug" if roles.MODE == "jug" else "holder"
                label = "JUGGERNAUT" if roles.MODE == "jug" else "HOT POTATO"
                who = st.get(key) if st else None
                secs = max(0, round(st.get("fuse_at", 0) - time.time())) if (roles.MODE == "pot" and st and who) else None
                if now - self.last.get("addr", 0.0) > 0.25 or getattr(self, "addr_who", None) != who:
                    self.last["addr"], self.addr_who = now, who
                    self.addr_cache = roles.find_actor(who, players, roles.HUMAN) if who else None
                addr = getattr(self, "addr_cache", None)
                tgt = next((p for p in players if p["addr"] == addr), None) if addr else None
                if who and who == roles.HUMAN and roles.MODE == "pot":
                    roles.write_marker(who, None, None, label, secs, True)      # you have it
                elif mine and tgt and who != roles.HUMAN:
                    import math
                    brg = math.degrees(math.atan2(tgt["x"] - mine["x"], tgt["z"] - mine["z"]))
                    rel = (brg - mine["yaw"] * 360.0 / 16384.0 + 180.0) % 360.0 - 180.0
                    flat = math.hypot(tgt["x"] - mine["x"], tgt["z"] - mine["z"])
                    # where his head is relative to where we look (degrees, right and up), for the overlay to put a marker over it
                    elev = math.degrees(math.atan2((tgt.get("y", 0.0) + HEAD_ABOVE_FEET) - (mine.get("y", 0.0) + EYE_ABOVE_FEET), max(flat, 0.1)))
                    look_up = (me.get("pitch") or 0) * 360.0 / 16384.0
                    roles.write_marker(who, round(flat), round(rel), label, secs, head=[round(rel, 2), round(elev - look_up, 2)])
                elif who and who != roles.HUMAN:
                    roles.write_marker(who, None, None, label, secs)           # known but not found on screen
                else:
                    roles.write_marker(None, None, None)
            except Exception as e:
                log(f"marker failed: {e}")
        if now - self.last.get("slow", 0.0) < 0.2:                # everything below is for 5 times a second, not every frame
            return
        self.last["slow"] = now
        hp = me.get("health")
        if (roles.MODE == "jug" and roles.GATLING and w and w.get("ok") and hp and hp > 0 and roles.HUMAN
                and not (getattr(self, "st", None) or {}).get("jug") and roles.has_gatling(me.get("inventory"))
                and roles.claim(roles.HUMAN)):
            log("you picked up the silver Gatling")
        if not w or not w.get("ok") or not hp or hp <= 0 or self.role is None:
            if self.role is None and self.speed != 1.0:
                self.set_speed(1.0)
            return
        inv = me.get("inventory") or {}
        owned = {x["slot"]: x for x in inv.get("weapons") or []}
        if self.role == "jug":
            if roles.jug_short(inv, self.first) and now - self.last["give"] > 6.0:
                self.last["give"] = now
                res = roles.jug_give(self.api, self.first)
                self.first = False                            # armour and med bags only once
                log(f"Juggernaut loadout: {res.get('ok') if isinstance(res, dict) else res}")
            return
        # infected: the knife, nothing else
        carried = inv.get("carried") or {}
        if 8 not in owned and now - self.last["give"] > 1.5:
            self.last["give"] = now
            self.api.give(gungame.GIVE[8])
            log("gave the knife")
            return
        if 8 not in owned:
            return
        if inv.get("slot") != 8:
            if now - self.last["key"] > 0.5:
                self.last["key"] = now
                self.tap(8)
            return
        if [s for s in owned if s not in (1, 8)] and now - self.last["strip"] > 0.15:
            self.last["strip"] = now
            log(f"took away the guns: {self.api.strip_weapons(8, 0)}")
        if carried.get("IKNIFE", 0) < 2 and now - self.last["give"] > 4.0:
            self.last["give"] = now
            self.api.give(gungame.GIVE[8])


def run(pid, parent):
    dev = frida.get_local_device()
    session = dev.attach(pid)
    script = session.create_script((HERE / "input_agent.js").read_text(encoding="utf-8"))
    script.on("message", lambda m, d: None)
    script.load()
    api = script.exports_sync
    log(f"attached to pid {pid}; mode {roles.MODE}; name {roles.HUMAN or '(unknown: no role for you)'}")
    try:
        p = Player(api)
        while alive(pid) and (not parent or alive(parent)):
            try:
                p.step(time.time())
            except frida.InvalidOperationError:
                break
            except Exception as e:
                log(f"step failed: {e}")
            time.sleep(0.016)
    finally:
        try:
            roles.write_marker(None, None, None)
            api.set_speed(1.0)
            api.release()
            api.shutdown()
            time.sleep(0.5)
        except Exception:
            pass
        try:
            session.detach()
        except Exception:
            pass
        log("let go of the game")


def main():
    parent = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    if not roles.MODE:
        log("no mode: nothing to do")
        return
    while not parent or alive(parent):
        pid = human_pid()
        if pid:
            try:
                run(pid, parent)
            except Exception as e:
                log(f"could not attach: {e}")
            time.sleep(5)
        else:
            time.sleep(3)


if __name__ == "__main__":
    main()
