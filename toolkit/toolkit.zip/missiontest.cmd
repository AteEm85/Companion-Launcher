@echo off
rem Seamless Co-op Mission test: mission 1 is skipped through, then mission 2 should load in the same games
rem (the host bot's and yours). See missiontest.py. Log: state\missiontest.txt
cd /d "%~dp0"
".venv\Scripts\python.exe" -u missiontest.py
