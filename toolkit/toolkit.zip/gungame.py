"""Gun game: one weapon at a time, a kill moves you up the ladder, a death moves you down one rung.
The last two rungs are TNT and the knife; a kill with the knife wins the round (everyone starts over)."""
import dataclasses
import os

# weapon slots: 1 fists, 2 pistol, 3 rifle, 4 shotgun, 5 double-barrel, 6 sawed-off, 7 TNT, 8 knife, 9 gatling
DEFAULT_ORDER = [5, 4, 3, 9, 6, 2, 7, 8]     # TNT and the knife last
LADDER = list(DEFAULT_ORDER)
try:                                          # the launcher passes its choice on in BOT_GG_ORDER ("5,4,3,...")
    _o = [int(x) for x in os.environ.get("BOT_GG_ORDER", "").split(",") if x.strip()]
    if _o and all(1 <= x <= 9 for x in _o):
        LADDER = _o
except ValueError:
    pass
STINNETT = bool(os.environ.get("BOT_GG_STINNETT"))   # gatling included: the stinnett cheat lets you move with it
NAMES = {1: "fists", 2: "pistol", 3: "rifle", 4: "shotgun", 5: "double-barrel", 6: "sawed-off",
         7: "TNT", 8: "knife", 9: "gatling"}
CHEAT = "olpostal"          # typed as key presses during play: every weapon (and ammo)


def slot_for(rung):
    return LADDER[max(0, min(rung, len(LADDER) - 1))]


def rung_skill(base, rung):
    """The bot's Skill for this rung: only the rung's weapon is used, whatever the personality."""
    slot = slot_for(rung)
    kw = dict(favorite=slot, lean=None, prefer_close=[slot], prefer_far=[slot], prefer_long=[slot],
              far_long=None, tnt=False, melee_only=False, knife_first=False)
    if slot == 7:
        kw.update(tnt=True, melee_only=True, keep_distance=60.0, back_off=40.0)
    elif slot == 8:
        kw.update(melee_only=True, keep_distance=2.0, back_off=0.0, prefer_close=[8, 1], prefer_far=[8, 1],
                  prefer_long=[8, 1], knife_keep=60.0)
    return dataclasses.replace(base, **kw)

# What the game is asked to hand over for each rung (Player_PickupItem names; ammo items are guesses to confirm)
AMMO_ITEM = {2: "IBULLIT", 3: "ICART", 4: "ISHELLS", 5: "ISHELLS", 6: "ISHELLS", 9: "ICLIP"}
AMMO_PACKS = 20                    # ammo items handed over with a weapon (the game caps it at the gun's maximum)
WEAPON_ITEM = {2: "IPISTOL", 3: "IRIFLE", 4: "ISGUN", 5: "IDBSGUN", 6: "ISAWGUN", 7: "IDYNAM", 8: "IKNIFE",
               9: "IGATGUN"}
GIVE = {s: [WEAPON_ITEM[s]] + ([AMMO_ITEM[s]] * AMMO_PACKS if s in AMMO_ITEM else []) for s in WEAPON_ITEM}
GIVE[7] = ["IDYNAM"] * 6
GIVE[8] = ["IKNIFE"] * 6                # as many knives as TNT sticks: they can be thrown
