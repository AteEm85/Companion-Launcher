"""Gun game: one weapon at a time, a kill moves you up the ladder, a death moves you down one rung.
The last two rungs are TNT and the knife; a kill with the knife wins the round (everyone starts over)."""
import dataclasses
import os

# weapon slots: 1 fists, 2 pistol, 3 rifle, 4 shotgun, 5 double-barrel, 6 sawed-off, 7 TNT, 8 knife, 9 gatling
DEFAULT_ORDER = [5, 4, 3, 9, 6, 2, 7, 8]     # TNT and the knife last
LADDER = list(DEFAULT_ORDER)
try:                                          # the launcher passes its choice on in BOT_GG_ORDER ("5,4,3,...")
    _o = [int(x) for x in os.environ.get("BOT_GG_ORDER", "").split(",") if x.strip()]
    if _o and all(1 <= x <= 9 for x in _o):
        LADDER = _o
except ValueError:
    pass
RANDOM = bool(os.environ.get("BOT_GG_RANDOM"))      # reshuffle the ladder (knife stays last) before every game
ROUNDS = max(1, int(os.environ.get("BOT_GG_ROUNDS", "1") or 1))   # knife wins before the game ends
LAUNCH = os.environ.get("BOT_GG_LAUNCH", "")        # one token per launcher start: a leftover state file is ignored
STINNETT = bool(os.environ.get("BOT_GG_STINNETT"))   # gatling included: the stinnett cheat lets you move with it
NAMES = {1: "fists", 2: "pistol", 3: "rifle", 4: "shotgun", 5: "double-barrel", 6: "sawed-off",
         7: "TNT", 8: "knife", 9: "gatling"}
_STATE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "state")
ROUND_FILE = os.path.join(_STATE, "gg_ladder.json")
BANNER_FILE = os.path.join(_STATE, "gg_banner.json")      # read by ggbanner.py: ROUND n COMPLETE / winner / ROUND n+1 BEGIN
FREEZE_FILE = os.path.join(_STATE, "gg_freeze.json")      # {"until": epoch}: everyone stands still until then
HOLD = 5.0                                                 # seconds ROUND n COMPLETE and the winner's name stay up
BEGIN = 2.5                                                # then ROUND n+1 BEGIN, then play
_BORN = __import__("time").time()
CHEAT = "olpostal"          # typed as key presses during play: every weapon (and ammo)


def slot_for(rung):
    return LADDER[max(0, min(rung, len(LADDER) - 1))]


def rung_skill(base, rung):
    """The bot's Skill for this rung: only the rung's weapon is used, whatever the personality."""
    slot = slot_for(rung)
    kw = dict(favorite=slot, lean=None, prefer_close=[slot], prefer_far=[slot], prefer_long=[slot],
              far_long=None, tnt=False, melee_only=False, knife_first=False)
    if slot == 7:
        kw.update(tnt=True, melee_only=True, keep_distance=60.0, back_off=40.0)
    elif slot == 8:
        kw.update(melee_only=True, keep_distance=2.0, back_off=0.0, prefer_close=[8, 1], prefer_far=[8, 1],
                  prefer_long=[8, 1], knife_keep=60.0)
    return dataclasses.replace(base, **kw)

# What the game is asked to hand over for each rung (Player_PickupItem names; ammo items are guesses to confirm)
AMMO_ITEM = {2: "IBULLIT", 3: "ICART", 4: "ISHELLS", 5: "ISHELLS", 6: "ISHELLS", 9: "ICLIP"}
AMMO_PACKS = 20                    # ammo items handed over with a weapon (the game caps it at the gun's maximum)
WEAPON_ITEM = {2: "IPISTOL", 3: "IRIFLE", 4: "ISGUN", 5: "IDBSGUN", 6: "ISAWGUN", 7: "IDYNAM", 8: "IKNIFE",
               9: "IGATGUN"}
GIVE = {s: [WEAPON_ITEM[s]] + ([AMMO_ITEM[s]] * AMMO_PACKS if s in AMMO_ITEM else []) for s in WEAPON_ITEM}
for _s in (5, 6):                       # the double-barrel and sawed-off draw on the shotgun's shells: with no
    GIVE[_s] = ["ISGUN"] + GIVE[_s]     # shotgun in the pack their ammo stays 0 (seen in the 1 Nov test)
GIVE[7] = ["IDYNAM"] * 6
GIVE[8] = ["IKNIFE"] * 6                # as many knives as TNT sticks: they can be thrown

# After a give, the ammo item's count is set outright (the pickup alone left the double-barrel with nothing, 2 Nov test).
AMMO_FILL = {"IBULLIT": 60, "ICART": 60, "ISHELLS": 40, "ICLIP": 100}
# The double-barrel and the sawed-off fire the shotgun's shells and need the shotgun in the pack: it isn't taken away.
KEEP_ALSO = {5: 4, 6: 4}


def fill(api, slot):
    """Set the rung weapon's ammo to a full supply. Returns the api's answer, or None when the weapon takes none."""
    item = AMMO_ITEM.get(slot)
    if item is None:
        return None
    try:
        return api.set_count(item, AMMO_FILL.get(item, 40))
    except Exception as e:
        return f"error {e}"


# Same ladder for every player, new order each game: the bot that wins writes the next order (and a round number) to
# state/gg_ladder.json, and every bot picks it up within a second and starts again from the bottom rung.
def next_round(shuffle=True):
    """A round is over: write the next ladder (shuffled, the knife last, when asked) for the other bots, who start
    again from the bottom, and use it. Returns the round id."""
    import json, random, time
    rest = [s for s in LADDER if s != 8]
    if shuffle:
        random.shuffle(rest)
    order = rest + ([8] if 8 in LADDER else [])
    rid = int(time.time() * 1000)
    n = 1
    try:
        n = int(json.load(open(ROUND_FILE)).get("n", 0)) + 1 if _fresh() else 1      # rounds finished so far
    except (OSError, ValueError, TypeError):
        pass
    try:
        os.makedirs(os.path.dirname(ROUND_FILE), exist_ok=True)
        tmp = ROUND_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"round": rid, "launch": LAUNCH, "order": order, "n": n}, f)
        os.replace(tmp, ROUND_FILE)
    except OSError:
        pass
    LADDER[:] = order
    return rid, n


def _fresh():
    """The state file is from this launch (not left over from an earlier game)."""
    import json
    try:
        return os.path.getmtime(ROUND_FILE) >= _BORN - 3600 and json.load(open(ROUND_FILE)).get("launch", "") == LAUNCH
    except (OSError, ValueError):
        return False


def poll_round(seen):
    """The (round id, order) another bot wrote after we started and for this launch, if it isn't the one we've seen."""
    import json
    try:
        if os.path.getmtime(ROUND_FILE) < _BORN:
            return None
        d = json.load(open(ROUND_FILE))
        if d.get("launch", "") != LAUNCH or d.get("round") == seen:
            return None
        order = [int(x) for x in d["order"]]
        if sorted(order) != sorted(LADDER):
            return None
        return d["round"], order
    except (OSError, ValueError, KeyError, TypeError):
        return None


def poll_over():
    """When the human player won the last round: the epoch time the game should end (a bot types the host's kill limit), or None."""
    import json
    try:
        d = json.load(open(os.path.join(_STATE, "gg_over.json")))
        if d.get("launch", "") == LAUNCH and float(d.get("at", 0)) >= _BORN:
            return float(d["at"])
    except (OSError, ValueError, TypeError):
        pass
    return None


def announce_round(done, winner, last):
    """A round is won: put ROUND n COMPLETE and the winner's name up (ggbanner.py) and freeze everybody until
    ROUND n+1 BEGIN has been and gone. After the last round only the first part is shown, then the game ends."""
    import json, time
    t0 = time.time()
    try:
        os.makedirs(_STATE, exist_ok=True)
        for path, data in ((FREEZE_FILE, {"until": t0 + HOLD + (0 if last else BEGIN)}),
                           (BANNER_FILE, {"seq": int(t0 * 1000), "t0": t0, "title": f"ROUND {done} COMPLETE", "name": winner,
                                          "begin": None if last else f"ROUND {done + 1} BEGIN", "hold": HOLD,
                                          "begin_secs": BEGIN})):
            tmp = path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f)
            os.replace(tmp, path)
    except OSError:
        pass


_frozen = [0.0, 0.0]      # [until, next time to read the file]


def frozen():
    """True while a round has just ended and everybody holds still (read from the file a few times a second)."""
    import json, time
    now = time.time()
    if not LAUNCH:
        return False
    if now >= _frozen[1]:
        _frozen[1] = now + 0.2
        try:
            if os.path.getmtime(FREEZE_FILE) >= _BORN:
                _frozen[0] = float(json.load(open(FREEZE_FILE)).get("until", 0))
        except (OSError, ValueError, TypeError):
            pass
    return now < _frozen[0]
