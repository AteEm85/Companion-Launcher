"""Look up and down while dead (as in the 1997 Outlaws), for YOUR game copy.

What the Remaster does (found with lookprobe 1-3, 11 Nov; Steam build): the player physics routine (0xb68f0) sets a flag when your
health is 0 (0xb6a29: [rbp+0] = 1) and then skips the whole block that reads the mouse (0xb779a: jne past it). The left/right turn
has a dead-camera path of its own; the up/down one is left at 0 (xmm11, cleared at 0xb6935), so the pitch, written every frame at
0xb8cc3, never changes while you are dead.

This puts the mouse's up/down back: right after the routine stores that value for the pitch code (0xb7bdb: [rsp+0x48] = xmm11),
when the dead flag is set it writes the mouse's own up/down (the input record at [rbp+0xa8], +0xc - what the alive path reads at
0xb792c) into that slot. The pitch code then does with it exactly what it does alive (sensitivity, invert, the +-0x8e3 limit).

Only your own game (not the bots' copies, which run with -userpath); nothing is sent to anyone. Runs until your game closes, and
picks up a new game copy if you start one. Steam build only for now.

  python deadlook.py
"""
import subprocess
import time

import frida

JS = r"""
const exe = Process.mainModule;
const stamp = exe.base.add(exe.base.add(0x3c).readU32() + 8).readU32();
if (stamp !== 0x6a39ed68) {
  send({ kind: 'error', message: 'not the Steam build (0x' + stamp.toString(16) + '): nothing changed' });
} else {
  let n = 0;
  Interceptor.attach(exe.base.add(0xb7be2), function () {
    const c = this.context;
    try {
      if (c.rbp.readS32() === 0) return;                         // alive: the game read the mouse itself
      const input = c.rbp.add(0xa8).readPointer();
      if (input.isNull()) return;
      const dy = input.add(0xc).readFloat();
      if (dy !== 0) { c.rsp.add(0x48).writeFloat(dy); n++; }
    } catch (e) {}
  });
  setInterval(function () { if (n) { send({ kind: 'used', n: n }); n = 0; } }, 30000);
  send({ kind: 'ready' });
}
"""


def own_game_pids():
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='OutlawsAHOM.exe'\" | "
          "ForEach-Object { '{0}|{1}' -f $_.ProcessId, $_.CommandLine }")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True,
                           timeout=30, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.SubprocessError):
        return []
    return [int(l.split("|", 1)[0]) for l in r.stdout.splitlines() if l.strip() and "-userpath" not in l]


def main():
    dev = frida.get_local_device()
    done = {}
    print("look up and down while dead: waiting for your game...")
    while True:
        for pid in own_game_pids():
            if pid in done:
                continue
            try:
                s = dev.attach(pid)
                sc = s.create_script(JS)
                sc.on("message", lambda m, d, pid=pid: print(pid, (m.get("payload") or m.get("description"))))
                sc.load()
                done[pid] = s
                print(f"on in your game (pid {pid})")
            except Exception as e:
                print(f"could not attach to {pid}: {e}")
                done[pid] = None
        alive = set(own_game_pids())
        for pid in list(done):
            if pid not in alive:
                done.pop(pid, None)
        time.sleep(5)


if __name__ == "__main__":
    main()
