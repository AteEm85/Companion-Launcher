@echo off
cd /d "%~dp0"
set BOT_DUMPITEMS=1
".venv\Scripts\python.exe" -u pathcheck.py --keep --minutes 1 --no-global-kill --maps hargrove town_2p drygulch lilbatl
exit
