@echo off
rem 3-minute TNT throw check: a sapper vs two on The Dip (dm), then Stone (team). Close your own Outlaws window first.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u tntcheck.py --minutes 3
echo DONE> tntcheck_done.txt
