@echo off
rem Host test, round 4: no playing needed. Start Outlaws, stay in the main menu, double-click this file.
rem After about 8 seconds it hosts a LAN game by itself. The result is in state\hostnext4.txt (2 minutes).
cd /d "%~dp0"
".venv\Scripts\python.exe" -u hostnext4.py %*
