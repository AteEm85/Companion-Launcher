"""Survival: count the human player's deaths by watching their own game's health (no hooks, just a memory read).

  python deathwatch.py <run id>

Finds the one OutlawsAHOM.exe that isn't a bot (pids in horde_logs\\*.log are bots), reads the local player's health
a few times a second and counts every drop to 0 (health comes back up when you respawn). The count goes in
state\\deaths_<run>.txt for horde.py to put in the stats. Stops when state\\stop_<run> appears or the game closes."""
import re
import sys
import time
from pathlib import Path

import frida

HERE = Path(__file__).resolve().parent
STATE = HERE / "state"
LOGS = HERE / "horde_logs"
JS = """
const exe = Process.mainModule;
const stamp = exe.base.add(exe.base.add(0x3c).readU32() + 8).readU32();
const PD = stamp === 0x6a39ed68 ? 0xf0e5b0 : 0xf08030;            // Steam build, else GOG
rpc.exports = { health() {
  try { const pd = exe.base.add(PD).readPointer(); if (pd.isNull()) return null; return pd.add(0x2c).readFloat(); }
  catch (e) { return null; }
} };
"""


def log(msg):
    try:
        with (HERE / "deathwatch_log.txt").open("a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S ") + msg + "\n")
    except OSError:
        pass


def bot_pids():
    pids = set()
    for lg in LOGS.glob("*.log"):
        try:
            pids |= set(re.findall(r"\(pid (\d+)\)", lg.read_text(errors="replace")))
        except OSError:
            pass
    return pids


def main():
    run = sys.argv[1] if len(sys.argv) > 1 else "x"
    stop = STATE / f"stop_{run}"
    out = STATE / f"deaths_{run}.txt"
    STATE.mkdir(exist_ok=True)
    dev = frida.get_local_device()
    session = None
    while session is None:
        if stop.exists():
            return
        humans = [p.pid for p in dev.enumerate_processes() if p.name.lower() == "outlawsahom.exe" and str(p.pid) not in bot_pids()]
        if len(humans) == 1:
            try:
                session = dev.attach(humans[0])
                script = session.create_script(JS)
                script.load()
                api = script.exports_sync
                log(f"watching pid {humans[0]}")
            except Exception as e:
                log(f"attach failed: {e}")
                session = None
        time.sleep(2.0)
    deaths, alive, low_since = 0, False, None
    out.write_text("0")
    while not stop.exists():
        try:
            h = api.health()
        except Exception as e:
            log(f"game gone: {e}")
            break
        if h is not None:
            if h > 0:
                alive, low_since = True, None
            elif alive:
                low_since = low_since or time.time()
                if time.time() - low_since > 0.3:
                    deaths += 1
                    alive = False
                    out.write_text(str(deaths))
                    log(f"death {deaths}")
        time.sleep(0.2)
    try:
        session.detach()
    except Exception:
        pass


if __name__ == "__main__":
    main()
