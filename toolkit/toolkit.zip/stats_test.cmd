@echo off
cd /d "%~dp0"
set BOT_STATS_PLAYER=StatTest
set PATHCHECK_NOSTATS=pc3
set PATHCHECK_WINDOWS=visible
".venv\Scripts\python.exe" -u pathcheck.py --keep --minutes 5 --no-global-kill --maps drygulch
exit
