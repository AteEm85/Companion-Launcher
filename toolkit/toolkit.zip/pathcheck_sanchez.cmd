@echo off
rem Fort Sanchez pathing / well / respawn check: 3 bots alone for 8 minutes. Close your own Outlaws window first.
rem Results: pathcheck_report.txt and pathcheck_logs\ft_sanch*. pathcheck_done.txt appears at the end.
cd /d "%~dp0"
del pathcheck_done.txt >nul 2>&1
".venv\Scripts\python.exe" -u pathcheck.py --minutes 8 --maps ft_sanch > pathcheck_run.txt 2>&1
echo finished > pathcheck_done.txt
