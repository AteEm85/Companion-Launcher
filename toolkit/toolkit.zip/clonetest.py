"""Mission 3 clones test (clonetest.cmd): horde.py runs Thin Ice, your game joins, step 1 is skipped (the test cheat), and
the Frost Clones step runs for 90 s; then everything closes. Log: state\\clonetest.txt (and the clones' horde_logs\\orleans_clone*.log)."""
import os, subprocess, sys, threading, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
GAME = HERE.parent / "OutlawsAHOM.exe"
OUT = open(HERE / "state" / "clonetest.txt", "w", encoding="utf-8")


def w(m):
    OUT.write(f"{time.strftime('%H:%M:%S')} {m}\n"); OUT.flush()


st = {"game": None, "skipped": False}
p = subprocess.Popen([sys.executable, "-u", str(HERE / "horde.py"), "--map", "orleans", "--minutes", "30", "--users", "1", "--mission", "frost"],
                     cwd=str(HERE), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace",
                     env=dict(os.environ, HORDE_CHAIN_FILE="clonetest_chain.json"))
for line in p.stdout:
    line = line.rstrip(); w(line)
    if "lobby up" in line and st["game"] is None:
        st["game"] = subprocess.Popen([str(GAME), "-netdriver", "lan", "-skipintromovies", "-join", "127.0.0.1"], cwd=str(GAME.parent))
        subprocess.Popen([sys.executable, "-u", str(HERE / "autojoin.py"), str(st["game"].pid), "red"], cwd=str(HERE))
    if "mission step 1/" in line and not st["skipped"]:
        st["skipped"] = True
        threading.Timer(8, lambda: (HERE / "state" / "cheat_skip.flag").write_text("skip")).start()
    if "mission step 2/" in line:
        threading.Timer(90, lambda: subprocess.run(["cmd", "/c", str(HERE / "stoptest.cmd")])).start()
