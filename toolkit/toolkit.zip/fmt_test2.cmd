@echo off
cd /d "%~dp0"
set BOT_TRACEFMT=1
set BOT_STATS_PLAYER=ExactTest
set HORDE_WINDOWS=visible
".venv\Scripts\python.exe" -u horde.py --map drygulch --minutes 5 --wave 20 --hero
exit
