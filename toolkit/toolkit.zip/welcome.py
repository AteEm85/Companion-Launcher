"""Opening title: python welcome.py <run id> <horde.py pid>
Waits until you are in the game on the Survivors team (the human_<run>.flag from the passive host), then shows
WELCOME TO HORDE MODE / GOOD LUCK in big spooky letters over the game for a few seconds. Never takes the focus
(no-activate, click-through, see announce.py). Does nothing in the classic style."""
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
KEY = "#010101"          # this colour is see-through


def main():
    run = sys.argv[1] if len(sys.argv) > 1 else ""
    parent = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    import ambient
    st = HERE / "state"
    stop, over, human = st / f"stop_{run}", st / f"music_stop_{run}", st / f"human_{run}.flag"
    while not human.exists():
        if stop.exists() or over.exists() or (parent and not ambient.alive(parent)):
            return
        time.sleep(0.5)
    time.sleep(2.5)                                    # let the map appear first
    if stop.exists() or over.exists():
        return
    import ctypes
    u = ctypes.windll.user32
    fg0 = u.GetForegroundWindow()
    import tkinter as tk
    from tkinter import font as tkfont
    root = tk.Tk()
    root.withdraw()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.configure(bg=KEY)
    try:
        root.attributes("-transparentcolor", KEY)
    except tk.TclError:
        pass
    fams = {f.lower(): f for f in tkfont.families()}
    face = next((fams[n] for n in ("chiller", "jokerman", "old english text mt", "impact") if n in fams), "Impact")
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    big, small = max(40, sh // 9), max(28, sh // 14)
    cv = tk.Canvas(root, width=sw, height=int(sh * 0.40), bg=KEY, highlightthickness=0)
    cv.pack()
    for text, y, size, col in (("WELCOME TO HORDE MODE", int(sh * 0.11), big, "#8a0b0b"), ("GOOD LUCK", int(sh * 0.27), small, "#a31212")):
        f = (face, size, "bold")
        for dx, dy in ((-3, 3), (3, 3), (0, 5), (-3, -2), (3, -2)):     # black outline and shadow
            cv.create_text(sw // 2 + dx, y + dy, text=text, font=f, fill="black")
        cv.create_text(sw // 2, y, text=text, font=f, fill=col)
    root.geometry(f"{sw}x{int(sh * 0.40)}+0+{int(sh * 0.06)}")
    try:
        root.attributes("-alpha", 0.0)
    except tk.TclError:
        pass
    try:
        root.update()
        hwnd = u.GetParent(root.winfo_id()) or root.winfo_id()
        style = u.GetWindowLongW(hwnd, -20)
        u.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x80 | 0x20 | 0x80000)
        u.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)
        u.ShowWindow(hwnd, 4)
        if fg0 and u.GetForegroundWindow() != fg0:
            u.SetForegroundWindow(fg0)
    except Exception:
        root.deiconify()
    t0 = time.time()
    FADE_IN, HOLD, FADE_OUT = 1.5, 4.0, 2.0

    def tick():
        t = time.time() - t0
        if t >= FADE_IN + HOLD + FADE_OUT or stop.exists():
            root.destroy()
            return
        a = t / FADE_IN if t < FADE_IN else 1.0 if t < FADE_IN + HOLD else 1 - (t - FADE_IN - HOLD) / FADE_OUT
        try:
            root.attributes("-alpha", max(0.0, min(0.95, a)))
        except tk.TclError:
            pass
        try:
            if fg0 and u.GetForegroundWindow() != fg0:
                u.SetForegroundWindow(fg0)
        except Exception:
            pass
        root.after(40, tick)
    tick()
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
