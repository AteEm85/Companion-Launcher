@echo off
cd /d "%~dp0"
set HORDE_WINDOWS=visible
set BOT_STUCK_LOG=horde_logs\stuck.csv
set BOT_TRACKLOG=horde_logs\track.csv
del horde_logs\stuck.csv horde_logs\track.csv 2>nul
".venv\Scripts\python.exe" -u horde.py --map town_2p --minutes 3 --hero --ramp 30
exit
