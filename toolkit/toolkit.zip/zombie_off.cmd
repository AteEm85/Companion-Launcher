@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" zombieskins.py off
pause
