@echo off
rem Host-the-next-map test. This one DOES act on your game once (see hostnext.py).
rem 1. Start Outlaws yourself and stay in the main menu.  2. Double-click this file.
rem 3. Host a LAN game (Deathmatch, time limit 1 minute) and play until it ends.
rem 4. Back in the main menu, do not touch anything: after 5 seconds it should host the next map by itself.
rem 5. Tell Claude what happened. The result is in state\hostnext.txt.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u hostnext.py %*
pause
