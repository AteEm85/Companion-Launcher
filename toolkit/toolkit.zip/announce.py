"""On-screen banner over the game: python announce.py "Horde Becomes Stronger" [seconds]
A borderless, always-on-top, click-through window at the top centre of the main screen. It never takes the focus from the
game (WS_EX_NOACTIVATE) and closes itself after a few seconds. Used by horde.py whenever the bots get stronger."""
import random
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent


def thunder(volume=1.0):
    """Play one of the game's own thunder sounds (thunder1.wav / thunder2.wav, read from its archives the first time).
    Returns how long it plays in seconds (0 if there is no sound)."""
    try:
        import struct
        import wave
        import winsound
        want = random.choice(["thunder1.wav", "thunder2.wav"])
        cache = HERE / "sounds" / want
        if not cache.exists():
            for lab in ("olpatch5.lab", "olsfx.lab", "olpatch6.lab", "olpatch4.lab", "olpatch3.lab"):
                path = HERE.parent / lab
                if not path.exists():
                    continue
                with path.open("rb") as f:
                    head = f.read(16)
                    n, = struct.unpack_from("<I", head, 8)
                    ent = f.read(16 * n)
                    f.seek(16 + 16 * n)
                    names = f.read(struct.unpack_from("<I", head, 12)[0])
                    for i in range(n):
                        no, off, size, _t = struct.unpack_from("<IIII", ent, 16 * i)
                        if names[no:names.index(b"\0", no)].decode("latin1").lower() == want:
                            f.seek(off)
                            cache.parent.mkdir(exist_ok=True)
                            cache.write_bytes(f.read(size))
                            break
                if cache.exists():
                    break
        if not cache.exists():
            return 0.0
        try:
            with wave.open(str(cache), "rb") as w:
                length = w.getnframes() / float(w.getframerate())
        except Exception:
            length = 5.0
        play = cache
        if volume < 0.99:                                   # a quieter copy (distant storms)
            quiet = cache.with_name(cache.stem + "_far.wav")
            try:
                if not quiet.exists() or quiet.stat().st_mtime < cache.stat().st_mtime:
                    import array
                    with wave.open(str(cache), "rb") as src:
                        prm, frames = src.getparams(), src.readframes(src.getnframes())
                    if prm.sampwidth == 2:
                        a = array.array("h"); a.frombytes(frames); frames = array.array("h", (int(x * volume) for x in a)).tobytes()
                    elif prm.sampwidth == 1:
                        frames = bytes(128 + int((x - 128) * volume) for x in frames)
                    with wave.open(str(quiet), "wb") as dst:
                        dst.setparams(prm); dst.writeframes(frames)
                play = quiet
            except Exception:
                play = cache
        winsound.PlaySound(str(play), winsound.SND_FILENAME | winsound.SND_ASYNC)
        return min(length, 10.0)
    except Exception:
        return 0.0


def main():
    text = sys.argv[1] if len(sys.argv) > 1 else "Horde Becomes Stronger"
    secs = float(sys.argv[2]) if len(sys.argv) > 2 else 3.5
    if "--sound-only" in sys.argv[1:]:                          # just the thunder (the banner itself: tierhud.py)
        left = thunder()
        if left > 0:
            time.sleep(left + 0.2)
        return
    playing = thunder()
    began = time.time()
    fg0 = 0
    try:
        import ctypes
        fg0 = ctypes.windll.user32.GetForegroundWindow()       # whoever has the focus now (the game): hand it back afterwards
    except Exception:
        ctypes = None
    import tkinter as tk
    root = tk.Tk()
    root.withdraw()                                            # shown below without activating
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    bg = "#d9d2c3"      # light parchment: dark red text needs it to stay readable
    root.configure(bg=bg)
    try:
        root.attributes("-alpha", 0.93)
    except tk.TclError:
        pass
    tk.Label(root, text=text.upper(), font=("Impact", 34, "bold"), fg="#7a0a0a", bg=bg, padx=36, pady=8).pack()
    root.update_idletasks()
    w, h = root.winfo_reqwidth(), root.winfo_reqheight()
    x = (root.winfo_screenwidth() - w) // 2
    root.geometry(f"{w}x{h}+{x}+{int(root.winfo_screenheight() * 0.08)}")
    try:                                    # no focus, no taskbar button, mouse clicks pass through
        import ctypes
        root.update()
        u = ctypes.windll.user32
        hwnd = u.GetParent(root.winfo_id()) or root.winfo_id()
        style = u.GetWindowLongW(hwnd, -20)
        u.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x80 | 0x20 | 0x80000)   # NOACTIVATE, TOOLWINDOW, TRANSPARENT, LAYERED
        u.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)            # topmost, no move/size, no activation, show
        u.ShowWindow(hwnd, 4)                                                    # SW_SHOWNOACTIVATE
        if fg0 and u.GetForegroundWindow() != fg0:
            u.SetForegroundWindow(fg0)
    except Exception:
        root.deiconify()
    root.after(int(secs * 1000), root.destroy)
    def _refocus():
        try:
            import ctypes
            if fg0 and ctypes.windll.user32.GetForegroundWindow() != fg0:
                ctypes.windll.user32.SetForegroundWindow(fg0)
        except Exception:
            pass
        root.after(250, _refocus)
    root.after(120, _refocus)
    root.mainloop()
    left = playing - (time.time() - began)       # keep the process alive until the thunder has finished
    if left > 0:
        time.sleep(left + 0.2)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
