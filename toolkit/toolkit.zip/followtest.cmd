@echo off
rem follow.py test: two bots play two 1-minute matches (rottest.txt); your own game joins the first and should be taken
rem to the second by itself (Continue on the score screen, join the new lobby). Logs: state\rottest.txt, state\followtest.txt
cd /d "%~dp0"
start "rotation" /min cmd /c ".venv\Scripts\python.exe -u rotation.py rottest.txt --once -- sanchez mary --fight > state\rottest.txt 2>&1"
echo waiting 40 seconds for the bots' lobby...
timeout /t 40 /nobreak > nul
start "" "..\OutlawsAHOM.exe" -netdriver lan -skipintromovies -join 127.0.0.1
".venv\Scripts\python.exe" -u follow.py auto - state\followtest.txt
