@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" teamcolors.py on
pause
