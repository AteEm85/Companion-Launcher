"""Packs the big mod files for new players (launchertools.ensure_files downloads them).
Writes botctl\\_xmas_pack\\, for each set: <set>_files.json (every file: size, sha256, which part) and <set>_files_1.zip,
_2 ... (each under PART_MB). These go into the public Bot-Launcher-Files repo on GitHub (its main branch).
The sets: "christmas" - what zombieskins.py installs for the Christmas Horde (christmas\\*.SPX/.NWX/... minus the retired
ones), the christmas\\*.json data and christmas\\music\\*.wav; "zombie" (25 Nov) - everything in zombie\\ (the zombie
skins and sounds, the Halloween pumpkins and cobwebs).
Usage: python make_xmas_pack.py"""
import hashlib, json, os, sys, time, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "_xmas_pack")
PART_MB = 90                    # (raw size: each zip stays under GitHub's 100 MB per file)
sys.path.insert(0, HERE)


def file_list():
    import zombieskins
    xmas = os.path.join(HERE, "christmas")
    rel = ["christmas/" + n for n in zombieskins.files(True)]
    rel += ["christmas/" + n for n in sorted(os.listdir(xmas)) if n.lower().endswith(".json") and os.path.isfile(os.path.join(xmas, n))]
    mus = os.path.join(xmas, "music")
    if os.path.isdir(mus):
        rel += ["christmas/music/" + n for n in sorted(os.listdir(mus)) if n.lower().endswith(".wav")]
    seen, out = set(), []
    for r in rel:
        if r.lower() not in seen and os.path.isfile(os.path.join(HERE, *r.split("/"))):
            seen.add(r.lower()); out.append(r)
    return out


def zombie_list():
    z = os.path.join(HERE, "zombie")
    return ["zombie/" + n for n in sorted(os.listdir(z)) if os.path.isfile(os.path.join(z, n))] if os.path.isdir(z) else []


SETS = {"christmas": file_list, "zombie": zombie_list}


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def pack(name, rel):
    files, parts = {}, []
    part, zf, used = 0, None, 0
    print(f"{name}: {len(rel)} files")
    for i, r in enumerate(rel, 1):
        p = os.path.join(HERE, *r.split("/"))
        size = os.path.getsize(p)
        if zf is None or used + size > PART_MB * 1024 * 1024:
            if zf: zf.close()
            part += 1; used = 0
            zf = zipfile.ZipFile(os.path.join(OUT, f"{name}_files_{part}.zip"), "w", zipfile.ZIP_DEFLATED, compresslevel=6)
        zf.write(p, r)
        used += size
        files[r] = [size, sha(p), part]
        if i % 100 == 0: print(f"  {i} / {len(rel)}")
    if zf: zf.close()
    for k in range(1, part + 1):
        n = f"{name}_files_{k}.zip"; p = os.path.join(OUT, n)
        parts.append({"name": n, "size": os.path.getsize(p), "sha256": sha(p)})
    man = {"version": time.strftime("%Y%m%d%H%M%S"), "files": files, "parts": parts}
    with open(os.path.join(OUT, f"{name}_files.json"), "w") as f:
        json.dump(man, f, indent=0)
    total = sum(v[0] for v in files.values())
    print(f"{name} done: {len(files)} files, {total / 1e6:.0f} MB, in {part} part(s)")


def main():
    os.makedirs(OUT, exist_ok=True)
    for n in os.listdir(OUT):
        os.remove(os.path.join(OUT, n))
    for name, lister in SETS.items():
        pack(name, lister())
    print(f"done -> {OUT}")


if __name__ == "__main__":
    main()
