"""Launcher sounds, taken from the game's own sound files (nothing is copied into the launcher): a gunshot
click on the main buttons.

The WAVs are read out of the game's archives (olpatch5.lab) the first time, turned down to VOLUME and saved in
botctl\\sounds\\, so delete that folder to get them extracted again (or after changing the volume).
Windows only (winsound); anywhere else this is silent."""
import io
import struct
import sys
import wave
from array import array
from pathlib import Path

try:
    import winsound
except ImportError:                                        # not Windows
    winsound = None

CLICK = "gatlshot.wav"   # the game's own sounds
VOLUME = 0.30                          # of the original loudness (70% quieter); the saved copies are already scaled
SUFFIX = "_quiet.wav"
LABS = ["olgeo.lab", "olpatch1.lab", "olpatch2.lab", "olpatch3.lab", "olpatch4.lab", "olpatch5.lab", "Olpatch6.lab"]


def _directory(path):
    with open(path, "rb") as f:
        magic, _ver, n, names_size = struct.unpack("<4sIII", f.read(16))
        if magic != b"LABN":
            return {}
        entries = [struct.unpack("<III4s", f.read(16)) for _ in range(n)]
        names = f.read(names_size)
    out = {}
    for name_off, off, size, _typ in entries:
        out[names[name_off:names.find(b"\0", name_off)].decode("latin-1").lower()] = (off, size)
    return out


def quieter(data, volume=VOLUME):
    """The WAV bytes with every 16-bit sample scaled by `volume` (other formats are returned as they are)."""
    try:
        with wave.open(io.BytesIO(data)) as w:
            params, frames = w.getparams(), w.readframes(w.getnframes())
        if params.sampwidth != 2:
            return data
        samples = array("h")
        samples.frombytes(frames)
        if sys.byteorder == "big":
            samples.byteswap()
        samples = array("h", (int(v * volume) for v in samples))
        if sys.byteorder == "big":
            samples.byteswap()
        out = io.BytesIO()
        with wave.open(out, "wb") as w:
            w.setparams(params)
            w.writeframes(samples.tobytes())
        return out.getvalue()
    except Exception:
        return data


def stored(name):
    return name[:-4] + SUFFIX


class Sounds:
    def __init__(self, here, game_dir):
        self.folder = Path(here) / "sounds"
        self.game_dir = Path(game_dir)
        self.enabled = True
        self.ready = False

    def prepare(self):
        """Extract the three WAVs from the game's archives if they are not in the sounds folder yet."""
        want = [n for n in (CLICK,) if not (self.folder / stored(n)).exists()]
        try:
            if want:
                self.folder.mkdir(exist_ok=True)
                found = {}
                for lab in LABS:                       # the newest copy wins, as in the game
                    path = self.game_dir / lab
                    if not path.exists():
                        continue
                    directory = _directory(path)
                    with open(path, "rb") as f:
                        for name in want:
                            if name in directory:
                                off, size = directory[name]
                                f.seek(off)
                                found[name] = f.read(size)
                for name, data in found.items():
                    (self.folder / stored(name)).write_bytes(quieter(data))
            self.ready = winsound is not None and all((self.folder / stored(n)).exists() for n in (CLICK,))
        except Exception:
            self.ready = False
        return self.ready

    def play(self, name, wait=False):
        """Play a sound (a new one cuts off the one still playing). `wait` returns when it has finished."""
        path = self.folder / stored(name)
        if not (self.enabled and self.ready and path.exists()):
            return
        try:
            winsound.PlaySound(str(path), winsound.SND_FILENAME | (0 if wait else winsound.SND_ASYNC))
        except Exception:
            pass
