@echo off
rem Takes every Horde mod out of the game folder (zombie skins and team
rem colours, the lit map files). Closes the game first.
cd /d "%~dp0"
echo Closing the game...
taskkill /IM OutlawsAHOM.exe /F >nul 2>&1
timeout /t 3 /nobreak >nul
echo Taking the Horde mods out...
".venv\Scripts\python.exe" companionhost.py --cleanup
echo.
echo Done. You can start Outlaws normally now.
pause
