@echo off
rem Test: puts [12] in front of your name in your own game. Start the game normally, run this, then host a LAN game and look at the scoreboard.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u rankname.py --name T4H_WaRRioR --prefix "[12]"
pause
