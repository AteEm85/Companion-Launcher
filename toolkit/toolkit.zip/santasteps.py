"""Santa's booming footsteps (the Christmas Horde), played on each player's own PC: louder the closer he is, from the
side he is on (left/right, a little softer behind you), one boom per stride while he walks. So he can be found on a
big map like The Fort.
  host:   python santasteps.py <run id> <horde.py pid>      (Santa's position: state\\santa_<run>.json, written by his brain)
  joiner: the Outlaws Companion calls run() with the host's /horde.json as the position source.
Your own position and facing are read from your own game through a tiny Frida script (read only).
The sound: christmas\\music\\santa_step.wav (a deep thump, a crunch of snow and the jingle), made into stereo copies at
a few loudness levels and pan positions the first time (standard library only)."""
import array
import json
import math
import os
import sys
import time
import wave
from pathlib import Path

HERE = Path(__file__).resolve().parent
STEP = HERE / "christmas" / "music" / "santa_step.wav"
STRIDE = 3.6                   # world units Santa walks per boom (he is a giant)
MIN_GAP = 0.36                 # seconds between booms at the least
HEAR = 320.0                   # world units: no boom beyond this
VOLS = [0.7, 0.5, 0.35, 0.24, 0.15, 0.09, 0.05]   # (30% under full: loud enough to find him, not deafening)
PANS = [-1.0, -0.66, -0.33, 0.0, 0.33, 0.66, 1.0]

ME_JS = r"""
const BUILDS = { 0x6a39efd0: 0xf08030, 0x6a39ed68: 0xf0e5b0 };      // PlayerData* global: GOG, Steam
const exe = Process.mainModule;
const stamp = exe.base.add(exe.base.add(0x3c).readU32() + 8).readU32();
const PD = BUILDS[stamp] || BUILDS[0x6a39efd0];
rpc.exports = {
  me() {
    try {
      const pd = exe.base.add(PD).readPointer();
      if (pd.isNull()) return null;
      const a = pd.readPointer();
      if (a.isNull()) return null;
      return { x: a.add(0x38).readFloat(), y: a.add(0x3c).readFloat(), z: a.add(0x40).readFloat(),
               yaw: a.add(0x46).readU16() & 0x3fff, dead: (a.add(0x10).readU32() & 0x4000) !== 0 };
    } catch (e) { return null; }
  },
};
"""


def variants(src=STEP, out_dir=None):
    """{(vol index, pan index): path} of the stereo copies (made once, again whenever the sound changes)."""
    out_dir = Path(out_dir or (HERE / "christmas" / "steps_cache"))
    out_dir.mkdir(parents=True, exist_ok=True)
    with wave.open(str(src), "rb") as w:
        prm = w.getparams()
        mono = array.array("h"); mono.frombytes(w.readframes(prm.nframes))
    stamp = int(os.path.getmtime(src))
    out = {}
    for vi, v in enumerate(VOLS):
        for pi, p in enumerate(PANS):
            path = out_dir / f"step_{vi}_{pi}.wav"
            out[(vi, pi)] = path
            mark = out_dir / f"step_{vi}_{pi}.stamp"
            if path.exists() and mark.exists() and mark.read_text() == str(stamp):
                continue
            gl = v * min(1.0, 1.0 - p) ** 0.5 if p > 0 else v      # equal-power-ish: the far side drops away
            gr = v * min(1.0, 1.0 + p) ** 0.5 if p < 0 else v
            st = array.array("h", [0]) * (2 * len(mono))
            for i, s in enumerate(mono):
                st[2 * i] = int(s * gl); st[2 * i + 1] = int(s * gr)
            with wave.open(str(path), "wb") as o:
                o.setnchannels(2); o.setsampwidth(2); o.setframerate(prm.framerate); o.writeframes(st.tobytes())
            mark.write_text(str(stamp))
    return out


def pick(me, santa):
    """(vol index, pan index) of the boom for you at `me` (x, z, yaw) with Santa at `santa`, or None (too far)."""
    dx, dz = santa["x"] - me["x"], santa["z"] - me["z"]
    d = math.hypot(dx, dz)
    if d > HEAR:
        return None
    loud = 0.7 * (1.0 - d / HEAR) ** 2.0                 # falls off quicker with distance
    face = me["yaw"] / 16384.0 * 2 * math.pi             # 0 faces +z, turning toward +x
    rel = math.atan2(dx, dz) - face
    pan = math.sin(rel)                                  # + : on your right
    if math.cos(rel) < 0:
        loud *= 0.8                                      # behind you: a touch softer
    if loud < VOLS[-1] * 0.6:   # too faint to bother
        return None
    vi = min(range(len(VOLS)), key=lambda i: abs(VOLS[i] - loud))
    pi = min(range(len(PANS)), key=lambda i: abs(PANS[i] - pan))
    return vi, pi


def attach_me(pid):
    """(get_me, close) for your own game."""
    import frida
    session = frida.get_local_device().attach(pid)
    script = session.create_script(ME_JS)
    script.on("message", lambda m, d: None)
    script.load()
    api = script.exports_sync

    def get_me():
        try: return api.me()
        except Exception: return None

    def close():
        try: script.unload()
        except Exception: pass
        try: session.detach()
        except Exception: pass
    return get_me, close


def run(get_santa, get_me, should_stop, sounds=None, log=lambda m: None):
    """Boom while Santa walks, until should_stop(). get_santa() -> {x, y, z, t} or None; get_me() -> {x, z, yaw, dead}."""
    import winsound
    sounds = sounds or variants()
    last, walked, last_boom, booms = None, 0.0, 0.0, 0
    while not should_stop():
        time.sleep(0.05)
        s = get_santa()
        if not s or time.time() - s.get("t", 0) > 3.0:
            last = None; continue
        if last is not None:
            step = math.hypot(s["x"] - last[0], s["z"] - last[1])
            if step < 30:                                  # (a respawn is a jump, not a walk)
                walked += step
        last = (s["x"], s["z"])
        now = time.time()
        if walked >= STRIDE and now - last_boom >= MIN_GAP:
            walked = 0.0
            me = get_me()
            if not me or me.get("dead"):
                continue
            k = pick(me, s)
            if k is None:
                continue
            last_boom = now
            winsound.PlaySound(str(sounds[k]), winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
            booms += 1
            if booms in (1, 10) or booms % 100 == 0:
                log(f"santa steps: {booms} booms (last at volume {VOLS[k[0]]}, pan {PANS[k[1]]})")


def human_pid(run_id):
    """Your own game on the host PC: the one game copy that none of this run's bots started."""
    import re
    import frida
    bots = set()
    for lg in (HERE / "horde_logs").glob("*.log"):
        try: bots |= set(re.findall(r"\(pid (\d+)\)", lg.read_text(errors="replace")))
        except OSError: pass
    pids = [p.pid for p in frida.get_local_device().enumerate_processes()
            if p.name.lower() == "outlawsahom.exe" and str(p.pid) not in bots]
    return pids[0] if len(pids) == 1 else None


def main():
    run_id = sys.argv[1] if len(sys.argv) > 1 else ""
    parent = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    sys.path.insert(0, str(HERE))
    import ambient
    st = HERE / "state"
    pos, stop, over = st / f"santa_{run_id}.json", st / f"stop_{run_id}", st / f"music_stop_{run_id}"
    logf = HERE / "horde_logs" / "music_log.txt"

    def log(m):
        try:
            with open(logf, "a") as f: f.write(time.strftime("%H:%M:%S ") + m + "\n")
        except OSError: pass

    def gone():
        return stop.exists() or over.exists() or (parent and not ambient.alive(parent))
    while not pos.exists():                                 # until Santa is out
        if gone(): return
        time.sleep(1)
    pid = None
    for _ in range(30):
        pid = human_pid(run_id)
        if pid: break
        time.sleep(2)
    if not pid:
        log("santa steps: your game window wasn't found"); return
    get_me, close = attach_me(pid)
    log(f"santa steps: listening in your game (pid {pid})")

    def get_santa():
        try: return json.loads(pos.read_text())
        except (OSError, ValueError): return None
    try:
        run(get_santa, get_me, gone, log=log)
    finally:
        close()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        try:
            with open(HERE / "horde_logs" / "music_log.txt", "a") as f: f.write(time.strftime("%H:%M:%S ") + f"santa steps failed: {e}\n")
        except OSError:
            pass
