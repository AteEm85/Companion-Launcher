"""Bot brain: hunt the nearest living player, aim, shoot only with a clear line of sight, reload fully,
pick the best weapon that has ammo, collect items, and respawn with E after dying.

Behaviours (BEHAVIOURS, picked per bot) change what it fights with: the sapper throws TNT (tnt.py), the sniper
and the pistolero favour the rifle and the pistol, the brawler fights with the knife or its fists only.

Movement uses the level's sector graph (nav.py) when the level has been identified: routes to items, to
where a target was last seen, and to random spots when wandering. Without a level it falls back to walking
straight at things. Keys are chosen relative to where we're looking, so the bot can follow a route while
aiming at an enemy.

The brain runs at about 20 ticks a second. Each tick it reads the world through the agent (positions, dead
flags, line of sight computed on the game thread, inventory, ground items), then presses or releases keys
and replaces any pending turn with a speed-limited step toward where it wants to look.
"""
import math
import random
import time
from dataclasses import dataclass, field

import items as itemlib
import nav
import tnt

FULL_TURN = 16384                  # 14-bit angles: 16384 = 360 degrees
EYE = 0.85                         # our eye height as a fraction of player height (estimate)
AIM = 0.6                          # aim point on the target, fraction of height from the feet.
                                   # Above 0.5 is the head zone (x1.5) when also near the centre line.
TNT_SLOT = 7                       # never chosen by best_weapon: only the sapper throws it (Brain.tnt_fight)
FIST_SLOT = 1
GATLING_SLOT = 9                   # can't move while it's out: used only standing still in a fight
KNIFE_SLOT = 8                     # the only weapon that works in the water (secondary fire = jab, reach 8)
BADGE_AVOID = 14.0                 # keep at least this far from a badge on the ground (pickup is ~3.5)
DOOR_REACH = 6.0                   # press E for a door on the route within this distance
DOOR_RETRY = 1.6                   # seconds to let a door swing before nudging again (85 deg at 60/s)
WINDOW_REACH = 10.0                # shoot out a window on the route within this distance
MOVE_KEYS = ("w", "a", "s", "d", "space", "lctrl", "lshift")
# Fire buttons on the default binds the bot copies use: mouse_left = KEY_ORD_SMALL_FIRE (primary),
# mouse_right = KEY_ORD_BIG_FIRE (secondary).
PRIMARY_FIRE = "mouse_left"
SECONDARY_FIRE = "mouse_right"
RELOAD_KEY = "r"
USE_KEY = "f"                      # KEY_ORD_USE: uses the medbag
# Shotgun and double-barrel: one press per shot. Every other weapon repeats while the button is held.
# Why (weapon logic 0xdd340/0xdd150, chor timings from the weapons' .NWX files, 100 ms per step): a fire
# or reload animation can't be interrupted on these two, a press made during one only counts if the
# button is still down when it ends, and holding fire past the end of the shot animation repeats it,
# which on an empty gun plays a ~0.5 s click. See Bots.md, "Weapon timing".
PUMP_SLOTS = {4, 5}
# Teams (actor +0xB0 low nibble): 1 red, 2 blue, 3 green, 4 black, 0 none. Game modes: 1 capture the flag,
# 2 tag, 3 kill the fool with the chicken, 4 secret document, 5 team play, 6 death match. In 1, 4 and 5 players
# keep the team they picked. In 2 and 3 everyone is team 2 except the one "holder" (team 1), and the game drops
# damage between same-team players unless teamDamage is on. See Bots.md, "Teams and CTF".
TEAM_MODES = {1, 4, 5}
CTF_MODE = 1
RED, BLUE = 1, 2
TEAM_NAMES = {0: "none", 1: "red", 2: "blue", 3: "green", 4: "black"}
FLAG_HOME = 3.0                    # a flag this close (flat) to its base counts as home
# Lobby (input_agent.js lobby()): game state 8 = waiting for this player's pick. Picks: 2 join, 3 red, 4 blue.
LOBBY_STATE = 8
LOBBY_JOIN, LOBBY_RED, LOBBY_BLUE = 2, 3, 4
RELOAD_ACTION = 3                  # weapon logic action number for a reload (0-2 are the fire modes)
TNT_WOUND_ACTION = 5               # TNT: the throw is wound up and waits for primary fire to be let go (0xda1be)
DEFAULT_KEEP = 30.0                # Skill.keep_distance of the default bot


def wrap(delta):
    return (delta + FULL_TURN // 2) % FULL_TURN - FULL_TURN // 2


def to_units(degrees):
    return degrees / 360 * FULL_TURN


def to_deg(units):
    return units * 360 / FULL_TURN


def bearing(src, dst):
    """Heading that points from src to dst (0 faces +z, increasing toward +x)."""
    return to_units(math.degrees(math.atan2(dst["x"] - src["x"], dst["z"] - src["z"]))) % FULL_TURN


def clamp(v, m):
    return max(-m, min(m, v))


def flat_dist(a, b):
    return math.hypot(b["x"] - a["x"], b["z"] - a["z"])


def keys_toward(yaw, heading):
    """W/A/S/D combination that moves toward `heading` while facing `yaw` (8 directions)."""
    rel = to_deg(wrap(round(heading - yaw)))          # positive = to our right
    keys = set()
    if abs(rel) < 67.5:
        keys.add("w")
    elif abs(rel) > 112.5:
        keys.add("s")
    if 22.5 < rel < 157.5:
        keys.add("d")
    elif -157.5 < rel < -22.5:
        keys.add("a")
    return keys


@dataclass
class Skill:
    turn_speed: float = 240.0      # max turn rate, degrees per second (heading and pitch)
    aim_error: float = 4.0         # aim wobble amplitude, degrees
    reaction: float = 0.25         # seconds a target must be visible before we shoot
    sight_memory: float = 1.0      # a target out of sight for less than this keeps the reaction already made
    max_engage: float = 120.0      # never shoot beyond this distance, whatever the weapon's range
    keep_distance: float = DEFAULT_KEEP   # stop advancing inside this distance and strafe instead
    respawn_delay: float = 1.5     # seconds after dying before pressing E
    lobby_delay: float = 2.0       # seconds in the lobby before pressing Join (lets the menu settle)
    # Weapon slots by preference, best first. Close range favours the shotguns, long range the rifle.
    # Pistol, knife and fists are last resorts. TNT (7) and the sawed-off (6) are never picked. In the water
    # it's the knife, or fists (Brain.melee_slot).
    prefer_close: list = field(default_factory=lambda: [5, 4, 3, 9, 2, 8, 1])
    prefer_far: list = field(default_factory=lambda: [3, 9, 5, 4, 2, 8, 1])
    far: float = 90.0              # beyond this distance use prefer_far
    sprint: bool = True            # hold sprint (lshift) whenever moving (not while crouched)
    min_item_value: float = 5.0    # ignore items worth less than this (see items.value). Plain ammo
                                   # top-ups are worth 8, so idle bots collect them; pistol-only ammo 4.
    item_patience: float = 4.0     # give up on an item after this long without getting closer
    armor_detour: float = 60.0     # mid-fight or on the CTF objective, still go for a boiler plate this far along
                                   # the route, scaled by what it gives (/100: heavy plate 90, smallest 30)
    # Secondary fire for everything (pistol fanning, the knife's jab) except these slots. The double-barrel's
    # primary fires both barrels; the fists' primary punch does 1.0 damage, the secondary 0.3 (ifist.itm).
    primary_slots: set = field(default_factory=lambda: {5, 1})
    reload_stall: float = 1.2      # holding R this long with no new round: let go and press again
    close_range: float = 40.0      # an enemy this close (in sight, or seen within fight_memory) is a close fight
    fight_memory: float = 3.0      # seconds an enemy out of sight still counts as close
    close_reload_below: int = 5    # in a close fight only reload with fewer rounds than this loaded (not the
                                   # shotguns, which pump() reloads shell by shell between shots)
    hold_slack: float = 6.0        # extra degrees of aim error tolerated while holding fire down
    aggression: float = 3.0        # extra degrees of aim error accepted on every shot
    lead_turn: float = 0.25        # shotguns: share of the turn made before the shot leaves (0.1 s) counted
                                   # as aimed (6 deg at 240 deg/s)
    queue_cone: float = 30.0       # during a shotgun reload, queue the next shot when aimed within this
    medbag_health: float = 4.0     # use a medbag at or below this health (of 10) in a fight
    medbag_health_idle: float = 6.0   # ... and at or below this with nobody in sight
    crouch_hold: float = 1.5       # keep crouching this long after a crouch-jump (through a window)
    ctf_chase: float = 40.0        # CTF: chase a visible enemy within this distance; farther ones are only
                                   # shot at while we keep to the objective
    air_time: float = 15.0         # seconds with our head under water before we swim up for air (players drown
                                   # after about 30)
    breathe: float = 1.5           # seconds with our head out of the water that count as a fresh breath
    knife_value: float = 80.0      # item value of a knife while we have none, on Orleans (the river map) ...
    knife_value_wet: float = 130.0 # ... and while we're in the water. Elsewhere knives are worth nothing.
    knife_keep: float = 15.0       # on land, keep stabbing with the knife already out at an enemy this close
                                   # (switching to a gun takes time)
    knife_hold: float = 5.0        # and keep it out this long after climbing out of the water, whatever the range
    shore_chase: float = 30.0      # in the water with the knife out, go for an enemy on land this close: out of
                                   # the water and stab
    # Behaviour (BEHAVIOURS below).
    behaviour: str = "default"
    favorite: int = None           # weapon slot it fights with first: its pickups and ammo are worth more, and
                                   # keep_distance and back_off only apply while it's usable
    melee_only: bool = False       # never picks up or fights with guns (the brawler)
    knife_first: bool = False      # on every map, getting a knife lying about comes first, with no fighting on the
                                   # way (on Orleans every bot does it, fighting as it goes)
    back_off: float = 0.0          # with the favourite usable, back away from an enemy closer than this
    tnt: bool = False              # throws TNT (the sapper; see Brain.tnt_fight): with sticks left it never
                                   # takes out a gun (user)
    tnt_min: float = 45.0          # never land a stick closer than this to us (blast radius 50; ~0.2 damage at 45),
                                   # or than a standing throw's reach less 2 if that's shorter (Brain.tnt_min);
                                   # an enemy closer than this still gets one (see tnt_self_max), and we back off
                                   # while it cooks
    tnt_max: float = 85.0          # light one for an enemy up to this far (standing reach ~65, running adds more);
                                   # farther ones we walk toward with the TNT out
    tnt_self_max: float = 4.0      # an enemy closer than tnt_min gets the stick thrown so it goes off right at them
                                   # (user), if the blast would do us at most this much (before armour; a full hit
                                   # is 12), allowing for us backing off until it goes
    dodge_tnt: bool = True         # run from a lit stick within dodge_radius: anyone's, ours once thrown
    dodge_radius: float = 45.0


# Behaviours: picked per bot with a tag (sanchez:sapper) or --behaviour, as Skill overrides.
BEHAVIOURS = {
    "default": {},
    # TNT whenever it has sticks (tnt.py, user): never a gun until they're gone. It lights one for any enemy within
    # 85 (farther, it walks toward them with the TNT out) and winds up at once. It cooks the stick so it goes off
    # just after it lands where the enemy is heading, landing it at least 45 (or a standing throw less 2) from
    # itself. An enemy closer than that gets it aimed low and let go at the last moment, to go off right at them.
    # Out of sticks it fights with guns like the default bot, from 60 away.
    "sapper": dict(favorite=TNT_SLOT, tnt=True, keep_distance=60.0, back_off=40.0),
    # The rifle at every range, from far off.
    "sniper": dict(favorite=3, prefer_close=[3, 5, 4, 9, 2, 8, 1], prefer_far=[3, 9, 5, 4, 2, 8, 1],
                   keep_distance=70.0, back_off=35.0),
    # The knife's jab, or fists without one. No guns, so it charges. Finding a knife comes first, on any map.
    "brawler": dict(melee_only=True, knife_first=True, prefer_close=[KNIFE_SLOT, FIST_SLOT],
                    prefer_far=[KNIFE_SLOT, FIST_SLOT], keep_distance=2.0, knife_value=150.0, knife_value_wet=150.0),
    # The pistol (fanned) first.
    "pistolero": dict(favorite=2, prefer_close=[2, 5, 4, 3, 9, 8, 1], prefer_far=[2, 3, 9, 5, 4, 8, 1]),
}


def behaviour_skill(name):
    return Skill(behaviour=name, **BEHAVIOURS[name])


class Brain:
    TICK = 0.05
    REPLAN = 2.0                   # seconds between route refreshes
    WAYPOINT_REACHED = 2.0         # flat distance at which a portal waypoint counts as passed
    CORNER_REACHED = 1.5           # the same for a point to walk round a corner
    DROP_AT = 2.0                  # a waypoint this far below us is a ledge to drop off
    ITEM_COSTS_EVERY = 1.0         # seconds between recomputing route lengths to items
    UNSTICK_CROUCH = 0.3           # seconds of crouch before the unstick jump and strafe
    CROUCH_LEAD = 0.35             # crouch held this long counts as taken hold (if the height doesn't show it)
    CROUCH_JUMP_AT = 3.0           # jump this close (flat) to a crouch-jump opening, once crouched
    JUMP_PULSE = 0.3               # jump key: down this long, then up as long, so a short jump retries
    PUMP_PRESS_MAX = 0.7           # let go of a shotgun trigger after this long even if no shot went out
    GIVE_UP_STUCKS = 3             # unsticks in a row on the way to one portal before routing round it
    STUCK_MEMORY = 12.0            # ... counted as in a row if no more than this many seconds apart
    AVOID_FOR = 30.0               # seconds a portal we gave up on costs extra to route through (nav.AVOID_COST)
    DOOR_TRIES = 3                 # E presses at one door before giving up on it
    WINDOW_PATIENCE = 4.0          # seconds shooting at one window before giving up on it
    TNT_LAND_MARGIN = 0.25         # let a stick go so it goes off this long after landing (it bounces and rolls)
    TNT_LAST_CALL = 0.45           # fuse left at which a lit stick goes, aimed or not
    TNT_LIGHT_WAIT = 1.5           # seconds pressing secondary fire for a stick to light before giving up
    TNT_LIT_UNSEEN = 1.0           # seconds into the lighting animation without seeing the lit stick: take it as lit
    TNT_LIT_GRACE = 0.6            # seconds into the lighting action (0) with no lit stick seen before winding up
                                   # anyway (only if the agent has never shown us a lit stick)
    TNT_SWITCH_WAIT = 1.0          # seconds with the TNT selected before lighting: the switch animation (user: a
                                   # press during it went to the old weapon, and the stick went out unlit)
    TNT_REPRESS = 0.3              # seconds the weapon may sit idle with primary held before we press it again
    TNT_WIND_WAIT = 2.5            # seconds after lighting to see the wind-up state before throwing regardless
    TNT_MIN_VIEW = -45.0           # lowest view pitch (degrees) a close throw aims at
    TNT_BACK_OFF = 7.0             # with a stick out, back off from an enemy this much inside tnt_min
    TNT_SETTLE = 0.35              # close throw: stand still this long before choosing where it goes...
    TNT_SETTLE_NEAR = 15.0         # ... unless the enemy is closer than this
    TNT_LEAD = 0.8                 # share of a target's measured velocity to lead it by
    TNT_LEAD_MAX = 1.5             # seconds ahead at most

    JOIN_GRACE = 5.0               # seconds after the last awaited player shows up before we start (lets them
                                   # press Join and spawn)

    def __init__(self, bot, skill=None, log=print, wait_for=None, wait_max=120.0, bench=None):
        self.bot = bot             # botctl.Bot: press(), held, api, units_per_mouse, items, badges, level_key
        self.skill = skill or Skill()
        self.log = log
        # Team balance (bench.Bench, or None): on the bigger team, stay dead instead of respawning.
        self.bench = bench
        self.bench_decided = False # this death's sit-out decision has been made
        self.my_team = None        # our team while alive, remembered for while we're dead
        # A hosting bot stands still at the start until this many other players are in the match, or for
        # wait_max seconds at most, so it doesn't score before anyone has joined.
        self.wait_for = wait_for
        self.wait_max = wait_max
        self.wait_started = None
        self.wait_full = None      # when the awaited player count was first reached
        self.rng = random.Random()
        self.target_addr = None
        self.visible_since = None  # when the current target became visible
        self.last_visible = 0.0    # when we last saw a target
        self.last_seen = None      # {x, y, z} where we last saw a target
        self.aim_offset = 0.0      # current heading wobble, degrees
        self.pitch_offset = 0.0    # current pitch wobble, degrees
        self.strafe_key = "a"
        self.strafe_until = 0.0
        self.stuck_check = None    # (time, x, z) when we last checked progress
        self.unstick_until = 0.0
        self.unstick_crouch_until = 0.0
        self.crouch_since = 0.0    # when crouch last went down
        self.crouch_until = 0.0    # keep crouching until then (after a crouch-jump)
        self.crouch_logged = False
        self.jump_at = 0.0         # start of the current jump-key pulse
        self.progress = (0.0, 0.0, 0.0)  # (time, x, z) for stalled()
        self.is_stalled = False
        self.next_nudge = 0.0      # earliest time to press E at a door again
        self.next_window_shot = 0.0
        self.next_medbag = 0.0     # earliest time to press USE for a medbag again
        self.medbag_try = None     # (time, medbags carried, health) when we last pressed USE
        self.inv_names = None      # names in the inventory array last tick (None = take a fresh baseline)
        self.had_badge = False
        self.tapped = set()        # keys pressed by tap() last tick, released this tick
        self.died_at = None
        self.next_respawn_press = 0.0
        self.lobby_since = None    # when we noticed we're waiting in the lobby
        self.lobby_pressed = 0.0
        self.reloading = False
        self.reload_progress = (None, 0.0)   # (rounds loaded, when it last changed)
        self.reload_held = False   # R is held down while reloading (one tap loads only one round)
        self.fire_held = None      # fire button currently held down, if any
        self.fire_since = 0.0      # when it went down
        self.fire_loaded = None    # rounds loaded when it went down (a drop means the shot is out)
        self.reload_since = 0.0    # when R last went down or up
        self.last_action = None    # the weapon's action on the previous tick (inventory["action"])
        self.last_shot_at = 0.0    # when the last shotgun shot animation started
        self.next_switch = 0.0
        self.item_goal = None      # address of the ground item we're walking to
        self.item_since = 0.0      # when we last got closer to it
        self.item_best = 0.0       # closest we've been to it (route length)
        self.ignored_items = {}    # address -> time until which we leave it alone
        self.item_costs = {}       # address -> route length (None = unreachable)
        self.item_costs_at = 0.0
        # Navigation
        self.level = None          # nav.Level for the loaded map
        self.level_name = None
        self.level_key = None      # the game's level pointer when we identified it
        self.route = None
        self.route_goal = None
        self.route_at = 0.0
        self.wander_goal = None
        self.wander_until = 0.0
        self.avoid = {}            # portal key (nav.Edge.key) -> time until which routes go round it
        self.stuck_key = None      # portal we were heading for at the last unstick
        self.stuck_count = 0       # unsticks in a row on the way to it
        self.stuck_at = 0.0        # when the last unstick started
        self.obstacle = None       # (portal key, since, E presses) for the door or window we're working on
        # Water (see note_water)
        self.wet = False           # feet in the water: guns don't fire here
        self.under_since = None    # when our head last went under (not reset by a short trip up)
        self.above_since = None    # when our head last came out
        self.surfacing = False     # swimming up for air
        self.surface_wait = None   # (since, highest eye height) while surfacing, to notice we can't get higher
        self.shore_target = None   # enemy on land swim() wants us to climb out at with the knife
        self.left_water_at = -1e9  # when we last came out of the water (Skill.knife_hold)
        self.water_route = None    # route through the water sectors when under a roof (water_waypoint)
        self.water_route_at = 0.0
        self.water_route_goal = None
        self.swim_low_until = 0.0  # swim lower (crouch) until then: stuck under a roof
        # Teams and CTF
        self.team_seen = None      # (team, mode) last logged
        self.objective = None      # (label, {x, y, z}) for CTF, or None
        # TNT (see tnt_fight) and dodging lit sticks
        self.tracks = {}           # player addr -> (time, x, z, vx, vz): smoothed velocity, for leading throws
        self.tnt_phase = None      # None, "light", "wind", "hold", "thrown"
        self.tnt_since = 0.0       # when the phase started
        self.tnt_lit_at = 0.0      # when our stick lit (its fuse runs from then)
        self.tnt_light_seen = None # when we first saw the lighting action (0) for this stick
        self.tnt_lit_seen = False  # the agent showed us the lit stick (else tnt_lit_at is the lighting's start;
                                   # None: not seen, and logged)
        self.tnt_pressed_at = 0.0  # when secondary went down for this stick (for the timing log)
        self.tnt_times = {}        # "lit" / "wound" -> seconds after that press, for the log
        self.tnt_idle_since = None # primary held but the weapon idle since then (the press got lost: press again)
        self.tnt_repress = False   # primary let go to be pressed again next tick
        self.tnt_close = False     # the target is close: the stick goes off at them in the air (tnt_close_hold)
        self.tnt_commit = False    # ... and we've passed the moment to throw it away instead
        self.tnt_last_close = None # (solution, point) of the last close throw found
        self.tnt_wound_at = 0.0    # when the wind-up ended (power grows from then)
        self.tnt_target = None     # the player we throw at (last seen)
        self.tnt_jumped = False    # jumped for reach during this throw
        self.tnt_lob = False       # this throw goes as a lob (the flat arc hits the level)
        self.tnt_arc_ok = True     # some throw at the target has a clear arc (check_arcs)
        self.tnt_arc_at = 0.0      # next arc check
        self.tnt_fb_turn = 0.0     # degrees off the target's direction for a last-moment throw (check_arcs)
        self.tnt_arc_cache = {}    # enemy addr -> (time, arc clear) for tnt_unseen_target
        self._neighbours = None    # (level, [set of sector indices] per sector) for arc_clear
        self.tnt_blocked = None    # the target we last found no clear throw at (logged once)
        self.tnt_retries = 0       # extra presses when a let-go didn't throw
        self.tnt_actions = []      # weapon actions seen during this throw, for the log
        self.tnt_plan = None       # (power, flight, goal) of the throw as let go
        self.tnt_next = 0.0        # earliest time to light another
        self.tnt_now = 0.0         # this tick's time, for tnt_solution
        self.tnt_watch = None      # our thrown stick in flight (watch_stick)
        self.gravity = tnt.load_gravity()
        self._tnt_min = None       # (gravity, tnt_min()) cached
        self.top_speed = 20.0      # fastest we've been seen moving on the ground (burst_risk)
        self.slot_seen = None      # weapon slot selected, and since when (TNT_SWITCH_WAIT)
        self.slot_since = 0.0
        self.lit_works = False     # the agent has shown us a lit stick in our hand at least once
        self.dodging = False

    # -- input helpers --------------------------------------------------------------------------------
    def set_keys(self, wanted):
        """Hold exactly the movement keys in `wanted`, plus sprint while moving upright."""
        if self.skill.sprint and wanted & {"w", "a", "s", "d"} and "lctrl" not in wanted:
            wanted = wanted | {"lshift"}
        if "lctrl" in wanted and "lctrl" not in self.bot.held:
            self.crouch_since = time.time()
        for k in MOVE_KEYS:
            if k in wanted and k not in self.bot.held:
                self.bot.press(k, True)
            elif k not in wanted and k in self.bot.held:
                self.bot.press(k, False)

    def tap(self, key):
        """Press `key` now; tick() releases it at the start of the next tick."""
        if key not in self.tapped:
            self.bot.press(key, True)
            self.tapped.add(key)

    def hold_reload(self, down):
        if down != self.reload_held:
            self.bot.press(RELOAD_KEY, down)
            self.reload_held = down
            self.reload_since = time.time()

    def stop_reload(self):
        self.reloading = False
        self.hold_reload(False)

    def fire_button(self, weapon):
        if weapon is not None and weapon["slot"] in self.skill.primary_slots:
            return PRIMARY_FIRE
        return SECONDARY_FIRE

    def press_fire(self, button, weapon, now):
        if self.fire_held != button:
            self.release_fire()
            self.bot.press(button, True)
            self.fire_held, self.fire_since, self.fire_loaded = button, now, weapon["loaded"]

    def release_fire(self):
        if self.fire_held:
            self.bot.press(self.fire_held, False)
            self.fire_held = None

    def trigger(self, weapon, want, now, inv=None, queue=False):
        """Drive the fire button. Shotgun and double-barrel: see pump(); `queue` is a looser wish to shoot,
        for a shot that only goes out when the current reload ends. Everything else: hold while we want to
        shoot, and the game keeps firing until the gun is empty."""
        action = inv.get("action") if inv else None
        if weapon is None:
            self.release_fire()
        elif weapon["slot"] in PUMP_SLOTS and action is not None:
            self.pump(weapon, action, want, now, queue)
        elif weapon["slot"] in PUMP_SLOTS:
            # Without the weapon state: press, and let go once the shot is out.
            if self.fire_held:
                if weapon["loaded"] < self.fire_loaded or now - self.fire_since > self.PUMP_PRESS_MAX:
                    self.release_fire()
            elif want and weapon["loaded"] > 0:
                self.press_fire(self.fire_button(weapon), weapon, now)
        elif want and (weapon["ammo"] is None or weapon["loaded"] > 0 or weapon["slot"] == KNIFE_SLOT):
            # (The knife's jab doesn't use up the knife, whatever its loaded count says.)
            self.press_fire(self.fire_button(weapon), weapon, now)
        else:
            self.release_fire()

    def pump(self, w, action, want, now, queue=False):
        """Shotgun / double-barrel in a fight: keep the next action queued behind the current one.

        The game holds one queued action and starts it the frame the current animation ends, provided
        its button is still down. So: once the shot animation has started, let go of fire (holding it
        would repeat the shot) and press R so the reload follows on at once. Once the reload has
        started, keep R down (letting go stops it after one round) and, if we want to shoot, press
        fire so the shot follows the moment the gun is full. A queued press needs a fresh key-down,
        hence the release on the tick an action starts. The queued shot only leaves when the reload ends
        (100 ms after, in fact), and we keep aiming meanwhile, so it only needs `queue`: roughly facing the
        target."""
        loaded, reserve = w["loaded"], w["reserve"] or 0
        can_reload = loaded < w["capacity"] and reserve > 0
        started = action != self.last_action
        self.last_action = action
        if action in (0, 1, 2):                         # shot animation running
            if started:
                gap = now - self.last_shot_at
                if gap < 5.0:                           # back-to-back shots: report the cycle time
                    self.log(f"{w['name']} shot, {gap:.2f}s after the last")
                self.last_shot_at = now
            self.release_fire()
            if started or reserve <= 0:
                self.hold_reload(False)                 # fresh key-down next tick
            else:
                self.hold_reload(True)
        elif action == RELOAD_ACTION:
            self.hold_reload(True)
            if want or queue:
                if started:
                    self.release_fire()
                else:
                    self.press_fire(self.fire_button(w), w, now)
            else:
                self.release_fire()
        else:                                           # idle
            if want and loaded > 0:
                self.hold_reload(False)
                if self.fire_held and now - self.fire_since > self.PUMP_PRESS_MAX:
                    self.release_fire()                 # nothing started (weapon still coming up?): retry
                else:
                    self.press_fire(self.fire_button(w), w, now)
            elif can_reload:
                self.release_fire()
                if self.reload_held and now - self.reload_since > self.PUMP_PRESS_MAX:
                    self.hold_reload(False)             # held but no reload started: press again
                else:
                    self.hold_reload(True)
            else:
                self.release_fire()
                self.hold_reload(False)

    def note_inventory(self, inv):
        """Log items entering or leaving the inventory array (names as they are in memory) and badge
        pickups, so a pickup the brain didn't act on shows up in the console."""
        if not inv:
            return
        names = {s["name"] for s in inv.get("slots") or [] if s["name"]}
        if self.inv_names is not None and names != self.inv_names:
            counts = {s["name"]: s["count"] for s in inv.get("slots") or []}
            change = [f"+{n} ({counts.get(n)})" for n in sorted(names - self.inv_names)]
            change += [f"-{n}" for n in sorted(self.inv_names - names)]
            self.log("inventory: " + " ".join(change))
        self.inv_names = names
        has = bool(inv.get("hasBadge"))
        if has != self.had_badge:
            self.log("picked up the badge" if has else "no longer holding the badge")
            self.had_badge = has

    def use_medbag(self, health, inv, now, engaged):
        """Press USE when hurt and carrying a medbag (IDOCBAG). The remaster has no select-item action, so
        USE applies the medbag directly. If the count doesn't drop after a press, say so and back off."""
        if not inv or health is None:
            return
        bags = inv.get("carried", {}).get("IDOCBAG") or 0
        if self.medbag_try:
            t, before, hp = self.medbag_try
            if now - t >= 1.0:
                if bags >= before and health <= hp:
                    self.log(f"pressed {USE_KEY.upper()} with {before} medbag(s) at health {hp:.1f}, but nothing "
                             f"happened (is USE bound to {USE_KEY!r} in this copy?)")
                    self.next_medbag = now + 10.0
                self.medbag_try = None
            return
        limit = self.skill.medbag_health if engaged else self.skill.medbag_health_idle
        if bags > 0 and 0 < health <= limit and now >= self.next_medbag:
            self.tap(USE_KEY)
            self.log(f"health {health:.1f}: using a medbag ({bags} left)")
            self.medbag_try = (now, bags, health)
            self.next_medbag = now + 1.5

    def fire_range(self, weapon):
        """The weapon's effective range for the fire mode we use, capped by max_engage."""
        if weapon is None:
            return self.skill.max_engage
        eff = weapon["effRange"] if self.fire_button(weapon) == PRIMARY_FIRE else weapon.get("effRange2", 0)
        eff = eff or weapon["effRange"]
        return min(self.skill.max_engage, eff) if eff > 0 else self.skill.max_engage

    def look_toward(self, me, heading, pitch):
        """Speed-limited turn toward a heading and pitch (14-bit units)."""
        max_step = to_units(self.skill.turn_speed * self.TICK)
        yaw_err = wrap(round(heading - me["yaw"]))
        pitch_err = pitch - me["pitch"]
        # Mouse x turns right (heading up); mouse y down lowers the pitch, so pitch takes the opposite sign.
        self.bot.api.set_look(clamp(yaw_err, max_step) / self.bot.units_per_mouse,
                              -clamp(pitch_err, max_step) / self.bot.units_per_mouse)

    def aim(self, me, target, dist):
        """Aim at the target with wobble. Returns (heading error, pitch error) in degrees, without wobble."""
        s = self.skill
        self.aim_offset = clamp(self.aim_offset + random.uniform(-1, 1) * s.aim_error * 0.3, s.aim_error)
        self.pitch_offset = clamp(self.pitch_offset + random.uniform(-1, 1) * s.aim_error * 0.15, s.aim_error / 2)
        eye_y = me["y"] + EYE * me["height"]
        aim_y = target["y"] + AIM * target["height"]
        want_yaw = bearing(me, target)
        want_pitch = to_units(math.degrees(math.atan2(aim_y - eye_y, max(dist, 1.0))))
        self.look_toward(me, want_yaw + to_units(self.aim_offset), want_pitch + to_units(self.pitch_offset))
        return to_deg(wrap(round(want_yaw - me["yaw"]))), to_deg(want_pitch - me["pitch"])

    # -- level and routes -----------------------------------------------------------------------------
    def ensure_level(self, me, others):
        """Identify the loaded map from live positions when the game's level changes."""
        key = self.bot.level_key
        if key is None or key == self.level_key:
            return
        self.level_key = key
        points = [dict(p, kind="player") for p in [me] + others if not p.get("dead")]
        points += [dict(i, kind="item") for i in self.bot.items + self.bot.badges]
        started = time.time()
        name, sectors, score = nav.identify(points)
        if name and score >= 0.8 * len(points):
            ch = (self.bot.self_state or {}).get("crouchHeight")
            ch = ch if ch and 1.0 < ch < 6.0 else nav.CROUCH_HEIGHT
            self.level, self.level_name = nav.Level(sectors, nav.lvt.load_inf(name), crouch_height=ch), name
            self.log(f"map: {name} ({score}/{len(points)} positions match, {time.time() - started:.1f}s), "
                     f"crouched height {ch:.2f}")
        else:
            self.level, self.level_name = None, None
            self.log(f"map not recognised (best {name}: {score}/{len(points)}); walking straight")
        self.route, self.item_costs, self.avoid = None, {}, {}

    def nav_point(self, me):
        """Where we are for routes. The sector graph has no way up out of the water, so in it routes start
        from the surface: straight above us in open water, or the nearest open water when under a roof."""
        if not self.wet or self.level is None:
            return me
        air = self.level.air_point(me["x"], me["y"] + 0.3, me["z"])
        if air is None:
            return me
        return dict(me, x=air[0], y=air[2] + 0.1, z=air[1])

    def avoiding(self, now):
        """Keys of the portals we gave up on that routes should still go round."""
        if self.avoid:
            self.avoid = {k: t for k, t in self.avoid.items() if t > now}
        return self.avoid

    def give_up(self, key, now, why):
        """Route round a portal we can't get through for AVOID_FOR seconds: a jump that falls short, a door
        that won't open, a window that won't break, a gap the map data says we fit through but we don't. If
        it's the only way, routes still use it."""
        self.avoid[key] = now + self.AVOID_FOR
        self.route = None
        self.stuck_key, self.stuck_count, self.obstacle = None, 0, None
        self.log(f"can't get through at ({key[2]:.0f}, {key[3]:.0f}), {why}: going round for {self.AVOID_FOR:.0f}s")

    def next_edge(self):
        """Key of the portal we're heading for: the next waypoint's, or the one after a corner or line-up
        point."""
        for wp in (self.route or [])[:2]:
            if wp.get("edge"):
                return wp["edge"]
        return None

    def waypoint(self, me, goal, now):
        """Next point to walk to on the way to `goal`, or None if there's no route."""
        if self.level is None:
            return dict(goal, jump=False, crouch=False)
        me = self.nav_point(me)
        stale = self.route is None or now - self.route_at > self.REPLAN
        moved = self.route_goal is not None and flat_dist(self.route_goal, goal) > 4.0
        if stale or moved:
            self.route = self.level.route(me, goal, self.avoiding(now))
            self.route_goal, self.route_at = dict(goal), now
            if self.route is None:
                return None
        # Drop waypoints we've passed: close enough, or we're already in the sector beyond them.
        here = self.level.locate(me["x"], me["y"], me["z"])
        # A line-up point in front of a narrow opening lies in our own sector: it's passed when we're close
        # to it or already through the opening.
        while len(self.route) > 1:
            wp = self.route[0]
            if wp.get("approach"):
                passed = flat_dist(me, wp) < 1.2 or self.route[1]["sector"] == here
            elif wp.get("corner"):
                # A point to walk round something jutting into our sector (a building corner): passed when
                # we're close, once we can walk straight on to the next waypoint, or if we're past it already.
                passed = (flat_dist(me, wp) < self.CORNER_REACHED
                          or here is not None and self.level.clear_line(here, me, self.route[1])
                          or here is not None and here != wp["sector"]
                          and any(w["sector"] == here for w in self.route[1:]))
            elif wp.get("jump"):
                # A ledge or window sill: passed once we're up on it, not when we're close to its foot.
                # Also passed once we're beyond it (over a thin sill and down the other side).
                passed = (wp["sector"] == here
                          or flat_dist(me, wp) < self.WAYPOINT_REACHED and me["y"] > wp["y"] - 0.5
                          or any(w["sector"] == here for w in self.route[1:]))
            elif wp["y"] < me["y"] - self.DROP_AT:
                # A ledge to drop off (a porch roof): passed once we're down there or beyond, not when we're
                # near the edge, or we'd turn back for the next waypoint underneath us.
                passed = wp["sector"] == here or any(w["sector"] == here for w in self.route[1:])
            else:
                # A portal: passed once we're through it (in its sector, or already in the next one when it
                # leads into a thin one). Close to it but still on this side we head on through it (below)
                # rather than cutting across to the next waypoint: `blocked` only sees our sector's solid
                # walls, and the next waypoint can lie past a window, a ledge or the porch sectors in front of
                # a building that only this portal gets us through. Without a point past it, cut across if
                # that doesn't run into the door frame or a post.
                passed = (here is not None and here in (wp["sector"], self.route[1]["sector"])
                          or not wp.get("beyond") and flat_dist(me, wp) < self.WAYPOINT_REACHED
                          and (here is None or not self.level.blocked(here, me, self.route[1])))
            if not passed:
                break
            popped = self.route.pop(0)
            if popped.get("edge") is not None and not popped.get("approach"):
                # Got through after all.
                if popped["edge"] == self.stuck_key:
                    self.stuck_key, self.stuck_count = None, 0
                if self.obstacle and popped["edge"] == self.obstacle[0]:
                    self.obstacle = None
        wp = self.route[0]
        if (wp.get("beyond") and not wp.get("approach") and not wp.get("corner")
                and flat_dist(me, wp) < (1.0 if wp["y"] < me["y"] - self.DROP_AT else self.WAYPOINT_REACHED)):
            # At the opening: head on through it, to a point just past it. On the edge of a drop, head on over
            # it, not for the edge under our feet.
            return dict(wp, x=wp["beyond"]["x"], z=wp["beyond"]["z"])
        return wp

    # -- weapons --------------------------------------------------------------------------------------
    @staticmethod
    def usable(w):
        """A weapon we can fight with: fists, or a gun with rounds loaded or in reserve."""
        return w["ammo"] is None or w["loaded"] > 0 or (w["reserve"] or 0) > 0

    def best_weapon(self, inv, dist, exclude=()):
        order = self.skill.prefer_far if dist is not None and dist > self.skill.far else self.skill.prefer_close
        by_slot = {w["slot"]: w for w in inv["weapons"]}
        for slot in order:
            w = by_slot.get(slot)
            if w and slot != TNT_SLOT and slot not in exclude and self.usable(w):
                return w
        return None

    @staticmethod
    def melee_slot(inv):
        """The weapon for the water: the knife if we have one, otherwise fists (None if neither shows up)."""
        slots = {w["slot"] for w in inv["weapons"]}
        return KNIFE_SLOT if KNIFE_SLOT in slots else FIST_SLOT if FIST_SLOT in slots else None

    def close_fight(self, me, now, dist, engaged):
        """An enemy within Skill.close_range: in sight, or seen there moments ago (ducked behind a corner)."""
        s = self.skill
        if engaged:
            return dist is not None and dist < s.close_range
        return (self.last_seen is not None and now - self.last_visible < s.fight_memory
                and flat_dist(me, self.last_seen) < s.close_range)

    def manage_weapon(self, me, now, dist, engaged):
        """Switch to the best usable weapon, and reload fully. Returns (weapon, may_fire)."""
        inv = me.get("inventory")
        if not inv:
            return None, True
        current = next((w for w in inv["weapons"] if w["slot"] == inv["slot"]), None)

        # Holding the badge: fists only.
        if inv.get("hasBadge"):
            self.stop_reload()
            if inv["slot"] != FIST_SLOT:
                self.release_fire()
                if now >= self.next_switch:
                    self.log("holding the badge: switching to fists")
                    self.tap(str(FIST_SLOT))
                    self.next_switch = now + 1.0
                return current, False
            return current, True

        # In the water or on top of it, no guns (they don't fire under water, and on top it counts as cheating):
        # the knife, or fists without one.
        if self.wet:
            self.stop_reload()
            melee = self.melee_slot(inv)
            if melee is None:
                self.release_fire()
                return current, False
            if inv["slot"] != melee:
                self.release_fire()
                if now >= self.next_switch:
                    self.log(f"in the water: switching to {'the knife' if melee == KNIFE_SLOT else 'fists'}")
                    self.tap(str(melee))
                    self.next_switch = now + 1.0
                return current, False
            return current, True

        # A sapper with sticks keeps the TNT out, fighting or not, and never fires a gun (user). tnt_fight throws.
        if self.tnt_ready(inv):
            self.stop_reload()
            self.release_fire()
            if inv["slot"] != TNT_SLOT and now >= self.next_switch:
                self.log(f"switch {current['name'] if current else 'weapon'} -> TNT ({itemlib.tnt_count(inv)} sticks)")
                self.tap(str(TNT_SLOT))
                self.next_switch = now + 1.5
            return current, False

        # The knife already out and an enemy at arm's length, or just out of the water (we climbed out at
        # someone): stab rather than spend the switch time on a gun.
        if current is not None and current["slot"] == KNIFE_SLOT and (
                now - self.left_water_at < self.skill.knife_hold
                or engaged and dist is not None and dist < self.skill.knife_keep):
            self.stop_reload()
            return current, True

        # Out of a fight we need to move, and the Gatling roots us: carry something else if we can.
        best = None
        if not engaged:
            best = self.best_weapon(inv, dist, exclude=(GATLING_SLOT,))
        best = best or self.best_weapon(inv, dist)

        # Switch when something better is usable or the current weapon is dry. Not mid-reload unless dry.
        dry = current is None or not self.usable(current)
        if best and current and best["slot"] != current["slot"] and now >= self.next_switch \
                and (dry or not (self.reloading or inv.get("action") == RELOAD_ACTION)):
            self.log(f"switch {current['name']} -> {best['name']}")
            self.release_fire()
            self.tap(str(best["slot"]))
            self.stop_reload()
            self.next_switch = now + 1.5
            return best, False
        if current is None or current["ammo"] is None or current["slot"] == TNT_SLOT:
            self.stop_reload()                      # fists/knife/TNT: nothing to reload
            return current, True

        if engaged and current["slot"] in PUMP_SLOTS and inv.get("action") is not None:
            self.reloading = False                  # in a fight pump() runs fire and reload together
            return current, True

        loaded, cap, reserve = current["loaded"], current["capacity"], current["reserve"] or 0
        full = loaded >= cap or reserve <= 0
        # Up close a part-loaded gun beats standing there reloading: with enough rounds in, don't start a
        # reload (even with the enemy just out of sight), and cut one short once the enemy shows up.
        enough = loaded >= min(self.skill.close_reload_below, cap)
        hold_off = current["slot"] not in PUMP_SLOTS and enough and self.close_fight(me, now, dist, engaged)
        if self.reloading and hold_off and engaged:
            self.stop_reload()
            self.log(f"reload cut short: {current['name']} {loaded}/{cap}, enemy at {dist:.0f}")
        if not self.reloading and not full and not hold_off and (loaded == 0 or not engaged):
            self.reloading = True
            self.reload_progress = (loaded, now)
            self.log(f"reloading {current['name']} {loaded}/{cap} (+{reserve})")
        if self.reloading:
            last, since = self.reload_progress
            if full:
                self.stop_reload()
                self.log(f"reloaded {current['name']} {loaded}/{cap}")
            elif loaded != last:
                self.reload_progress = (loaded, now)
            elif now - since > self.skill.reload_stall and self.reload_held:
                self.hold_reload(False)                     # stalled: let go, hold again next tick
                self.reload_progress = (loaded, now)
                return current, False
            if self.reloading:
                # Keep R down until the weapon is full (or out of spare rounds). Pressing it while a
                # shotgun shot is still animating is fine: the game starts the reload when that ends,
                # as long as R is still down then.
                self.release_fire()
                self.hold_reload(True)
        # Firing cancels a reload, so hold fire until it's done.
        return current, not self.reloading and loaded > 0

    # -- movement -------------------------------------------------------------------------------------
    def go(self, me, now, goal, aiming=False, keep=0.0, strafe=False):
        """Move toward `goal` along a route. When `aiming`, the view belongs to the aim code and we pick
        W/A/S/D relative to it; otherwise we face the next waypoint. Returns False if unreachable."""
        keys = set()
        reachable = True
        busy = False                          # waiting on a door or shooting out a window
        roofed = None
        if now < self.unstick_until:
            # Crouch-jump while strafing: a crouched player fits through window openings and low gaps.
            # Crouch first; jump and strafe once the crouch has taken hold.
            if now < self.unstick_crouch_until:
                keys = {"lctrl", "w"}
            else:
                keys = {self.strafe_key, "space", "w", "lctrl"}
        else:
            roofed = self.roofed_exit(me, now)
            if roofed is not None:
                wp = roofed                   # under the docks: out into open water first, where routes start
            else:
                wp = self.waypoint(me, goal, now) if flat_dist(me, goal) > keep else None
            if wp is None and flat_dist(me, goal) > keep:
                reachable = False
            if wp is not None:
                heading = bearing(me, wp)
                if aiming:
                    keys |= keys_toward(me["yaw"], heading)
                else:
                    self.look_toward(me, heading, 0)
                    if abs(to_deg(wrap(round(heading - me["yaw"])))) < 60:   # turn first on sharp corners
                        keys.add("w")
                d = flat_dist(me, wp)
                near = d < 6.0
                if wp.get("crouch_jump"):
                    # A low opening above a ledge (a window): crouch first, jump once the crouch has
                    # taken hold, and stay crouched through the jump and a little after.
                    if near and self.crouched(me, now) and d < self.CROUCH_JUMP_AT:
                        keys |= self.jump_keys(now)
                        self.crouch_until = now + self.skill.crouch_hold
                elif wp.get("jump") and near:
                    keys |= self.jump_keys(now)
                if wp.get("crouch") and near or self.in_crouch_space(me):
                    keys.add("lctrl")
                if roofed is None:
                    busy = self.handle_obstacles(me, now, wp, aiming)
            if now < self.crouch_until:
                keys.add("lctrl")
            if strafe:
                if now > self.strafe_until:
                    self.strafe_key = self.rng.choice("ad")
                    self.strafe_until = now + self.rng.uniform(0.6, 1.8)
                if not keys & {"a", "d"}:
                    keys.add(self.strafe_key)
            # Avoid badges before the stuck check, so holding back from a badge doesn't count as stuck.
            keys = self.avoid_badges(me, keys)
            self.check_stuck(now, me, bool(keys & {"w", "a", "s", "d"}) and not strafe and not busy)
        if self.wet and self.roof_over(me) is not None:
            keys = self.roof_keys(me, now, keys)
        elif self.wet:
            # Swim up (jump) to stay at the surface, where routes run and the banks can be climbed. No crouching.
            keys = (keys - {"lctrl"}) | {"space"}
        self.set_keys(keys)
        return reachable

    def roofed_exit(self, me, now):
        """In the water under a roof (below the docks): the next point on the way out into open water, else None."""
        if self.roof_over(me) is None:
            return None
        air = self.level.air_point(me["x"], me["y"] + 0.3, me["z"])
        if air is None:
            return None
        return self.water_waypoint(me, {"x": air[0], "z": air[1]}, now)

    def roof_over(self, me):
        """The roof's height when we're in water with no air above it (under the docks and the riverside
        buildings), else None."""
        if not self.wet or self.level is None:
            return None
        i = self.level.water_at(me["x"], me["y"] + 0.3, me["z"])
        if i is None or self.level.sectors[i].vadjoin >= 0:
            return None
        return self.level.sectors[i].ceiling

    def roof_keys(self, me, now, keys):
        """Keys under a roof in the water. Never swim up: that pins us to the roof. Swim lower (crouch) when our
        head nears it, and for a second whenever we stop getting anywhere: the beams and the tops of the
        pilings' walls catch us up there, and going lower gets us loose (user)."""
        roof = self.roof_over(me)
        keys = keys - {"space"}
        if keys & {"w", "a", "s", "d"} and self.stalled(now, me):
            if now >= self.swim_low_until:
                self.log("stuck under a roof in the water: swimming lower")
            self.swim_low_until = now + 1.0
        if now < self.swim_low_until or roof is not None and me["y"] + me["height"] > roof - 1.0:
            keys.add("lctrl")
        return keys

    def water_waypoint(self, me, goal, now):
        """Next point on the way to `goal` (x, z) under water: a route through the water sectors at our depth,
        round the pilings under the docks (a straight line runs into them). Straight at it without a route."""
        g = {"x": goal["x"], "y": me["y"], "z": goal["z"]}
        if (self.water_route is None or now - self.water_route_at > 1.0
                or flat_dist(self.water_route_goal, g) > 3.0):
            self.water_route = self.level.route(me, g) or []
            self.water_route_at, self.water_route_goal = now, g
        while len(self.water_route) > 1 and flat_dist(me, self.water_route[0]) < 2.0:
            self.water_route.pop(0)
        wp = self.water_route[0] if self.water_route else g
        return {"x": wp["x"], "y": wp["y"], "z": wp["z"]}

    def crouched(self, me, now):
        """Crouch has taken hold: we're down at our crouched height, or it has been held CROUCH_LEAD."""
        if "lctrl" not in self.bot.held:
            return False
        ch = (self.bot.self_state or {}).get("crouchHeight")
        if ch and me["height"] <= ch + 0.25:
            if not self.crouch_logged:
                self.crouch_logged = True
                self.log(f"crouched: height {me['height']:.2f} after {now - self.crouch_since:.2f}s")
            return True
        return now - self.crouch_since >= self.CROUCH_LEAD

    def jump_keys(self, now):
        """The jump key in pulses, so a jump that fell short gets a fresh press."""
        if now - self.jump_at >= 2 * self.JUMP_PULSE:
            self.jump_at = now
        return {"space"} if now - self.jump_at < self.JUMP_PULSE else set()

    def stalled(self, now, me):
        """True when we've barely moved over the last ~0.4 s. Call every tick."""
        t, x, z = self.progress
        if now - t >= 0.4:
            self.is_stalled = math.hypot(me["x"] - x, me["z"] - z) < 0.8
            self.progress = (now, me["x"], me["z"])
        return self.is_stalled

    def handle_obstacles(self, me, now, wp, aiming):
        """Doors and windows on the route (nav marks them on waypoints). We only act when stalled in front
        of one: E toggles a door, so pressing it on an open door would close it. Returns True while we're
        waiting on one, which keeps the stuck handling from strafing away. After DOOR_TRIES presses or
        WINDOW_PATIENCE seconds of shooting we give up on it (give_up) and stop waiting."""
        stalled = self.stalled(now, me)
        door, window = wp.get("door"), wp.get("window")
        nxt = (self.route[1] if self.route and len(self.route) > 1
               and (self.route[0] is wp or wp.get("edge") is not None and self.route[0].get("edge") == wp["edge"])
               else None)                     # (waypoint() hands out a copy when steering past a portal)
        if nxt and not door and not window:      # the obstacle may sit just past the next waypoint
            door, window = nxt.get("door"), nxt.get("window")
            wp = nxt
        if door and ((door["x"] - me["x"]) * (wp["x"] - me["x"]) + (door["z"] - me["z"]) * (wp["z"] - me["z"]) < 0
                     and flat_dist(me, wp) > 1.0):
            door = None                       # already behind us
        key = wp.get("edge")
        if self.obstacle and now - self.obstacle[1] > 20.0:
            self.obstacle = None              # an old one: start counting afresh
        if door and flat_dist(me, door) < DOOR_REACH:
            if stalled and now >= self.next_nudge:
                tries = self.obstacle[2] + 1 if self.obstacle and self.obstacle[0] == key else 1
                if tries > self.DOOR_TRIES:
                    # With no portal to route round (a door inside one sector), stop waiting on it and let
                    # the stuck handling take over.
                    if key is not None:
                        self.give_up(key, now, "the door won't open")
                    return False
                self.obstacle = (key, now, tries)
                if not aiming:
                    self.look_toward(me, bearing(me, door), 0)
                self.tap("e")
                self.next_nudge = now + DOOR_RETRY
                self.log("door in the way: pressing E")
            return now < self.next_nudge
        if (window and not aiming and not self.wet and flat_dist(me, window) < WINDOW_REACH and stalled
                and (me.get("inventory") or {}).get("slot") != TNT_SLOT):   # firing would light a stick
            if not (self.obstacle and self.obstacle[0] == key):
                self.obstacle = (key, now, 0)
            elif now - self.obstacle[1] > self.WINDOW_PATIENCE:
                if key is not None:
                    self.give_up(key, now, "the window won't break")
                return False
            dist = max(flat_dist(me, window), 1.0)
            want_yaw = bearing(me, window)
            want_pitch = to_units(math.degrees(math.atan2(window["y"] - (me["y"] + EYE * me["height"]), dist)))
            self.look_toward(me, want_yaw, want_pitch)
            lined_up = abs(to_deg(wrap(round(want_yaw - me["yaw"])))) < 4 and abs(to_deg(want_pitch - me["pitch"])) < 4
            if lined_up and now >= self.next_window_shot:
                inv = me.get("inventory") or {}
                weapon = next((w for w in inv.get("weapons", []) if w["slot"] == inv.get("slot")), None)
                self.tap(self.fire_button(weapon))
                self.next_window_shot = now + 1.0
                self.log("window in the way: shooting it")
            return True
        return False

    def in_crouch_space(self, me):
        if self.level is None:
            return False
        sec = self.level.locate(me["x"], me["y"], me["z"])
        return sec is not None and self.level._crouch_only(sec, me["x"], me["z"])

    def avoid_badges(self, me, keys):
        """Never walk onto a badge: stop advancing toward one and strafe away from it."""
        for b in self.bot.badges:
            d = flat_dist(me, b)
            if d > BADGE_AVOID:
                continue
            rel = to_deg(wrap(round(bearing(me, b) - me["yaw"])))     # positive = badge on our right
            if abs(rel) < 100:                                       # it's ahead of us
                keys.discard("w")
                if d < BADGE_AVOID / 2:
                    keys.add("s")
            keys.discard("a")
            keys.discard("d")
            keys.add("a" if rel > 0 else "d")
        return keys

    def check_stuck(self, now, me, moving):
        if self.stuck_check is None or not moving:
            self.stuck_check = (now, me["x"], me["z"])
            return
        t, x, z = self.stuck_check
        if now - t < 0.8:
            return
        if math.hypot(me["x"] - x, me["z"] - z) < 2.0:
            # The same portal again: after GIVE_UP_STUCKS in a row, route round it for a while.
            key = self.next_edge()
            if key is not None and key == self.stuck_key and now - self.stuck_at < self.STUCK_MEMORY:
                self.stuck_count += 1
            else:
                self.stuck_key, self.stuck_count = key, 1
            self.stuck_at = now
            if key is not None and self.stuck_count >= self.GIVE_UP_STUCKS:
                self.give_up(key, now, "stuck")
            self.strafe_key = self.rng.choice("ad")
            self.unstick_crouch_until = now + self.UNSTICK_CROUCH
            self.unstick_until = self.unstick_crouch_until + 0.6
            self.crouch_until = self.unstick_until + 1.0
            self.route = None                 # replan from wherever we end up
            self.wander_goal = None
        self.stuck_check = (now, me["x"], me["z"])

    def wander(self, me, now):
        if self.wander_goal is None or now > self.wander_until or flat_dist(me, self.wander_goal) < 4:
            spot = self.level.random_spot(self.rng, self.nav_point(me)) if self.level else None
            if spot is None:                  # no map (or a miss): pick a point ahead of us
                heading = math.radians(to_deg(me["yaw"]) + self.rng.uniform(-90, 90))
                spot = {"x": me["x"] + 40 * math.sin(heading), "y": me["y"], "z": me["z"] + 40 * math.cos(heading)}
            self.wander_goal, self.wander_until = spot, now + 15.0
        if not self.go(me, now, self.wander_goal):
            self.wander_goal = None

    # -- items ----------------------------------------------------------------------------------------
    def seek_item(self, me, now, aiming=False, knife_only=False, armor_only=False):
        """Walk to the most worthwhile reachable item, or with `knife_only` the nearest reachable knife however
        far, or with `armor_only` a boiler plate within Skill.armor_detour. Returns False when there's nothing
        worth getting."""
        inv = me.get("inventory")
        if not inv:
            return False
        if now - self.item_costs_at > self.ITEM_COSTS_EVERY:
            items = self.bot.items
            costs = (self.item_routes(me, items, now) if self.level is not None
                     else [flat_dist(me, it) for it in items])
            self.item_costs = {it["addr"]: c for it, c in zip(items, costs)}
            self.item_costs_at = now
        if knife_only:
            it = self.nearest_knife(me, now)
        elif armor_only:
            it = self.armor_nearby(me, inv, now)
        else:
            it = itemlib.pick(self.bot.items, me, inv, self.bot.badges, self.ignored_items, now,
                              cost=self.item_costs.get if self.level else None, knife=self.knife_value(),
                              favorite=self.skill.favorite, melee_only=self.skill.melee_only)
        if it is None or not knife_only and it["value"] < self.skill.min_item_value:
            self.item_goal = None
            return False
        if it["addr"] != self.item_goal:
            self.item_goal, self.item_since, self.item_best = it["addr"], now, it["dist"]
            self.log(f"going for {it['name']} (worth {it['value']:.0f}) {it['dist']:.0f} away")
        if it["dist"] < self.item_best - 1.0:
            self.item_best, self.item_since = it["dist"], now
        elif now - self.item_since > self.skill.item_patience:
            # Not getting closer (blocked), or standing on it without it being taken (we're full).
            self.ignored_items[it["addr"]] = now + 20.0
            self.log(f"giving up on {it['name']}")
            self.item_goal = None
            return False
        under = self.level.air_point(it["x"], it["y"] + 0.5, it["z"]) if self.level is not None else None
        if under is not None and self.wet:
            self.dive(me, now, it, aiming)    # in the water with it: swim straight there
            return True
        if under is None and not aiming and flat_dist(me, it) < 2.0:
            self.set_keys({"w"} | ({"lctrl"} if self.in_crouch_space(me) else set()))
            return True                       # right on top of it: the bearing swings wildly, just step
        # An item in the water is first walked to as the surface above it; once in, we dive.
        goal = it if under is None else {"x": under[0], "y": under[2], "z": under[1]}
        if not self.go(me, now, goal, aiming=aiming):
            self.ignored_items[it["addr"]] = now + 20.0
            self.item_goal = None
            return False
        return True

    def want_knife(self, me):
        """On Orleans a bot without a knife makes getting one its first job (user): before other items, the CTF
        objective and hunting, and while fighting it heads for one instead of closing in. A brawler
        (Skill.knife_first) does it on every map. Not while holding the badge (fists only) or carrying a flag
        home."""
        inv = me.get("inventory")
        return ((self.level_name == "orleans" or self.skill.knife_first) and bool(inv) and not inv.get("hasBadge")
                and not me.get("carries")
                and not any(w["slot"] == KNIFE_SLOT for w in inv["weapons"]))

    def nearest_knife(self, me, now, badge_margin=8.0):
        """The knife on the ground with the shortest way there (Brain.item_costs), or None."""
        best = None
        for it in self.bot.items:
            if it.get("name") != itemlib.KNIFE or self.ignored_items.get(it["addr"], 0) > now:
                continue
            d = self.item_costs.get(it["addr"]) if self.level is not None else flat_dist(me, it)
            if d is None:
                continue
            if any(math.hypot(it["x"] - b["x"], it["z"] - b["z"]) < badge_margin for b in self.bot.badges):
                continue
            if best is None or d < best["dist"]:
                best = dict(it, value=self.knife_value(), dist=d)
        return best

    def armor_nearby(self, me, inv, now, badge_margin=8.0):
        """The best boiler plate we'd still take (items.armor_value) within its detour (Skill.armor_detour scaled
        by what it gives), or None."""
        best, best_score = None, 0.0
        for it in self.bot.items:
            name = it.get("name")
            if name not in itemlib.ARMOR or self.ignored_items.get(it["addr"], 0) > now:
                continue
            d = self.item_costs.get(it["addr"]) if self.level is not None else flat_dist(me, it)
            if d is None or d > self.skill.armor_detour * itemlib.ARMOR[name] / 100.0:
                continue
            if any(math.hypot(it["x"] - b["x"], it["z"] - b["z"]) < badge_margin for b in self.bot.badges):
                continue
            v = itemlib.armor_value(name, inv)
            if v > 0 and v / (d + 15.0) > best_score:
                best, best_score = dict(it, value=v, dist=d), v / (d + 15.0)
        return best

    def item_routes(self, me, items, now):
        """Route length to each item (None = unreachable). Items in the water (Orleans' knives lie on the river
        bed) count from in the water as the straight swim there, from dry land as the route to the surface above
        them plus the dive."""
        goals, wet = [], {}
        for k, it in enumerate(items):
            air = self.level.air_point(it["x"], it["y"] + 0.5, it["z"]) if self.level.water else None
            if air is None:
                goals.append(it)
            else:
                wet[k] = air
                goals.append({"x": air[0], "y": air[2] + 0.1, "z": air[1]})
        costs = self.level.route_lengths(self.nav_point(me), goals, self.avoiding(now))
        for k, (ax, az, top, _) in wet.items():
            it = items[k]
            if self.wet:
                costs[k] = math.dist((me["x"], me["y"], me["z"]), (it["x"], it["y"], it["z"]))
            elif costs[k] is not None:
                costs[k] += top - it["y"] + math.hypot(ax - it["x"], az - it["z"])
        return costs

    def knife_value(self):
        """What a knife is worth while we have none (items.value: nothing once we have one): only on Orleans or to
        a brawler, and most while we're in the water."""
        if self.level_name != "orleans" and not self.skill.knife_first:
            return 0.0
        return self.skill.knife_value_wet if self.wet else self.skill.knife_value

    # -- water ----------------------------------------------------------------------------------------
    def note_water(self, me, now):
        """Track whether we're in the water (feet below the surface, or on top of it) and how long our head has
        been under, from the map's water sectors. Past Skill.air_time under, `surfacing` is set until we've had our head out
        for Skill.breathe seconds. A short trip up doesn't reset the clock: we don't know how fast air comes
        back."""
        lvl = self.level
        if lvl is None or not lvl.water:
            self.wet, self.under_since, self.above_since, self.surfacing = False, None, None, False
            return
        x, z = me["x"], me["z"]
        wet = lvl.in_water(x, me["y"], z)
        if wet != self.wet:
            self.log("in the water" if wet else "out of the water")
            self.wet = wet
            if not wet:
                self.left_water_at = now
        eye = me["y"] + EYE * me["height"]
        if lvl.water_at(x, eye, z) is not None:
            self.above_since = None
            if self.under_since is None:
                self.under_since = now
            under_for = now - self.under_since
            if not self.surfacing and under_for > self.skill.air_time:
                self.surfacing, self.surface_wait = True, (now, eye)
                self.log(f"under water for {under_for:.0f}s: swimming up for air")
            elif self.surfacing:
                # Not getting any higher with the surface right above: our eye may stay just under it while we
                # float there. Count that as air rather than hang at the top for good.
                since, best = self.surface_wait
                if eye > best + 0.3:
                    self.surface_wait = (now, eye)
                else:
                    air = lvl.air_point(x, me["y"] + 0.3, z)
                    if air and air[3] and now - since > 3.0 and eye > air[2] - 1.5:
                        self.log(f"at the surface but the eye stays under ({eye:.1f} < {air[2]:.1f}): "
                                 "counting it as air")
                        self.under_since, self.surfacing = None, False
        elif self.under_since is not None:
            if self.above_since is None:
                self.above_since = now
            if now - self.above_since >= self.skill.breathe:
                self.log(f"breathed after {self.above_since - self.under_since:.0f}s under water")
                self.under_since, self.above_since, self.surfacing = None, None, False

    def swim(self, me, now, target):
        """In the water or on top of it. Returns True when it handled the tick: swimming up for air (fighting on
        the way if we can), or a melee fight (knife, or fists without one) with an enemy who is in the water too or
        within reach. Otherwise the land logic runs, with go() keeping us at the surface and routing out, and
        without a target: no guns in the water."""
        inv = me.get("inventory")
        armed = bool(inv) and inv["slot"] == self.melee_slot(inv)
        self.shore_target = None
        if target is not None:
            weapon = next((w for w in inv["weapons"] if w["slot"] == inv["slot"]), None) if armed else None
            reach = math.dist((me["x"], me["y"], me["z"]), (target["x"], target["y"], target["z"]))
            if not armed or not (self.level.in_water(target["x"], target["y"], target["z"])
                                 or reach < self.fire_range(weapon)):
                if armed and inv["slot"] == KNIFE_SLOT and flat_dist(me, target) < self.skill.shore_chase:
                    # On land but close: climb out at them with the knife up (the land fight logic does it, and
                    # manage_weapon keeps the knife once we're out, see Skill.knife_keep).
                    self.shore_target = target
                target = None                 # melee only, at someone in the water or in reach
        if not self.surfacing and target is None:
            return False
        keys = set()
        dist = flat_dist(me, target) if target else None
        weapon, may_fire = self.manage_weapon(me, now, dist, engaged=target is not None)
        if target is not None:
            if self.visible_since is None:
                self.visible_since = now
            self.last_visible = now
            self.last_seen = {"x": target["x"], "y": target["y"], "z": target["z"]}
            yaw_err, pitch_err = self.aim(me, target, dist)
            reach = math.dist((me["x"], me["y"] + me["height"] / 2, me["z"]),
                              (target["x"], target["y"] + target["height"] / 2, target["z"]))
            want = (may_fire and now - self.visible_since > self.skill.reaction
                    and reach < self.fire_range(weapon) * 0.8 and abs(yaw_err) < 25 and abs(pitch_err) < 30)
            self.trigger(weapon, want, now, inv)
        else:
            self.release_fire()
        roofed = self.roof_over(me) is not None
        if self.surfacing:
            air = self.level.air_point(me["x"], me["y"] + 0.3, me["z"])
            if air is not None and math.hypot(air[0] - me["x"], air[1] - me["z"]) > 1.0:
                # Under a roof: out to open water first, round the pilings.
                wp = (self.water_waypoint(me, {"x": air[0], "z": air[1]}, now) if roofed
                      else {"x": air[0], "z": air[1]})
                heading = bearing(me, wp)
                if target is not None:
                    keys |= keys_toward(me["yaw"], heading)
                else:
                    self.look_toward(me, heading, 0)
                    if abs(to_deg(wrap(round(heading - me["yaw"])))) < 60:
                        keys.add("w")
            if not roofed:
                keys.add("space")
        else:
            # Close in, rising to the target when it's above us (we sink on our own).
            if dist > 2.0:
                keys |= keys_toward(me["yaw"], bearing(me, target))
            if target["y"] + target["height"] / 2 > me["y"] + me["height"] / 2 + 1.0:
                keys.add("space")
        if roofed:
            keys = self.roof_keys(me, now, keys)
        self.set_keys(keys)
        return True

    def dive(self, me, now, goal, aiming):
        """Swim straight to a point in the water (an item on the river bed): face it, pitch and all, and go.
        Jump rises when it's above us; otherwise we sink onto it."""
        heading = bearing(me, goal)
        d = flat_dist(me, goal)
        keys = set()
        if aiming:
            if d > 1.0:
                keys |= keys_toward(me["yaw"], heading)
        else:
            eye = me["y"] + EYE * me["height"]
            self.look_toward(me, heading, to_units(math.degrees(math.atan2(goal["y"] + 0.5 - eye, max(d, 1.0)))))
            if d > 1.0 and abs(to_deg(wrap(round(heading - me["yaw"])))) < 60:
                keys.add("w")
        if goal["y"] > me["y"] + 0.5:
            keys.add("space")
        self.set_keys(keys)

    # -- behaviours -----------------------------------------------------------------------------------
    def desperate(self, inv):
        """Nothing to fight with (items.desperate), where a sapper's sticks count and a brawler never is."""
        if self.skill.tnt and itemlib.tnt_count(inv) > 0:
            return False
        return itemlib.desperate(inv, self.skill.melee_only)

    def favorite_ready(self, inv):
        """Whether the behaviour's favourite weapon is to hand (owned and loaded or with spare ammo; TNT: sticks
        left), so its keep_distance and back_off apply."""
        fav = self.skill.favorite
        if fav is None or not inv:
            return fav is None
        if fav == TNT_SLOT:
            return itemlib.tnt_count(inv) > 0 and not self.wet
        w = next((w for w in inv["weapons"] if w["slot"] == fav), None)
        return w is not None and self.usable(w)

    def back_away(self, me, now, target, step=20.0):
        """Walk away from `target` while aiming at it, strafing. False if there's no way back there."""
        d = max(flat_dist(me, target), 0.1)
        goal = {"x": me["x"] + (me["x"] - target["x"]) / d * step, "y": me["y"],
                "z": me["z"] + (me["z"] - target["z"]) / d * step}
        return self.go(me, now, goal, aiming=True, strafe=True)

    def track(self, players, now):
        """Smoothed velocity of every living player, from its position tick to tick (for leading TNT throws)."""
        seen = set()
        for p in players:
            seen.add(p["addr"])
            old = self.tracks.get(p["addr"])
            vx = vz = 0.0
            if old and 0 < now - old[0] < 0.5:
                dt = now - old[0]
                mx, mz = (p["x"] - old[1]) / dt, (p["z"] - old[2]) / dt
                if math.hypot(mx, mz) < 60.0:         # faster is a respawn or a teleport, not running
                    vx, vz = old[3] + 0.35 * (mx - old[3]), old[4] + 0.35 * (mz - old[4])
            self.tracks[p["addr"]] = (now, p["x"], p["z"], vx, vz)
        for addr in [a for a in self.tracks if a not in seen]:
            del self.tracks[addr]

    def predict(self, p, ahead, now):
        """Where player p (tnt_fight stores its position, seen_at, vx and vz each tick, in sight or not: the user
        allows that for TNT) will be `ahead` seconds from now, leading by part of its velocity."""
        t = min(ahead + now - p.get("seen_at", now), self.TNT_LEAD_MAX) * self.TNT_LEAD
        return {"x": p["x"] + p.get("vx", 0.0) * t, "y": p["y"], "z": p["z"] + p.get("vz", 0.0) * t}

    def ceiling_over(self, a, b):
        """The lower ceiling of the sectors at a and b (a throw's arc has to fit under it), or None without a map."""
        if self.level is None:
            return None
        tops = []
        for p in (a, b):
            i = self.level.locate(p["x"], p["y"] + 0.5, p["z"])
            if i is not None:
                tops.append(self.level.ceiling_at(i, p["x"], p["z"]))
        return min(tops) if tops else None

    def dodge(self, me, now, aiming=False):
        """Run from lit sticks within Skill.dodge_radius (not the one in our own hand), straight away from them.
        When `aiming` the view stays on the target. Returns True while running."""
        if not self.skill.dodge_tnt:
            return False
        held = (self.bot.lit or {}).get("addr")
        ax = az = 0.0
        nearest = None
        for st in self.bot.explosives:
            if st["addr"] == held:
                continue
            st = self.stick_rest(st, me["y"])
            d = math.dist((me["x"], me["y"], me["z"]), (st["x"], st["y"], st["z"]))
            radius = self.skill.dodge_radius + (3.0 if self.dodging else 0.0)   # a little farther once running
            if d >= radius:
                continue
            w = (radius - d) / max(flat_dist(me, st), 0.5)
            ax, az = ax + (me["x"] - st["x"]) * w, az + (me["z"] - st["z"]) * w
            nearest = d if nearest is None else min(nearest, d)
        if nearest is None:
            self.dodging = False
            return False
        if not self.dodging:
            self.log(f"lit TNT {nearest:.0f} away: running")
            self.dodging = True
        heading = bearing({"x": 0.0, "z": 0.0}, {"x": ax, "z": az}) if ax or az else me["yaw"] + FULL_TURN // 2
        keys = keys_toward(me["yaw"], heading)
        if self.stalled(now, me):
            keys.add(self.strafe_key)              # backed into a wall: slide along it
        self.set_keys(keys)
        return True

    def stick_rest(self, st, floor_y):
        """Where a stick will come down: itself when it's slow (lying or rolling), else where its flight meets
        `floor_y`. So a stick flying past, our own on its way out included, isn't run from."""
        if math.dist((st["vx"], st["vy"], st["vz"]), (0, 0, 0)) < 10.0:
            return st
        disc = st["vy"] ** 2 + 2 * self.gravity * max(st["y"] - floor_y, 0.0)
        t = (st["vy"] + math.sqrt(disc)) / self.gravity
        return dict(st, x=st["x"] + st["vx"] * t, y=floor_y, z=st["z"] + st["vz"] * t)

    # -- TNT (the sapper) -------------------------------------------------------------------------------
    # Secondary fire lights a stick, primary winds up, and letting go throws (tnt.py has the mechanics). The fuse
    # runs from lighting, so the throw is held ("cooked") until the stick will go off TNT_LAND_MARGIN after it
    # lands, and aimed at where the target will be by then; a close target gets it going off right at them
    # (tnt_close_hold). Phases: light (secondary held until the lighting starts), wind (primary held from then
    # on, so the wind-up follows the lighting at once, until the weapon is wound up), hold (aim, wait, let go)
    # and thrown (until the stick has left our hand).
    def tnt_ready(self, inv):
        """A sapper with sticks, able to use them: on dry land (no lighting in the water) and without the badge."""
        return (self.skill.tnt and bool(inv) and not self.wet and not inv.get("hasBadge")
                and itemlib.tnt_count(inv) > 0 and any(w["slot"] == TNT_SLOT for w in inv["weapons"]))

    def tnt_wanted(self, me, now):
        """Go after the enemy in sight with TNT (tnt_fight)? Whenever we can, once we've reacted to them."""
        return (self.tnt_ready(me.get("inventory")) and now >= self.tnt_next and self.visible_since is not None
                and now - self.visible_since >= self.skill.reaction)

    def tnt_min(self):
        """How far from us a stick has to land: Skill.tnt_min, or less when a standing throw doesn't carry that far
        (the gravity measured live, ~97, gives ~42). Closer targets get the close throw (tnt_close_hold)."""
        if self._tnt_min is None or self._tnt_min[0] != self.gravity:
            still = {"x": 0.0, "y": 0.0, "z": 0.0, "height": 6.0}
            reach = tnt.reach(still, (0.0, 0.0, 0.0), 0.0, 1.0, 0.0, self.gravity)[0]
            self._tnt_min = (self.gravity, min(self.skill.tnt_min, reach - 2.0))
        return self._tnt_min[1]

    def tnt_reset(self):
        self.tnt_phase, self.tnt_target, self.tnt_plan = None, None, None

    def tnt_set(self, phase, now):
        self.tnt_phase, self.tnt_since = phase, now

    def tnt_solution(self, me, pw, flattest=None, check_arc=False):
        """The throw with power `pw` that lands the stick where the target will be when it goes off (we let go
        flight + TNT_LAND_MARGIN before the fuse ends). Flattest throw unless this throw switched to a lob
        (tnt_lob), or as `flattest` says. With `check_arc`, a throw whose arc runs into the level (a wall, a roof)
        counts as none. Returns (solution or None, goal point)."""
        flattest = not self.tnt_lob if flattest is None else flattest
        vel = (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0)
        flight, sol, goal = 0.9, None, None
        for _ in range(3):
            goal = self.predict(self.tnt_target, flight + self.TNT_LAND_MARGIN, self.tnt_now)
            sol = tnt.solve(me, vel, goal, pw, self.gravity, self.ceiling_over(me, goal), flattest=flattest)
            if sol is None:
                break
            flight = sol["flight"]
        if sol is not None and check_arc and not self.arc_clear(me, vel, sol, pw):
            sol = None
        return sol, goal

    def arc_clear(self, me, vel, sol, pw):
        """Whether a throw's arc stays in open space (a stick that hits a wall or a roof on the way can come back
        at us). Walls have no thickness in this engine, so a point beyond one is simply in the next sector: the
        arc is followed sector by sector, every ~3 units. Each step stays in its sector, under the ceiling, or
        passes into a neighbouring one through an opening it fits at that height (sector_step). Without a map we
        can't tell: clear."""
        lvl = self.level
        if lvl is None:
            return True
        start = (me["x"], me["y"] + tnt.LAUNCH_HEIGHT * me.get("height", 6.0), me["z"])
        here = lvl.locate(*start)
        if here is None:
            return True                                     # we're nowhere on the map: can't tell
        length = sol["flight"] * math.hypot(tnt.SPEED * pw, math.hypot(vel[0], vel[2]))
        prev = start
        for p in tnt.arc(me, vel, sol, pw, n=max(12, int(length / 3.0)), g=self.gravity):
            here = self.sector_step(here, prev, p)
            if here is None:
                return False
            prev = p
        return True

    def sector_neighbours(self, i):
        """Sectors a thrown stick can pass into from sector i: through a wall's adjoins, or the one stacked above
        or below (vadjoin)."""
        if self._neighbours is None or self._neighbours[0] is not self.level:
            secs = self.level.sectors
            near = [set() for _ in secs]
            for s in secs:
                for w in s.walls:
                    near[s.index].update(k for k in (w.adjoin, w.dadjoin) if 0 <= k < len(secs))
                if 0 <= s.vadjoin < len(secs):
                    near[s.index].add(s.vadjoin)
                    near[s.vadjoin].add(s.index)
            self._neighbours = (self.level, near)
        return self._neighbours[1][i]

    def sector_step(self, i, a, b, depth=0):
        """The sector point b is in, coming from point a in sector i, or None when the step is blocked: above the
        ceiling, into the floor, or into a sector that isn't a neighbour reached through an opening tall enough
        at that height. A step that skips a sector is halved (3 times at most)."""
        lvl = self.level
        x, y, z = b
        j = None
        for k in [i, *self.sector_neighbours(i)]:
            s = lvl.sectors[k]
            if s.walls and s.contains(x, z) and lvl.floor_at(k, x, z) - 0.5 <= y <= lvl.ceiling_at(k, x, z) + 0.5:
                j = k
                break
        if j is None:
            j = lvl.locate(x, y, z)
            if j is None:
                return None
        if y > lvl.ceiling_at(j, x, z) - 0.2 or y < lvl.floor_at(j, x, z) - 0.2:
            return None
        if j == i:
            return j
        if j in self.sector_neighbours(i):
            si, sj = lvl.sectors[i], lvl.sectors[j]
            if si.vadjoin == j or sj.vadjoin == i:
                return j                                    # up or down into a stacked sector
            mx, mz = (a[0] + x) / 2, (a[2] + z) / 2
            low = max(lvl.floor_at(i, mx, mz), lvl.floor_at(j, mx, mz))
            high = min(lvl.ceiling_at(i, mx, mz), lvl.ceiling_at(j, mx, mz))
            if low + 0.1 < (a[1] + y) / 2 < high - 0.2:
                return j
            return None
        if depth >= 3:
            return None
        mid = tuple((u + v) / 2 for u, v in zip(a, b))
        k = self.sector_step(i, a, mid, depth + 1)
        return None if k is None else self.sector_step(k, mid, b, depth + 1)

    def check_arcs(self, me, now, pw):
        """While holding a lit stick, every 0.3 s: does the flat throw's arc stay clear of the level, else does the
        lob's? Sets tnt_lob (aim the lob from now on) and tnt_arc_ok (some throw gets there). Decided ahead of the
        release because a lob flies longer, so it has to go sooner."""
        if now < self.tnt_arc_at:
            return
        self.tnt_arc_at = now + 0.3
        vel = (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0)
        flat, goal = self.tnt_solution(me, pw, flattest=True)
        safe = flat is not None and flat_dist(me, goal) >= self.tnt_min() - 3.0
        if safe:
            if self.arc_clear(me, vel, flat, pw):
                lob, ok = False, True
            else:
                ok = self.tnt_solution(me, pw, flattest=False, check_arc=True)[0] is not None
                lob = ok
            if (lob, ok) != (self.tnt_lob, self.tnt_arc_ok):
                self.log("TNT: the flat throw hits the level; lobbing it" if lob
                         else "TNT: every throw at them hits the level; waiting" if not ok else "TNT: flat throw clear")
            self.tnt_lob, self.tnt_arc_ok = lob, ok
            if ok:
                return
        if pw < 1.0:
            return                                          # power still building: the last moment is far off
        # No good throw: the one for the last moment (tnt_fallback) goes the nearest way off the target's that's
        # clear. Only searched then, as it costs a few arc checks.
        for turn in (0.0, 30.0, -30.0, 60.0, -60.0, 90.0, -90.0, 135.0, -135.0, 180.0):
            self.tnt_fb_turn = turn
            fb = self.tnt_fallback(me, pw)
            if fb is not None and self.arc_clear(me, vel, fb, pw):
                break
        else:
            self.tnt_fb_turn = 0.0

    def tnt_unseen_target(self, me, now, enemies):
        """Sapper: an enemy out of sight but within a standing throw, to lob a stick at (user: TNT may go by where
        everyone is; you'd hear them anyway). The nearest one whose throw arc is clear of the level (checked at most
        every 0.5 s per enemy). None if there's none, or we can't throw now."""
        if not self.tnt_ready(me.get("inventory")) or now < self.tnt_next:
            return None
        reach = tnt.reach(me, (0.0, 0.0, 0.0), 0.0, 1.0, me["y"], self.gravity)[0]
        near = [p for p in enemies if flat_dist(me, p) <= reach]
        if not near:
            return None
        best = min(near, key=lambda p: flat_dist(me, p))
        fresh = best["addr"] not in self.tnt_arc_cache or now - self.tnt_arc_cache[best["addr"]][0] >= 0.5
        if not self.tnt_arc_possible(me, now, best):
            return None
        if fresh:
            self.log(f"TNT: an enemy out of sight {flat_dist(me, best):.0f} away")
        return best

    def tnt_arc_possible(self, me, now, p):
        """Is there a full-power throw from where we stand at player p (flat or lob) whose arc is clear of the level?
        Targets beyond a standing throw count as possible (running adds reach; the hold re-checks). Cached for 0.5 s
        per player."""
        cached = self.tnt_arc_cache.get(p["addr"])
        if cached and now - cached[0] < 0.5:
            return cached[1]
        # At where they are now: this is about walls in the way, and where they're heading changes by the throw.
        saved, self.tnt_now = self.tnt_target, now
        self.tnt_target = dict(p, seen_at=now, vx=0.0, vz=0.0)
        still = dict(me, vx=0.0, vy=0.0, vz=0.0)
        standing = tnt.reach(still, (0.0, 0.0, 0.0), to_deg(bearing(me, p)), 1.0, p["y"], self.gravity)[0]
        if flat_dist(me, p) > standing:
            ok = True
        elif flat_dist(me, p) < self.tnt_min():
            sol = self.tnt_burst(still, 1.0)[0]             # close: the throw that goes off at them
            ok = sol is None or self.arc_clear(still, (0.0, 0.0, 0.0), sol, 1.0)
        else:
            ok = any(self.tnt_solution(still, 1.0, flattest=f, check_arc=True)[0] for f in (True, False))
        self.tnt_target = saved
        self.tnt_arc_cache = {a: c for a, c in self.tnt_arc_cache.items() if now - c[0] < 5.0}
        self.tnt_arc_cache[p["addr"]] = (now, ok)
        return ok

    def tnt_fallback(self, me, pw):
        """Somewhere to throw a stick that must go now, when the target can't be reached safely: in the target's
        direction, at least tnt_min + 8 from us (past them when they're close), at most as far as it carries."""
        t = self.tnt_target
        d = max(flat_dist(me, t), 0.1)
        vel = (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0)
        # Turned off the target's direction by tnt_fb_turn when check_arcs found that way blocked.
        heading = math.radians(to_deg(bearing(me, t)) + self.tnt_fb_turn)
        carry = tnt.reach(me, vel, math.degrees(heading), pw, t["y"], self.gravity, self.ceiling_over(me, t))[0]
        far = min(max(self.tnt_min() + 8.0, d), carry - 1.0)
        for share in (1.0, 0.85, 0.7, 0.5):             # (reach() leaves out our sideways drift: a bit shorter)
            goal = {"x": me["x"] + math.sin(heading) * far * share, "y": t["y"],
                    "z": me["z"] + math.cos(heading) * far * share}
            sol = tnt.solve(me, vel, goal, pw, self.gravity, self.ceiling_over(me, goal))
            if sol is not None:
                return sol
        return None

    def tnt_look(self, me, sol):
        """Turn toward a throw solution (or, without one, the target at the farthest-carrying pitch). Returns the
        (heading, pitch) error in degrees."""
        if sol is not None:
            want_yaw, want_pitch = to_units(sol["yaw"]), to_units(sol["view_pitch"])
        else:
            want_yaw, want_pitch = bearing(me, self.tnt_target), to_units(45.0 - tnt.THROW_PITCH)
        self.look_toward(me, want_yaw, want_pitch)
        return to_deg(wrap(round(want_yaw - me["yaw"]))), to_deg(want_pitch - me["pitch"])

    def tnt_fight(self, me, now, target):
        """Run the TNT throw (see the section comment). `target` is the enemy in sight, or None (the throw goes on
        at where they were heading)."""
        s = self.skill
        inv = me.get("inventory") or {}
        self.tnt_now = now
        # Follow the target where it really is, in sight or not (user: fine for TNT).
        addr = (target or self.tnt_target or {}).get("addr")
        live = target or next((p for p in self.bot.all_players if addr and p["addr"] == addr and not p["dead"]), None)
        if live is not None:
            tr = self.tracks.get(live["addr"])
            self.tnt_target = dict(live, seen_at=now, vx=tr[3] if tr else 0.0, vz=tr[4] if tr else 0.0)
        if self.tnt_target is None:
            self.tnt_target = dict(me, addr=None)          # nothing to aim at (shouldn't happen): straight ahead
        weapon = next((w for w in inv.get("weapons", []) if w["slot"] == TNT_SLOT), None)
        action, lit = inv.get("action"), self.bot.lit
        if self.tnt_actions[-1:] != [action]:
            self.tnt_actions.append(action)
        self.stop_reload()
        dist = flat_dist(me, self.tnt_target)

        if self.tnt_phase is None:
            self.tnt_actions = [action]
            if lit:                                         # a stick already lit (we re-attached mid-throw)
                self.log("TNT: a stick is already lit; throwing it")
                self.tnt_lit_at = now - 2.0                 # its age is unknown: assume it's old
                self.tnt_lit_seen, self.tnt_pressed_at, self.tnt_times = True, now, {}
                self.tnt_idle_since, self.tnt_repress = None, False
                self.tnt_close, self.tnt_commit = dist < self.tnt_min(), False
                self.release_fire()
                self.press_fire(PRIMARY_FIRE, weapon or {"loaded": 0}, now)
                self.tnt_set("wind", now)
                return
            self.tnt_look(me, self.tnt_solution(me, 1.0)[0])
            far = dist > s.tnt_max
            if far:
                # Out of range even with a run-up: walk toward them with the TNT out, and light it once in range.
                self.go(me, now, self.tnt_target, aiming=True, keep=s.tnt_max - 10.0)
            else:
                self.tnt_move(me, now, None)
            if inv.get("slot") != TNT_SLOT:
                if now >= self.next_switch:
                    self.release_fire()
                    self.log(f"TNT: switching to TNT for an enemy {dist:.0f} away ({itemlib.tnt_count(inv)} sticks)")
                    self.tap(str(TNT_SLOT))
                    self.next_switch = now + 1.5
                return
            if far or action not in (None, -1) or weapon is None or now - self.slot_since < self.TNT_SWITCH_WAIT:
                return                                      # too far, or still bringing it up
            if not self.tnt_arc_possible(me, now, self.tnt_target):
                # Every throw at them from here runs into the level: get closer rather than waste a stick.
                if self.tnt_blocked != self.tnt_target.get("addr"):
                    self.tnt_blocked = self.tnt_target.get("addr")
                    self.log(f"TNT: no clear throw at them from here ({dist:.0f} away); moving in")
                self.go(me, now, self.tnt_target, aiming=True, keep=10.0)
                return
            self.tnt_blocked = None
            self.release_fire()
            self.press_fire(SECONDARY_FIRE, weapon, now)
            self.tnt_jumped, self.tnt_retries, self.tnt_plan = False, 0, None
            self.tnt_lob, self.tnt_arc_ok, self.tnt_arc_at, self.tnt_fb_turn = False, True, 0.0, 0.0
            self.tnt_pressed_at, self.tnt_times, self.tnt_lit_seen = now, {}, False
            self.tnt_idle_since, self.tnt_repress, self.tnt_light_seen = None, False, None
            self.tnt_close, self.tnt_commit, self.tnt_last_close = dist < self.tnt_min(), False, None
            self.tnt_set("light", now)
            self.log(f"TNT: lighting a stick for an enemy {dist:.0f} away")
            return

        if lit and not self.tnt_lit_seen and self.tnt_phase in ("light", "wind"):
            # The fuse runs from the moment it lit (until now we may have been timing it from the lighting's start).
            self.tnt_lit_seen = True
            self.tnt_lit_at = now - self.TICK / 2
            self.tnt_times["lit"] = now - self.tnt_pressed_at
        fuse_left = self.tnt_lit_at + tnt.FUSE - now
        if self.tnt_phase == "light":
            self.tnt_look(me, self.tnt_solution(me, 1.0)[0])
            self.tnt_move(me, now, None)
            if action == 0 and self.tnt_light_seen is None:
                self.tnt_light_seen = now
            if lit or (not self.lit_works and self.tnt_light_seen is not None
                       and now - self.tnt_light_seen >= self.TNT_LIT_GRACE):
                # Lit: wind up straight away, the throw gets its power while the fuse burns (user). Primary pressed
                # now is queued behind the lighting animation (tnt.py); letting go of secondary doesn't stop the
                # lighting. Only if the agent has never shown us a lit stick, and none shows up a while into the
                # lighting action (0), do we go by that action instead, timing the fuse from its start (it can only
                # be later, so we err toward throwing early). Action 0 alone isn't enough: during a weapon switch it
                # can be the old weapon's, and then the stick would go out unlit.
                if not self.tnt_lit_seen:
                    self.tnt_lit_at = self.tnt_light_seen - self.TICK / 2
                self.tnt_times["wind-up pressed"] = now - self.tnt_pressed_at
                self.release_fire()
                self.press_fire(PRIMARY_FIRE, weapon or {"loaded": 0}, now)
                self.tnt_set("wind", now)
            elif now - self.tnt_since > self.TNT_LIGHT_WAIT:
                self.release_fire()
                self.log(f"TNT: no stick lit after {self.TNT_LIGHT_WAIT:.1f}s (weapon actions {self.tnt_actions}); "
                         "giving up for now")
                self.tnt_next = now + 5.0
                self.tnt_reset()
            return

        if self.tnt_phase == "wind":
            self.tnt_look(me, self.tnt_solution(me, 1.0)[0])
            self.tnt_move(me, now, None)
            if self.tnt_repress:
                self.tnt_repress = False
                self.press_fire(PRIMARY_FIRE, weapon or {"loaded": 0}, now)
            elif action == TNT_WOUND_ACTION:
                self.tnt_wound_at = now - self.TICK / 2
                self.tnt_times["wound"] = now - self.tnt_pressed_at
                self.tnt_set("hold", now)
                return
            elif action in (-1, None) and (self.tnt_lit_seen or now - self.tnt_since > self.TNT_REPRESS):
                # Lit, primary held, yet the weapon sits idle: the queued press got lost. Let go and press again
                # next tick, rather than hold a lit stick that isn't wound up.
                if self.tnt_idle_since is None:
                    self.tnt_idle_since = now
                elif now - self.tnt_idle_since >= self.TNT_REPRESS and action == -1:
                    self.log(f"TNT: lit but not winding up (weapon actions {self.tnt_actions}); pressing again")
                    self.release_fire()
                    self.tnt_repress, self.tnt_idle_since = True, None
            else:
                self.tnt_idle_since = None
            if self.tnt_lit_seen is False and now - self.tnt_since > self.TNT_LIT_UNSEEN:
                self.tnt_lit_seen = None                    # (logged once)
                self.log("TNT: lighting done but the lit stick never showed up; timing the fuse from the lighting")
            if now - self.tnt_lit_at > self.TNT_WIND_WAIT:
                self.log(f"TNT: no wind-up state ({TNT_WOUND_ACTION}) after "
                         f"{self.TNT_WIND_WAIT:.1f}s (weapon actions {self.tnt_actions}); holding anyway")
                self.press_fire(PRIMARY_FIRE, weapon or {"loaded": 0}, now)
                self.tnt_wound_at = now
                self.tnt_set("hold", now)
            elif fuse_left <= self.TNT_LAST_CALL:
                self.tnt_release(me, now, "the fuse is nearly out (still winding up)", None, None, 0.5)
            return

        if self.tnt_phase == "hold":
            pw = tnt.power(now - self.tnt_wound_at)
            t = self.tnt_target
            near = flat_dist(me, t) < self.tnt_min() + (4.0 if self.tnt_close else 0.0)
            if near != self.tnt_close and not self.tnt_commit:
                self.tnt_close = near
                self.log(f"TNT: target {dist:.0f} away: " + ("close, it goes off right at them" if near
                                                               else "back to landing it at them"))
            if self.tnt_close:
                self.tnt_close_hold(me, now, pw, fuse_left)
                return
            self.check_arcs(me, now, pw)
            sol, goal = self.tnt_solution(me, pw)
            safe = sol is not None and flat_dist(me, goal) >= self.tnt_min() - 3.0
            aim_sol = sol if safe and self.tnt_arc_ok else self.tnt_fallback(me, pw)
            yaw_err, pitch_err = self.tnt_look(me, aim_sol)
            lined = aim_sol is not None and abs(yaw_err) < 2.5 and abs(pitch_err) < 2.5
            self.tnt_move(me, now, goal, fuse_left)
            cooked = safe and fuse_left <= sol["flight"] + self.TNT_LAND_MARGIN + self.TICK
            # Coming at us: soon there's no safe throw left, so let go now, cooked or not. Unless they'll still be
            # far enough off when it goes for the close throw (tnt_close_hold) to get them.
            toward = ((me["x"] - t["x"]) * t.get("vx", 0.0) + (me["z"] - t["z"]) * t.get("vz", 0.0)) / max(dist, 0.1)
            closing = (safe and toward > 3.0 and flat_dist(me, goal) < self.tnt_min() + 10.0
                       and self.burst_risk(me, self.predict(t, fuse_left, now), fuse_left) > s.tnt_self_max)
            # The last moment it can still get far enough from us before it goes off.
            last_call = max(self.TNT_LAST_CALL, aim_sol["flight"] + self.TICK if aim_sol else 1.0)
            if lined and (cooked or closing) and self.tnt_arc_ok:
                self.tnt_release(me, now, None if cooked else "they're closing in", sol, goal, pw)
            elif fuse_left <= last_call:
                why = ("the way there is blocked" if safe and lined else "not lined up" if safe
                       else "the target is too close" if sol is not None or dist < self.tnt_min() + 5
                       else "the target is out of reach")
                self.tnt_release(me, now, f"the fuse is nearly out, {why}", aim_sol, goal, pw)
            return

        # thrown: the stick should have left our hand. If it hasn't (the let-go came before the wind-up ended,
        # say), press and let go again. Keep backing off from where it goes off if that's near.
        self.tnt_look(me, self.tnt_plan[1] if self.tnt_plan else None)
        goal = self.tnt_plan[2] if self.tnt_plan else None
        if not (goal and flat_dist(me, goal) < s.dodge_radius and self.back_away(me, now, goal)):
            self.set_keys(set())
        if not lit or lit.get("addr") != (self.tnt_watch or {}).get("addr"):
            self.tnt_next = now + 0.5
            self.tnt_reset()
        elif now - self.tnt_since > 0.3:
            if self.tnt_retries < 4:
                self.tnt_retries += 1
                self.log(f"TNT: still in hand after letting go (weapon action {action}); pressing again")
                self.tap(PRIMARY_FIRE)
                self.tnt_since = now
            elif fuse_left < -0.5:
                self.tnt_reset()                            # it went off in our hand, or the agent lost it

    def tnt_close_hold(self, me, now, pw, fuse_left):
        """The hold with the target closer than tnt_min (user): aim low and let go at the last moment, so the stick
        goes off right at them (in the air, or as it lands), backing off if they're very close. At the last moment a
        throw away
        (tnt_fallback) could still get clear, we choose: at them if the blast would do us at most tnt_self_max
        and the way there is clear, else away. After that we're committed."""
        s = self.skill
        t = self.tnt_target
        fb = self.tnt_fallback(me, pw)
        # From a little before the moment to choose until we let go, hold still: backing off takes reach off the
        # throw. Unless they're right on us, or coming at us (standing still would let them close in).
        d = max(flat_dist(me, t), 0.1)
        toward = ((me["x"] - t["x"]) * t.get("vx", 0.0) + (me["z"] - t["z"]) * t.get("vz", 0.0)) / d
        if ((self.tnt_commit or fuse_left <= self.TNT_SETTLE + (fb["flight"] + self.TICK if fb else 1.0))
                and d >= self.TNT_SETTLE_NEAR and toward < 5.0):
            self.set_keys(set())
        else:
            self.tnt_move(me, now, None, fuse_left)
        sol, point = self.tnt_burst(me, pw)
        if sol is None:
            # At the edge of our reach a throw can't get to their body: land it at their feet instead.
            sol, point = self.tnt_solution(me, pw, flattest=True)
        if sol is not None:
            self.tnt_last_close = (sol, point)
        elif self.tnt_commit and self.tnt_last_close:
            sol, point = self.tnt_last_close                # lost it for a tick: keep to the last one
        yaw_err, pitch_err = self.tnt_look(me, sol)
        lined = sol is not None and abs(yaw_err) < 4.0 and abs(pitch_err) < 4.0
        risk = None
        if sol is not None:
            at = dict(self.predict(t, fuse_left, now), y=point["y"])      # where they'll be when it goes off
            risk = self.burst_risk(me, at, sol["flight"])                  # (we back off once it's thrown)
        if not self.tnt_commit or risk is None or risk > 2 * s.tnt_self_max:
            decide = max(self.TNT_LAST_CALL, fb["flight"] + self.TICK if fb else 1.0,
                         sol["flight"] + self.TICK if sol else 0.0)
            if self.tnt_commit and fuse_left <= self.TNT_LAST_CALL:
                pass                                        # too late to throw it anywhere else
            elif not self.tnt_commit and fuse_left > decide:
                return
            elif (sol is not None and risk <= s.tnt_self_max
                  and self.arc_clear(me, (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0), sol, pw)):
                if not self.tnt_commit:
                    self.tnt_commit = True
                    self.log(f"TNT: it goes off at them ({flat_dist(me, t):.0f} away, ~{risk:.1f} damage to us)")
            else:
                why = ("no throw gets to them" if sol is None else f"it would do us ~{risk:.1f}"
                       if risk > s.tnt_self_max else "the way there is blocked")
                goal = {"x": fb["x"], "y": t["y"], "z": fb["z"]} if fb else None
                self.tnt_release(me, now, f"too close, {why}; throwing it away", fb, goal, pw)
                return
        # Let go when the stick will get to them just as the fuse ends (a tick late is still a few units past them).
        if sol is not None and fuse_left <= sol["flight"] + self.TICK and (lined or fuse_left <= sol["flight"]):
            self.tnt_release(me, now, f"close, going off at them; ~{risk:.1f} damage to us", sol, point, pw)
        elif sol is None and fuse_left <= 2 * self.TICK:
            self.tnt_release(me, now, "close, the fuse is out", None, None, pw)

    def tnt_burst(self, me, pw):
        """Close throw: the flattest one that gets the stick to the target's body (half its height up, else 0.8),
        where it will be when it gets there, rising or falling, aimed no lower than TNT_MIN_VIEW. Returns
        (solution or None, that point)."""
        vel = (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0)
        t = self.tnt_target
        point = None
        for share in (0.5, 0.8):
            flight, sol = 0.3, None
            for _ in range(3):
                point = self.predict(t, flight, self.tnt_now)
                point["y"] += share * t.get("height", 6.0)
                sol = tnt.solve(me, vel, point, pw, self.gravity, self.ceiling_over(me, point), flattest=True,
                                descending=False, min_launch=self.TNT_MIN_VIEW + tnt.THROW_PITCH)
                if sol is None:
                    break
                flight = sol["flight"]
            if sol is not None:
                return sol, point
        return None, point

    def burst_risk(self, me, point, after):
        """Blast damage to us (before armour) from a stick going off at `point` `after` seconds from now, with us
        backing away from it until then (thrown phase) at half our top speed (we strafe, a wall may stop us), or
        faster if we're already moving away faster."""
        d = max(flat_dist(me, point), 0.1)
        ux, uz = (me["x"] - point["x"]) / d, (me["z"] - point["z"]) / d
        away = max(0.7 * ((me.get("vx") or 0.0) * ux + (me.get("vz") or 0.0) * uz), 0.5 * self.top_speed)
        gap = d + away * max(after, 0.0)
        rise = me["y"] + me.get("height", 6.0) / 2 - point["y"]
        return tnt.damage(math.hypot(gap, rise))

    def tnt_move(self, me, now, goal=None, fuse_left=None):
        """Feet during a throw. Too close: back off. Where the stick should land (`goal`, else the target) is out
        of reach standing still: run at it (our speed carries the stick on), and near the moment to let go jump
        as well. In reach: stand still, so the throw goes where it was aimed. Decided on the standing reach, not
        on the throw with our speed added, or stopping would put it back out of reach. "Too close" is
        TNT_BACK_OFF inside tnt_min: anyone within a standing throw gets one that goes off at them anyway."""
        t = self.tnt_target
        goal = goal or t
        if flat_dist(me, t) < self.tnt_min() - self.TNT_BACK_OFF:
            if not self.back_away(me, now, t):
                self.set_keys(set())
            return
        dist = flat_dist(me, goal)
        standing = tnt.reach(me, (0.0, 0.0, 0.0), to_deg(bearing(me, goal)), 1.0, goal["y"], self.gravity,
                             self.ceiling_over(me, goal))[0]
        if t.get("addr") is None or dist <= standing - 1.0:
            self.set_keys(set())
            self.stuck_check = None
            return
        keys = keys_toward(me["yaw"], bearing(me, goal))
        if (self.tnt_phase == "hold" and fuse_left is not None and not self.tnt_jumped
                and fuse_left < 1.4 + self.TNT_LAND_MARGIN + 0.3):
            keys.add("space")
            self.tnt_jumped = True
            self.log(f"TNT: jumping for reach ({dist:.0f} away, {standing:.0f} standing)")
        self.set_keys(keys)

    def tnt_release(self, me, now, why, sol, goal, pw):
        """Let go of primary fire: the stick flies."""
        self.release_fire()
        fuse_left = self.tnt_lit_at + tnt.FUSE - now
        lit = self.bot.lit or {}
        self.tnt_watch = {"addr": lit.get("addr"), "at": now, "lit_at": self.tnt_lit_at, "power": pw,
                          "target": self.tnt_target.get("addr"), "samples": [], "last": None, "logged": False,
                          "self_vel": (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0)}
        self.tnt_plan = (pw, sol, goal)
        target = (f"{flat_dist(me, goal):.0f} away" if goal else "nowhere in particular")
        if sol:
            target += f", flight {sol['flight']:.2f}s, launch {sol['launch']:.0f} deg"
        times = ", ".join(f"{k} +{v:.2f}s" for k, v in self.tnt_times.items())
        self.log(f"TNT: thrown{' (' + why + ')' if why else ''}: power {pw:.2f}, to {target}, fuse left "
                 f"{fuse_left:.2f}s, weapon actions {self.tnt_actions}"
                 + (f" (after the lighting press: {times})" if times else ""))
        self.tnt_set("thrown", now)

    def watch_stick(self, me, now):
        """Follow our thrown stick: log how it left our hand (speed against tnt.py's model) and the gravity its
        flight shows, which then replaces the default, and where it went off, against the target and us."""
        w = self.tnt_watch
        if w is None or w["addr"] is None:
            self.tnt_watch = None
            return
        st = next((e for e in self.bot.explosives if e["addr"] == w["addr"]), None)
        held = (self.bot.lit or {}).get("addr") == w["addr"]
        if st is None:
            if w["last"] is not None or now - w["at"] > 2.0:
                self.stick_done(me, now)
            return
        if held:
            return
        w["last"] = st
        samples = w["samples"]
        if not w.get("flying_done"):
            if samples and (st["vy"] > samples[-1][1] + 0.5
                            or math.hypot(st["vx"], st["vz"]) < 0.7 * math.hypot(samples[0][2], samples[0][3])):
                w["flying_done"] = True                     # it bounced
            else:
                samples.append((now, st["vy"], st["vx"], st["vz"]))
        if not w["logged"] and samples:
            w["logged"] = True
            _, vy, vx, vz = samples[0]
            sx, sy, sz = w["self_vel"]
            speed = math.dist((vx, vy, vz), (sx, sy, sz))
            self.log(f"TNT flight: left at {speed:.1f} (model: {max(tnt.MIN_SPEED, tnt.SPEED * w['power']):.1f}) "
                     f"on top of our {math.hypot(sx, sz):.1f}")
        if w.get("flying_done") and not w.get("gravity_done"):
            w["gravity_done"] = True
            if len(samples) >= 4 and samples[-1][0] - samples[0][0] >= 0.25:
                n = len(samples)
                mt = sum(t for t, *_ in samples) / n
                mv = sum(v for _, v, *_ in samples) / n
                var = sum((t - mt) ** 2 for t, *_ in samples)
                g = -sum((t - mt) * (v - mv) for t, v, *_ in samples) / var if var else 0.0
                if 15.0 < g < 250.0:
                    self.gravity = g if self.gravity == tnt.GRAVITY else 0.5 * (self.gravity + g)
                    tnt.save_gravity(self.gravity)
                    self.log(f"TNT flight: gravity {g:.1f} over {n} samples; using {self.gravity:.1f}")
                else:
                    self.log(f"TNT flight: gravity {g:.1f} looks wrong ({n} samples); keeping {self.gravity:.1f}")

    def stick_done(self, me, now):
        """Our stick is gone (went off): log where, against the target and us."""
        w, self.tnt_watch = self.tnt_watch, None
        last = w["last"]
        if last is None:
            self.log("TNT: lost track of the stick")
            return
        msg = f"TNT: went off {now - w['lit_at']:.1f}s after lighting, {flat_dist(me, last):.0f} from us"
        t = next((p for p in self.bot.all_players if p["addr"] == w["target"]), None)
        if t is not None:
            d = math.dist((last["x"], last["y"], last["z"]), (t["x"], t["y"] + t["height"] / 2, t["z"]))
            msg += f", {d:.0f} from the target (~{tnt.damage(d):.1f} damage before armour)"
        self.log(msg)

    # -- one tick -------------------------------------------------------------------------------------
    def tick(self, now):
        for key in list(self.tapped):           # every tap lasts exactly one tick
            self.bot.press(key, False)
            self.tapped.discard(key)

        try:
            me, others = self.bot.players()
        except RuntimeError:
            me, others = None, []
        own = self.bot.self_state or {}
        health = me["health"] if me else own.get("health")
        if self.join_lobby(now):           # in the lobby our player may exist, parked below the map
            return
        if self.bench:
            self.bench.note(now, self.bot.all_players, self.bot.game, self.bot.level_key)

        # Our own death: wait a moment, then press E until we're back. While dead there may be no live
        # player actor at all (ours turned into a corpse), so this goes by PlayerData health.
        if health is not None and health <= 0:
            if self.died_at is None:
                self.died_at = now
                self.log("died")
                if self.tnt_phase is not None:
                    self.log(f"TNT: died during the throw ({self.tnt_phase})")
                self.tnt_reset()
                self.set_keys(set())
                self.bot.api.set_look(0, 0)
                self.stop_reload()
                self.release_fire()
            if now - self.died_at > self.skill.respawn_delay and not self.sitting_out(now) \
                    and now >= self.next_respawn_press:
                self.tap("e")
                self.next_respawn_press = now + 1.0
            return
        if me is None:
            self.set_keys(set())                # not in a match, or between levels
            self.release_fire()
            return
        if self.died_at is not None:
            self.log("respawned")
            self.died_at, self.last_seen, self.target_addr, self.route = None, None, None, None
            self.visible_since = None
            self.bench_decided = False
            self.inv_names, self.had_badge = None, False     # a respawn resets the inventory: not news
            self.slot_seen = None                            # and brings the weapon up again
            self.wet, self.under_since, self.above_since, self.surfacing = False, None, None, False
            self.left_water_at, self.water_route = -1e9, None
            if self.bench and self.bench.out:   # alive without pressing E: a new level started
                self.bench.leave()
                self.log("back in: new level")
        self.my_team = me.get("team")
        if self.waiting_for_players(now, others):
            self.set_keys(set())
            self.release_fire()
            return

        self.ensure_level(me, others)
        self.note_team(me)
        self.note_water(me, now)
        living = [p for p in others if not p["dead"]]
        enemies = [p for p in living if not self.is_ally(me, p)]
        visible = [p for p in enemies if p.get("visible")]
        target = min(visible, key=lambda p: flat_dist(me, p)) if visible else None
        self.note_inventory(me.get("inventory"))
        self.use_medbag(health, me.get("inventory"), now, engaged=target is not None)
        objective = self.ctf_objective(me, living)
        self.track(living, now)
        if not self.wet:
            self.top_speed = max(self.top_speed, min(40.0, math.hypot(me.get("vx") or 0.0, me.get("vz") or 0.0)))
        slot = (me.get("inventory") or {}).get("slot")
        if slot != self.slot_seen:
            self.slot_seen, self.slot_since = slot, now
        if self.bot.lit:
            self.lit_works = True
        self.watch_stick(me, now)
        if self.tnt_phase is not None:
            # A throw under way goes on, target in sight or not: a lit stick has to leave our hand.
            self.tnt_fight(me, now, target)
            return
        if self.wet:
            if self.swim(me, now, target):
                return
            target = self.shore_target        # in the water we only fight hand to hand (swim())

        if target is None:
            if now - self.last_visible > self.skill.sight_memory:
                self.visible_since = None
            self.release_fire()
            self.manage_weapon(me, now, None, engaged=False)    # reload / pick weapons while hunting
            if self.dodge(me, now):
                return
            # Sapper: nobody in sight, but someone within a throw behind cover gets a stick lobbed at them.
            unseen = self.tnt_unseen_target(me, now, enemies) if not objective or not me.get("carries") else None
            if unseen is not None:
                self.tnt_fight(me, now, unseen)
                return
            if self.want_knife(me) and self.seek_item(me, now, knife_only=True):
                return
            if objective:
                # Fetch ammo or a weapon first only when we have nothing to fight with (and no flag).
                inv = me.get("inventory")
                if not me.get("carries") and inv and self.desperate(inv) and self.seek_item(me, now):
                    return
                # A boiler plate close by is worth the detour (user).
                if not me.get("carries") and self.seek_item(me, now, armor_only=True):
                    return
                self.go(me, now, objective, keep=self.objective_keep())
                return
            if self.seek_item(me, now):
                return
            if self.last_seen and flat_dist(me, self.last_seen) > 6:
                if self.go(me, now, self.last_seen):
                    return
            self.last_seen = None
            self.wander(me, now)
            return

        # Nothing good to fight with: go and get ammo or a weapon first, keeping an eye on the target.
        if not self.wet and me.get("inventory") and self.desperate(me["inventory"]):
            self.aim(me, target, flat_dist(me, target))
            if self.seek_item(me, now, aiming=True, knife_only=self.want_knife(me)):
                self.release_fire()
                return

        # A brawler without a knife goes for one lying about before anything else, and doesn't fight on the way
        # (user). With none on the map it fights with its fists.
        if self.skill.knife_first and not self.wet and self.want_knife(me) and self.seek_item(me, now, knife_only=True):
            self.release_fire()
            return

        dist = flat_dist(me, target)
        if target["addr"] != self.target_addr:
            self.target_addr = target["addr"]
            self.log(f"target -> {target['addr']} at {dist:.0f}")
        if self.visible_since is None:
            self.visible_since = now
        self.last_visible = now
        self.last_seen = {"x": target["x"], "y": target["y"], "z": target["z"]}

        if self.tnt_wanted(me, now):
            self.tnt_fight(me, now, target)
            return

        yaw_err, pitch_err = self.aim(me, target, dist)
        weapon, may_fire = self.manage_weapon(me, now, dist, engaged=True)
        fire_range = self.fire_range(weapon)

        # Lined up: the aim error fits in the target's silhouette plus a degree, the weapon's spread
        # (pellets and fanned shots fan out, so the crosshair needn't be dead on) and Skill.aggression.
        # A shotgun shot leaves 0.1 s after the press while we keep turning toward the target, so part of
        # that turn counts as aimed too. Weapons that fire while held (pistol fanning and the like) keep
        # the button down through aim wobble instead: every release cuts the burst short.
        s = self.skill
        half_w = math.degrees(math.atan2(1.5, max(dist, 1.0)))                       # radius 1.5
        half_h = math.degrees(math.atan2(target["height"] / 2, max(dist, 1.0)))
        slack, turn = 1.0 + s.aggression, 0.0
        if weapon:
            slack += weapon.get("spread" if self.fire_button(weapon) == PRIMARY_FIRE else "spread2") or 0
            if weapon["slot"] in PUMP_SLOTS:
                turn = s.lead_turn * s.turn_speed * 0.1
            else:
                slack += s.hold_slack
        lined_up = abs(yaw_err) - turn < half_w + slack and abs(pitch_err) - turn < half_h + slack
        facing = abs(yaw_err) < s.queue_cone and abs(pitch_err) < s.queue_cone
        ready = may_fire and now - self.visible_since > s.reaction and dist < fire_range
        self.trigger(weapon, ready and lined_up, now, me.get("inventory"), queue=ready and facing)

        if self.dodge(me, now, aiming=True):
            return

        # With the Gatling out we can't move: stand still and shoot.
        if me.get("inventory") and me["inventory"]["slot"] == GATLING_SLOT:
            self.set_keys(set())
            self.stuck_check = None
            return

        # Orleans without a knife: shoot back, but head for a knife rather than closing in.
        if self.want_knife(me) and self.seek_item(me, now, aiming=True, knife_only=True):
            return

        # A boiler plate close by: grab it, shooting on the way (user). Not with a flag to bring home.
        if not me.get("carries") and self.seek_item(me, now, aiming=True, armor_only=True):
            return

        # CTF: a flag carrier keeps heading for home, and nobody chases a far-off enemy away from the
        # objective; we shoot at them on the way.
        if objective and (me.get("carries") or dist > self.skill.ctf_chase):
            self.go(me, now, objective, aiming=True, keep=self.objective_keep())
            return

        # With the favourite weapon (or TNT) to hand, keep the behaviour's distance, backing off if they come close.
        fav = self.favorite_ready(me.get("inventory"))
        if fav and s.back_off and dist < s.back_off and self.back_away(me, now, target):
            return

        # Close in along a route (shotguns get closer), strafing while we aim.
        keep = min(s.keep_distance if fav else DEFAULT_KEEP,
                   fire_range * 0.6 if weapon is None or weapon["slot"] != TNT_SLOT else s.keep_distance)
        self.go(me, now, target, aiming=True, keep=keep, strafe=dist < keep * 2)

    # -- teams and CTF --------------------------------------------------------------------------------
    def is_ally(self, me, p):
        """A player we must not shoot: same team in a team mode. In the holder modes (everyone but the
        holder shares team 2) same-team players only count as allies while the game blocks the damage."""
        team = me.get("team") or 0
        if team == 0 or p.get("team") != team:
            return False
        game = self.bot.game or {}
        return game.get("mode") in TEAM_MODES or not game.get("teamDamage")

    def sitting_out(self, now):
        """While dead: whether to stay dead to keep the teams even (see bench.py). Decided once per death,
        then rechecked while sitting out."""
        if not self.bench:
            return False
        if not self.bench_decided:
            self.bench_decided = True
            return self.bench.at_death(now, self.my_team)
        return self.bench.still_out(now, self.my_team)

    def waiting_for_players(self, now, others):
        """Whether we're still holding off at the start for the others to join (see wait_for). Counts living
        players only: corpses would inflate it once the early joiners fight each other. Once the count is
        reached the grace countdown runs to the end: the early joiners keep killing each other, so the living
        count dips all the time and restarting the countdown on every dip held us back for minutes."""
        if not self.wait_for:
            return False
        joined = sum(1 for p in others if not p["dead"])
        if self.wait_started is None:
            self.wait_started = now
            self.log(f"waiting for {self.wait_for} player(s) to join (at most {self.wait_max:.0f}s)")
        if self.wait_full is None and joined >= self.wait_for:
            self.wait_full = now
            self.log(f"{joined} player(s) in; starting in {self.JOIN_GRACE:.0f}s")
        if self.wait_full is not None:
            if now - self.wait_full < self.JOIN_GRACE:
                return True
            self.log("go")
        else:
            if now - self.wait_started < self.wait_max:
                return True
            self.log(f"only {joined} of {self.wait_for} player(s) joined after {self.wait_max:.0f}s; starting anyway")
        self.wait_for = None
        return False

    def join_lobby(self, now):
        """In the lobby, waiting for our pick: press Join, or Join Red / Join Blue in a team game
        (bot.team_pref, default red). Returns whether we're in the lobby."""
        lobby = getattr(self.bot, "lobby", None)
        if not lobby or lobby["state"] != LOBBY_STATE or lobby["pick"] != 0:
            self.lobby_since = None
            return False
        if self.lobby_since is None:
            self.lobby_since = now
            self.set_keys(set())
            self.release_fire()
        if now - self.lobby_since >= self.skill.lobby_delay and now - self.lobby_pressed >= 3.0:
            team = getattr(self.bot, "team_pref", None) or "red"
            pick = (LOBBY_BLUE if team == "blue" else LOBBY_RED) if lobby["mode"] in TEAM_MODES else LOBBY_JOIN
            self.bot.api.lobby_join(pick)
            self.lobby_pressed = now
            self.log({LOBBY_JOIN: "lobby: join", LOBBY_RED: "lobby: join red", LOBBY_BLUE: "lobby: join blue"}[pick]
                     + f" (game mode {lobby['mode']})")
        return True

    def note_team(self, me):
        game = self.bot.game or {}
        seen = (me.get("team"), game.get("mode"))
        if seen != self.team_seen:
            self.team_seen = seen
            self.log(f"team {TEAM_NAMES.get(seen[0], seen[0])}, game mode {seen[1]}"
                     f"{' (capture the flag)' if seen[1] == CTF_MODE else ''}"
                     f"{', team damage on' if game.get('teamDamage') else ''}")

    def ctf_objective(self, me, living):
        """Where to go in capture the flag, or None outside CTF. In order: bring the enemy flag home if we
        carry it; return our own flag if it lies dropped somewhere; take the enemy flag if nobody on our
        side has it; otherwise go after whoever carries our flag (a capture needs our flag at our base),
        or escort our carrier."""
        game = self.bot.game or {}
        ctf, team = game.get("ctf"), me.get("team")
        if game.get("mode") != CTF_MODE or not ctf or team not in (RED, BLUE):
            return self.set_objective(None)
        own, enemy = (ctf["red"], ctf["blue"]) if team == RED else (ctf["blue"], ctf["red"])
        if not own.get("base") or not enemy.get("base"):
            return self.set_objective(None)
        own_bit, enemy_bit = (1, 2) if team == RED else (2, 1)          # carries: bit 0 red, bit 1 blue
        own_taker = next((p for p in living if p.get("carries", 0) & own_bit), None)
        enemy_taker = next((p for p in [me] + living if p.get("carries", 0) & enemy_bit), None)
        # A flag lying away from its base as a ground item (GRFLAG / GBFLAG) is a dropped one. Checked
        # alongside the game's flag pointer in case a dropped flag is a new actor the pointer doesn't follow.
        def flag_at(side, name):
            away = [it for it in self.bot.items
                    if it.get("name") == name and flat_dist(it, side["base"]) > FLAG_HOME]
            return away[0] if away else side.get("flag")
        own_name, enemy_name = ("GRFLAG", "GBFLAG") if team == RED else ("GBFLAG", "GRFLAG")
        own_flag, enemy_flag = flag_at(own, own_name), flag_at(enemy, enemy_name)
        if me.get("carries", 0) & enemy_bit:
            return self.set_objective("bring their flag home", own["base"])
        if own_taker is None and own_flag and flat_dist(own_flag, own["base"]) > FLAG_HOME:
            return self.set_objective("return our dropped flag", own_flag)
        if enemy_taker is None:
            return self.set_objective("take their flag", enemy_flag or enemy["base"])
        if own_taker is not None:
            return self.set_objective("chase our flag carrier", own_taker)
        return self.set_objective("escort our carrier", enemy_taker)

    def objective_keep(self):
        """How close to get to the objective: stay a few units off a teammate we escort."""
        return 6.0 if self.objective and self.objective[0] == "escort our carrier" else 1.0

    def set_objective(self, label, where=None):
        if label is None:
            self.objective = None
            return None
        if self.objective is None or self.objective[0] != label:
            self.log(f"CTF: {label}")
        goal = {"x": where["x"], "y": where["y"], "z": where["z"]}
        self.objective = (label, goal)
        return goal

    # -- main loop ------------------------------------------------------------------------------------
    def run(self, seconds=None):
        end = None if seconds is None else time.time() + seconds
        self.bot.api.set_look_step(200)         # the brain limits turn speed itself
        try:
            while end is None or time.time() < end:
                started = time.time()
                self.tick(started)
                time.sleep(max(0.0, self.TICK - (time.time() - started)))
        finally:
            if self.bench:
                self.bench.leave()           # stops counting as sitting out; the game copy stays dead
            self.set_keys(set())
            self.stop_reload()
            self.release_fire()
            for key in list(self.tapped):
                self.bot.press(key, False)
            self.tapped.clear()
            self.bot.api.set_look(0, 0)
            self.bot.api.set_look_step(15)
