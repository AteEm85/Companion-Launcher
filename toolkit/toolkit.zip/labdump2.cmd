@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" labdump.py olobj.lab olpatch1.lab olpatch2.lab olpatch3.lab olpatch4.lab olpatch5.lab Olpatch6.lab outlaws.lab olweap.lab oltex.lab --out labdump2.txt
pause
