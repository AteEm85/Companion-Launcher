"""Christmas trees in a map's object lists (the Christmas Horde): the text .OBT and the compiled .OBB with an xmastree
object added at each spot in christmas\\trees.json, and the bulbs along the tops of outside walls (christmas\\lights.json:
[name, sector, x, y, z] each) (worked out beforehand from each map's sectors: outdoors, on the
ground, near where people play, clear of walls and the map's own objects). Used by darkitems.patch(mode="christmas")."""
import re, struct

TREE = "xmastree"
TREE_FLAGS = (0, 4060086272)          # as the map's own cacti and shrubs (drygulch)


def add_text(text, trees, first_id=0x7E000001, flags=TREE_FLAGS, keep_case=False):
    """The OBT with the trees added (and its OBJECTS count raised)."""
    m = re.search(r"^OBJECTS (\d+)", text, re.M)
    if not m: return text
    lines = []
    for k, t in enumerate(trees):
        name, (sid, x, y, z) = ((t[0] if keep_case else t[0].lower()), t[1:]) if len(t) == 5 else (TREE, t)
        lines.append(" NAME: %s ID: %08X SECTOR: %08X X: %.2f Y: %.2f Z: %.2f PCH: 0.00 YAW: 360.00 ROL: 0.00 FLAGS: %d %d"
                     % (name, first_id + k, sid, x, y, z, flags[0], flags[1]))
    # after the last object line
    last = list(re.finditer(r"^ NAME: .*$", text, re.M))
    at = last[-1].end() if last else m.end()
    nl = "\r\n" if "\r\n" in text else "\n"
    text = text[:at] + nl + nl.join(lines) + text[at:]
    return text[:m.start()] + "OBJECTS %d" % (int(m.group(1)) + len(trees)) + text[m.end():]


def add_binary(data, trees, first_id=0x7E000001, flags=TREE_FLAGS, keep_case=False):
    """The OBB with the trees added: records '03 00 00 00 0b NAME 00' + ten 32-bit values, the count before the first."""
    rec = b"\x03\x00\x00\x00\x0b"
    first = data.find(rec)
    if first < 4: return None
    count = struct.unpack_from("<I", data, first - 4)[0]
    if count != len(re.findall(rb"\x03\x00\x00\x00\x0b[A-Za-z0-9_]+\x00", data)): return None    # not the layout we know
    out = bytearray(data)
    struct.pack_into("<I", out, first - 4, count + len(trees))
    for k, t in enumerate(trees):
        name, (sid, x, y, z) = ((t[0] if keep_case else t[0].lower()), t[1:]) if len(t) == 5 else (TREE, t)
        out += rec + name.encode() + b"\x00"
        out += struct.pack("<II", first_id + k, sid) + struct.pack("<ffffff", x, y, z, 0.0, 360.0, 0.0) + struct.pack("<II", *flags)
    return bytes(out)
