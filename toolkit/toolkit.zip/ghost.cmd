@echo off
rem Headless-player experiment (changes nothing in the game files).
rem 1. Start a LAN game from the launcher with NO bots (just you hosting, in the lobby or in the match).
rem 2. Run this file. A second player named GhostBot_01 should appear and walk around for ~28 seconds.
rem    Tell Claude what you saw (did it join? did it show up? did the host crash?).  Add the host's player name if it is not T4H_WaRRioR:  ghost.cmd 127.0.0.1 5069 YourName
cd /d "%~dp0"
".venv\Scripts\python.exe" -u ghost.py %*
pause
