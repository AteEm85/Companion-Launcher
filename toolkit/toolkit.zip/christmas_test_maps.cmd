@echo off
rem Christmas Horde test for the standard maps (not The Fort or Wilderness, those are done): pick a map, you join the LAN game yourself on the Survivors.
rem Each time, every game window is closed first and anything left over from an earlier test is taken out.
rem When a game is over (or you close it) press a key and you come back to this menu for the next map.
rem Add --ramp 10 to the horde.py line to fake a kill every 10 s and see Santa arrive sooner.
cd /d "%~dp0"
:menu
echo.
echo  Christmas Horde: pick a map to test
echo    1  Buckshotville
echo    2  Dry Gulch
echo    3  The Granary
echo    4  Hargrove's Pattern Repair
echo    5  Bunkers
echo    6  Simms At Night
echo    7  Orleans
echo    8  Thud Tower
echo    9  Sanctuary
echo    0  Quit
echo.
set "MAP="
set /p PICK=Map number: 
if "%PICK%"=="0" goto :eof
if "%PICK%"=="1" set "MAP=civpow2"
if "%PICK%"=="2" set "MAP=drygulch"
if "%PICK%"=="3" set "MAP=granary"
if "%PICK%"=="4" set "MAP=hargrove"
if "%PICK%"=="5" set "MAP=lilbatl"
if "%PICK%"=="6" set "MAP=mltsimms"
if "%PICK%"=="7" set "MAP=orleans"
if "%PICK%"=="8" set "MAP=thudtowr"
if "%PICK%"=="9" set "MAP=town_2p"
if not defined MAP (
    echo Not a map on the list.
    goto :menu
)
echo Closing any open game windows...
taskkill /IM OutlawsAHOM.exe /F >nul 2>&1
timeout /t 3 /nobreak >nul
.venv\Scripts\python.exe companionhost.py --cleanup
.venv\Scripts\python.exe -u horde.py --map %MAP% --christmas --users 1
echo.
echo Test over. Clearing up...
.venv\Scripts\python.exe companionhost.py --cleanup
pause
goto :menu
