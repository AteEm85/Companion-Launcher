@echo off
rem In-game next map test: two bots play two 1-minute matches; the host bot hosts the second map in the same game copy
rem and the other bot joins it. Writes state\rottest.txt.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u rotation.py rottest.txt --once -- sanchez mary --fight > state\rottest.txt 2>&1
