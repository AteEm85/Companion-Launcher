@echo off
rem Bills Homestead Remastered (already installed in the game folder), 5 minutes, 3 bots.
cd /d "%~dp0"
echo [{"key":"billhmre","name":"Bills Homestead Remastered","modes":"CKMD"}]> maps_extra.json
".venv\Scripts\python.exe" -u pathcheck.py --keep --minutes 5 --no-global-kill --maps billhmre
echo [{"key": "warranch", "name": "Warrior's Ranch By: Warrior", "modes": "KMD"}]> maps_extra.json
exit
