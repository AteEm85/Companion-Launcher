@echo off
rem Overnight run: tests every flagged map not done yet, one at a time, no limit.
rem When it finishes normally, this window closes and the PC shuts down after 2 minutes (shutdown /a cancels it).
cd /d "%~dp0"
".venv\Scripts\python.exe" -u mapbatch.py --only flagged_maps.txt --lanes 1 %*
if errorlevel 1 (
    echo The run stopped with an error, so the PC is NOT shutting down.
    pause
    exit /b 1
)
taskkill /IM OutlawsAHOM.exe /F >nul 2>&1
shutdown /s /t 120 /c "Map tests finished. Shutting down in 2 minutes (shutdown /a cancels)."
exit
