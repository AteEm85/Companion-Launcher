"""Juggernaut and Infection: two free-for-all games where a few players hold a special role.

  Juggernaut (BOT_ROLE=jug): a free for all. The first Juggernaut is whoever picks up the one silver Gatling gun on the map (BOT_JUG_GATLING; without it, the first kill) (150 armour,
      every weapon, 7 TNT, 6 knives, 2 med bags); whoever kills the Juggernaut becomes the next one. Everybody can see
      who it is: each game copy tints the Juggernaut's actor red (team 1, as the chicken's holder is in KFC mode),
      and the bots make him their first target.
  Infection  (BOT_ROLE=inf): one bot starts infected (knife and fists only, faster). Anyone an infected player kills
      is infected too. When everybody is infected the game ends; if the time runs out first the survivors win.

  Hot Potato (BOT_ROLE=pot): TNT only. One player holds the potato, with a fuse (POTATO_FUSE s). Any kill between the
      holder and somebody else passes the potato to the other one and resets the fuse. When the fuse runs out the
      holder blows up (his own game copy takes his health to 0) and the potato goes to somebody else.

Nobody can see another player's name in the game, only in the kill feed, so ONE referee (the hosting bot, which
already reads the feed for the stats) keeps the roles in state/roles.json. Every other bot, and the player's own
game (rolesplayer.py), reads that file and dresses itself accordingly.
"""
import json
import os
import re
import time

MODE = os.environ.get("BOT_ROLE", "")                  # "jug" | "inf" | ""
LAUNCH = os.environ.get("BOT_ROLE_LAUNCH", "")         # one token per launcher start: a leftover file is ignored
HUMAN = (os.environ.get("BOT_STATS_PLAYER") or "").strip()
_STATE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "state")
FILE = os.path.join(_STATE, "roles.json")
BANNER_FILE = os.path.join(_STATE, "gg_banner.json")   # shown by ggbanner.py
_BORN = time.time()
INFECTED_SPEED = 1.3                                   # an infected player runs this much faster (the agent allows 1.0 - 2.0)
POTATO_FUSE = 25.0                                     # seconds a holder has before he blows up
POTATO_GRACE = 4.0                                     # extra seconds for the new holder after a blow-up (he is spawning)
ALPHA_DELAY = 25.0                                     # seconds after the referee's first look before the first infection
JUG_ARMOR = 150
GATLING = os.environ.get("BOT_JUG_GATLING") == "1"     # Juggernaut: the first one is whoever picks up the one silver Gatling gun
GATLING_WAIT = 240.0                                   # nobody found it by then: the first kill makes the Juggernaut after all
CLAIM_FILE = os.path.join(_STATE, "jug_claim.json")
NATIVE = os.environ.get("BOT_ROLE_NATIVE") == "1"      # Juggernaut played in the game's chicken mode: the game picks and tints the holder
CHICKEN_MODE = 3                                       # the game's mode number for "kill the fool with the chicken"
HOLDER_TEAM = 1                                        # the holder is team 1 (red); everybody else is team 2
JUG_TNT, JUG_KNIVES, JUG_BAGS = 7, 6, 2
GATLING_ROUNDS = 100                                   # the Gatling's rounds each time somebody becomes the Juggernaut
# Handed over ONCE when somebody becomes the Juggernaut: 150 armour and 2 med bags (a med bag is 3 uses).
JUG_ONCE = ["IBPLATE"] + ["IDOCBAG"] * JUG_BAGS
ONCE_COUNTS = {"IBPLATE": JUG_ARMOR, "IDOCBAG": JUG_BAGS * 3}
# Handed over again whenever they run low: every weapon, TNT, knives and ammo
JUG_GIVE = ["IPISTOL", "IRIFLE", "ISGUN", "IDBSGUN", "ISAWGUN", "IGATGUN"] + ["IDYNAM"] * JUG_TNT + ["IKNIFE"] * JUG_KNIVES \
    + ["IBULLIT"] * 10 + ["ICART"] * 10 + ["ISHELLS"] * 10 + ["ICLIP"] * 10
JUG_COUNTS = {"IDYNAM": JUG_TNT, "IKNIFE": JUG_KNIVES, "IBULLIT": 60, "ICART": 60, "ISHELLS": 40, "ICLIP": 60}   # no refills: this is all


def claim(name):
    """This player's own inventory holds the silver Gatling: first come, first served (O_EXCL), for the referee to read."""
    if not (MODE == "jug" and GATLING and name):
        return False
    try:
        os.makedirs(_STATE, exist_ok=True)
        fd = os.open(CLAIM_FILE, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
        with os.fdopen(fd, "w") as f:
            json.dump({"launch": LAUNCH, "name": name, "t": time.time()}, f)
        return True
    except OSError:
        return False


def claimed():
    """The name of whoever picked up the silver Gatling in this launch, or None."""
    try:
        d = json.load(open(CLAIM_FILE))
        return d.get("name") if d.get("launch", "") == LAUNCH else None
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def clear_claim():
    """Referee start: a claim left by an earlier launch goes."""
    try:
        d = json.load(open(CLAIM_FILE))
        if d.get("launch", "") != LAUNCH:
            os.remove(CLAIM_FILE)
    except (OSError, ValueError, TypeError, AttributeError):
        pass


def has_gatling(inv):
    return any(w.get("slot") == 9 for w in (inv or {}).get("weapons") or [])


def is_holder(game, actor):
    """This actor is the chicken's holder (the Juggernaut): chicken mode, red team."""
    return bool(game) and game.get("mode") == CHICKEN_MODE and (actor or {}).get("team") == HOLDER_TEAM


def gatling_empty(inv):
    """The Juggernaut's Gatling has nothing in the chamber: a reload is seconds of standing still, so it is topped up instead."""
    return any(w.get("slot") == 9 and (w.get("loaded") or 0) <= 0 and (w.get("capacity") or 0) > 0
               for w in (inv or {}).get("weapons") or [])


def jug_short(inv, first):
    """The Juggernaut needs the loadout: once, when somebody becomes the Juggernaut (it is handed over whole, with the
    Gatling's 100 rounds). Ammo is not topped up after that: it runs out. Only a missing weapon is handed over again."""
    if first:
        return True
    have = {w["slot"] for w in (inv or {}).get("weapons") or []}
    return len(have) < 6


def jug_give(api, first):
    """Hand the loadout over. `first` (a new Juggernaut): armour, med bags, every weapon, TNT, knives, a fixed amount of
    ammo and exactly GATLING_ROUNDS rounds for the Gatling. Otherwise only the weapons that went missing."""
    res = api.give((JUG_ONCE if first else []) + JUG_GIVE)
    if not first:
        return res
    counts = dict(JUG_COUNTS)
    counts.update(ONCE_COUNTS)
    for item, n in counts.items():
        try:
            api.set_count(item, n)
        except Exception:
            pass
    try:
        api.fill_gatling(GATLING_ROUNDS)
    except Exception:
        pass
    return res


def _atomic(path, data):
    try:
        os.makedirs(_STATE, exist_ok=True)
        tmp = "%s.tmp%d" % (path, os.getpid())
        with open(tmp, "w") as f:
            json.dump(data, f)
        os.replace(tmp, path)
    except OSError:
        pass


def read():
    """The roles of this launch, or None."""
    try:
        if os.path.getmtime(FILE) < _BORN - 3600:
            return None
        d = json.load(open(FILE))
        return d if d.get("launch", "") == LAUNCH and d.get("mode") == MODE else None
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def is_juggernaut(state, name):
    return bool(state) and bool(name) and state.get("jug") == name


def is_infected(state, name):
    return bool(state) and bool(name) and name in (state.get("infected") or [])


def banner(title, name, hold=4.0):
    """Put a line on the screen (ggbanner.py): a title and a name."""
    t0 = time.time()
    _atomic(BANNER_FILE, {"seq": int(t0 * 1000), "t0": t0, "title": title, "name": name, "begin": None, "hold": hold,
                          "begin_secs": 0.0, "nofocus": True})


def bot_names():
    names = set()
    try:
        for f in os.listdir(_STATE):
            if f.startswith("name_") and f.endswith(".txt"):
                try:                                        # only bots still running: a leftover name file from an
                    pf = os.path.join(_STATE, "pos_%s.txt" % f[5:-4])    # earlier game has no fresh position file
                    if time.time() - os.path.getmtime(pf) > 5.0:
                        continue
                    names.add(open(os.path.join(_STATE, f)).read().strip())
                except OSError:
                    pass
    except OSError:
        pass
    return {n for n in names if n}


def knife_skill(base):
    """The skill of an infected bot: the knife and fists, nothing else (the knife rung of the gun game)."""
    import dataclasses
    return dataclasses.replace(base, favorite=8, lean=None, prefer_close=[8, 1], prefer_far=[8, 1], prefer_long=[8, 1],
                               far_long=None, tnt=False, melee_only=True, knife_first=False, keep_distance=2.0,
                               back_off=0.0, knife_keep=60.0)


class Referee:
    """Run by the hosting bot only: reads kill-feed lines, keeps state/roles.json."""

    def __init__(self, log=print):
        self.log = log
        self.s = {"launch": LAUNCH, "mode": MODE, "seq": 0, "jug": None, "infected": [], "alpha": None, "over": False,
                  "held": {}, "winner": None,
                  "holder": None, "fuse_at": 0.0, "boom": 0, "boom_name": None, "booms": {}}
        self.t0 = time.time()
        self.last_tick = self.t0
        self.me = ""
        clear_claim()

    def save(self):
        self.s["seq"] += 1
        _atomic(FILE, self.s)

    def participants(self):
        p = bot_names() | ({self.me} if self.me else set())
        if HUMAN:
            p.add(HUMAN)
        return p

    def kill(self, killer, victim):
        """killer killed victim (names as the feed shows them)."""
        if self.s["over"] or killer == victim:
            return
        if MODE == "jug" and not NATIVE:
            if self.s["jug"] is None and GATLING and time.time() - self.t0 < GATLING_WAIT:   # the silver Gatling decides the first one, not a kill
                return
            if self.s["jug"] is None or victim == self.s["jug"]:
                self.s["jug"] = killer
                self.log(f"ROLES: {killer} is the Juggernaut (killed {victim})")
                banner("THE JUGGERNAUT", killer)
                self.save()
        elif MODE == "pot":
            h = self.s["holder"]
            if h and h in (killer, victim):                      # any kill with the holder in it hands the potato over
                self.pass_to(victim if killer == h else killer, f"{killer} killed {victim}")
        elif MODE == "inf":
            inf = self.s["infected"]
            if killer in inf and victim not in inf:
                inf.append(victim)
                self.log(f"ROLES: {victim} is infected by {killer} ({len(inf)} of {len(self.participants())})")
                banner("INFECTED", victim)
                self.save()

    def native(self, players, me_name):
        """Chicken mode does the work: whoever is team 1 (red, tinted by the game) is the Juggernaut. Keep roles.json in step."""
        if self.s["over"]:
            return
        h = next((p for p in players if p.get("team") == HOLDER_TEAM), None)
        if h is None:
            return
        name = name_of_actor(h, players, me_name)
        if name and name != self.s["jug"]:
            self.s["jug"] = name
            self.log(f"ROLES: {name} is the Juggernaut (the game's chicken holder)")
            banner("THE JUGGERNAUT", name)
            self.save()

    def pass_to(self, name, why, grace=0.0):
        self.s["holder"] = name
        self.s["fuse_at"] = time.time() + POTATO_FUSE + grace
        self.log(f"ROLES: {name} has the hot potato ({why}); fuse {POTATO_FUSE:g}s")
        banner("HOT POTATO", name)
        self.save()

    def tick(self, now):
        """Once a second or so: hold-time counting, the first infection, the potato's fuse, the end."""
        dt, self.last_tick = min(2.0, now - self.last_tick), now
        if self.s["over"]:
            return
        if MODE == "jug" and GATLING and not NATIVE and self.s["jug"] is None:
            c = claimed()
            if c:
                self.s["jug"] = c
                self.log(f"ROLES: {c} picked up the silver Gatling and is the Juggernaut")
                banner("THE JUGGERNAUT", c)
                self.save()
        if MODE == "jug" and self.s["jug"]:
            h = self.s["held"]
            h[self.s["jug"]] = round(h.get(self.s["jug"], 0.0) + dt, 1)
            self.save()
        elif MODE == "pot":
            import random
            people = sorted(self.participants())
            h = self.s["holder"]
            if h is None:
                if len(people) >= 2 and now - self.t0 >= ALPHA_DELAY:
                    self.pass_to(random.choice(people), "first holder")
            elif now >= self.s["fuse_at"]:                         # the fuse is out: the holder blows up
                self.s["boom"] += 1
                self.s["boom_name"] = h
                self.s["booms"][h] = self.s["booms"].get(h, 0) + 1
                self.log(f"ROLES: BOOM, {h} blew up with the potato (booms {self.s['booms']})")
                banner("BOOM", h)
                rest = [n for n in people if n != h]
                self.pass_to(random.choice(rest) if rest else h, "after the blow-up", grace=POTATO_GRACE)
        elif MODE == "inf":
            if self.s["alpha"] is None and now - self.t0 >= ALPHA_DELAY:
                import random
                bots = sorted(bot_names() | ({self.me} if self.me else set()))
                if len(bots) >= 1:
                    a = random.choice(bots)
                    self.s["alpha"] = a
                    self.s["infected"] = [a]
                    self.log(f"ROLES: {a} starts the infection")
                    banner("PATIENT ZERO", a, 5.0)
                    self.save()
            elif self.s["alpha"] is not None:
                p = self.participants()
                if p and p <= set(self.s["infected"]):
                    self.s["over"], self.s["winner"] = True, "the infected"
                    self.log("ROLES: everyone is infected")
                    banner("EVERYONE IS INFECTED", "", 6.0)
                    self.save()



# -- Who is the Juggernaut on screen? Names live only in the kill feed, but every bot publishes its position next to its
# name (state/pos_<pid>.txt, name_<pid>.txt), so a name can be matched to the actor standing there. ------------------
def publish(pid, name, me):
    """Write this game copy's position and name for the others (about twice a second)."""
    try:
        os.makedirs(_STATE, exist_ok=True)
        with open(os.path.join(_STATE, "pos_%s.txt" % pid), "w") as f:
            f.write("%.1f %.1f %.1f %.2f" % (me["x"], me["z"], me["y"], time.time()))
        with open(os.path.join(_STATE, "name_%s.txt" % pid), "w") as f:
            f.write(name)
    except (OSError, KeyError, TypeError):
        pass


def positions():
    """{bot name: (x, z)} from the position files that are fresh (written within the last 3 s)."""
    out = {}
    try:
        for fn in os.listdir(_STATE):
            if not (fn.startswith("pos_") and fn.endswith(".txt")):
                continue
            pid = fn[4:-4]
            try:
                x, z, _y, t = open(os.path.join(_STATE, fn)).read().split()[:4]
                if time.time() - float(t) > 3.0:
                    continue
                name = open(os.path.join(_STATE, "name_%s.txt" % pid)).read().strip()
                out[name] = (float(x), float(z))
            except (OSError, ValueError):
                pass
    except OSError:
        pass
    return out


def name_of_actor(actor, players, me_name=None):
    """Whose actor this is: ours, a bot's (the one that published a position next to it), or else the human's."""
    if actor.get("local"):
        return me_name
    pos = positions()
    best, bd = None, 15.0 ** 2
    for name, (x, z) in pos.items():
        d = (actor["x"] - x) ** 2 + (actor["z"] - z) ** 2
        if d < bd and name != me_name:
            best, bd = name, d
    return best or (HUMAN or None)


def find_actor(name, players, me_name=None):
    """The address of the actor that is `name`, among `players` (actor dicts with addr, x, z, dead, local).
    Our own actor when it is us; a bot's by the position it published; the human's as the one actor no bot stands on."""
    live = [p for p in players if not p.get("dead")]
    if name == me_name:
        return next((p["addr"] for p in players if p.get("local")), None)
    others = [p for p in live if not p.get("local")]
    pos = positions()
    if name in pos:
        x, z = pos[name]
        best = min(others, key=lambda p: (p["x"] - x) ** 2 + (p["z"] - z) ** 2, default=None)
        if best is not None and (best["x"] - x) ** 2 + (best["z"] - z) ** 2 < 15.0 ** 2:
            return best["addr"]
        return None
    # not a bot: the human. The actors with no bot (and not us) close by; exactly one means that is him.
    bot_xy = [v for k, v in pos.items() if k != me_name]
    free = [p for p in others if all((p["x"] - x) ** 2 + (p["z"] - z) ** 2 > 12.0 ** 2 for x, z in bot_xy)]
    return free[0]["addr"] if len(free) == 1 else None


class Tint:
    """Keeps the Juggernaut's actor on team 1 (red) in this game copy and puts the one it had before back."""

    def __init__(self, api, log=print):
        self.api, self.log = api, log
        self.addr, self.was, self.at = None, 0, 0.0

    def update(self, addr, now, team_of=None):
        if addr != self.addr:
            self.clear()
        if addr is None or now - self.at < 0.5:
            return
        self.at = now
        try:
            r = self.api.set_actor_team(addr, 1)
            if isinstance(r, dict) and r.get("ok"):
                if addr != self.addr:
                    self.addr, self.was = addr, int(r.get("was", 0))
                    self.log(f"ROLES: tinting {addr} red (was team {self.was})")
            elif addr != self.addr:
                self.addr = addr
                self.log(f"ROLES: could not tint {addr}: {r}")
        except Exception as e:
            self.addr = addr
            self.log(f"ROLES: tint failed: {e}")

    def clear(self):
        if self.addr is not None:
            try:
                self.api.set_actor_team(self.addr, self.was)
            except Exception:
                pass
        self.addr = None


MARKER_FILE = os.path.join(_STATE, "jug_marker.json")      # drawn by ggbanner.py on the player's screen


MARKER_PORT = 47653                                   # UDP on this PC: the head marker's position, many times a second
_udp = [None]
_file_at = [0.0]


def write_marker(name, dist, rel, label="JUGGERNAUT", secs=None, me=False, head=None):
    """Tell the overlay who the Juggernaut is, how far and which way (rel: degrees, positive = to the right); None clears.
    The head position goes out by UDP every call (the overlay draws it at once); the text file only a few times a second."""
    try:
        import json, socket
        if _udp[0] is None:
            _udp[0] = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _udp[0].sendto(json.dumps({"head": head if name else None, "me": me, "label": label}).encode(), ("127.0.0.1", MARKER_PORT))
    except Exception:
        pass
    now = time.time()
    if now - _file_at[0] < 0.25:
        return
    _file_at[0] = now
    _atomic(MARKER_FILE, {"t": now, "name": name, "dist": dist, "rel": rel, "label": label, "secs": secs, "me": me, "head": None} if name else {"t": now, "name": None})