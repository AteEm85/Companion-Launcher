@echo off
rem Rebuilds BotLauncher.exe from the newest launcher.py, then starts it (the launcher's Update button runs this).
setlocal
cd /d "%~dp0"
taskkill /IM BotLauncher.exe /F >nul 2>&1
timeout /t 2 /nobreak >nul
rem A frozen BotLauncher.exe that started this passes on TCL_LIBRARY/TK_LIBRARY pointing into its temp folder, which is
rem gone once it closes. PyInstaller then decides Tcl/Tk is missing and leaves tkinter out of the exe, so drop them.
set "TCL_LIBRARY="
set "TK_LIBRARY="
set "B=%~dp0.build"
if not exist "%B%\Scripts\python.exe" (
    py -3 -m venv "%B%" 2>nul || python -m venv "%B%" || (echo Python 3 not found; install it from python.org & pause & exit /b 1)
)
"%B%\Scripts\python.exe" -c "import tkinter" || (echo This Python has no tkinter & pause & exit /b 1)
"%B%\Scripts\python.exe" -m pip install -q --disable-pip-version-check pyinstaller || (echo could not install pyinstaller & pause & exit /b 1)
"%B%\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --icon "%~dp0launcher.ico" --name BotLauncher --distpath "%~dp0." --workpath "%B%\work" --specpath "%B%" launcher.py || (pause & exit /b 1)
powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 '%~dp0launcher.py').Hash.ToLower()" > "%B%\built.sha"
powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 '%~dp0update_launcher.cmd').Hash.ToLower()" >> "%B%\built.sha"
echo.
echo Done: %~dp0BotLauncher.exe
start "" "%~dp0BotLauncher.exe"
timeout /t 2 /nobreak >nul
exit
