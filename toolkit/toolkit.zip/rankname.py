"""Puts the rank in front of YOUR name in your own game: attaches to the running game (the one you started yourself, not a
bot's copy) and rewrites the name the game asks its platform layer for, '[12]T4H_WaRRioR' instead of 'T4H_WaRRioR'.
Same hook the bots use for their own names (botctl.py, hookPlatformName), only attached late.

  python rankname.py --name T4H_WaRRioR --prefix "[12]"      (test: a fixed prefix)
  python rankname.py --name T4H_WaRRioR --char mary           (the prefix from that character's level and prestige)

Leave it running while you play; start it before or after the game. Log lines: 'rankname: ...'."""
import argparse, json, subprocess, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOG = HERE / "state" / "rankname_log.txt"
JS = r"""
const OWN = __OWN__;
const PREFIX = __PREFIX__;
const PLAT_GLOBAL_RVA = 0xf38b08;
let hooked = false, seen = 0, renamed = 0, platLogged = 0;
function note(m) { send({ kind: 'info', message: m }); }
function hook() {
  if (hooked) return true;
  const base = Process.mainModule.base;
  const obj = base.add(PLAT_GLOBAL_RVA).readPointer();
  if (obj.isNull()) return false;
  const fn = obj.readPointer().add(0x48).readPointer();
  if (fn.isNull()) return false;
  hooked = true;
  Interceptor.attach(fn, {
    onEnter(args) { this.out = args[1]; this.idx = args[2].toInt32(); },
    onLeave() {
      try {
        const out = this.out;
        const len = out.add(0x18).readU64().toNumber();
        const cap = out.add(0x20).readU64().toNumber();
        const dp = out.add(0x10).readPointer();
        if (len < 1 || len > 200 || dp.isNull()) return;
        const text = dp.readUtf8String(len);
        if (platLogged++ < 3) note('platform name for user ' + this.idx + ': ' + text + ' (capacity ' + cap + ')');
        if (text !== OWN) return;                       // only our own name (other players are asked for the same way)
        const room = (cap > 0 && cap < 4096) ? cap : 15;
        let want = PREFIX + text;
        if (want.length > room) want = PREFIX + text.substring(0, Math.max(1, room - PREFIX.length));
        dp.writeUtf8String(want);                       // also writes the closing NUL
        out.add(0x18).writeU64(want.length);
        if (renamed++ < 3) note('  -> ' + want + (renamed === 3 ? '  (the game asks every frame; not logged again)' : ''));
      } catch (err) { if (seen++ < 30) note('name hook error: ' + err); }
    }
  });
  note('hooked the platform name call');
  return true;
}

// PROBE: what does the game's player info hold (the key/value pairs it stores per player)? Looking for the character.
const INFO_RVA = 0x2aa2e0;
const INFO_PROLOGUE = '48895c24084c894c242055565741544155415641';
let infoHooked = false, infoSeen = 0;
const seenKV = new Set();
function hex(buf) { return Array.from(new Uint8Array(buf), b => ('0' + b.toString(16)).slice(-2)).join(''); }
function hookInfo() {
  if (infoHooked) return true;
  const addr = Process.mainModule.base.add(INFO_RVA);
  let cur = '';
  try { cur = hex(addr.readByteArray(20)); } catch (err) { return false; }
  if (cur !== INFO_PROLOGUE) { note('player info function not at the expected place (different game build?)'); infoHooked = true; return true; }
  infoHooked = true;
  Interceptor.attach(addr, { onEnter(args) {
    try {
      const key = args[2].add(0x10).readPointer().readCString();
      let shown = '?';
      try { const l = args[3].add(0x18).readU64().toNumber(); if (l >= 0 && l < 200) shown = args[3].add(0x10).readPointer().readUtf8String(l); } catch (err) {}
      const kv = key + ' = ' + shown;
      if (!seenKV.has(kv) && infoSeen < 80) { seenKV.add(kv); infoSeen++; note('player info: ' + kv); }
    } catch (err) {}
  } });
  note('probing the player info function');
  return true;
}
const infoTimer = setInterval(() => { try { if (hookInfo()) clearInterval(infoTimer); } catch (err) {} }, 10);

// PROBE 2: where does the live value of the cvar mp_defaultChar sit? Find the name in writable memory (cvar objects
// keep it inline) and report the bytes around it every few seconds, only when they change.
const PROBECHAR = __PROBECHAR__;
if (PROBECHAR) {
  const pat = '6d 70 5f 64 65 66 61 75 6c 74 43 68 61 72 00';      // "mp_defaultChar\0"
  let cands = null; const last = {}; let scanning = false;
  // scan in small async pieces so the game never stalls, and say how far it got
  function startScan() {
    scanning = true;
    const ranges = Process.enumerateRanges('rw-').filter(r => r.size > 0 && r.size < 0x10000000);
    const found = []; let i = 0;
    note('charprobe: scanning ' + ranges.length + ' memory ranges');
    function next() {
      if (i >= ranges.length) { cands = found; note('charprobe: scan done, ' + found.length + ' writable hits for mp_defaultChar'); return; }
      const r = ranges[i++];
      if (i % 200 === 0) note('charprobe: scan ' + i + '/' + ranges.length);
      try {
        Memory.scan(r.base, r.size, pat, {
          onMatch: (addr) => { found.push(addr); },
          onError: () => {},
          onComplete: () => { setTimeout(next, 1); }
        });
      } catch (e) { setTimeout(next, 1); }
    }
    next();
  }
  function tick() {
    try {
      if (cands === null) { if (!scanning) startScan(); return; }
      // follow the pointers stored right after each hit (the cvar's value is usually in an object they lead to)
      for (const a of cands) {
        for (let po = 0x20; po <= 0x48; po += 8) {
          let p = null;
          try { p = a.add(po).readPointer(); } catch (e) { continue; }
          const pv = p.toString();
          if (p.compare(ptr('0x10000')) < 0 || p.compare(ptr('0x7fffffffffff')) > 0) continue;
          let hs = '';
          try { hs = hex(p.readByteArray(0x80)); } catch (e) { continue; }
          const k2 = a.toString() + '+' + po.toString(16) + '->' + pv;
          if (last[k2] === undefined) { note('charprobe PTR ' + k2 + ' ' + hs); }
          else if (last[k2] !== hs) {
            let diff = [];
            for (let i = 0; i < hs.length; i += 2) if (hs.substr(i, 2) !== last[k2].substr(i, 2)) diff.push((i / 2) + ':' + last[k2].substr(i, 2) + '->' + hs.substr(i, 2));
            note('charprobe PTR CHANGED ' + k2 + ' ' + diff.join(' '));
          } else continue;
          last[k2] = hs;
        }
      }
      for (const a of cands) {
        let hexs = '';
        try { hexs = hex(a.sub(0x40).readByteArray(0x140)); } catch (e) { continue; }
        const k = a.toString();
        if (last[k] !== hexs) {
          if (last[k] !== undefined) {
            let diff = [];
            for (let i = 0; i < hexs.length; i += 2) if (hexs.substr(i, 2) !== last[k].substr(i, 2)) diff.push((i / 2 - 0x40) + ':' + last[k].substr(i, 2) + '->' + hexs.substr(i, 2));
            note('charprobe CHANGED @' + k + ' offsets(rel. to name): ' + diff.join(' '));
          } else note('charprobe @' + k + ' ' + hexs);
          last[k] = hexs;
        }
      }
    } catch (e) { note('charprobe error: ' + e); }
  }
  note('charprobe: armed');
  setTimeout(() => { tick(); setInterval(tick, 2000); }, 1000);
}

// PROBE 3: the game announces each player's model file (SANCHEZ.NWX, MARY.NWX, ...) in the packets it sends. Log every
// outgoing packet that names one, so we can see which one is the host's own character.
const WATCHNET = __WATCHNET__;
if (WATCHNET) {
  const seen = {}; let nlog = 0;
  function peek(buf, len, how) {
    try {
      if (len <= 0 || len > 1500) return;
      const bytes = new Uint8Array(buf.readByteArray(len));
      let txt = ''; for (const b of bytes) txt += (b >= 32 && b < 127) ? String.fromCharCode(b) : '.';
      const m = txt.toUpperCase().match(/[A-Z0-9_]+\.NWX/);
      if (!m) return;
      const key = hex(bytes.buffer);
      if (seen[key] || nlog >= 80) return;
      seen[key] = 1; nlog++;
      note('netwatch ' + how + ' model=' + m[0] + ' len=' + len + ' hex=' + key.substr(0, 120) + ' txt=' + txt.substr(0, 90));
    } catch (e) {}
  }
  for (const nm of ['sendto', 'send']) {
    try {
      const f = Process.getModuleByName('ws2_32.dll').getExportByName(nm);
      Interceptor.attach(f, { onEnter(a) { peek(a[1], a[2].toInt32(), nm); } });
    } catch (e) { note('netwatch: no ' + nm + ': ' + e); }
  }
  try {
    const f = Process.getModuleByName('ws2_32.dll').getExportByName('WSASendTo');
    Interceptor.attach(f, { onEnter(a) { try { const n = a[2].toInt32(); for (let i = 0; i < n; i++) { const e = a[1].add(i * 16); peek(e.add(8).readPointer(), e.readU32(), 'WSASendTo'); } } catch (e) {} } });
  } catch (e) { note('netwatch: no WSASendTo: ' + e); }
  note('netwatch: armed (pick your character and host)');
}
let tries = 0;
const t = setInterval(() => {
  tries++;
  let ok = false;
  try { ok = hook(); } catch (err) { if (tries % 200 === 0) note('waiting for the platform object: ' + err); }
  if (ok || tries > 6000) clearInterval(t);
}, 10);
"""

def own_game_pids():
    """pids of OutlawsAHOM.exe started without -userpath (the bots' copies all have it)."""
    cmd = ["powershell", "-NoProfile", "-Command",
           "Get-CimInstance Win32_Process -Filter \"Name='OutlawsAHOM.exe'\" | Select-Object ProcessId,CommandLine | ConvertTo-Json"]
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=20, creationflags=0x08000000).stdout.strip()
    except Exception:
        return []
    if not out:
        return []
    data = json.loads(out)
    if isinstance(data, dict):
        data = [data]
    return [d["ProcessId"] for d in data if "-userpath" not in (d.get("CommandLine") or "")]

CFG_CHARS = {1: "sanchez", 2: "james", 3: "twofeathers", 4: "drdeath", 5: "bob", 6: "mary"}

def config_char():
    """The character the game saved last (kexengine.cfg: seta mp_defaultChar "N"). The game writes it only when it exits,
    so this is the character of the last session; changing character in the menu shows up after the next restart."""
    import re
    p = Path.home() / "Saved Games" / "Nightdive Studios" / "Outlaws EX" / "kexengine.cfg"
    try:
        m = re.search(r'mp_defaultChar\s+"(\d+)"', p.read_text(errors="ignore"))
        return CFG_CHARS.get(int(m.group(1))) if m else None
    except (OSError, ValueError):
        return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True, help="your name as the game shows it now")
    ap.add_argument("--prefix", help="fixed text put in front of the name (test)")
    ap.add_argument("--probechar", action="store_true", help="log where the live mp_defaultChar value is in memory")
    ap.add_argument("--watchnet", action="store_true", help="log outgoing packets that name a model file (finds the host's own character)")
    ap.add_argument("--char", help="character key: the prefix comes from its level and prestige")
    a = ap.parse_args()
    import frida
    dev = frida.get_local_device()
    hooked = {}
    print("rankname: waiting for your game (start it normally); Ctrl+C to stop", flush=True)
    while True:
        for pid in own_game_pids():
            if pid in hooked:
                continue
            prefix = a.prefix
            if prefix is None:
                sys.path.insert(0, str(HERE))
                import xp
                ch = a.char or config_char()
                if not ch:
                    print("rankname: no --char and no saved character found; add --char mary (or sanchez, james, twofeathers, drdeath, bob)", flush=True)
                    hooked[pid] = None
                    continue
                print(f"rankname: character {ch}" + ("" if a.char else " (from the game's saved settings)"), flush=True)
                st = xp.status(a.name, xp.char_key(ch) or ch)
                prefix = f"[{st['level']}{xp.TIER_LETTER[st['prestige']]}]"
            try:
                session = dev.attach(pid)
                script = session.create_script(JS.replace("__OWN__", json.dumps(a.name)).replace("__PREFIX__", json.dumps(prefix)).replace("__PROBECHAR__", "true" if a.probechar else "false").replace("__WATCHNET__", "true" if a.watchnet else "false"))
                def on_msg(m, _d):
                    if m.get("type") == "send" and isinstance(m.get("payload"), dict):
                        line = "rankname: " + str(m["payload"].get("message"))
                    elif m.get("type") == "error":
                        line = "rankname error: " + str(m.get("description"))
                    else:
                        return
                    print(line, flush=True)
                    try:
                        LOG.parent.mkdir(exist_ok=True)
                        with LOG.open("a", encoding="utf-8") as f:
                            f.write(time.strftime("%H:%M:%S ") + line + "\n")
                    except OSError:
                        pass
                script.on("message", on_msg)
                script.load()
                hooked[pid] = (session, script)
                print(f"rankname: attached to your game (pid {pid}); prefix {prefix}", flush=True)
            except Exception as e:
                print(f"rankname: could not attach to pid {pid}: {e}", flush=True)
                hooked[pid] = None
        alive = set(own_game_pids())
        for pid in [p for p in hooked if p not in alive]:
            hooked.pop(pid, None)
        time.sleep(3)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
