"""Gun game with fists on the ladder: every character's fists hit as hard as Mary's (imfist.itm: DAMAGE_1 4.0, DAMAGE_2 2.3; the
others have 1.0 / 0.3, James 0.8 / 0.3). fists\\*.itm are the game's own fist items (olweap/olpatch2/olpatch4) with only those two numbers changed.
They are packed into one archive of our own (modlab.py, olremaster<N>.lab, which the game loads on top of its own files) like the
gold Gatling, and removed again by off().
  python fistdmg.py on | off"""
import os, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
GAME = HERE.parent
sys.path.insert(0, str(HERE))
SRC = HERE / "fists"
FMARK = b"OUTLAWS-GUNGAME-FISTS"       # our own trailer: zombieskins.py / silvergat.py / modlab.find_ours() leave the archive alone


def _mine():
    out = []
    try:
        for p in GAME.iterdir():
            n = p.name.lower()
            if n.startswith("olremaster") and n.endswith(".lab") and n[10:-4].isdigit():
                with open(p, "rb") as f:
                    f.seek(-len(FMARK), 2)
                    if f.read() == FMARK:
                        out.append(p)
    except OSError:
        pass
    return out


def on():
    import modlab
    off()
    files = sorted(SRC.glob("*.itm"))
    if not files:
        raise RuntimeError("fists\\*.itm are missing")
    path = modlab.build(str(GAME), [(p.name, str(p)) for p in files])
    with open(path, "rb") as f:
        data = f.read()
    if data.endswith(modlab.MARK):
        data = data[:-len(modlab.MARK)] + FMARK
    with open(path, "wb") as f:
        f.write(data)
    return True


def off():
    ok = True
    for p in _mine():
        try:
            p.unlink()
        except OSError:
            ok = False
    return ok


if __name__ == "__main__":
    c = sys.argv[1] if len(sys.argv) > 1 else "on"
    if c == "on": print(on())
    elif c == "off": print(off())
