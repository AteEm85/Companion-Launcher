"""Scan every map: modes from its .rcm, and whether the sector map builds and how connected it is.

    mapscan.cmd            every map; results in mapscan_report.txt and mapscan.csv
Each map is built in its own process with a time limit, so one huge or broken map can't stop the scan.
"""
import json
import re
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import lvt

GAME = lvt.GAME_DIR


def rcm_text(key):
    loose = GAME / f"{key}.rcm"
    if not loose.exists():
        for p in GAME.glob("*.rcm"):
            if p.stem.lower() == key.lower():
                loose = p
                break
    if loose.exists():
        return loose.read_bytes().decode("latin-1"), "custom"
    data = lvt.read_from_standard(f"{key}.rcm")
    return (data.decode("latin-1"), "standard") if data else (None, None)


def info(key):
    text, kind = rcm_text(key)
    if text is None:
        return None
    name = re.search(r"NAME:\s*(.+)", text)
    modes = re.search(r"MODES:\s*(\w+)", text)
    level = re.search(r"LEVEL:\s*(\S+)", text)
    return {"key": key, "kind": kind, "name": name.group(1).strip() if name else key,
            "modes": modes.group(1).upper() if modes else "", "level": level.group(1) if level else key}


def one(key):
    d = info(key)
    if d is None:
        print(json.dumps({"key": key, "error": "no rcm"}))
        return
    t = time.time()
    try:
        import nav
        sectors = lvt.load(d["level"])
        d["sectors"] = sum(1 for s in sectors if s.walls)
        lvl = nav.Level(sectors, lvt.load_inf(d["level"]), name=key)
        main = getattr(lvl, "main", None)
        d["main"] = len(main) if main is not None else -1
        d["edges"] = sum(len(v) for v in lvl.edges.values())
        d["traps"] = getattr(lvl, "trap_edges_removed", 0)
        d["water"] = len(lvl.water)
        d["panels"] = len(lvl.panels)
    except Exception as e:
        d["error"] = f"{type(e).__name__}: {e}"[:160]
    d["secs"] = round(time.time() - t, 1)
    print(json.dumps(d))


def all_keys():
    keys = {p.stem for p in GAME.glob("*.rcm")}
    for lab in lvt.LABS:
        p = GAME / lab
        if p.exists():
            keys |= {n[:-4] for n in lvt.lab_directory(p) if n.endswith(".rcm")}
    return sorted(keys, key=str.lower)


def main():
    if len(sys.argv) > 2 and sys.argv[1] == "--one":
        one(sys.argv[2])
        return
    rows = []
    keys = all_keys()
    print(f"{len(keys)} maps")
    for i, k in enumerate(keys, 1):
        try:
            r = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--one", k], capture_output=True,
                               text=True, timeout=240, cwd=str(HERE))
            line = (r.stdout.strip().splitlines() or [""])[-1]
            row = json.loads(line) if line.startswith("{") else {"key": k, "error": (r.stderr or "no output")[-150:]}
        except subprocess.TimeoutExpired:
            row = {"key": k, "error": "timeout (240 s)"}
        rows.append(row)
        print(f"[{i}/{len(keys)}] {k}: {row.get('modes', '?')} sectors={row.get('sectors')} main={row.get('main')} "
              f"{row.get('error', '')}", flush=True)
        (HERE / "mapscan.csv").write_text("\n".join(json.dumps(r) for r in rows))
    data = [{"key": r["key"], "name": r.get("name", r["key"]), "modes": r.get("modes", ""), "kind": r.get("kind", ""),
             "skip": bool(r.get("error"))} for r in rows if r.get("modes")]
    (HERE / "maps_data.json").write_text(json.dumps(data, indent=0))      # the launcher and botctl read this
    out = ["Map scan", "=" * 8, ""]
    for r in rows:
        out.append(f"{r['key']:14} {r.get('kind', '?'):8} {r.get('modes', ''):7} {r.get('name', '')[:28]:28} "
                   f"sectors={r.get('sectors', '-')} main={r.get('main', '-')} traps={r.get('traps', '-')} "
                   f"{r.get('secs', '-')}s {r.get('error', '')}")
    (HERE / "mapscan_report.txt").write_text("\n".join(out))
    print("done")


if __name__ == "__main__":
    main()
