@echo off
rem Tests the maps the offline audit flagged (flagged_maps.txt), one at a time, 50 per run; double-click again for the next 50.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u mapbatch.py --only flagged_maps.txt --lanes 1 --limit 50 %*
pause
