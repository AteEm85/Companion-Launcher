@echo off
rem Where does the game keep the character you picked? Start the game, run this, then in the character menu pick Sanchez, then Mary, then Bob (no need to host). Claude reads state\rankname_log.txt.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u rankname.py --name T4H_WaRRioR --prefix "[12]" --probechar
pause
