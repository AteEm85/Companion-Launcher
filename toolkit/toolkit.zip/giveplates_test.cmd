@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe giveplates.py 100
type giveplates_log.txt
pause
