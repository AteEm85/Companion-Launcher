"""Last Man Standing: free-for-all, one life each (--lives). A bot that dies stays dead; the last one alive wins
and the game ends. You (a human) are not held to the rule, so play it on the honor system: stop when you die.

  python lms.py --map drygulch --bots 4 --levels nightmare,hard,easy,easiest [--lives 1] [--minutes 10]
Logs: lms_logs\\<map>_<name>.log, result in lms_logs\\result.txt
"""
import argparse
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

from horde import CHARS, NOWIN, kill, pump

HERE = Path(__file__).resolve().parent
LOGS = HERE / "lms_logs"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--map", default="drygulch")
    ap.add_argument("--bots", type=int, default=4)
    ap.add_argument("--levels", default="nightmare,hard,easy,easiest")
    ap.add_argument("--lives", type=int, default=1)
    ap.add_argument("--minutes", type=float, default=10)
    ap.add_argument("--fps", default="60")
    ap.add_argument("--window-mode", default=os.environ.get("HORDE_WINDOWS", "hidden"))
    ap.add_argument("--users", type=int, default=0)
    a = ap.parse_args()
    LOGS.mkdir(exist_ok=True)
    levels = [x for x in a.levels.split(",") if x] or ["easy"]
    procs, logs, names = [], [], []

    def start(i, host=False):
        name = f"lm{i + 1}"
        level = levels[i % len(levels)]
        spec = ":".join([name, CHARS[i % len(CHARS)], "lv_" + level] + (["nightmare"] if level in ("nightmare", "hell") else []))
        log = LOGS / f"{a.map}_{name}.log"
        cmd = [sys.executable, "-u", str(HERE / "botctl.py"), spec, "--slot", str(i), "--fps", a.fps, "--size", "320x180",
               "--fight", "--no-taunts", "--window-mode", a.window_mode, "--no-bench"]
        cmd += ["--host", "--map", a.map, "--mode", "dm", "--wait-for", str(a.users), "--maxplayers", "8"] if host \
            else ["--join", "127.0.0.1"]
        p = subprocess.Popen(cmd, cwd=str(HERE), env=dict(os.environ, PYTHONUNBUFFERED="1", BOT_TAG=name, BOT_LMS=str(a.lives), BOT_MAP=a.map),
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace", creationflags=NOWIN)
        threading.Thread(target=pump, args=(p, log), daemon=True).start()
        procs.append(p); logs.append(log); names.append(name)
        print(f"{time.strftime('%H:%M:%S')} started {name} ({level})", flush=True)
        return p, log

    result = "no winner before the time ran out"
    try:
        host, hlog = start(0, True)
        end = time.time() + 150
        while time.time() < end and host.poll() is None:
            time.sleep(2)
            try:
                if "attached to" in hlog.read_text(errors="replace"):
                    break
            except OSError:
                pass
        if host.poll() is not None:
            print("the host bot exited early"); return
        print("lobby up", flush=True)
        time.sleep(12)
        for i in range(1, a.bots):
            start(i)
            time.sleep(8)
        t_end = time.time() + a.minutes * 60
        while time.time() < t_end:
            time.sleep(3)
            out = []
            for n, lg in zip(names, logs):
                try:
                    out.append("LMS: eliminated" in lg.read_text(errors="replace"))
                except OSError:
                    out.append(False)
            alive = [n for n, o in zip(names, out) if not o]
            if len(alive) == 1 and len(names) == a.bots:
                result = f"{alive[0]} wins ({levels[names.index(alive[0]) % len(levels)]}), last one standing"
                break
            if not alive:
                result = "everyone was eliminated"
                break
        print(result, flush=True)
        (LOGS / "result.txt").write_text(result + "\n")
        time.sleep(3)
    finally:
        kill(procs, logs)


if __name__ == "__main__":
    main()
