@echo off
rem Writes the Christmas version of a map (the lights overlay on its outside walls) to christmas\previews\ to look at in LawMaker.
rem   christmas_lights_preview.cmd fort
cd /d "%~dp0"
set MAP=%1
if "%MAP%"=="" set MAP=fort
.venv\Scripts\python.exe -c "import json,lvt,xmaslights,sys; m=sys.argv[1]; w=json.load(open('christmas/lights.json'))[m]; t=lvt.read_from_labs(m+'.lvt').decode('latin-1'); open('christmas/previews/'+m+'.lvt','w',encoding='latin-1',newline='').write(xmaslights.patch_lvt(t,w)); print(len(w),'walls')" %MAP%
echo Written: christmas\previews\%MAP%.lvt
pause
