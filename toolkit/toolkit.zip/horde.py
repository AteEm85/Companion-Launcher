"""Survival Horde: you (red team) against bots (blue team) that arrive in waves, tougher each time.

  python horde.py --map drygulch --minutes 15 [--hero] [--wave 45] [--max 7] [--fps 60]

A passive blue bot hosts the game (it never fights). The enemy bots arrive by how many kills you have; the bots already in the game are
raised to the new tier (nobody leaves) and more join (see TIERS / NORMAL_TIERS below, and CHALLENGE_TIERS for --challenge):
  normal     easiest at the start, easy at 4 kills, normal at 8, hard at 12, nightmare at 16, hell at 20 (only with --hell)
  --challenge  normal at the start, hard at 5 kills, nightmare at 10, hell at 15
  40 kills   you win and the game ends (+5 for each other Survivor player); so does --minutes (default 15).
Armor: 100 after the normal bots in either mode; Challenge mode also gives 150 after the nightmare bots (giveplates.py).
--hero adds a red bot to stand in for the player (testing); otherwise you join the LAN game yourself on the red team.
Logs: horde_logs\\<map>_<name>.log
"""
import argparse
import uuid
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOGS = HERE / "horde_logs"
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
CHARS = ["james", "mary", "bob", "drdeath"]
_ALL = ["james", "mary", "bob", "drdeath", "sanchez", "twofeathers"]
# The horde's tiers, in order. To add one, add a line: `kills` = the survivor's kills at which the horde becomes this tier (the
# bots already in the game are raised to it, no one leaves), `count` = bots in this tier at that moment, `joins` = kills at
# which one more bot joins, `skill` = the bot difficulty (a key of brain.DIFFICULTY), `plates` = armor you get when the tier
# is left behind (0 = none), `pool` = the characters the new bots are picked from.
NORMAL_TIERS = [
    dict(name="easiest", skill="easiest", kills=0, count=1, joins=(1, 3), plates=0, pool=["twofeathers", "sanchez"]),
    dict(name="easy", skill="easy", kills=4, count=3, joins=(7,), plates=0, pool=["james", "drdeath", "bob", "sanchez"]),
    dict(name="normal", skill="normal", kills=8, count=6, joins=(10,), plates=100, pool=_ALL),
    dict(name="hard", skill="hard", kills=12, count=8, joins=(14,), plates=0, pool=_ALL, strong=True),
    dict(name="nightmare", skill="nightmare", kills=16, count=10, joins=(), plates=0, pool=_ALL, strong=True),
]
HELL = dict(name="hell", skill="hell", kills=20, count=10, joins=(), plates=0, pool=_ALL, strong=True)     # only when "Include Hell" is ticked
# Challenge mode: it starts at Normal and is over in 15 kills' worth of climbing (Hell is always in).
CHALLENGE_TIERS = [
    dict(name="normal", skill="normal", kills=0, count=1, joins=(1, 3), plates=100, pool=_ALL),
    dict(name="hard", skill="hard", kills=5, count=4, joins=(7,), plates=0, pool=_ALL, strong=True),
    dict(name="nightmare", skill="nightmare", kills=10, count=6, joins=(12,), plates=150, pool=_ALL, strong=True),
    dict(name="hell", skill="hell", kills=15, count=8, joins=(18, 21), plates=0, pool=_ALL, strong=True),
]
# Melee zombies: the difficulty climbs on its own kills (Hard, Nightmare at 7, Hell at 15) while the bots still join at the
# normal (or Challenge) table's kill numbers.
MELEE_TIERS = [
    dict(name="hard", skill="hard", kills=0, count=1, joins=(), plates=0, pool=["mary", "twofeathers"], strong=True),
    dict(name="nightmare", skill="nightmare", kills=7, count=1, joins=(), plates=100, pool=["mary", "twofeathers"], strong=True),   # armor at 15 kills, as Hell begins
    dict(name="hell", skill="hell", kills=15, count=1, joins=(), plates=0, pool=["mary", "twofeathers"], strong=True),
]
TIERS, TIER, ORDER, POOL, PLATES, COUNTS = [], {}, [], {}, {}, []
START_LEVEL = "easiest"          # the host bot's own level (it never fights)


def set_tiers(hell=False, challenge=False, melee=False):
    """(Re)build the tier tables: the normal climb (Hell added at the end when asked for) or the Challenge climb. Melee
    zombies: the difficulty from MELEE_TIERS, the number of bots still from the normal (or Challenge) table."""
    global START_LEVEL
    COUNTS[:] = CHALLENGE_TIERS if challenge else NORMAL_TIERS + ([HELL] if hell else [])
    TIERS[:] = MELEE_TIERS if melee else COUNTS
    START_LEVEL = TIERS[0]["skill"]
    TIER.clear(); TIER.update({t["name"]: t for t in TIERS})
    ORDER[:] = [t["name"] for t in TIERS]
    POOL.clear(); POOL.update({t["name"]: t["pool"] for t in TIERS})
    PLATES.clear(); PLATES.update({t["name"]: t["plates"] for t in TIERS if t["plates"]})   # light, medium, heavy boiler plate after that tier is gone


set_tiers()
WIN_KILLS = 40                  # the Survivors win at this many kills with one player on their team ...
PER_PLAYER = 5                  # ... and this many more for each other player on it (3 players: 50, 6 players: 65)


def win_target(players):
    return WIN_KILLS + PER_PLAYER * max(0, players - 1)
OBSERVERS = ("hd2", "hd3")      # zombies that are in the game and read its kill feed (the host waits in the lobby and sees none)
# Maps with no Team mode get capture-the-flag teams instead; the bots then ignore the flags (BOT_NO_FLAGS).
HORDE_MODE = {}                 # filled by team_rcm_for if Team Play could not be added to a map
SUICIDES = {"suicide", "fall", "drowned", "crushed", "telefrag", "self-destruct", "blew themselves up", "explosion with nobody near"}


def plan(k):
    """(tier name, how many bots) the enemy side has at k kills (the survivor's kills)."""
    t = [t for t in TIERS if k >= t["kills"]][-1]
    c = [c for c in COUNTS if k >= c["kills"]][-1]                   # the same table, except for Melee zombies
    return t["name"], c["count"] + sum(1 for j in c["joins"] if k >= j)




def tier_strong(level):
    return bool(TIER.get(level, {}).get("strong"))


DARK = False                    # Dark Mode: close encounters in the dark (--dark)
MELEE = False                   # Melee only: the Horde is Mary and Two Feathers, with knives and fists only (--melee); the map is left as it is
MELEE_CHARS = ["mary", "twofeathers"]


def spec(name, char, team, level, display=""):
    strong_tier = level
    level = TIER[level]["skill"] if level in TIER else level          # the tier's bot difficulty
    tags = [name, char, team, "lv_" + level]
    if level in ("nightmare", "hell"):
        tags += ["nightmare"]
    if MELEE:
        tags += ["zombie_boxer" if char == "mary" else "zombie_knifer"]  # Mary: mostly fists, now and then the knife; Two Feathers: the knife
                                                                        # while he has one, else fists; never a gun or TNT, and no hesitation
        if tier_strong(strong_tier):
            tags += ["wp_8s1s"]                                         # strong with the knife and the fists
    elif DARK:
        tags += ["closeq"]                                              # shotguns, knife and fists only
        if tier_strong(strong_tier):
            tags += ["wp_4s5s6s8s1s7w2w3w9w"]                           # strong where it counts, no TNT, weak with the guns it never carries
    elif tier_strong(strong_tier):
        tags += ["wp_" + "".join(f"{i}s" for i in range(1, 10))]       # strong with every weapon
    return ":".join(tags) + ("=" + display if display else "")


def ev(msg):
    """Print a game event and keep it in horde_logs\\events.txt."""
    line = f"{time.strftime('%H:%M:%S')} {msg}"
    print(line, flush=True)
    try:
        with open(LOGS / "events.txt", "a") as f:
            f.write(line + "\n")
    except OSError:
        pass


def kill(procs, logs):
    for p in procs:
        subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True, creationflags=NOWIN)
    for path in logs:
        try:
            for pid in re.findall(r"\(pid (\d+)\)", Path(path).read_text(errors="replace")):
                subprocess.run(["taskkill", "/PID", pid, "/F"], capture_output=True, creationflags=NOWIN)
        except OSError:
            pass


RUN = uuid.uuid4().hex[:8]                      # this game's id: its bots only obey its own leave flags




def reward(level, bot_pids):
    """After the last bot of a tier leaves: top the human's armor up (giveplates.py, in the background)."""
    amount = PLATES.get(level)
    if not amount:
        return
    pids = set(map(str, bot_pids))
    for lg in LOGS.glob("*.log"):
        try:
            pids |= set(re.findall(r"\(pid (\d+)\)", lg.read_text(errors="replace")))
        except OSError:
            pass
    ev(f"the {level} bots are gone: {'light' if amount == 50 else 'medium' if amount == 100 else 'heavy'} boiler plate for you")
    subprocess.Popen([sys.executable, str(HERE / "giveplates.py"), str(amount), "--exclude", ",".join(sorted(pids))],
                     cwd=str(HERE), creationflags=NOWIN)


def end_match(why):
    """Ask the host game to end the match itself (its own time/kill limits), then give everyone ~20 s on the scoreboard."""
    try:                                             # the scoreboard is coming up: the music and storms stop
        (HERE / "state").mkdir(exist_ok=True)
        (HERE / "state" / f"music_stop_{RUN}").write_text(why)
        ev(f"match over ({why}): the music, wolves and storms stop")
    except OSError:
        pass
    try:
        (HERE / "state").mkdir(exist_ok=True)
        (HERE / "state" / f"end_{RUN}.flag").write_text(why)
    except OSError:
        return
    time.sleep(20)


LEAVE_GAP = 3.0      # seconds between one bot starting to leave and the next (the others keep fighting meanwhile)
JOIN_GAP = 3.0       # seconds between one new bot being let into the game and the next


def leave_then_kill(procs, logs, wait=6.0, stagger=False):
    """Ask the bots to leave the match through the game's pause menu (so the others see them go, not a frozen body), wait
    until their game windows have closed (up to `wait` seconds), then end whatever is still running."""
    state = HERE / "state"
    tags, pids = [], []
    for path in logs:
        try:
            tags.append(Path(path).stem.rsplit("_", 1)[1])
            pids += re.findall(r"\(pid (\d+)\)", Path(path).read_text(errors="replace"))
        except (OSError, IndexError):
            pass
    try:
        state.mkdir(exist_ok=True)
        for n, t in enumerate(tags):
            if stagger and n:
                time.sleep(LEAVE_GAP)
            (state / f"leave_{RUN}_{t}.flag").write_text("leave")
    except OSError:
        pass
    end = time.time() + wait
    while time.time() < end and pids:
        try:
            out = subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True, creationflags=NOWIN).stdout
        except OSError:
            break
        alive = set(re.findall(r'"OutlawsAHOM\.exe","(\d+)"', out))
        if not any(p in alive for p in pids):
            break
        time.sleep(0.5)
    kill(procs, logs)
    for t in tags:
        try:
            (state / f"leave_{RUN}_{t}.flag").unlink()
        except OSError:
            pass
        try:
            (state / f"go_{RUN}_{t}.flag").unlink()
        except OSError:
            pass


def pump(p, path):
    with open(path, "w", errors="replace") as f:
        for line in p.stdout:
            f.write(line)
            f.flush()


# Sanctuary's .rcm (inside the game's archives) lists no Team Play mode. For a Horde game we put a loose copy beside the
# game with the M added (a loose .rcm overrides the archives) and take it away again when the game is over, so normal
# games on Sanctuary are untouched.
TEAM_RCM = {"town_2p": (b"MODES:  DKCT", b"MODES:  DKCTM")}


BOT_NAME = re.compile(r"^(Zombie|Bot|Host Bot)( \d+)?$")


def survivors(text):
    """The players (anyone who isn't one of our bots) an observer has seen in the kill feed: the Survivors team."""
    names = set()
    for line in re.findall(r"^FMT: G (.+)$", text, re.M):
        line = line.strip()
        m = re.match(r"^(.+) (?:killed|blew) you(?: up)?!$", line)
        if m:
            names.add(m.group(1)); continue
        m = re.match(r"^(.+) (?:killed|blew up) (.+)!$", line)
        if m:
            names.update(n for n in m.groups() if n != "You")
    return {n for n in names if n != "You" and not BOT_NAME.match(n) and n.lower() not in ("himself", "herself", "themselves")}


def survivor_kills(text):
    """Kills by players (anyone who isn't one of our bots) of our bots, from an observer's kill-feed lines."""
    n = 0
    for line in re.findall(r"^FMT: G (.+)$", text, re.M):
        line = line.strip()
        m = re.match(r"^(.+) (?:killed|blew) you(?: up)?!$", line)      # the observer itself was the victim
        if m:
            if not BOT_NAME.match(m.group(1)) and m.group(1) != "You": n += 1
            continue
        m = re.match(r"^(.+) (?:killed|blew up) (.+)!$", line)
        if m and not BOT_NAME.match(m.group(1)) and BOT_NAME.match(m.group(2)):
            n += 1
    return n


def team_rcm_for(level):
    if level not in TEAM_RCM:
        return
    import atexit
    import lvt
    path = lvt.GAME_DIR / f"{level}.rcm"
    if path.exists():
        if b"M" not in (re.search(rb"MODES:\s*(\w+)", path.read_bytes()) or [b"", b""])[1].upper():
            HORDE_MODE[level] = "ctf"                       # the player's own file has no Team Play: CTF teams instead
        return                                              # the player's own file: leave it alone
    data = lvt.read_from_labs(f"{level}.rcm")
    old, new = TEAM_RCM[level]
    if not data or old not in data:
        HORDE_MODE[level] = "ctf"
        return
    path.write_bytes(data.replace(old, new))
    atexit.register(lambda: path.unlink() if path.exists() else None)
    print(f"added Team Play to {level}.rcm for this game", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--map", default="drygulch")
    ap.add_argument("--minutes", type=float, default=15)
    ap.add_argument("--wave", type=float, default=45, help="seconds between new bots")
    ap.add_argument("--max", type=int, default=7, help="most horde bots at once")
    ap.add_argument("--ramp", type=float, default=0, help="testing: pretend one extra kill every this many seconds")
    ap.add_argument("--hero", action="store_true", help="a red bot plays your part (testing)")
    ap.add_argument("--fps", default="60")
    ap.add_argument("--window-mode", default=os.environ.get("HORDE_WINDOWS", "hidden"))
    ap.add_argument("--users", type=int, default=0, help="humans to wait for before the first wave")
    ap.add_argument("--challenge", action="store_true", help="Challenge mode: Normal bots to start, Hard at 5 kills, Nightmare at 10, Hell at 15")
    ap.add_argument("--melee", action="store_true", help="Melee only: knives and fists; every gun and ammo pickup on the map is a knife; the Horde is Mary and Two Feathers")
    ap.add_argument("--dark", action="store_true", help="Dark Mode: a flashlight in a black map, shotguns/knives/TNT only, bots fight up close")
    ap.add_argument("--hell", action="store_true", help="at 25 kills the bots become Hell bots")
    ap.add_argument("--classic", action="store_true", help="plain Outlaws style: no zombie skins, colours, darkness, music or storms; bots are called Bot 1, Bot 2 ...")
    ap.add_argument("--ranked", action="store_true", help="save kills/deaths of the red player in ranked.db")
    ap.add_argument("--player", default="", help="ranked: the player's name")
    ap.add_argument("--character", default="", help="ranked: the character the player uses")
    a = ap.parse_args()
    global DARK, MELEE
    DARK = bool(a.dark)
    MELEE = bool(a.melee)
    set_tiers(a.hell, a.challenge, MELEE)
    team_rcm_for(a.map)
    if DARK:
        import atexit
        import darkitems
        os.environ["BOT_DARK"] = "1"                      # the bots (their own processes) skip rifles, pistols, gatlings and their ammo
        darkitems.patch(a.map, log=lambda m: print(m, flush=True))
        atexit.register(darkitems.restore)
    else:
        try:
            import darkitems
            darkitems.restore()                           # loose files left by a Dark Mode game that was cut short
        except Exception:
            pass
    LOGS.mkdir(exist_ok=True)
    for old_log in LOGS.glob(f"{a.map}_*.log"):         # last game's logs must not be read as this game's (kill counts!)
        try:
            old_log.unlink()
        except OSError:
            pass
    # Only one Survival game at a time: an old horde.py that survived a "close all windows" shares our log files and
    # would end our bots (its kill reads the game pids from the same logs). End any other one first.
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command",
                        "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'horde\\.py|lms\\.py' -and "
                        f"$_.ProcessId -ne {os.getpid()} -and $_.ProcessId -ne {os.getppid()} -and $_.Name -match 'python' }} | "
                        "ForEach-Object { taskkill /PID $_.ProcessId /T /F | Out-Null }"],
                       capture_output=True, timeout=60, creationflags=NOWIN)
    except (OSError, subprocess.SubprocessError):
        pass
    for f in list((HERE / "state").glob("leave_*.flag")) + list((HERE / "state").glob("go_*.flag")) + list((HERE / "state").glob("level_*.flag")):          # leftovers from an earlier run
        try:
            f.unlink()
        except OSError:
            pass
    procs, logs = [], []
    count = [0]

    release_lock, last_release = threading.Lock(), [0.0]

    def release_when_ready(name, p, log):
        """A new bot waits in the lobby (not spawned) until its brain is attached and running; then bots are let in one at
        a time, JOIN_GAP seconds apart, so none stands around helpless and they don't all appear at once."""
        end = time.time() + 150
        while time.time() < end and p.poll() is None:
            try:
                if "fighting;" in log.read_text(errors="replace"):
                    break
            except OSError:
                pass
            time.sleep(0.5)
        time.sleep(1.5)
        with release_lock:
            wait = last_release[0] + JOIN_GAP - time.time()
            if wait > 0:
                time.sleep(wait)
            try:
                (HERE / "state" / f"go_{RUN}_{name}.flag").write_text("go")
            except OSError:
                pass
            last_release[0] = time.time()

    def start(name, char, team, level, host=False, display="", hold=False):
        s = spec(name, char, team, level, "Host Bot" if host else display)
        log = LOGS / f"{a.map}_{name}.log"
        cmd = [sys.executable, "-u", str(HERE / "botctl.py"), s, "--slot", str(count[0]), "--fps", a.fps, "--size", "320x180",
               "--fight", "--no-taunts", "--window-mode", a.window_mode, "--no-bench"]
        cmd += ["--host", "--map", a.map, "--mode", HORDE_MODE.get(a.map, "team"), "--wait-for", str(a.users), "--maxplayers", "14"] if host \
            else ["--join", "127.0.0.1"]
        count[0] += 1
        env = dict(os.environ, PYTHONUNBUFFERED="1", BOT_TAG=name, BOT_RUN=RUN, BOT_MAP=a.map)
        if a.map in HORDE_MODE:
            env["BOT_NO_FLAGS"] = "1"
        if a.player:
            env.update(BOT_STATS_PLAYER=a.player, BOT_STATS_NOSAVE="1")
        if name == "hero":
            env["BOT_STATS_HIDE"] = "1"
        if name in OBSERVERS:                         # in-game zombies that read the kill feed (the host in the lobby sees none)
            env.update(BOT_STATS_OBS="1", BOT_TRACEFMT="1", BOT_STATS_NOSAVE="1", BOT_STATS_PLAYER=a.player or "human")
        if host:
            env["BOT_PASSIVE"] = "1"
        if hold:
            env["BOT_HOLD_JOIN"] = "1"
        if name == "hd1":
            env.update(BOT_TRACEFMT="1", BOT_LIMITS=f"999,{max(1, int(round(a.minutes)))}")   # the kill target moves with the players: horde.py ends the match
            if a.player:
                env["BOT_RANKED"] = "1"
            else:
                env.update(BOT_STATS_PLAYER="human", BOT_STATS_NOSAVE="1")
        p = subprocess.Popen(cmd, cwd=str(HERE), env=env, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, text=True, errors="replace", creationflags=NOWIN)
        threading.Thread(target=pump, args=(p, log), daemon=True).start()
        procs.append(p)
        logs.append(log)
        ev(f"started {name} ({char}, {team}, {level})")
        if hold:
            threading.Thread(target=release_when_ready, args=(name, p, log), daemon=True).start()
        return p, log

    sid, began = uuid.uuid4().hex, time.time()


    forced = [0]                                      # kills the game itself reported at the end (see the matchend flag)

    def observer_text():
        """The log of the first in-game observer that has recognised the human and counts their kills exactly ('' if none)."""
        for nm in OBSERVERS:
            try:
                path = LOGS / f"{a.map}_{nm}.log"
                if path.stat().st_mtime < began - 2:          # last game's log (not rewritten yet): not ours
                    continue
                t = path.read_text(errors="replace")
            except OSError:
                continue
            if "exact counting" in t:
                return t
        return ""

    def save_ranked(final=False):
        """Kills = blue bots' deaths (only the red player kills them); deaths = the red player's deaths seen by hd1."""
        if not a.player:
            return
        import ranked
        kills = deaths = suicides = 0
        causes = {}
        otext = observer_text()
        exact = bool(otext)
        if otext:                                          # an observer read the game's own kill messages: exact numbers
            for cause in re.findall(r"^STATS: .+ died: (.+?) \(kills", otext, re.M):
                deaths += 1
                causes[cause] = causes.get(cause, 0) + 1
                if cause in SUICIDES:
                    suicides += 1
            for cause in re.findall(r"^STATS: .+ reclassified: (.+)$", otext, re.M):     # a death the game blamed on a zombie: it was a fall / own blast
                suicides += 1
                causes["killed by a player"] = max(0, causes.get("killed by a player", 1) - 1)
                causes[cause] = causes.get(cause, 0) + 1
            kills = len(re.findall(r"^STATS: .+ killed .+ \(kills \d+\)$", otext, re.M))
        for lg in logs:
            try:
                text = lg.read_text(errors="replace")
            except OSError:
                continue
            if lg.name.endswith("_hd1.log"):
                if not otext:
                    deaths = text.count("RANK: player died")
                    suicides = len(re.findall(r"RANK: player died near=0\b", text))
            if not exact and "_hd" in lg.name and not lg.name.endswith("_hd1.log"):
                kills += len(re.findall(r"^died$", text, re.M))
        kills = max(kills, forced[0])
        try:                                             # deathwatch.py counts the player's own deaths (the host's reading is unreliable)
            seen = int((HERE / "state" / f"deaths_{RUN}.txt").read_text().strip())
            if seen >= deaths:
                deaths = seen
        except (OSError, ValueError):
            pass
        try:
            ranked.save_session(sid, a.player, a.character, a.map, kills, deaths, began, suicides, a.ranked, causes or None)
        except Exception as e:                       # a locked or unreachable database must not stop the game
            print("ranked: could not save:", e, flush=True)
        if final and a.ranked:                       # the finished ranked game goes to the online rankings (waits in an outbox if it can't)
            def push():
                try:
                    import onlinerank
                    ok = onlinerank.submit(sid, a.player, a.character, a.map, kills, deaths, began)
                    ev("ranked game sent to the online rankings" if ok else
                       ("ranked game saved; it will go to the online rankings once a GitHub token is set up (online_settings.json) or you are online"))
                except Exception as e:
                    ev(f"could not send the ranked game online: {e}")
            t = threading.Thread(target=push, daemon=True)
            t.start()
            t.join(30)

    import teamcolors
    themed = False
    try:
        # Survival look: Survivors (you, purple) vs Horde (green). Installed now, removed when the game ends.
        if a.classic:
            ev("classic Outlaws style: no mods")
            try:                                             # leftovers of an earlier modded run go (the game must be closed for the file edits)
                if not teamcolors.running() and teamcolors.dirty():
                    teamcolors.set_theme("off", quiet=True)
                import zombieskins as _zs
                _zs.off()
            except Exception:
                pass
        elif teamcolors.running():
            ev("the game is already open, so the Survivors/Horde colors can't be installed this time")
        else:
            if teamcolors.dirty():
                teamcolors.set_theme("off", quiet=True)      # left over from a run that was cut short
            import zombieskins
            zombies = zombieskins.available()           # zombie sprites keep their own colours: no team tint at all
            themed = teamcolors.set_theme("on", quiet=True, neutral="horde" if zombies else False, dark="flash" if a.dark else True)
            if zombies:
                try:
                    zombies = zombieskins.on()
                    if zombies:                                  # and take them out again whenever the game closes, whatever happens
                        subprocess.Popen([sys.executable, str(HERE / "zombieskins.py"), "watch"], cwd=str(HERE),
                                         creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
                except Exception as e:
                    ev(f"could not install the zombie skins: {e}"); zombies = False
            ev(("Survivors (purple tint) vs Horde (zombie skins) installed" if zombies else "Survivors (purple) vs Horde (green) installed") if themed else "could not install the Survivors/Horde colors")
        if not a.classic:
            try:                                           # creepy background loop and the odd distant storm, until the game ends
                if (HERE / "sounds" / "horde_ambient.wav").exists():
                    subprocess.Popen([sys.executable, str(HERE / "ambient.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN)
                if (HERE / "wolf.py").exists():
                    subprocess.Popen([sys.executable, str(HERE / "wolf.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN)
                if (HERE / "deathsound.py").exists() and (HERE / "sounds" / "horde_death.wav").exists():
                    subprocess.Popen([sys.executable, str(HERE / "deathsound.py"), RUN, str(os.getpid()), a.map], cwd=str(HERE), creationflags=NOWIN)
                if (HERE / "tierhud.py").exists():
                    subprocess.Popen([sys.executable, str(HERE / "tierhud.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN)
                if (HERE / "welcome.py").exists():
                    subprocess.Popen([sys.executable, str(HERE / "welcome.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN)
                if (HERE / "storm.py").exists():
                    subprocess.Popen([sys.executable, str(HERE / "storm.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN)
            except OSError:
                pass
        host, hlog = start("hd1", MELEE_CHARS[0] if MELEE else CHARS[0], "blue", START_LEVEL, host=True)
        end = time.time() + 150
        while time.time() < end and host.poll() is None:
            time.sleep(2)
            try:
                if "attached to" in hlog.read_text(errors="replace"):
                    break
            except OSError:
                pass
        if host.poll() is not None:
            print("the host bot exited early")
            return
        print("lobby up", flush=True)
        time.sleep(12)
        if a.hero:
            start("hero", "bob", "red", "nightmare")
            time.sleep(8)
        t_start = time.time()
        t_end = time.time() + a.minutes * 60
        nxt = [2]
        cur = {"level": None, "bots": []}          # the enemy bots in play: (process, log)

        team_names = set()                               # the Survivors seen in the kill feed (the win target grows with them)

        def total_kills():
            """The Survivors' kills: every player on the Survivors team, not only the first one an observer recognised.
            Read from the game's own kill feed in the in-game observers' logs ('FMT: G <player> killed Zombie 3!',
            '<player> killed you!' when the observer itself was the victim). Zombies that die by themselves (a fall,
            their own TNT) and zombie kills don't count. Each observer sees every kill, so the higher of their counts is
            used (a line one of them missed doesn't matter, and nothing is counted twice). Until an observer has seen
            the feed, the count of bot deaths is used instead."""
            best = None
            for nm in OBSERVERS:
                try:
                    path = LOGS / f"{a.map}_{nm}.log"
                    if path.stat().st_mtime < began - 2:          # last game's log (not rewritten yet): not ours
                        continue
                    t = path.read_text(errors="replace")
                except OSError:
                    continue
                if "FMT: G " in t:
                    n = survivor_kills(t)
                    best = n if best is None else max(best, n)
                    team_names.update(survivors(t))
            if best is not None:
                return best
            text = observer_text()
            if text:
                return len(re.findall(r"^STATS: .+ killed .+ \(kills \d+\)$", text, re.M))
            n = 0
            for lg in logs:
                if "_hd" in lg.name and not lg.name.endswith("_hd1.log"):
                    try:
                        n += len(re.findall(r"^died$", lg.read_text(errors="replace"), re.M))
                    except OSError:
                        pass
            return n

        def add_bot(level):
            pool = MELEE_CHARS if MELEE else POOL[level]
            have = [c for c, _, _ in cur["bots"]]
            char = next((c for c in pool if c not in have), pool[len(have) % len(pool)])
            p, lg = start(f"hd{nxt[0]}", char, "blue", level, display=f"{'Bot' if a.classic else 'Zombie'} {len(cur['bots']) + 1}", hold=True)
            cur["bots"].append((char, p, lg))
            nxt[0] += 1

        watcher = None
        if a.player and not a.hero:                      # the human's deaths: read from their own game's health
            try:
                watcher = subprocess.Popen([sys.executable, str(HERE / "deathwatch.py"), RUN], cwd=str(HERE), creationflags=NOWIN)
            except OSError:
                watcher = None
        ended_flag = HERE / "state" / f"matchend_{RUN}.flag"
        target = [win_target(1)]
        ev(f"the Survivors win at {target[0]} kills ({WIN_KILLS}, +{PER_PLAYER} for each other player on their team)")
        while time.time() < t_end:
            k = total_kills() + (int((time.time() - t_start) / a.ramp) if a.ramp else 0)
            t_now = win_target(max(len(team_names), 1))
            if t_now != target[0]:
                target[0] = t_now
                ev(f"{len(team_names)} players on the Survivors team ({', '.join(sorted(team_names))}): they win at {t_now} kills")
            if ended_flag.exists() and k < target[0]:     # the game ended the match itself: only its time limit is left on
                ev(f"the game's time is up ({k} of {target[0]} kills)")
                break
            if k >= target[0]:
                ev(f"YOU WIN: {k} kills")
                end_match("win")
                break
            level, want = plan(k)
            if cur["level"] is not None and ORDER.index(level) < ORDER.index(cur["level"]):
                level = cur["level"]            # a tier is never taken back
            if level != cur["level"]:
                if cur["bots"]:
                    # The bots stay in the game and are raised to the new difficulty on the spot (no leaving, no standing in
                    # the pause menu); more bots join to make up the new count.
                    ev(f"{k} kills: the {cur['level']} bots become {level} bots, {max(0, want - len(cur['bots']))} more join")
                    for _, _, lg in cur["bots"]:
                        try:
                            (HERE / "state" / f"level_{RUN}_{Path(lg).stem.rsplit('_', 1)[1]}.flag").write_text(TIER[level]["skill"] + ("+strong" if tier_strong(level) else ""))
                        except (OSError, IndexError):
                            pass
                    if not a.hero:
                        reward(cur["level"], [p.pid for p in procs])
                    try:                                 # tell the player on screen
                        subprocess.Popen([sys.executable, str(HERE / "announce.py"), "Horde Becomes Stronger"], cwd=str(HERE), creationflags=NOWIN)
                    except OSError:
                        pass
                cur["level"] = level
                try:                                     # the small tier label on screen (tierhud.py) reads this
                    (HERE / "state" / f"tier_{RUN}.txt").write_text(level)
                except OSError:
                    pass
            while len(cur["bots"]) < want:
                if cur["bots"]:
                    ev(f"{k} kills: another {level} bot joins")
                add_bot(level)
            time.sleep(2)
            save_ranked()
        else:
            ev("time is up")
            end_match("time")
        print("match over", flush=True)
    finally:
        save_ranked()
        leave_then_kill([p for p, lg in zip(procs, logs) if not lg.name.endswith("_hd1.log")],
                        [lg for lg in logs if not lg.name.endswith("_hd1.log")], stagger=False)
        save_ranked(True)
        try:
            (HERE / "state" / f"stop_{RUN}").write_text("stop")
        except OSError:
            pass
        kill(procs, logs)
        try:                                            # keep this run's logs: the next run overwrites them
            import shutil
            keep = LOGS / "runs" / time.strftime("%Y%m%d_%H%M%S", time.localtime(began))
            keep.mkdir(parents=True, exist_ok=True)
            for lg in logs:
                shutil.copy2(lg, keep / Path(lg).name)
            for old in sorted((LOGS / "runs").iterdir())[:-6]:      # the last six runs only
                shutil.rmtree(old, ignore_errors=True)
        except Exception:
            pass
        try:
            if teamcolors.dirty():
                ok = False
                for _ in range(5):                              # the bot game windows take a moment to close
                    time.sleep(3)
                    ok = teamcolors.set_theme("off", quiet=True)
                    if ok:
                        break
                if ok:
                    ev("team colors restored to red/blue")
                else:                                           # your own game window is still open: finish once it closes
                    ev("team colors will be restored when you close the game")
                    subprocess.Popen([sys.executable, str(HERE / "teamcolors.py"), "off", "--wait"], cwd=str(HERE),
                                     creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except Exception as e:
            ev(f"could not restore team colors: {e}")
        if a.dark:
            try:
                import darkitems
                for _ in range(5):
                    if darkitems.restore(): break
                    time.sleep(3)
            except Exception as e:
                ev(f"could not remove the Dark Mode map files: {e}")
        try:
            import zombieskins
            if zombieskins.installed():
                ok = False
                for _ in range(5):
                    ok = zombieskins.off()
                    if ok: break
                    time.sleep(3)
                if not ok:                                      # still in use: finish once the game closes
                    subprocess.Popen([sys.executable, str(HERE / "zombieskins.py"), "off", "--wait"], cwd=str(HERE),
                                     creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except Exception as e:
            ev(f"could not remove the zombie skins: {e}")


if __name__ == "__main__":
    main()
