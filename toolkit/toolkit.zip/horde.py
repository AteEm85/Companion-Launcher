"""Survival Horde: you (red team) against bots (blue team) that arrive in waves, tougher each time.

  python horde.py --map drygulch --minutes 30 [--hero] [--wave 45] [--max 7] [--fps 60]

A passive blue bot hosts the game (it never fights). The enemy bots arrive by how many kills you have; the bots already in the game are
raised to the new tier (nobody leaves) and more join (see TIERS / NORMAL_TIERS below, and CHALLENGE_TIERS for --challenge):
  normal     easiest at the start, easy at 4 kills, normal at 8, hard at 12, nightmare at 16, hell at 20 (only with --hell)
  --challenge  normal at the start, hard at 5 kills, nightmare at 10, hell at 15
  40 kills   you win and the game ends (+5 for each other Survivor player); so does --minutes (default 30).
Armor: 100 after the normal bots in either mode; Challenge mode also gives 150 after the nightmare bots (giveplates.py).
--christmas  the Christmas Horde: elves (red and green, elf hats, jingling footsteps), a snowy world with falling snow and
           Christmas trees, Christmas music; at the kill target Santa arrives (Hell, the Gatling he walks with, 150 armor,
           10 times Mary's health) and the Survivors win when they kill him. Santa is his own model (SANTA.NWX); no elf is
           Sanchez (there is no elf Sanchez), but a player can be.
--hero adds a red bot to stand in for the player (testing); otherwise you join the LAN game yourself on the red team.
Logs: horde_logs\\<map>_<name>.log
"""
import argparse
import uuid
import os
import re
import subprocess
import sys
import math
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOGS = HERE / "horde_logs"
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
CHARS = ["james", "mary", "bob", "drdeath"]
_ALL = ["james", "mary", "bob", "drdeath", "sanchez", "twofeathers"]
# The horde's tiers, in order. To add one, add a line: `kills` = the survivor's kills at which the horde becomes this tier (the
# bots already in the game are raised to it, no one leaves), `count` = bots in this tier at that moment, `joins` = kills at
# which one more bot joins, `skill` = the bot difficulty (a key of brain.DIFFICULTY), `plates` = armor you get when the tier
# is left behind (0 = none), `pool` = the characters the new bots are picked from.
NORMAL_TIERS = [
    dict(name="easiest", skill="easiest", kills=0, count=1, joins=(1, 3), plates=0, pool=["twofeathers", "sanchez"]),
    dict(name="easy", skill="easy", kills=4, count=3, joins=(7,), plates=0, pool=["james", "drdeath", "bob", "sanchez"]),
    dict(name="normal", skill="normal", kills=8, count=6, joins=(10,), plates=100, pool=_ALL),
    dict(name="hard", skill="hard", kills=12, count=8, joins=(14,), plates=0, pool=_ALL, strong=True),
    dict(name="nightmare", skill="nightmare", kills=16, count=10, joins=(), plates=0, pool=_ALL, strong=True),
]
HELL = dict(name="hell", skill="hell", kills=20, count=10, joins=(), plates=0, pool=_ALL, strong=True)     # only when "Include Hell" is ticked
# Challenge mode: it starts at Normal and is over in 15 kills' worth of climbing (Hell is always in).
CHALLENGE_TIERS = [
    dict(name="normal", skill="normal", kills=0, count=1, joins=(1, 3), plates=100, pool=_ALL),
    dict(name="hard", skill="hard", kills=5, count=4, joins=(7,), plates=0, pool=_ALL, strong=True),
    dict(name="nightmare", skill="nightmare", kills=10, count=6, joins=(12,), plates=150, pool=_ALL, strong=True),
    dict(name="hell", skill="hell", kills=15, count=8, joins=(18, 21), plates=0, pool=_ALL, strong=True),
]
# Melee zombies: the difficulty climbs on its own kills (Hard, Nightmare at 7, Hell at 15) while the bots still join at the
# normal (or Challenge) table's kill numbers.
# (8 Nov, the user's rework) the climb starts at Easiest; ghost zombies are also slowed by `speed` (of a player's) and only walk
# (`walk`) in the first two tiers. Bot zombies get the tiers but not the speeds (a game copy runs at the game's own speed).
_MP = ["mary", "twofeathers"]
MELEE_TIERS = [
    dict(name="easiest", skill="easiest", kills=0, count=1, joins=(), plates=0, pool=_MP, speed=0.5, walk=True),
    dict(name="easy", skill="easy", kills=4, count=1, joins=(), plates=0, pool=_MP, speed=0.6, walk=True),
    dict(name="normal", skill="normal", kills=8, count=1, joins=(), plates=0, pool=_MP, speed=0.7),
    dict(name="hard", skill="hard", kills=15, count=1, joins=(), plates=0, pool=_MP, strong=True, speed=0.8),
    dict(name="nightmare", skill="nightmare", kills=24, count=1, joins=(), plates=100, pool=_MP, strong=True, speed=0.9),   # armor as Hell begins
    dict(name="hell", skill="hell", kills=32, count=1, joins=(), plates=0, pool=_MP, strong=True, speed=1.0),
]
# Ghost zombies: twice the bots' numbers at every step (the bots' climb peaks at 10: 20 by Nightmare), and 5 more join at
# GHOST_SURGE_KILLS (25 in all). Melee: the steps follow the melee tiers' own kill numbers. The host bot's lobby is made for
# GAME_MAX_PLAYERS (it was 14: the host turned the 13th ghost zombie away with "85 02"); 32 is the most botctl can set, and a
# player address only fits up to id 30, so at most 30 - 1 (the host) - the humans zombies.
GAME_MAX_PLAYERS = 32
GHOST_SCALE = 2.0
GHOST_SURGE_KILLS, GHOST_SURGE = 32, 5          # (was 35: the last group joins as Hell begins)
GHOST_MELEE_STEPS = [(0, 2), (1, 4), (3, 6), (7, 8), (8, 12), (11, 14), (15, 16), (19, 18), (24, 20), (GHOST_SURGE_KILLS, 25)]
HUMANS = [1]                     # people on the Survivors (each takes a player slot)
GHOST_MAX = [16]                 # --ghost-max (the Game Modes tab's "Max zombies"): the climb above, scaled so its top (25) is this
GHOST_TOP = 25


def scale_ghosts(n):
    """the climb's number of zombies at this point, scaled to the chosen maximum (each one's moves go to every other player:
    25 lagged on a fast PC, so 16 is the default; slower PCs pick fewer)"""
    return max(1, int(round(n * GHOST_MAX[0] / GHOST_TOP)))


def ghost_cap():
    return max(1, min(GAME_MAX_PLAYERS, 30) - 1 - HUMANS[0])
TIERS, TIER, ORDER, POOL, PLATES, COUNTS = [], {}, [], {}, {}, []
START_LEVEL = "easiest"          # the host bot's own level (it never fights)


def set_tiers(hell=False, challenge=False, melee=False):
    """(Re)build the tier tables: the normal climb (Hell added at the end when asked for) or the Challenge climb. Melee
    zombies: the difficulty from MELEE_TIERS, the number of bots still from the normal (or Challenge) table."""
    global START_LEVEL
    COUNTS[:] = CHALLENGE_TIERS if challenge else NORMAL_TIERS + ([HELL] if hell else [])
    TIERS[:] = MELEE_TIERS if melee else COUNTS
    START_LEVEL = TIERS[0]["skill"]
    TIER.clear(); TIER.update({t["name"]: t for t in TIERS})
    ORDER[:] = [t["name"] for t in TIERS]
    POOL.clear(); POOL.update({t["name"]: t["pool"] for t in TIERS})
    PLATES.clear(); PLATES.update({t["name"]: t["plates"] for t in TIERS if t["plates"]})   # light, medium, heavy boiler plate after that tier is gone


set_tiers()
# The Christmas Horde's own climb (16 Nov, the user): Easy at 8 kills, Normal at 14, Hard at 18, Nightmare at 25 - and the launcher's
# "Final tier" choice: Hell (Hell at 30 on top of that), Nightmare (the default), Hard (Hard at 25) or Normal (Normal at 25); for
# Hard and Normal the tiers below are spread evenly up to it. The bots joining inside a tier move with it (same share of the way
# through the tier), and the last tier has the full Nightmare horde.
XMAS_TOPS = ("hell", "nightmare", "hard", "normal")
def xmas_tiers(top="nightmare"):
    top = top if top in XMAS_TOPS else "nightmare"
    order = ["easiest", "easy", "normal", "hard", "nightmare", "hell"]
    if top in ("nightmare", "hell"): starts = {"easiest": 0, "easy": 8, "normal": 14, "hard": 18, "nightmare": 25, "hell": 30}
    else:
        names = order[:order.index(top) + 1]
        starts = {n: int(round(25.0 * i / (len(names) - 1))) for i, n in enumerate(names)}
    src = {t["name"]: t for t in NORMAL_TIERS + [HELL]}
    names = [n for n in order[:order.index(top) + 1] if n in starts]
    out = []
    for i, n in enumerate(names):
        t = dict(src[n]); o0 = src[n]["kills"]; o1 = src[order[order.index(n) + 1]]["kills"] if n != "hell" else o0 + 4
        n0 = starts[n]; n1 = starts[names[i + 1]] if i + 1 < len(names) else n0 + (o1 - o0)
        t["kills"] = n0
        t["joins"] = tuple(sorted({min(n1 - 1, max(n0 + 1, int(round(n0 + (j - o0) * (n1 - n0) / float(o1 - o0))))) for j in src[n]["joins"]}))
        if i == len(names) - 1: t["count"] = max(t["count"], src["nightmare"]["count"]); t["joins"] = (); t["strong"] = True
        out.append(t)
    return out


def set_xmas_tiers(top):
    global START_LEVEL
    COUNTS[:] = xmas_tiers(top); TIERS[:] = COUNTS
    START_LEVEL = TIERS[0]["skill"]
    TIER.clear(); TIER.update({t["name"]: t for t in TIERS})
    ORDER[:] = [t["name"] for t in TIERS]
    POOL.clear(); POOL.update({t["name"]: t["pool"] for t in TIERS})
    PLATES.clear(); PLATES.update({t["name"]: t["plates"] for t in TIERS if t["plates"]})


WIN_KILLS = 40                  # the Survivors win at this many kills with one player on their team ...
PER_PLAYER = 5                  # ... and this many more for each other player on it (3 players: 50, 6 players: 65)


def win_target(players):
    return WIN_KILLS + PER_PLAYER * max(0, players - 1)
OBSERVERS = ("hd2", "hd3")      # zombies that are in the game and read its kill feed (the host waits in the lobby and sees none)
# Maps with no Team mode get capture-the-flag teams instead; the bots then ignore the flags (BOT_NO_FLAGS).
HORDE_MODE = {}                 # filled by team_rcm_for if Team Play could not be added to a map
MODES_BOTCTL = {"ctf": (1,), "tag": (2,), "chicken": (3,), "doc": (4,), "team": (5,), "dm": (6,)}     # (botctl.MODES' game-mode numbers)
SUICIDES = {"suicide", "fall", "drowned", "crushed", "telefrag", "self-destruct", "blew themselves up", "explosion with nobody near"}


GHOSTS_ON = [False]
MISSION = [None]                # a Christmas Co-op Mission (missions.py) instead of the Horde's climb
CHAIN_IDS_NEEDED = 22                            # player ids a mission may take (a host game has 29; see KEEP_HOST below)
CLONE_WAIT, CLONE_GAP, CLONE_REJOIN = 4.0, 1.0, 15.0   # the clones step: wait for the cleared field, then one clone a second
FORCE_KIND = [None]             # a mission step's own enemy kind (the Jack Frost fight: snowmen only), else the mission's mix
BOSS_NAMES = "Krampus|Nutcracker|Jack Frost|Frost Clone \\d+|Gingerbread Man|Santa|Bob Graham|Dr\\. Death|Headless Demon|Healer"
DOC_AT = 30                     # the Horde (ghosts): Dr. Death joins at this many kills (18 Nov, the user: "spawn the Healer in at 30
                                #  kills"; was half the kill target) and heals the zombies near him
DOC_HP, DOC_REGEN = 60, 0.3     # his health (a zombie's is 10) and, in the twin-boss finale, his own health back a second


HALLOW = [False]                # the Halloween props are in this game (and every player's game has the Halloween files)


def HALLOWEEN_ON():
    """the Horde's Halloween look (props, fog, skeletons, Bob Graham's pumpkin head): halloween_settings.json {"props": false} turns the props off"""
    try:
        import json as _j
        return bool(_j.loads((HERE / "halloween_settings.json").read_text()).get("props", True))
    except (OSError, ValueError, AttributeError):
        return True


def halloween_ok(users):
    """the Halloween files (zombie\\*.NWX, *.ITM, the map's props) reach every player: alone, or the mod server sends them
    (a BotLauncher.exe built with this modserver.py; the old one doesn't, and a friend's game without the props' object
    list would not match the host's)"""
    if not (HERE / "zombie" / "halloween.json").exists():
        return False
    if users <= 1:
        return True
    try:
        import urllib.request, json as _j
        with urllib.request.urlopen("http://127.0.0.1:8765/manifest.json", timeout=5) as r_:
            return bool(_j.load(r_).get("halloween"))
    except Exception:
        return False


def load_mission(a):
    """--mission <id>, or the mission the launcher's Tools tab picked a moment ago (state/next_mission.json, used once)"""
    import json as _j
    mid = a.mission
    f = HERE / "state" / "next_mission.json"
    if not mid:
        try:
            d = _j.loads(f.read_text())
            if time.time() - float(d.get("t", 0)) < 600:
                mid = d.get("id")
        except (OSError, ValueError, AttributeError):
            pass
    try:
        f.unlink()
    except OSError:
        pass
    if not mid:
        return None
    import missions
    return missions.get(mid)


def plan(k):
    """(tier name, how many bots) the enemy side has at k kills (the survivor's kills)."""
    t = [t for t in TIERS if k >= t["kills"]][-1]
    if GHOSTS_ON[0] and TIERS is not COUNTS and TIERS[0].get("speed") is not None:     # melee ghost zombies: their own steps
        return t["name"], min(ghost_cap(), scale_ghosts([n for kk, n in GHOST_MELEE_STEPS if k >= kk][-1]))
    c = [c for c in COUNTS if k >= c["kills"]][-1]                   # the same table, except for Melee zombies
    n = c["count"] + sum(1 for j in c["joins"] if k >= j)
    if GHOSTS_ON[0]:
        # (15 Nov, the user: ghost zombies "way harder than the bots" at the same difficulty - twice the bots' numbers, up to 13
        #  Nightmare ghosts against 10 bots. They come in the bots' own numbers now; "Max zombies" still caps them.)
        n = min(ghost_cap(), GHOST_MAX[0], n)
    return t["name"], n


def level_flag(level, ghost=False):
    """what a zombie's level flag says: the bot difficulty, +strong, and for ghosts +walk / +speed=x (melee tiers; a bot's brain
    reads everything after the first + as one word, so a bot never gets them)"""
    t = TIER.get(level, {})
    out = t.get("skill", level) + ("+strong" if t.get("strong") else "")
    if not ghost: return out
    if t.get("walk"): out += "+walk"
    if t.get("speed") is not None: out += f"+speed={t['speed']:g}"
    return out




def tier_strong(level):
    return bool(TIER.get(level, {}).get("strong"))


DARK = False                    # Dark Mode: close encounters in the dark (--dark)
XMAS = False                    # the Christmas Horde (--christmas): elves, snow, and Santa at the end
MELEE = False                   # Melee Zombies: the Horde is Mary and Two Feathers, with knives and fists only (--melee); every ammo box is a knife, TNT or a canteen
MELEE_CHARS = ["mary", "twofeathers"]


def spec(name, char, team, level, display="", behaviour=None):
    if behaviour:                                                       # Santa: his own behaviour, nothing else
        return ":".join([name, char, team, "lv_" + level, "nightmare", behaviour]) + ("=" + display if display else "")
    strong_tier = level
    level = TIER[level]["skill"] if level in TIER else level          # the tier's bot difficulty
    tags = [name, char, team, "lv_" + level]
    if level in ("nightmare", "hell"):
        tags += ["nightmare"]
    if MELEE:
        tags += ["zombie_boxer" if char == "mary" else "zombie_knifer"]  # Mary: mostly fists, now and then the knife; Two Feathers: the knife
                                                                        # while he has one, else fists; never a gun or TNT, and no hesitation
        if tier_strong(strong_tier):
            tags += ["wp_8s1s"]                                         # strong with the knife and the fists
    elif DARK:
        tags += ["closeq"]                                              # shotguns, knife and fists only
        if tier_strong(strong_tier):
            tags += ["wp_4s5s6s8s1s7w2w3w9w"]                           # strong where it counts, no TNT, weak with the guns it never carries
    elif tier_strong(strong_tier):
        tags += ["wp_" + "".join(f"{i}s" for i in range(1, 10))]       # strong with every weapon
    return ":".join(tags) + ("=" + display if display else "")


def ev(msg):
    """Print a game event and keep it in horde_logs\\events.txt."""
    line = f"{time.strftime('%H:%M:%S')} {msg}"
    print(line, flush=True)
    try:
        with open(LOGS / "events.txt", "a") as f:
            f.write(line + "\n")
    except OSError:
        pass


def close_strays(wait=20):
    """No bot of this game has started yet, so any open game copy is a leftover (or still closing): end it and wait
    until it is really gone, because the Survival/Christmas look can't go into Common.kpf while the game is open.
    True when no game copy is left."""
    import teamcolors
    if not teamcolors.running(): return True
    subprocess.run(["taskkill", "/IM", "OutlawsAHOM.exe", "/F"], capture_output=True, creationflags=NOWIN)
    end = time.time() + wait
    while teamcolors.running() and time.time() < end:
        time.sleep(1)
    time.sleep(1)
    return not teamcolors.running()


def kill(procs, logs):
    for p in procs:
        subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True, creationflags=NOWIN)
    for path in logs:
        try:
            for pid in re.findall(r"\(pid (\d+)\)", Path(path).read_text(errors="replace")):
                subprocess.run(["taskkill", "/PID", pid, "/F"], capture_output=True, creationflags=NOWIN)
        except OSError:
            pass


RUN = uuid.uuid4().hex[:8]                      # this game's id: its bots only obey its own leave flags

# ---- Co-op Missions one after another without leaving the game (19 Nov). When a mission is won and another follows, this
# script ends but the host bot stays: its game copy and its botctl keep running, and state/chain_host.json says which it is.
# The next mission's horde.py (the launcher starts it at once, without closing anything) takes that host over: the same
# RUN (the host obeys that run's flags), the host hosts the new mission's map in its own copy (state/session_<profile>.json,
# as rotation.py does) and state/next_lobby.json takes your game there by itself (follow.py). The host's output goes to its
# log file directly (opened for appending only), so it outlives this script and the next one can empty the log.
CHAIN_HOST = HERE / "state" / "chain_host.json"
KEEP_HOST = [False]


def append_fd(path):
    """a file descriptor that only appends to path (FILE_APPEND_DATA: every write lands at the end, even after another
    process empties the file), for a child's output; None if Windows won't give one"""
    try:
        import ctypes, msvcrt
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateFileW.restype = ctypes.c_void_p
        h = k32.CreateFileW(str(path), 0x4 | 0x100000, 0x7, None, 4, 0x80, None)   # FILE_APPEND_DATA|SYNCHRONIZE, share all, OPEN_ALWAYS
        if not h or h == ctypes.c_void_p(-1).value:
            return None
        return msvcrt.open_osfhandle(h, os.O_WRONLY | os.O_APPEND)
    except Exception:
        return None


def pid_alive(pid):
    try:
        r = subprocess.run(["tasklist", "/FI", f"PID eq {int(pid)}", "/NH"], capture_output=True, text=True, timeout=15, creationflags=NOWIN)
        return str(int(pid)) in r.stdout
    except Exception:
        return False


class Adopted:
    """the last mission's host bot (its botctl process), standing in for a Popen"""
    def __init__(self, pid):
        self.pid, self._dead_at = int(pid), 0.0

    def poll(self):
        if time.time() - self._dead_at < 5.0:
            return None
        self._dead_at = time.time()
        return None if pid_alive(self.pid) else 1


def chained_host():
    """the host bot the last mission left running, if it is still there: {run, pid, log, t}, else None"""
    try:
        import json as _j
        ch = _j.loads(CHAIN_HOST.read_text())
        CHAIN_HOST.unlink()
    except (OSError, ValueError):
        return None
    if time.time() - float(ch.get("t", 0)) > 300 or not pid_alive(ch.get("pid", 0)):
        return None
    return ch




def reward(level, bot_pids):
    """After the last bot of a tier leaves: top the human's armor up (giveplates.py, in the background)."""
    amount = PLATES.get(level)
    if not amount:
        return
    pids = set(map(str, bot_pids))
    for lg in LOGS.glob("*.log"):
        try:
            pids |= set(re.findall(r"\(pid (\d+)\)", lg.read_text(errors="replace")))
        except OSError:
            pass
    ev(f"the {level} bots are gone: {'light' if amount == 50 else 'medium' if amount == 100 else 'heavy'} boiler plate for you")
    subprocess.Popen([sys.executable, str(HERE / "giveplates.py"), str(amount), "--exclude", ",".join(sorted(pids))],
                     cwd=str(HERE), creationflags=NOWIN)


ON_END = []          # called the moment a match is over (before the 20 s on the scoreboard): the game goes to the rankings then, not after the bots have left


def end_match(why):
    """Ask the host game to end the match itself (its own time/kill limits), then give everyone ~20 s on the scoreboard."""
    for fn in ON_END:
        try:
            fn()
        except Exception as e:
            print("end hook:", e, flush=True)
    try:                                             # the scoreboard is coming up: the music and storms stop
        (HERE / "state").mkdir(exist_ok=True)
        (HERE / "state" / f"music_stop_{RUN}").write_text(why)
        ev(f"match over ({why}): the music, wolves and storms stop")
    except OSError:
        pass
    try:
        (HERE / "state").mkdir(exist_ok=True)
        (HERE / "state" / f"end_{RUN}.flag").write_text(why)
    except OSError:
        return
    # (21 Nov, the user: the next mission has to come quickly) a won mission with another after it: 3 s on the scoreboard
    time.sleep(3 if MISSION[0] and why == "win" and MISSION[0].get("n", 4) < 4 else 20)


GHOSTS = set()       # the ghost zombies' processes (they have no game window to wait for)
LEAVE_GAP = 3.0      # seconds between one bot starting to leave and the next (the others keep fighting meanwhile)
JOIN_GAP = 3.0       # seconds between one new bot being let into the game and the next


def leave_then_kill(procs, logs, wait=6.0, stagger=False):
    """Ask the bots to leave the match through the game's pause menu (so the others see them go, not a frozen body), wait
    until their game windows have closed (up to `wait` seconds), then end whatever is still running."""
    state = HERE / "state"
    tags, pids = [], []
    for path in logs:
        try:
            tags.append(Path(path).stem.rsplit("_", 1)[1])
            pids += re.findall(r"\(pid (\d+)\)", Path(path).read_text(errors="replace"))
        except (OSError, IndexError):
            pass
    try:
        state.mkdir(exist_ok=True)
        for n, t in enumerate(tags):
            if stagger and n:
                time.sleep(LEAVE_GAP)
            (state / f"leave_{RUN}_{t}.flag").write_text("leave")
    except OSError:
        pass
    end = time.time() + wait
    ghosts = [p for p in procs if p in GHOSTS]
    while time.time() < end and ghosts and any(p.poll() is None for p in ghosts):     # ghosts leave by themselves (the disconnect message)
        time.sleep(0.25)
    while time.time() < end and pids:
        try:
            out = subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True, creationflags=NOWIN).stdout
        except OSError:
            break
        alive = set(re.findall(r'"OutlawsAHOM\.exe","(\d+)"', out))
        if not any(p in alive for p in pids):
            break
        time.sleep(0.5)
    kill(procs, logs)
    for t in tags:
        try:
            (state / f"leave_{RUN}_{t}.flag").unlink()
        except OSError:
            pass
        try:
            (state / f"go_{RUN}_{t}.flag").unlink()
        except OSError:
            pass


def pump(p, path):
    with open(path, "w", errors="replace") as f:
        for line in p.stdout:
            f.write(line)
            f.flush()


# Sanctuary's .rcm (inside the game's archives) lists no Team Play mode. For a Horde game we put a loose copy beside the
# game with the M added (a loose .rcm overrides the archives) and take it away again when the game is over, so normal
# games on Sanctuary are untouched.
TEAM_RCM = {"town_2p": (b"MODES:  DKCT", b"MODES:  DKCTM")}


BOT_NAME = re.compile(r"^((Zombie|Skeleton|Bot|Host Bot|Elf|Santa|Gingerbread|Snowman|Nutcracker|Present)( \d+| #\d{3}| No\. \d{3})?|Bob Graham|Dr\. Death|Headless Demon|Healer|Frost Clone \d+)$")      # (ghost zombies: "Zombie #001", "Bot No. 001", "Elf No. 001")
SANTA = "Santa"                 # the Christmas Horde's boss, as the kill feed names him
SANTA_EARLY = 12                # kills before the target at which Santa's game starts (it waits in the lobby)
DEMON_AT = 40                   # the Horde: the Headless Demon comes at this many kills, however many players (19 Nov, the user)
SANTA_LEAD = 1                  # kills before the target at which he is let out: his entrance and the kill count's delay take a kill's worth of time


def tk_ok():
    """can this Python open a window (tkinter with its Tcl/Tk)? Some Pythons are installed without it."""
    try:
        r = subprocess.run([sys.executable, "-c", "import tkinter; tkinter.Tcl()"], capture_output=True, timeout=15, creationflags=NOWIN)
        return r.returncode == 0
    except Exception:
        return False


def banner(text, secs=3.5, xmas=False, sound=True):
    """The big banner over your game, drawn by tierhud.py into its window (made when the match started: a new window
    opened mid-match makes the game let go of the keys you are holding). The thunder (Santa's laugh at Christmas): announce.py."""
    try:
        (HERE / "state" / f"banner_{RUN}.txt").write_text(f"{time.time():.3f}|{secs}|{1 if xmas else 0}|{text}")
    except OSError:
        pass
    if not sound: return
    try:                                    # the thunder; at Christmas Santa's "HO HO HO!" instead (christmas\\music\\hohoho.wav)
        subprocess.Popen([sys.executable, str(HERE / "announce.py"), "--hohoho" if xmas else "--sound-only"], cwd=str(HERE), creationflags=NOWIN)
    except OSError:
        pass


REACH_COUNT = 3.0                # seconds a player out of the zombies' reach gets before taking damage (ghost zombies only)


def warn_banner(text, secs=1.2):
    """the banner over your game (tierhud.py), without the thunder: the out-of-reach warning and its count"""
    try:
        (HERE / "state" / f"banner_{RUN}.txt").write_text(f"{time.time():.3f}|{secs}|0|{text}")
    except OSError:
        pass


def santa_down(text):
    """True when a player (not one of our bots) has killed Santa, from an observer's kill-feed lines."""
    for line in re.findall(r"^FMT: G (.+)$", text, re.M):
        m = re.match(r"^(.+) (?:killed|blew up) (.+)!$", line.strip())
        if m and m.group(2) == SANTA and not BOT_NAME.match(m.group(1)) and m.group(1) != "You":
            return True
    return False


def survivors(text):
    """The players (anyone who isn't one of our bots) an observer has seen in the kill feed: the Survivors team."""
    names = set()
    for line in re.findall(r"^FMT: G (.+)$", text, re.M):
        line = line.strip()
        m = re.match(r"^(.+) (?:killed|blew) you(?: up)?!$", line)
        if m:
            names.add(m.group(1)); continue
        m = re.match(r"^(.+) (?:killed|blew up) (.+)!$", line)
        if m:
            names.update(n for n in m.groups() if n != "You")
    return {n for n in names if n != "You" and not BOT_NAME.match(n) and n.lower() not in ("himself", "herself", "themselves")}


def survivor_kills(text):
    """Kills by players (anyone who isn't one of our bots) of our bots, from an observer's kill-feed lines."""
    n = 0
    for line in re.findall(r"^FMT: G (.+)$", text, re.M):
        line = line.strip()
        m = re.match(r"^(.+) (?:killed|blew) you(?: up)?!$", line)      # the observer itself was the victim
        if m:
            if not BOT_NAME.match(m.group(1)) and m.group(1) != "You": n += 1
            continue
        m = re.match(r"^(.+) (?:killed|blew up) (.+)!$", line)
        if m and not BOT_NAME.match(m.group(1)) and BOT_NAME.match(m.group(2)):
            n += 1
    return n


def bot_suicides(text):
    """Our bots' own deaths that were no one's kill (a fall, a self-destruct, ...), from an observer's kill-feed lines."""
    n = 0
    for line in re.findall(r"^FMT: G (.+)$", text, re.M):
        m = re.match(r"^(.+?) (?:committed suicide|died from a fall|drowned|got crushed|got telefragged|self-destructed)!$", line.strip())
        if m and BOT_NAME.match(m.group(1)):
            n += 1
    return n


def team_rcm_for(level):
    if level not in TEAM_RCM:
        return
    import atexit
    import lvt
    path = lvt.GAME_DIR / f"{level}.rcm"
    if path.exists():
        if b"M" not in (re.search(rb"MODES:\s*(\w+)", path.read_bytes()) or [b"", b""])[1].upper():
            HORDE_MODE[level] = "ctf"                       # the player's own file has no Team Play: CTF teams instead
        return                                              # the player's own file: leave it alone
    data = lvt.read_from_labs(f"{level}.rcm")
    old, new = TEAM_RCM[level]
    if not data or old not in data:
        HORDE_MODE[level] = "ctf"
        return
    path.write_bytes(data.replace(old, new))
    atexit.register(lambda: path.unlink() if path.exists() else None)
    print(f"added Team Play to {level}.rcm for this game", flush=True)


def main():
    global RUN
    ap = argparse.ArgumentParser()
    ap.add_argument("--map", default="drygulch")
    ap.add_argument("--minutes", type=float, default=30)
    ap.add_argument("--wave", type=float, default=45, help="seconds between new bots")
    ap.add_argument("--max", type=int, default=7, help="most horde bots at once")
    ap.add_argument("--ramp", type=float, default=0, help="testing: pretend one extra kill every this many seconds")
    ap.add_argument("--hero", action="store_true", help="a red bot plays your part (testing)")
    ap.add_argument("--fps", default="60")
    ap.add_argument("--window-mode", default=os.environ.get("HORDE_WINDOWS", "hidden"))
    ap.add_argument("--users", type=int, default=0, help="humans to wait for before the first wave")
    ap.add_argument("--challenge", action="store_true", help="Challenge mode: Normal bots to start, Hard at 5 kills, Nightmare at 10, Hell at 15")
    ap.add_argument("--melee", action="store_true", help="Melee only: knives and fists; every gun and ammo pickup on the map is a knife; the Horde is Mary and Two Feathers")
    ap.add_argument("--dark", action="store_true", help="Dark Mode: a flashlight in a black map, shotguns/knives/TNT only, bots fight up close")
    ap.add_argument("--hell", action="store_true", help="at 25 kills the bots become Hell bots")
    ap.add_argument("--private", action="store_true", help="a private game: the game's own private lobby, not offered to friends' apps")
    ap.add_argument("--christmas", action="store_true", help="the Christmas Horde: elves, snow, trees, Christmas music, and Santa at the end")
    ap.add_argument("--classic", action="store_true", help="plain Outlaws style: no zombie skins, colours, darkness, music or storms; bots are called Bot 1, Bot 2 ...")
    ap.add_argument("--xmas-top", default="nightmare", choices=XMAS_TOPS, help="the Christmas Horde's final tier: hell (at 30 kills), nightmare (25), hard (25) or normal (25)")
    ap.add_argument("--ghost-max", type=int, default=16, help="ghost zombies at the top of the climb (4-25; default 16)")
    ap.add_argument("--ghosts", action="store_true", help="the zombies are ghost players (netre\\ghost.py, no game copy each); the host bot and Santa stay bots")
    ap.add_argument("--ranked", action="store_true", help="save kills/deaths of the red player in ranked.db")
    ap.add_argument("--player", default="", help="ranked: the player's name")
    ap.add_argument("--character", default="", help="ranked: the character the player uses")
    ap.add_argument("--mission", default="", help="a Christmas Co-op Mission (missions.py id or number) instead of the Horde")
    a = ap.parse_args()
    MISSION[0] = load_mission(a)
    if MISSION[0]:                                        # (25 Nov: what the launcher's Online tab shows for this game - modserver.mission_now)
        try:
            import missions as _ms_
            import json as _js_
            (HERE / "state" / "mission_live.json").write_text(_js_.dumps({"id": MISSION[0].get("id"), "label": "Christmas " + _ms_.label(MISSION[0]),
                                                                          "max_humans": 4, "t": time.time()}))
            import atexit as _ax_
            _ax_.register(lambda: None if KEEP_HOST[0] else (HERE / "state" / "mission_live.json").unlink(missing_ok=True))
        except Exception:
            pass
    if MISSION[0]:                                        # a mission is the Christmas Horde's world with ghost elves, on its own map
        a.christmas, a.ghosts, a.classic, a.dark, a.challenge, a.melee, a.ranked = True, True, False, False, False, False, False
        a.map = MISSION[0]["map"]
        print(f"CO-OP MISSION {MISSION[0]['n']}: {MISSION[0]['title']} on {a.map}", flush=True)
    ADOPT = chained_host() if MISSION[0] else None
    if ADOPT:                                             # the last mission's host bot is still up: we go on in its game
        RUN = ADOPT["run"]
        print(f"going on from the last mission: its host bot (pid {ADOPT['pid']}) hosts {a.map} next", flush=True)
        for f in (HERE / "state").glob(f"*{RUN}*"):       # that run's flags and counts (end_, go_, deaths_ ...) start over
            try:
                f.unlink()
            except OSError:
                pass
    global DARK, MELEE, XMAS
    XMAS = bool(a.christmas) and not a.classic
    DARK = bool(a.dark) and not XMAS
    MELEE = bool(a.melee)
    GHOSTS_ON[0] = bool(a.ghosts)
    GHOST_MAX[0] = max(4, min(GHOST_TOP, a.ghost_max))
    set_tiers(a.hell, a.challenge, MELEE)
    if XMAS:
        os.environ["BOT_NO_KNIFE_THROW"] = "1"            # (16 Nov) only Santa throws knives: the elf bots stab (brain.fire_button)
    if XMAS and not MELEE and not a.challenge:
        set_xmas_tiers("hell" if (a.hell and a.xmas_top == "nightmare") else a.xmas_top)     # ("Include Hell" ticked: Hell on top)
        print("Christmas climb:", ", ".join(f"{t['name']} at {t['kills']}" + (f" (+1 at {', '.join(map(str, t['joins']))})" if t['joins'] else "") for t in TIERS), flush=True)
    if XMAS:                                              # no elf Sanchez (SANCHEZ.SPX stays plain): the elves are everyone else
        for t in TIERS + COUNTS:
            t["pool"] = [c for c in t["pool"] if c != "sanchez"] or ["james", "bob"]
        POOL.clear(); POOL.update({t["name"]: t["pool"] for t in TIERS})
    team_rcm_for(a.map)
    if XMAS:
        import atexit
        import darkitems
        darkitems.patch(a.map, log=lambda m: print(m, flush=True), mode="christmas_melee" if MELEE else "christmas",
                        mission=bool(MISSION[0]), keep_others=bool(ADOPT))   # Christmas trees (a mission: knocked over, a wrecked sleigh, zone markers)
        # (a chained mission: its map's files went in with the first mission's and stay - nothing is taken out and written again)
        if MISSION[0] and not ADOPT:
            # (23 Nov, the user: Mission 2 came with none of its toys and no sleigh) the game only picks up loose map files that
            # were there when it started: the later missions' maps go in now, while the games are still to start
            import missions as _ms
            for m_ in _ms.MISSIONS:
                if m_.get("n", 0) > MISSION[0].get("n", 0) and str(m_["map"]).lower() != str(a.map).lower():
                    try:
                        darkitems.patch(m_["map"], log=lambda m: print(m, flush=True), mode="christmas", mission=True, keep_others=True)
                    except Exception as e:
                        print(f"could not prepare {m_['map']} for its mission: {e}", flush=True)
        atexit.register(lambda: None if KEEP_HOST[0] else darkitems.restore())     # (kept for the next mission: they stay)
    elif MELEE:
        import atexit
        import darkitems
        darkitems.patch(a.map, log=lambda m: print(m, flush=True), mode="melee")      # every ammo box -> a knife, TNT or a canteen
        atexit.register(darkitems.restore)
    elif DARK:
        import atexit
        import darkitems
        os.environ["BOT_DARK"] = "1"                      # the bots (their own processes) skip rifles, pistols, gatlings and their ammo
        darkitems.patch(a.map, log=lambda m: print(m, flush=True))
        atexit.register(darkitems.restore)
    else:
        try:
            import darkitems
            darkitems.restore()                           # loose files left by a Dark Mode game that was cut short
            if not a.classic and not MISSION[0] and HALLOWEEN_ON() and halloween_ok(a.users):
                import atexit
                darkitems.patch(a.map, log=lambda m: print(m, flush=True), mode="halloween")   # jack-o'-lanterns, pumpkins, cobwebs
                atexit.register(darkitems.restore)
                HALLOW[0] = True
        except Exception:
            pass
    LOGS.mkdir(exist_ok=True)
    for old_log in LOGS.glob(f"{a.map}_*.log"):         # last game's logs must not be read as this game's (kill counts!)
        try:
            old_log.unlink()
        except OSError:
            pass
    # Only one Survival game at a time: an old horde.py that survived a "close all windows" shares our log files and
    # would end our bots (its kill reads the game pids from the same logs). End any other one first.
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command",
                        "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'horde\\.py|lms\\.py' -and "
                        f"$_.ProcessId -ne {os.getpid()} -and $_.ProcessId -ne {os.getppid()} -and $_.Name -match 'python' }} | "
                        "ForEach-Object { taskkill /PID $_.ProcessId /T /F | Out-Null }"],
                       capture_output=True, timeout=60, creationflags=NOWIN)
    except (OSError, subprocess.SubprocessError):
        pass
    for f in list((HERE / "state").glob("leave_*.flag")) + list((HERE / "state").glob("go_*.flag")) + list((HERE / "state").glob("level_*.flag")) + list((HERE / "state").glob("zreach_*.txt")) + list((HERE / "state").glob("punish_*.txt")):          # leftovers from an earlier run
        try:
            f.unlink()
        except OSError:
            pass
    procs, logs = [], []
    count = [0]

    release_lock, last_release = threading.Lock(), [0.0]

    def release_when_ready(name, p, log):
        """A new bot waits in the lobby (not spawned) until its brain is attached and running; then bots are let in one at
        a time, JOIN_GAP seconds apart, so none stands around helpless and they don't all appear at once."""
        end = time.time() + 150
        while time.time() < end and p.poll() is None:
            try:
                if "fighting;" in log.read_text(errors="replace"):
                    break
            except OSError:
                pass
            time.sleep(0.5)
        time.sleep(1.5)
        with release_lock:
            wait = last_release[0] + JOIN_GAP - time.time()
            if wait > 0:
                time.sleep(wait)
            try:
                (HERE / "state" / f"go_{RUN}_{name}.flag").write_text("go")
            except OSError:
                pass
            last_release[0] = time.time()

    ghost_n = [0]
    GHOST_PROCS = set()

    def start_ghost(name, char, level, display, hold, extra=None, gname=None):
        """A zombie as a ghost player: ghost.py joins the host bot's game; this script talks to it through the same flag files
        (go / level / leave) as to a bot, and its log says "fighting;", "died" and "FMT: G <killer> killed you!" like a bot's."""
        # botctl\ghost.py only when it is the ghost player (a flat copy): in the repository it is the first prototype, which can't
        # get past the lobby (launcher.ghost_script)
        script = next((p for p in (HERE / "ghost.py", HERE / "netre" / "ghost.py") if p.exists() and b"class FightWalker" in p.read_bytes()),
                      HERE / "netre" / "ghost.py")
        ghost_n[0] += 1
        n = ghost_n[0]
        gname = gname or f"{'Bot' if a.classic else 'Elf' if XMAS else 'Zombie'} {n}"          # like the bots' own names: Zombie 1, Zombie 2 ...
        skeleton = HALLOW[0] and not extra and n % 3 == 0 and (HERE / "zombie" / "SKELJAME.SPX").exists()   # every third zombie a skeleton
        if skeleton:
            char = "james"
            if gname.startswith("Zombie "):
                gname = "Skeleton " + gname.split(" ", 1)[1]                 # (named for what it is)
        log = LOGS / f"{a.map}_{name}.log"
        env = dict(os.environ, PYTHONUNBUFFERED="1", GHOST_RUN=RUN, GHOST_TAG=name, GHOST_STATE_DIR=str(HERE / "state"),
                   GHOST_HOLD="1" if hold else "0", GHOST_FRIENDS=r"(Zombie|Skeleton|Bot|Host Bot|Elf|Santa|Gingerbread|Snowman|Nutcracker|Present)( \d+| #\d{3}| No\. \d{3})?$|GhostBot|" + BOSS_NAMES,
                   GHOST_TEAM="blue", GHOST_NAME=gname, GHOST_CONN=gname, GHOST_CHAR=char, GHOST_LEVEL=a.map,
                   GHOST_DIFFICULTY=(TIER[level]["skill"] if level in TIER else level), GHOST_WEAPONS="melee" if MELEE else "normal",
                   GHOST_SPEED_SCALE=f"{TIER.get(level, {}).get('speed', 1.0):g}", GHOST_NO_SPRINT="1" if TIER.get(level, {}).get("walk") else "0",
                   GHOST_STARTWEAPON="1", GHOST_CHARSTATS="1", GHOST_NO_KNIFE_THROW="1" if XMAS else "0",
                   GHOST_MOANS="" if (a.classic or XMAS) else ",".join(f"ZMOAN{k}.WAV" for k in range(1, 10)), GHOST_STAY="43200", GHOST_WAIT_HOST="0",
                   GHOST_FEED="1" if n == 1 else "0", GHOST_SLOT=format(0x1802 + (n - 1) * 0x100, "x"), GHOST_ID=format(0x4e + n - 1, "x"), GHOST_LOG=f"horde_{name}",
                   GHOST_BIND=f"127.0.0.{1 + n}" if n > 1 else "0.0.0.0")
        if MISSION[0]:                                   # (a Co-op Mission's enemies hop any ledge to get at you: nav GHOST_JUMP_UP)
            env.setdefault("GHOST_JUMP_UP", "17")
            env.setdefault("GHOST_WATER_KNIFE", "1")
            env["GHOST_TAUNTS"] = "0"                    # (23 Nov, the user: no taunts from the enemies after a kill in the missions)
            # (25 Nov, the user: the Christmas Missions' difficulty slider - state\mission_difficulty.json, from the launcher's
            #  missions window: 1.0 as designed, 0.25 at the bottom, 1.25 at the top) every enemy and boss; ghost.py works out
            #  their aim, pace and strafing from it (the hostage and the present piles go by their own)
            try: env["GHOST_MISSION_DIFF"] = f"{float(__import__('json').loads((HERE / 'state' / 'mission_difficulty.json').read_text()).get('mult', 1.0)):g}"
            except (OSError, ValueError, AttributeError): env["GHOST_MISSION_DIFF"] = "1"
            if re.match(r"(Elf|Snowman|Nutcracker|Gingerbread) \d+$", str(gname or display or "")):
                env.setdefault("GHOST_LOST_LEAVE", "25")    # (an ordinary enemy lost 25 s - nobody it can get to - leaves; a fresh one comes)
            import missions
            ne_ = missions.MAP_TWEAKS.get(str(a.map).lower(), {}).get("no_enter")
            if ne_:                                      # (the big building on Orleans' ice: nobody goes up, anyone up there comes down)
                env.setdefault("GHOST_NO_ENTER", ",".join(str(i) for i in ne_))
            ns_ = missions.MAP_TWEAKS.get(str(a.map).lower(), {}).get("no_starts")
            if ns_:                                      # (a ghost's own spawn points: not in Sanctuary's jail cells either)
                env.setdefault("GHOST_NO_STARTS", ";".join(f"{x},{z}" for x, z in ns_))
        env.update(extra or {})
        if skeleton:
            env["GHOST_MODEL"] = "skeljame.nwx"
        p = subprocess.Popen([sys.executable, "-u", str(script), "127.0.0.1", "5069"], cwd=str(script.parent), env=env,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace", creationflags=NOWIN)
        threading.Thread(target=pump, args=(p, log), daemon=True).start()
        procs.append(p)
        logs.append(log)
        GHOST_PROCS.add(p); GHOSTS.add(p)
        ev(f"started {name} as the ghost {gname} ({char}, {level})")
        if hold:
            threading.Thread(target=release_when_ready, args=(name, p, log), daemon=True).start()
        return p, log

    def start(name, char, team, level, host=False, display="", hold=False, behaviour=None, release=True, extra=None, gname=None):
        if a.ghosts and not host and behaviour is None and name.startswith("hd"):
            return start_ghost(name, char, level, display, hold and release, extra=extra, gname=gname)
        s = spec(name, char, team, level, "Host Bot" if host else display, behaviour)
        log = LOGS / f"{a.map}_{name}.log"
        cmd = [sys.executable, "-u", str(HERE / "botctl.py"), s, "--slot", str(count[0]), "--fps", a.fps, "--size", "320x180",
               "--fight", "--no-taunts", "--window-mode", a.window_mode, "--no-bench"]
        cmd += ["--host", "--map", a.map, "--mode", HORDE_MODE.get(a.map, "team"), "--wait-for", str(a.users), "--maxplayers", str(GAME_MAX_PLAYERS)] + (["--private"] if a.private else []) if host \
            else ["--join", "127.0.0.1"]
        count[0] += 1
        env = dict(os.environ, PYTHONUNBUFFERED="1", BOT_TAG=name, BOT_RUN=RUN, BOT_MAP=a.map)
        if a.map in HORDE_MODE:
            env["BOT_NO_FLAGS"] = "1"
        if a.player:
            env.update(BOT_STATS_PLAYER=a.player, BOT_STATS_NOSAVE="1", BOT_STATS_CHAR=a.character or "")
        if name == "hero":
            env["BOT_STATS_HIDE"] = "1"
        if name.startswith("hd") and not host:       # every Horde bot logs the game's messages: its own "X killed you!" counts
            env["BOT_TRACEFMT"] = "1"
        if name == "hd2":
            env["BOT_PROBE_TEXT"] = "1"
        if name in OBSERVERS:                         # in-game zombies that read the kill feed (the host in the lobby sees none)
            env.update(BOT_STATS_OBS="1", BOT_TRACEFMT="1", BOT_STATS_NOSAVE="1", BOT_STATS_PLAYER=a.player or "human", BOT_STATS_CHAR=a.character or "")
        if host:
            env["BOT_PASSIVE"] = "1"
        if hold:
            env["BOT_HOLD_JOIN"] = "1"
        if name == "hd1":
            env.update(BOT_TRACEFMT="1", BOT_LIMITS=f"999,{max(1, int(round(a.minutes)))}")   # the kill target moves with the players: horde.py ends the match
            if a.player:
                env["BOT_RANKED"] = "1"
            else:
                env.update(BOT_STATS_PLAYER="human", BOT_STATS_NOSAVE="1")
        fd = None
        if host and MISSION[0]:                       # (a mission's host may outlive this script: see CHAIN_HOST)
            try:
                open(log, "w").close()
            except OSError:
                pass
            fd = append_fd(log)
        if fd is not None:
            p = subprocess.Popen(cmd, cwd=str(HERE), env=env, stdout=fd, stderr=subprocess.STDOUT, creationflags=NOWIN)
            os.close(fd)
        else:
            p = subprocess.Popen(cmd, cwd=str(HERE), env=env, stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, errors="replace", creationflags=NOWIN)
            threading.Thread(target=pump, args=(p, log), daemon=True).start()
        procs.append(p)
        logs.append(log)
        ev(f"started {name} ({char}, {team}, {level})")
        if hold and release:
            threading.Thread(target=release_when_ready, args=(name, p, log), daemon=True).start()
        return p, log

    def adopt_host(ch):
        """the last mission's host bot hosts this mission's map in its own game copy. (Adopted, log) or (None, None)."""
        import json as _j
        hlog_ = Path(ch["log"])
        try: game_pids = re.findall(r"\(pid (\d+)\)", hlog_.read_text(errors="replace"))   # (its game copy: read before the log is emptied)
        except OSError: game_pids = []
        try:
            open(hlog_, "w").close()                  # (its output appends: the last mission's lines must not count here)
        except OSError:
            pass
        def status():
            for f in (HERE / "state").glob("status_*.json"):
                try:
                    st = _j.loads(f.read_text())
                except (OSError, ValueError):
                    continue
                if st.get("host") and time.time() - float(st.get("t", 0)) < 10:     # (its pid is the real python's, not Popen's)
                    return f.stem[len("status_"):], st
            return None, None
        def step(profile, **kw):
            (HERE / "state" / f"session_{profile}.json").write_text(_j.dumps(dict(kw, t=time.time())))
        prof, st = None, None
        end_ = time.time() + 20
        while time.time() < end_ and prof is None:
            prof, st = status()
            time.sleep(1)
        if prof is None:
            ev("the last mission's host bot doesn't answer: starting a new one")
            return None, None
        end_ = time.time() + 40                       # the score screen: Continue until it is at the main menu
        while time.time() < end_:
            prof, st = status()
            if st and st.get("state") == 0 and not st.get("lobby"):
                break
            if st and st.get("state") != 0:
                step(prof, action="continue")
            time.sleep(3)
        else:
            ev("the last mission's host bot never got back to the main menu: starting a new one")
            return None, None
        # (23 Nov, the user: Mission 3's last two clones kept joining and leaving, then the host bot dropped out. A host game
        #  hands out player ids 2..30 once each - every ghost that joins takes a new one and none comes back - and Missions 1
        #  and 2 had used 22 of them. With too few left the old host bot goes and a new one hosts this mission (all 29 ids);
        #  your game stays and joins it by itself (follow.py), as with the kept one. (23 Nov: killed while the score screen
        #  was still up, your game lost its host and never answered the join - it goes once it is back at the main menu.)
        if int(ch.get("top_id") or 0) + CHAIN_IDS_NEEDED > 30:
            ev(f"the last host game has handed out player ids up to {ch.get('top_id')}: a new host bot for this mission")
            for pid_ in [str(ch["pid"])] + game_pids:
                subprocess.run(["taskkill", "/PID", pid_, "/T", "/F"], capture_output=True, creationflags=NOWIN)
            time.sleep(2)
            return None, None
        mode = MODES_BOTCTL.get(HORDE_MODE.get(a.map, "team"), (5,))[0]
        for attempt in range(2):
            step(prof, action="host", map=a.map, mode=mode, maxplayers=GAME_MAX_PLAYERS)
            end_ = time.time() + 45
            while time.time() < end_:
                time.sleep(1)
                _p, st = status()
                if st and st.get("lobby") and st.get("state") in (8, 2):
                    p_ = Adopted(ch["pid"])
                    procs.append(p_)
                    logs.append(hlog_)
                    ev(f"the host bot hosts {a.map} in the same game (no restart)")
                    # (23 Nov, the user: Mission 2 had no music and no steps on screen) the kept host bot saw the player join
                    # last mission already, and says so only once: the music, the steps and the snow wait for this flag
                    t_adopt = time.time()
                    def human_in():                          # (once follow.py has your game in: state/follow_in.txt)
                        end_ = time.time() + 180
                        while time.time() < end_:
                            try:
                                if float((HERE / "state" / "follow_in.txt").read_text()) > t_adopt - 2: break
                            except (OSError, ValueError):
                                pass
                            time.sleep(0.5)
                        try: (HERE / "state" / f"human_{RUN}.flag").write_text("in")
                        except OSError: pass
                    threading.Thread(target=human_in, daemon=True).start()
                    return p_, hlog_
        ev("the last mission's host bot could not host this map: starting a new one")
        return None, None

    sid, began = uuid.uuid4().hex, time.time()


    forced = [0]                                      # kills the game itself reported at the end (see the matchend flag)

    def observer_text():
        """The log of the first in-game observer that has recognised the human and counts their kills exactly ('' if none)."""
        for nm in OBSERVERS:
            try:
                path = LOGS / f"{a.map}_{nm}.log"
                if path.stat().st_mtime < began - 2:          # last game's log (not rewritten yet): not ours
                    continue
                t = path.read_text(errors="replace")
            except OSError:
                continue
            if "exact counting" in t:
                return t
        return ""

    sent = [False]

    def save_ranked(final=False):
        """Kills = blue bots' deaths (only the red player kills them); deaths = the red player's deaths seen by hd1."""
        if not a.player:
            return
        import ranked
        kills = deaths = suicides = 0
        causes = {}
        otext = observer_text()
        exact = bool(otext)
        if otext:                                          # an observer read the game's own kill messages: exact numbers
            for cause in re.findall(r"^STATS: .+ died: (.+?) \(kills", otext, re.M):
                deaths += 1
                causes[cause] = causes.get(cause, 0) + 1
                if cause in SUICIDES:
                    suicides += 1
            for cause in re.findall(r"^STATS: .+ reclassified: (.+)$", otext, re.M):     # a death the game blamed on a zombie: it was a fall / own blast
                suicides += 1
                causes["killed by a player"] = max(0, causes.get("killed by a player", 1) - 1)
                causes[cause] = causes.get(cause, 0) + 1
            kills = len(re.findall(r"^STATS: .+ killed .+ \(kills \d+\)$", otext, re.M))
        for lg in logs:
            try:
                text = lg.read_text(errors="replace")
            except OSError:
                continue
            if lg.name.endswith("_hd1.log"):
                if not otext:
                    deaths = text.count("RANK: player died")
                    suicides = len(re.findall(r"RANK: player died near=0\b", text))
            if not exact and "_hd" in lg.name and not lg.name.endswith("_hd1.log"):
                kills += len(re.findall(r"^died$", text, re.M))
        kills = max(kills, forced[0])
        try:                                             # deathwatch.py counts the player's own deaths (the host's reading is unreliable)
            seen = int((HERE / "state" / f"deaths_{RUN}.txt").read_text().strip())
            if seen >= deaths:
                deaths = seen
        except (OSError, ValueError):
            pass
        try:
            ranked.save_session(sid, a.player, a.character, a.map, kills, deaths, began, suicides, a.ranked, causes or None)
        except Exception as e:                       # a locked or unreachable database must not stop the game
            print("ranked: could not save:", e, flush=True)
        if final and not sent[0]:                    # every finished game goes to the rankings relay (XP, levels, prestige) when one is set up
            sent[0] = True                           # once: the match-over hook sends it, the close-down after the bots left does not repeat it
            try:
                import relay, xp
                if relay.configured() and a.player:
                    ck = xp.char_key(a.character)
                    if ck:
                        ended = time.time()
                        kl = xp.kills_between(a.player, ck, began, ended)[:kills]       # never more than the game's own count
                        relay.submit_game(sid, a.player, ck, a.map, began, ended, kills, deaths, suicides, a.ranked,
                                          kl, max(0, kills - len(kl)), mode="horde")
            except Exception as e:
                print("relay: could not send the game:", e, flush=True)
        if final and a.ranked:                       # the finished ranked game goes to the online rankings (waits in an outbox if it can't)
            def push():
                try:
                    import onlinerank
                    ok = onlinerank.submit(sid, a.player, a.character, a.map, kills, deaths, began)
                    ev("ranked game sent to the online rankings" if ok else
                       ("ranked game saved; it will go to the online rankings once a GitHub token is set up (online_settings.json) or you are online"))
                except Exception as e:
                    ev(f"could not send the ranked game online: {e}")
            t = threading.Thread(target=push, daemon=True)
            t.start()
            t.join(30)

    import teamcolors
    themed = False
    try:
        # Survival look: Survivors (you, purple) vs Horde (green). Installed now, removed when the game ends.
        if a.classic:
            ev("classic Outlaws style: no mods")
            try:                                             # leftovers of an earlier modded run go (the game must be closed for the file edits)
                if not teamcolors.running() and teamcolors.dirty():
                    teamcolors.set_theme("off", quiet=True)
                import zombieskins as _zs
                _zs.off()
            except Exception:
                pass
        elif ADOPT and teamcolors.dirty():               # (the next mission in the same games: the look is in and the games are open)
            themed = True
            ev("the Christmas look stays in from the last mission")
        elif not close_strays() and teamcolors.running():
            ev("the game is already open, so the Survivors/Horde colors can't be installed this time")
        else:
            if teamcolors.dirty():
                teamcolors.set_theme("off", quiet=True)      # left over from a run that was cut short
            import zombieskins
            zombies = zombieskins.available(XMAS)       # zombie sprites (elves) keep their own colours: no team tint at all
            for attempt in range(3):                    # a game copy that pops up meanwhile (or is still closing) blocks the file
                themed = teamcolors.set_theme("on", quiet=True, neutral=("grinch_plain" if MISSION[0] else "grinch" if XMAS else "horde") if zombies else False,   # (a mission: the Christmas names, no tint - Mrs. Claus was green)
                                              dark=(("winter_ice" if MISSION[0].get("theme") == "ice" else "winter_night") if MISSION[0] else "winter") if XMAS else "flash" if a.dark else True)
                if themed or not teamcolors.running(): break
                ev("a game copy was open while the look went in: closing it and trying again")
                close_strays()
            if zombies:
                try:
                    zombies = zombieskins.on(XMAS)
                    if zombies:                                  # and take them out again whenever the game closes, whatever happens
                        subprocess.Popen([sys.executable, str(HERE / "zombieskins.py"), "watch"], cwd=str(HERE),
                                         creationflags=NOWIN | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))   # (19 Nov: no console window: it sat over the game)
                except Exception as e:
                    ev(f"could not install the zombie skins: {e}"); zombies = False
            if XMAS:
                ev((("Co-op Mission: Players (green) vs Christmas (red), the snowy world installed" if MISSION[0] else "Christmas Horde: Grinches (green) vs Elves (red), Santa and the snowy world installed") if zombies else "Christmas Horde: the snowy world installed, but no elves (christmas folder missing)")
                   if themed else "could not install the Christmas look")
            else:
                ev(("Survivors (purple tint) vs Horde (zombie skins) installed" if zombies else "Survivors (purple) vs Horde (green) installed") if themed else "could not install the Survivors/Horde colors")
        if not a.classic:
            try:                                           # creepy background loop and the odd distant storm, until the game ends
                xmas_music = HERE / "christmas" / "music" / "christmas_ambient.wav"
                if MISSION[0] and (HERE / "christmas" / "music" / "mission_ambient.wav").exists():
                    xmas_music = HERE / "christmas" / "music" / "mission_ambient.wav"    # (the missions: a dark, slow "God Rest Ye Merry Gentlemen")
                if XMAS and xmas_music.exists():
                    subprocess.Popen([sys.executable, str(HERE / "ambient.py"), RUN, str(os.getpid()), str(xmas_music)], cwd=str(HERE), creationflags=NOWIN)
                elif not XMAS and (HERE / "sounds" / "horde_ambient.wav").exists():
                    subprocess.Popen([sys.executable, str(HERE / "ambient.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN)
                if XMAS and (HERE / "snow.py").exists():        # falling snow over the game once you are in
                    subprocess.Popen([sys.executable, str(HERE / "snow.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN)
                if XMAS and (HERE / "santasteps.py").exists():  # Santa's booming footsteps, from where he is
                    subprocess.Popen([sys.executable, str(HERE / "santasteps.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN)
                if (HERE / "wolf.py").exists() and not XMAS:
                    subprocess.Popen([sys.executable, str(HERE / "wolf.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN)
                if (HERE / "deathsound.py").exists() and (HERE / "sounds" / "horde_death.wav").exists():
                    subprocess.Popen([sys.executable, str(HERE / "deathsound.py"), RUN, str(os.getpid()), a.map], cwd=str(HERE), creationflags=NOWIN)
                if (HERE / "tierhud.py").exists():
                    # (24 Nov, the user: a friend running the missions got the music but no step text and no banners: the
                    #  bots' Python on his PC has no tkinter, which tierhud.py needs. Then the launcher - its own Tk always
                    #  works - shows them instead: state/hud_request_<run>.txt, picked up by launchertools.)
                    if tk_ok():
                        subprocess.Popen([sys.executable, str(HERE / "tierhud.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN,
                                         stdout=subprocess.DEVNULL, stderr=open(LOGS / "tierhud_log.txt", "w"))
                    else:
                        ev("this PC's Python has no tkinter: the launcher shows the mission text and banners")
                        try: (HERE / "state" / f"hud_request_{RUN}.txt").write_text(str(os.getpid()))
                        except OSError: pass
                if (HERE / "welcome.py").exists():
                    subprocess.Popen([sys.executable, str(HERE / "welcome.py"), RUN, str(os.getpid())] + (["christmas"] if XMAS else []) + ([__import__("missions").label(MISSION[0])] if MISSION[0] else []), cwd=str(HERE), creationflags=NOWIN)
                if (HERE / "storm.py").exists() and not XMAS:
                    subprocess.Popen([sys.executable, str(HERE / "storm.py"), RUN, str(os.getpid())], cwd=str(HERE), creationflags=NOWIN)
            except OSError:
                pass
        host = None
        if ADOPT:
            host, hlog = adopt_host(ADOPT)
        if host is None:
            host, hlog = start("hd1", MELEE_CHARS[0] if MELEE else CHARS[0], "blue", START_LEVEL, host=True)
        end = time.time() + 150
        while time.time() < end and host.poll() is None and not isinstance(host, Adopted):
            time.sleep(2)
            try:
                if "attached to" in hlog.read_text(errors="replace"):
                    break
            except OSError:
                pass
        if host.poll() is not None:
            print("the host bot exited early")
            return
        print("lobby up", flush=True)
        if ADOPT:                                         # (a kept host bot, or a new one standing in for it)
            try:                                          # your game: Continue on the score screen, then into this lobby (follow.py)
                import json as _j
                (HERE / "state" / "next_lobby.json").write_text(_j.dumps({"t": time.time(), "address": "127.0.0.1", "map": a.map, "team": "red"}))
            except OSError:
                pass
        time.sleep(12)
        if a.hero:
            start("hero", "bob", "red", "nightmare")
            time.sleep(8)
        t_start = time.time()
        t_end = time.time() + a.minutes * 60
        nxt = [2]
        cur = {"level": None, "bots": []}          # the enemy bots in play: (process, log)

        team_names = set()                               # the Survivors seen in the kill feed (the win target grows with them)

        def total_kills():
            """The Survivors' kills: every player on the Survivors team, not only the first one an observer recognised.
            Read from the game's own kill feed in the in-game observers' logs ('FMT: G <player> killed Zombie 3!',
            '<player> killed you!' when the observer itself was the victim). Zombies that die by themselves (a fall,
            their own TNT) and zombie kills don't count. Each observer sees every kill, so the higher of their counts is
            used (a line one of them missed doesn't matter, and nothing is counted twice). Until an observer has seen
            the feed, the count of bot deaths is used instead."""
            best, suic = None, 0
            for nm in OBSERVERS:
                try:
                    path = LOGS / f"{a.map}_{nm}.log"
                    if path.stat().st_mtime < began - 2:          # last game's log (not rewritten yet): not ours
                        continue
                    t = path.read_text(errors="replace")
                except OSError:
                    continue
                if "FMT: G " in t:
                    n = survivor_kills(t)
                    best = n if best is None else max(best, n)
                    suic = max(suic, bot_suicides(t))
                    team_names.update(survivors(t))
            if best is not None:
                # the kill feed misses some kills (both observers miss the same ones); every bot also logs its own
                # "X killed you!" (only a player's kills: not one elf blowing up another)
                return max(best, own_deaths())
            text = observer_text()
            if text:
                return max(len(re.findall(r"^STATS: .+ killed .+ \(kills \d+\)$", text, re.M)), bot_deaths())
            return bot_deaths()

        def own_deaths():
            """Each Horde bot's own deaths at a player's hands, from its own messages ("X killed you!", "X blew you up!")."""
            n = 0
            for lg in logs:
                if "_hd" in lg.name and not lg.name.endswith("_hd1.log"):
                    try:
                        t = lg.read_text(errors="replace")
                    except OSError:
                        continue
                    for m in re.finditer(r"^FMT: G (.+) (?:killed you|blew you up)!\r?$", t, re.M):
                        if not BOT_NAME.match(m.group(1)) and m.group(1) != "You":
                            n += 1
            return n

        def bot_deaths():
            """Every Horde bot's own deaths (each logs 'died'), the host and Santa left out."""
            n = 0
            for lg in logs:
                if "_hd" in lg.name and not lg.name.endswith("_hd1.log"):
                    try:
                        n += len(re.findall(r"^died\r?$", lg.read_text(errors="replace"), re.M))
                    except OSError:
                        pass
            return n

        kn_ = {}

        def add_bot(level):
            pool = MELEE_CHARS if MELEE else (POOL.get(level) or POOL.get("normal") or next(iter(POOL.values())))   # (17 Nov: a mission's "hard" step
                                                                                                          #  wasn't in the Christmas climb: KeyError, Mission 4 ended at once)
            have = [c for c, _, _ in cur["bots"]]
            char = next((c for c in pool if c not in have), pool[len(have) % len(pool)])
            ex_, gn_ = None, None
            if MISSION[0] and a.ghosts:                 # a Co-op Mission: elves, gingerbread men, evil snowmen and nutcrackers in turn
                import missions
                order_ = missions.enemy_order(MISSION[0]["id"])       # (each mission's own enemy every other time)
                kind = order_[nxt[0] % len(order_)]
                if FORCE_KIND[0]:
                    kind = next((e for e in missions.ENEMIES if e["name"] == FORCE_KIND[0]), kind)
                if kind.get("env"):
                    ex_ = dict(kind["env"])
                if kind.get("chars"):                   # (20 Nov, the user: the elves only as Dr. Death's and James's elf, in turn)
                    kn_["_c"] = kn_.get("_c", -1) + 1
                    char = kind["chars"][kn_["_c"] % len(kind["chars"])]
                if kind.get("char"):
                    char = kind["char"]
                    mdl = kind.get("model")
                    if mdl and (HERE / "christmas" / mdl.upper()).exists() and (HERE / "christmas" / mdl.upper().replace(".NWX", ".SPX")).exists():
                        ex_["GHOST_MODEL"] = mdl
                    if os.environ.get("GHOST_TROOP_MODEL") and ex_ is not None:   # (the General's called-in troops: white coats)
                        ex_["GHOST_MODEL"] = os.environ["GHOST_TROOP_MODEL"]
                    kn_[kind["name"]] = kn_.get(kind["name"], 0) + 1
                    gn_ = f"{kind['name']} {kn_[kind['name']]}"
            p, lg = start(f"hd{nxt[0]}", char, "blue", level, display=f"{'Bot' if a.classic else 'Elf' if XMAS else 'Zombie'} {len(cur['bots']) + 1}", hold=True,
                          extra=ex_, gname=gn_)
            cur["bots"].append((char, p, lg))
            nxt[0] += 1

        watcher = None
        if a.player and not a.hero:                      # the human's deaths: read from their own game's health
            try:
                watcher = subprocess.Popen([sys.executable, str(HERE / "deathwatch.py"), RUN], cwd=str(HERE), creationflags=NOWIN)
            except OSError:
                watcher = None
        def reach_referee():
            """Ghost zombies: a player standing where no zombie can walk to (a roof, a ledge) gets a warning and a 3-second count,
            then takes damage until they come back down. The ghosts report who is out of reach (state/zreach_<run>_<tag>.txt, the
            map's route finder from its main area); one ghost is named in state/punish_<run>.txt to deal the damage."""
            st = {}
            pfile = HERE / "state" / f"punish_{RUN}.txt"
            while not stop_ref[0]:
                time.sleep(0.25)
                now = time.time(); reports = {}
                for f in (HERE / "state").glob(f"zreach_{RUN}_*.txt"):
                    try:
                        lines = f.read_text().splitlines(); t0 = float(lines[0])
                    except (OSError, ValueError, IndexError):
                        continue
                    if now - t0 > 2.5:
                        continue
                    for ln in lines[1:]:
                        parts = ln.split("|")
                        if len(parts) >= 2:
                            reports.setdefault(parts[0], []).append(parts[1] == "1")
                punish = []
                for nm in list(st):
                    if nm not in reports:
                        st.pop(nm)
                many = len(reports) > 1
                for nm, oks in reports.items():
                    s_ = st.setdefault(nm, {"since": None, "shown": None})
                    if any(oks):                                      # a zombie can get to them (every report must agree they're out)
                        if s_["shown"] is not None:
                            warn_banner(("" if not many else nm + ": ") + "OK, the zombies can reach you", 1.5)
                        s_["since"] = None; s_["shown"] = None
                        continue
                    if s_["since"] is None:
                        s_["since"] = now
                        ev(f"{nm} is out of the zombies' reach: {REACH_COUNT:g} s to come back down")
                    left = REACH_COUNT - (now - s_["since"])
                    who = "" if not many else nm + ": "
                    if left > 0:
                        sec = int(math.ceil(left))
                        if s_["shown"] != sec:
                            s_["shown"] = sec; warn_banner(f"{who}Get down where the zombies can reach you! {sec}", 1.2)
                    else:
                        punish.append(nm)
                        if s_["shown"] != 0:
                            s_["shown"] = 0; warn_banner(f"{who}Out of the zombies' reach: taking damage!", 2.5)
                            ev(f"{nm} stayed out of the zombies' reach: taking damage until they come down")
                alive = [Path(lg).stem.rsplit("_", 1)[1] for _c, p_, lg in cur["bots"] if p_ in GHOSTS and p_.poll() is None]
                try:
                    pfile.write_text("\n".join(f"{nm}|{alive[0]}" for nm in punish) if (punish and alive) else "")
                except OSError:
                    pass

        stop_ref = [False]
        if a.ghosts and MELEE and not XMAS:              # the out-of-reach warning and damage: the melee-only Zombie Horde only
            threading.Thread(target=reach_referee, daemon=True).start()
            ON_END.append(lambda: stop_ref.__setitem__(0, True))
        def make_mission(santa):
            """The Co-op Mission's director (missions.py): one step after another, the elves kept coming at each step's strength,
            the objective on screen (state/obj_<run>.txt: tierhud.py, the live board), mini-bosses and the hostage as ghosts,
            Santa as in the Christmas Horde. Returns tick(): True once the mission is over."""
            import missions
            m = MISSION[0]
            st = {"i": -1, "step": None, "t0": 0.0, "k0": 0, "held": 0.0, "last": time.time(), "boss": None, "hp": "",
                  "hostage": None, "said": "", "blast_seen": 0, "done_at": None}
            obj = HERE / "state" / f"obj_{RUN}.txt"
            for f in (HERE / "state" / f"blast_{RUN}.txt", HERE / "state" / f"hostage_{RUN}.txt", HERE / "state" / f"pos_{RUN}.txt"):
                try: f.unlink()
                except OSError: pass

            def say(text):
                if text != st["said"]:
                    st["said"] = text
                    try: obj.write_text(text)
                    except OSError: pass

            def humans():
                """[(name, (x, y, z))] of the players (not elves, bosses or the hostage), from the feed ghost's position list"""
                try:
                    lines = (HERE / "state" / f"pos_{RUN}.txt").read_text().splitlines()
                    if time.time() - float(lines[0]) > 3.0: return []
                except (OSError, ValueError, IndexError):
                    return []
                out, hn = [], (m.get("hostage") or {}).get("name", "")
                for ln in lines[1:]:
                    p_ = ln.split("|")
                    if len(p_) < 4 or BOT_NAME.match(p_[0]) or re.fullmatch(BOSS_NAMES, p_[0]) or p_[0] == hn: continue
                    try: out.append((p_[0], (float(p_[1]), float(p_[2]), float(p_[3]))))
                    except ValueError: pass
                return out

            def elves(n, level):
                if level and level != cur["level"]:
                    for _, p_, lg in cur["bots"]:
                        try:
                            (HERE / "state" / f"level_{RUN}_{Path(lg).stem.rsplit('_', 1)[1]}.flag").write_text(level_flag(level, ghost=p_ in GHOSTS))
                        except (OSError, IndexError): pass
                    cur["level"] = level
                    try: (HERE / "state" / f"tier_{RUN}.txt").write_text(level)
                    except OSError: pass
                while len(cur["bots"]) < n:
                    add_bot(cur["level"] or "normal")

            def boss_env(b):
                ex_ = {"GHOST_HP": str(b["hp"]), "GHOST_FEED": "0", "GHOST_SPEED_SCALE": f"{b.get('speed', 1.0):g}"}
                for k_, env_ in (("arms", "GHOST_BOSS_ARMS"), ("dmg", "GHOST_BOSS_DMG"), ("gap", "GHOST_BOSS_GAP"), ("snd", "GHOST_SHOTSND"),
                                 ("proj", "GHOST_PROJ"), ("proj_n", "GHOST_PROJ_N"), ("tnt_fuse", "GHOST_TNT_FUSE"), ("tnt_next", "GHOST_TNT_NEXT"),
                                 ("tnt_model", "GHOST_TNT_MODEL"), ("proj_speed", "GHOST_PROJ_SPEED"), ("mag", "GHOST_BOSS_MAG"), ("kick", "GHOST_KICK"),
                                 ("tnt_arm", "GHOST_TNT_ARM"), ("tnt_self", "GHOST_TNT_SELF"), ("tnt_range", "GHOST_TNT_RANGE"),
                                 ("sidearm", "GHOST_SIDEARM"), ("side_gap", "GHOST_SIDE_GAP"), ("side_dmg", "GHOST_SIDE_DMG"), ("side_mag", "GHOST_SIDE_MAG"), ("side_reload", "GHOST_SIDE_RELOAD"),
                                 ("pit_safe", "GHOST_PIT_SAFE"), ("reload", "GHOST_BOSS_RELOAD")):
                    if b.get(k_) is not None:
                        ex_[env_] = str(b[k_])
                if b.get("arms"):
                    ex_["GHOST_PICKUPS"] = "0"                  # (its own gun only)
                if b.get("model") and (HERE / "christmas" / b["model"].upper()).exists() and (HERE / "christmas" / b["model"].upper().replace(".NWX", ".SPX")).exists():
                    ex_["GHOST_MODEL"] = b["model"]                 # his own look
                return ex_

            def boss_start(key):
                b = missions.MINI_BOSSES[key]
                ev(f"mini-boss: {b['name']} ({b['char']}, {b['hp']} health, Hell aim)")
                ex_ = boss_env(b)
                if b.get("clear"):                              # (Santa: the elves leave the field to him)
                    els = [(p_, lg) for _c, p_, lg in cur["bots"]]
                    cur["bots"] = []
                    if els:
                        threading.Thread(target=leave_then_kill, args=([p_ for p_, _ in els], [lg for _, lg in els]), daemon=True).start()
                p_, lg = start_ghost(f"boss{st['i']}", b["char"], "hell", b["name"], False, gname=b["name"], extra=ex_)
                st["boss"] = (p_, lg, b)
                banner(b["intro"], 4.0, True)

            def clear_field():
                """every enemy and present leaves (the clones get the field to themselves)"""
                els = [(p_, lg) for _c, p_, lg in cur["bots"]] + [(p_, lg_) for p_, lg_, _t in st.get("gifts") or []]
                cur["bots"] = []; st["gifts"] = []
                if els:
                    threading.Thread(target=leave_then_kill, args=([p_ for p_, _ in els], [lg for _, lg in els]), daemon=True).start()

            def clones_start(sp_):
                """a mini-boss's clones: his arms, speed and look, little health, all sp_['n'] at once, each its own colour
                (sp_['models'], one per clone); a killed clone leaves the game. (20 Nov, the user: everything else leaves first.)"""
                b = dict(missions.MINI_BOSSES[sp_["boss"]]); b["hp"] = sp_.get("hp", 6)
                if sp_.get("kick"): b["kick"] = sp_["kick"]     # (23 Nov, the user: four at once sent him flying - the clones' own, 35% less)
                if sp_.get("clear"):
                    clear_field()
                st["clones"], st["clones_dead"] = [], 0
                mods = sp_.get("models") or []
                # (23 Nov, the user: "Only 1 clone spawned". All four joined in the very second the five henchmen were leaving and the
                #  host let only one of them in - the other three never got a player id and fought unseen. Now the clones join once
                #  the field has emptied (CLONE_WAIT s after it is cleared), one every CLONE_GAP s; a clone the host has not let in
                #  CLONE_REJOIN s after it started is ended and started again.)
                st["clones_todo"] = [(j, f"{sp_.get('name', 'Clone')} {j + 1}", dict(b, model=mods[j]) if j < len(mods) else b, 0)
                                     for j in range(int(sp_["n"]))]
                st["clones_next"] = time.time() + (CLONE_WAIT if sp_.get("clear") else 0.0)
                ev(f"{sp_['n']} clones of {b['name']} to kill ({b['hp']} health each, all at once)")

            def clones_join():
                """start the next clone that is due; restart one the host never let in"""
                now_ = time.time()
                for c_ in list(st.get("clones") or []):
                    if len(c_) > 4 and now_ - c_[3] > CLONE_REJOIN:
                        try: t_ = Path(c_[1]).read_text(errors="replace")
                        except OSError: t_ = ""
                        if "no player id left" in t_:
                            st["clones"].remove(c_)
                            ev(f"{c_[2]} can't join: the host game has no player id left for it")
                        elif "the host made this ghost player id" not in t_ and "died" not in t_:
                            st["clones"].remove(c_)
                            ev(f"{c_[2]} was never let into the game: starting it again")
                            threading.Thread(target=leave_then_kill, args=([c_[0]], [c_[1]]), kwargs={"wait": 0.5}, daemon=True).start()
                            st.setdefault("clones_todo", []).append(c_[4])
                            st["clones_next"] = max(st.get("clones_next", 0), now_ + 1.0)
                        else:
                            st["clones"][st["clones"].index(c_)] = c_[:3]      # (in: no more checks)
                if not st.get("clones_todo") or now_ < st.get("clones_next", 0):
                    return
                j, nm, b_, k = st["clones_todo"].pop(0)
                tag = f"clone{st['i']}n{j + 1}" + (f"r{k}" if k else "")   # (no "_" in the tag: leave_then_kill reads the tag after the last "_" -
                                                                             #  with clone1_4 the leave flag went to "4"; a restart gets its own tag)
                st["clones"].append(start_ghost(tag, b_["char"], "hell", nm, False, gname=nm, extra=boss_env(b_)) + (nm, now_, (j, nm, b_, k + 1)))
                st["clones_next"] = now_ + CLONE_GAP

            def clones_killed():
                """the killed clones leave the game at once (no coming back); the number killed so far"""
                for c_ in list(st.get("clones") or []):
                    try: dead = bool(re.search(r"^died\r?$", Path(c_[1]).read_text(errors="replace"), re.M))
                    except OSError: dead = False
                    if dead:
                        st["clones"].remove(c_); st["clones_dead"] = st.get("clones_dead", 0) + 1
                        threading.Thread(target=leave_then_kill, args=([c_[0]], [c_[1]]), kwargs={"wait": 1.5}, daemon=True).start()
                return st.get("clones_dead", 0)

            def piles_start(sp_):
                """a "reach" step with a "pool": sp_["pick"] of its spots chosen at random (at least "apart" ft from each other),
                each with a pile of presents on it - a ghost standing still with the pile's look (christmas\\GIFTPILE: a hostage
                that never follows anyone), which leaves the game the moment a player gets to it. (20 Nov, the user: random every
                time, and the pile vanishes when found.)"""
                import random as _r
                pool = [tuple(p_) for p_ in sp_.get("pool") or []]
                pick = []
                for _try in range(200):
                    pick = _r.sample(pool, min(sp_.get("pick", 3), len(pool)))
                    if all(math.hypot(a_[0] - b_[0], a_[1] - b_[1]) >= sp_.get("apart", 0) for i_, a_ in enumerate(pick) for b_ in pick[i_ + 1:]):
                        break
                st["spots"], st["piles"] = [list(p_) for p_ in pick], {}
                ev("the presents are hidden at " + "; ".join(f"{p_[0]:.0f},{p_[1]:.0f}" for p_ in pick))
                pl_ = sp_.get("pile") or {}
                have = (HERE / "christmas" / pl_.get("model", "x").upper()).exists() and (HERE / "christmas" / pl_.get("model", "x").upper().replace(".NWX", ".SPX")).exists()
                for k_, (x_, z_, y_) in enumerate(pick):
                    st["gift_n"] += 1
                    nm_ = f"{pl_.get('name', 'Present')} {st['gift_n']}"          # (a Present name: the enemies leave it be)
                    st["piles"][k_] = start_ghost(f"pile{k_ + 1}", "bob", "easy", nm_, False, gname=nm_,
                                                  extra={"GHOST_HOSTAGE": "1", "GHOST_HOSTAGE_FREE": "-1", "GHOST_STILL": "1", "GHOST_TEAM": "red", "GHOST_FEED": "0",
                                                         "GHOST_HP": "99999", "GHOST_SPAWN": f"{x_},{y_},{z_}", "GHOST_FRIENDS": ".*",
                                                         "GHOST_PICKUPS": "0", **({"GHOST_MODEL": pl_["model"]} if have else {})})

            def pile_found(k_):
                p_ = (st.get("piles") or {}).pop(k_, None)
                if p_:
                    threading.Thread(target=leave_then_kill, args=([p_[0]], [p_[1]]), kwargs={"wait": 0.5}, daemon=True).start()

            def piles_leave():
                for k_ in list((st.get("piles") or {}).keys()): pile_found(k_)

            def clones_leave():
                cl_ = st.get("clones") or []
                st["clones"] = []; st["clones_todo"] = []
                if cl_:
                    threading.Thread(target=leave_then_kill, args=([c_[0] for c_ in cl_], [c_[1] for c_ in cl_]), daemon=True).start()

            def boss_down():
                p_, lg, b = st["boss"]
                try: t_ = Path(lg).read_text(errors="replace")
                except OSError: return False
                hm = re.findall(r"health ([-\d.]+)/(\d+)", t_)
                st["hp"] = f" ({max(0, round(float(hm[-1][0]))):g}/{hm[-1][1]})" if hm else ""
                st["hp_frac"] = (float(hm[-1][0]) / max(1.0, float(hm[-1][1]))) if hm else 1.0
                return bool(re.search(r"^died\r?$", t_, re.M))

            def wave_start(w):
                sp_ = st["step"]
                st.update(wave=w, wave_k0=total_kills(), wave_gap=None)
                ev(f"wave {w + 1}/{len(sp_['waves'])}: {sp_['waves'][w]} to beat, {sp_['field'][w]} at a time ({sp_['levels'][w]})")
                banner(f"Wave {w + 1}!", 3.0, True)
                elves(sp_["field"][w], sp_["levels"][w])
                st["gift_next"] = time.time()                       # (a rush of exploding presents opens every wave)

            def start_step():
                st["i"] += 1
                if st["i"] >= len(m["steps"]):
                    ev(f"MISSION COMPLETE: {m['title']}")
                    try:                                   # (unlocks the next one in the launcher's mission list)
                        import json as _j
                        pf = HERE / "state" / "missions_progress.json"
                        try: prog = _j.loads(pf.read_text())
                        except (OSError, ValueError): prog = {}
                        beaten = set(prog.get("beaten", [])); beaten.add(m["id"]); prog["beaten"] = sorted(beaten)
                        pf.write_text(_j.dumps(prog))
                    except Exception:
                        pass
                    nxt = next((x for x in missions.MISSIONS if x["n"] == m["n"] + 1), None)
                    same_look = bool(nxt) and nxt.get("theme") == m.get("theme")   # (another look needs the games closed: Common.kpf)
                    if nxt:                                # the launcher loads the next one by itself once this game is over
                        try:
                            import json as _j
                            KEEP_HOST[0] = same_look          # (the host bot stays: the next mission goes on in its game)
                            (HERE / "state" / os.environ.get("HORDE_CHAIN_FILE", "mission_chain.json")).write_text(_j.dumps({"next": nxt["id"], "label": missions.label(nxt), "t": time.time(), "seamless": same_look}))
                            ev(f"next: {missions.label(nxt)} (it loads by itself)")
                        except OSError:
                            pass
                    say("MISSION COMPLETE" + (f"\nNext up: {missions.label(nxt)}. It loads by itself in a moment." if nxt else "\nChristmas is saved!"))
                    banner(m.get("win", "Mission Complete!"), 5.0, True)
                    end_match("win")
                    return True
                sp = m["steps"][st["i"]]
                st.update(step=sp, t0=time.time(), k0=total_kills(), held=0.0, last=time.time(), blast_seen=0)
                ev(f"mission step {st['i'] + 1}/{len(m['steps'])}: {sp['type']} - {sp['text']}")
                FORCE_KIND[0] = sp.get("enemy")              # (the Jack Frost fight: his snowmen only)
                if sp.get("clear") and sp["type"] != "clones":
                    clear_field()
                if sp["type"] != "santa" and sp["type"] != "clones":
                    elves(sp.get("elves", 4), sp.get("level", "normal"))
                try:                                       # (the escort: the elves stay down 10 s - they kept blocking the jail door)
                    rf_ = HERE / "state" / f"respawn_{RUN}.txt"
                    if sp.get("respawn"): rf_.write_text(str(sp["respawn"]))
                    elif rf_.exists(): rf_.unlink()
                except OSError: pass
                if sp["type"] == "rescue":                 # (25 Nov, the user: first to a pile of presents - her rifle - then the sleigh)
                    st["via_done"] = not sp.get("via")
                    try: (HERE / "state" / f"hostage_armed_{RUN}.flag").unlink()
                    except OSError: pass
                    if sp.get("via") and sp["via"].get("pile"):     # (a pile ghost only when asked for: Mission 2's is a map prop)
                        v_ = sp["via"]; pl_ = v_.get("pile") or {}
                        have_ = (HERE / "christmas" / pl_.get("model", "x").upper()).exists() and (HERE / "christmas" / pl_.get("model", "x").upper().replace(".NWX", ".SPX")).exists()
                        st["gift_n"] = st.get("gift_n", 0) + 1; nm_ = f"{pl_.get('name', 'Present')} {st['gift_n']}"
                        st.setdefault("piles", {})
                        st["piles"]["via"] = start_ghost("pilevia", "bob", "easy", nm_, False, gname=nm_,
                                                         extra={"GHOST_HOSTAGE": "1", "GHOST_HOSTAGE_FREE": "-1", "GHOST_STILL": "1", "GHOST_TEAM": "red", "GHOST_FEED": "0",
                                                                "GHOST_HP": "99999", "GHOST_SPAWN": f"{v_['at'][0]},{v_.get('y', 0.0)},{v_['at'][1]}", "GHOST_FRIENDS": ".*",
                                                                "GHOST_PICKUPS": "0", **({"GHOST_MODEL": pl_["model"]} if have_ else {})})
                if sp["type"] == "rescue" and hs and st["hostage"] is None:
                    hostage_start(unlock=bool(sp.get("unlock")))
                    if sp.get("unlock"): banner("Mrs. Claus's Cell Is Open!", 3.5, True)
                if sp["type"] == "waves":
                    wave_start(0)
                if sp["type"] == "boss":
                    boss_start(sp["boss"])
                    if sp.get("presents"):                    # (20 Nov, the user: Jack Frost comes with 2 exploding presents)
                        gift_now(int(sp["presents"]))
                if sp["type"] == "clones":
                    clones_start(sp)
                elif sp["type"] == "reach" and sp.get("pool"):
                    piles_start(sp)
                elif sp["type"] == "santa":
                    santa["out"], santa["at"] = True, time.time()
                    try:
                        (HERE / "state" / f"go_{RUN}_santa.flag").write_text("go")
                        (HERE / "state" / f"tier_{RUN}.txt").write_text("santa")
                    except OSError: pass
                    banner(sp.get("banner", "Santa Is Coming!"), 4.0, True)
                    els = [(p_, lg) for _c, p_, lg in cur["bots"]]
                    cur["bots"] = []
                    if els:
                        threading.Thread(target=leave_then_kill, args=([p_ for p_, _ in els], [lg for _, lg in els]), daemon=True).start()
                elif sp.get("banner"):
                    banner(sp["banner"], 3.5, True)
                return False

            # ---- Test cheat (the user, 17 Nov: "only for me, to get past the beginning stages quickly"): Ctrl+Alt+PgUp skips the
            # mission step you're on. Only when state\mission_cheats.txt exists on THIS PC (the host's): the file is never shipped,
            # and the director only runs on the host, so nobody who joins can use it. A skipped mission still counts as beaten.
            cheat = {"skip": 0}
            if (HERE / "state" / "mission_cheats.txt").exists():
                def cheat_keys():
                    try:
                        import ctypes, ctypes.wintypes as wt_
                        u32 = ctypes.windll.user32
                        if not u32.RegisterHotKey(None, 7, 0x2 | 0x1 | 0x4000, 0x21):          # Ctrl+Alt+PgUp
                            ev("CHEAT: Ctrl+Alt+PgUp is taken by another program: no step skipping"); return
                        ev("CHEAT: test mode on - Ctrl+Alt+PgUp skips the current mission step")
                        msg = wt_.MSG()
                        while u32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                            if msg.message == 0x312: cheat["skip"] += 1
                    except Exception as e:
                        ev(f"CHEAT: hotkey failed: {e}")
                threading.Thread(target=cheat_keys, daemon=True).start()

            def cheat_skip():
                """end the current step at once, as if it had been done: its boss / hostage leave, then the next step starts"""
                sp_ = st["step"]
                ev(f"CHEAT: step {st['i'] + 1} skipped ({sp_['type']})")
                if st.get("boss"):
                    threading.Thread(target=leave_then_kill, args=([st["boss"][0]], [st["boss"][1]]), daemon=True).start()
                    st["boss"] = None
                clones_leave(); piles_leave()
                if sp_["type"] == "rescue" and st.get("hostage"):
                    threading.Thread(target=leave_then_kill, args=([st["hostage"][0]], [st["hostage"][1]]), daemon=True).start()
                if sp_["type"] == "santa" and santa.get("proc") is not None:
                    threading.Thread(target=leave_then_kill, args=([santa["proc"]], [santa["log"]]), daemon=True).start()
                banner("Step Skipped (Test)", 2.0, True, sound=False)
                return start_step()

            # the start: the hostage is put in place, Santa's game starts early (it takes a while) and waits in the lobby
            hs = m.get("hostage")

            def hostage_home():
                """armed at the presents: that is where she comes back (x, y, z), not her cell"""
                sp_ = st.get("step") or {}
                v_ = sp_.get("via") if sp_.get("type") == "rescue" else None
                return [v_["at"][0], v_.get("y", 0.25), v_["at"][1]] if v_ and st.get("via_done") else None

            def hostage_arms():
                """the hostage's rifle (used once she is armed: state/hostage_armed_<run>.flag) and her look with it"""
                if not hs or not hs.get("rifle"): return {}
                out_ = {"GHOST_BOSS_ARMS": "rifle", "GHOST_PICKUPS": "0"}   # (no pick-ups: with them on she carried Mary's own
                                                                            #  shotgun and pistol instead - a shotgun's sound)
                if hs.get("rifle_dmg"): out_["GHOST_BOSS_DMG"] = str(hs["rifle_dmg"])
                am_ = hs.get("armed_model")
                if am_ and (HERE / "christmas" / am_.upper()).exists() and (HERE / "christmas" / am_.upper().replace(".NWX", ".SPX")).exists():
                    out_["GHOST_HOSTAGE_ARMED_MODEL"] = am_
                return out_

            def hostage_start(unlock=False):
                ev(f"the hostage: {hs['name']} waits at {hs['at']}" + (" (her cell unlocks)" if unlock else ""))
                tw_ = missions.MAP_TWEAKS.get(m["map"], {}) if unlock else {}
                st["hostage"] = start_ghost("hostage", hs["char"], "easy", hs["name"], False, gname=hs["name"],
                                            extra={"GHOST_HOSTAGE": "1", "GHOST_TEAM": "red", "GHOST_FEED": "0", "GHOST_HP": str(hs.get("hp", 40)), "GHOST_NO_ENTER": "",
                                                   "GHOST_SPAWN": ",".join(str(v) for v in hs["at"]), "GHOST_FRIENDS": ".*", **hostage_arms(),
                                                   "GHOST_UNLOCK": ";".join(f"{x_},{z_}" for x_, z_ in tw_.get("door_centres", [])),
                                                   **({"GHOST_MODEL": hs["model"]} if hs.get("model") and (HERE / "christmas" / hs["model"].upper()).exists()
                                                      and (HERE / "christmas" / hs["model"].upper().replace(".NWX", ".SPX")).exists() else {}),
                                                   "GHOST_HOSTAGE_SKIP": r"(Zombie|Skeleton|Bot|Host Bot|Elf|Santa|Gingerbread|Snowman|Nutcracker|Present)( \d+| #\d{3}| No\. \d{3})?$|GhostBot|" + BOSS_NAMES})
            if hs and m["steps"] and m["steps"][0]["type"] == "rescue":
                hostage_start()                            # (otherwise when its rescue step starts: Mission 3 clears the town first)
            if any(sp["type"] == "santa" for sp in m["steps"]):
                santa["proc"], santa["log"] = start("santa", "sanchez", "blue", "hell", display=SANTA, hold=True, behaviour="santa", release=False)
            say(f"{missions.label(m)}\n{m['brief']}")
            st["brief_until"] = time.time() + 10.0
            st["gifts"], st["gift_n"], st["gift_next"] = [], 0, time.time() + 10.0 + missions.PRESENT_EVERY

            def gift_step(now):
                """an exploding present every PRESENT_EVERY seconds: it runs at a player and blows up; once it has gone off it leaves"""
                for g_ in list(st["gifts"]):
                    p_, lg_, t0_ = g_
                    done = p_.poll() is not None
                    try: done = done or bool(re.search(r"^died\r?$", Path(lg_).read_text(errors="replace"), re.M))
                    except OSError: pass
                    if done or now - t0_ > 300:
                        st["gifts"].remove(g_)
                        threading.Thread(target=leave_then_kill, args=([p_], [lg_]), kwargs={"wait": 1.5}, daemon=True).start()
                if st.get("step") and st["step"]["type"] == "clones":     # (the clones have the field to themselves)
                    st["gift_next"] = max(st["gift_next"], now + missions.PRESENT_EVERY)
                if now >= st["gift_next"] and a.ghosts:
                    st["gift_next"] = now + missions.PRESENT_EVERY
                    try: n_p = max(1, len(humans()))              # one for every player
                    except Exception: n_p = 1
                    gift_now(n_p)

            def gift_now(n_p):
                now = time.time()
                if not a.ghosts: return
                pk = missions.PRESENT
                for _ in range(n_p):
                    st["gift_n"] += 1
                    ex_ = dict(pk["env"])
                    if pk.get("hp"): ex_["GHOST_HP"] = str(pk["hp"])
                    if (HERE / "christmas" / pk["model"].upper()).exists() and (HERE / "christmas" / pk["model"].upper().replace(".NWX", ".SPX")).exists():
                        ex_["GHOST_MODEL"] = pk["model"]
                    nm_ = f"{pk['name']} {st['gift_n']}"
                    ev(f"an exploding present: {nm_}")
                    p_, lg_ = start_ghost(f"gift{st['gift_n']}", pk["char"], cur["level"] or "normal", nm_, False, gname=nm_, extra=ex_)
                    st["gifts"].append((p_, lg_, now))
                banner("Exploding Presents Are Coming!" if n_p > 1 else "An Exploding Present Is Coming!", 2.5, True)

            def tick():
                now = time.time()
                if cur["bots"]:                                  # (an enemy that left by itself - lost on a ledge: its place is filled)
                    cur["bots"] = [b_ for b_ in cur["bots"] if b_[1].poll() is None]
                if ended_flag.exists():
                    ev("the game ended the match itself (its time limit)"); return True
                if st["step"] is None:
                    if now < st["brief_until"]: return False
                    return start_step()
                sf_ = HERE / "state" / "cheat_skip.flag"         # (the same test cheat from a file: missiontest.py's step skips)
                if sf_.exists() and (HERE / "state" / "mission_cheats.txt").exists():
                    try: sf_.unlink(); cheat["skip"] += 1
                    except OSError: pass
                if cheat["skip"]:
                    cheat["skip"] = 0
                    if cheat_skip(): return True
                gift_step(now)
                sp, n_, of = st["step"], st["i"] + 1, len(m["steps"])
                head = f"MISSION {m['n']}: {m['title'].upper()}  ({n_}/{of})\n"
                dt, st["last"] = now - st["last"], now
                if sp["type"] == "kills":
                    k = total_kills() - st["k0"]
                    say(head + f"{sp['text']}: {min(k, sp['n'])}/{sp['n']}")
                    if k >= sp["n"]: return start_step()
                    while len(cur["bots"]) < sp.get("elves", 4): add_bot(cur["level"] or "normal")
                elif sp["type"] == "hold":
                    hum = humans()
                    on = [nm for nm, p_ in hum if missions.in_box(p_, sp["box"], sp.get("y"))]
                    if on: st["held"] += dt
                    left = max(0, int(math.ceil(sp["secs"] - st["held"])))
                    near = min((missions.box_distance(p_, sp["box"]) for nm, p_ in hum), default=None)
                    where = ("" if on else f"\nThe red square is {near:.0f} ft away: GET IN IT!" if near is not None and near > 1
                             else "\nGET IN THE RED SQUARE!")
                    say(head + f"{sp['text']}\n{left} seconds left" + ("  (holding!)" if on else "") + where)
                    if st["held"] >= sp["secs"]:
                        banner("Held!", 2.5, True); return start_step()
                elif sp["type"] == "reach":
                    # (20 Nov, the user: Mission 1's second step - not another round of killing) get to every spot (sp["spots"]: x, z),
                    # in any order, while the elves keep coming; the side says how many are found and how far the nearest one left is.
                    # sp["then"]: a last goal after them - a player at a switch (at, r, y_min) has a door opened: a ghost steps into
                    # its sector (open_at; the door's INF runs on someone entering it, darkitems lock_doors), the switch itself dead.
                    hum = humans(); fd_ = st.setdefault("found", set()); th_ = sp.get("then")
                    spots_ = st.get("spots") if sp.get("pool") else sp["spots"]      # (a "pool": the piles' random spots)
                    if len(fd_) < len(spots_):
                        for k_, sp_ in enumerate(spots_):
                            sx_, sz_ = sp_[0], sp_[1]                   # (a third value: the floor it's on - not from the floor below)
                            if k_ not in fd_ and any(math.hypot(p_[0] - sx_, p_[2] - sz_) <= sp.get("r", 10) and (len(sp_) < 3 or abs(p_[1] - sp_[2]) < 8)
                                                     for nm, p_ in hum):
                                fd_.add(k_); ev(f"spot {k_ + 1} reached ({len(fd_)}/{len(spots_)})"); pile_found(k_)
                                if len(fd_) < len(spots_): banner(sp.get("got", "Found One!") + f" ({len(fd_)}/{len(spots_)})", 2.5, True)
                                elif th_: banner(th_.get("banner", "One More Thing!"), 3.0, True); st["then_t"] = now
                        if len(fd_) >= len(spots_) and not th_:
                            st["found"] = set(); banner(sp.get("done", "All Found!"), 3.0, True); return start_step()
                    if len(fd_) < len(spots_):
                        left_ = [(sp_[0], sp_[1]) for k_, sp_ in enumerate(spots_) if k_ not in fd_]
                        near = min((math.hypot(p_[0] - sx_, p_[2] - sz_) for nm, p_ in hum for sx_, sz_ in left_), default=None)
                        at_sw = th_ and any(math.hypot(p_[0] - th_["at"][0], p_[2] - th_["at"][1]) <= th_.get("r", 6) and p_[1] >= th_.get("y_min", -1e9) for nm, p_ in hum)
                        # (20 Nov, the user: not the distance - just a word while the nearest pile is far off, gone within 50 ft)
                        far_ = sp.get("far", 50)
                        say(head + f"{sp['text']} ({len(fd_)}/{len(spots_)})" + (f"\n{sp.get('near', 'Far away')}" if near is not None and near > far_ else "")
                            + (f"\n{th_.get('locked', 'Not yet!')}" if at_sw else ""))
                    else:
                        on_ = any(math.hypot(p_[0] - th_["at"][0], p_[2] - th_["at"][1]) <= th_.get("r", 6) and p_[1] >= th_.get("y_min", -1e9) for nm, p_ in hum)
                        if on_ and not st.get("opening"):
                            st["opening"] = now; st["open_tries"] = 0; ev("a player is at the switch: the gate opens")
                        if st.get("opening"):
                            vf_ = HERE / "state" / f"visit_{RUN}.txt"; cf_ = HERE / "state" / f"visit_{RUN}.txt.claim"
                            k_ = int((now - st["opening"]) // 3.0)               # (a ghost steps in every 3 s, 3 times: one may be dead)
                            if k_ >= 3:
                                for f_ in (vf_, cf_):
                                    try: f_.unlink()
                                    except OSError: pass
                                st["opening"] = None; st["found"] = set()
                                banner(th_.get("done", "Done!"), 3.0, True); return start_step()
                            if k_ >= st["open_tries"]:
                                st["open_tries"] = k_ + 1
                                try:
                                    cf_.unlink(missing_ok=True)
                                    vf_.write_text(",".join(str(v) for v in th_["open_at"]) + f",{now}")
                                except OSError: pass
                        dsw = min((math.hypot(p_[0] - th_["at"][0], p_[2] - th_["at"][1]) for nm, p_ in hum), default=None)
                        say(head + th_["text"] + (f"\n{th_.get('near', 'It')} is {dsw:.0f} ft away" if dsw is not None and not st.get("opening") else ""))
                    while len(cur["bots"]) < sp.get("elves", 3): add_bot(cur["level"] or "normal")
                elif sp["type"] == "tnt":
                    hum = humans(); hint = ""
                    if hum:                                   # (the user, 17 Nov: lost - which way to the TNT, which way to the vault)
                        vx, vz = sp["at"]
                        dv = min(math.hypot(p_[0] - vx, p_[2] - vz) for nm, p_ in hum)
                        hint = f"\nThe vault (red lanterns, down in the cellar): {dv:.0f} ft away"
                        if sp.get("tnt_at"):
                            dt_ = min(math.dist((p_[0], p_[1], p_[2]), tuple(t)) for nm, p_ in hum for t in sp["tnt_at"])
                            hint += f"\nTNT (green lantern signs): the nearest is {dt_:.0f} ft away"
                    say(head + sp["text"] + hint)
                    try: bl = (HERE / "state" / f"blast_{RUN}.txt").read_text().splitlines()
                    except OSError: bl = []
                    for ln in bl:
                        try: t_, x_, y_, z_ = (float(v) for v in ln.split("|"))
                        except ValueError: continue
                        if t_ >= st["t0"] and missions.inside((x_, y_, z_), sp["at"], sp["r"]):
                            ev(f"the vault is blown open (TNT at {x_:.0f},{z_:.0f})")
                            banner("The Vault Is Open!", 3.5, True); return start_step()
                elif sp["type"] == "waves":
                    w_ = st.get("wave", 0); size = sp["waves"][w_]
                    if st.get("wave_gap"):                                   # (a short breather between waves)
                        left_ = int(math.ceil(st["wave_gap"] - now))
                        say(head + f"{sp['text']}\nWave {w_ + 1} beaten! Wave {w_ + 2} in {max(0, left_)}...")
                        if now >= st["wave_gap"]: wave_start(w_ + 1)
                    else:
                        k = total_kills() - st["wave_k0"]
                        say(head + f"{sp['text']}\nWave {w_ + 1}/{len(sp['waves'])}: {min(k, size)}/{size}")
                        if k >= size:
                            if w_ + 1 >= len(sp["waves"]):
                                banner(sp.get("done", "The Waves Are Beaten!"), 3.0, True); return start_step()
                            banner(f"Wave {w_ + 1} Beaten!", 2.5, True); st["wave_gap"] = now + 8.0
                        else:
                            while len(cur["bots"]) < sp["field"][w_]: add_bot(cur["level"] or "normal")
                elif sp["type"] == "rescue":
                    try:
                        t_, x_, y_, z_, fr_, who_ = (HERE / "state" / f"hostage_{RUN}.txt").read_text().split("|", 5)
                        hpos, freed = (float(x_), float(y_), float(z_)), fr_ == "1"
                    except (OSError, ValueError):
                        hpos, freed, who_ = None, False, ""
                    if freed and not st.get("was_freed"):           # (17 Nov: Santa's greeting only the first time she's freed)
                        banner(f"{hs['name'] if hs else 'The Hostage'} Is Free!", 3.0, True, sound=not st.get("ever_freed"))
                        st["ever_freed"] = True
                    if st.get("was_freed") and not freed:
                        banner(f"{hs['name'] if hs else 'The Hostage'} Went Down!", 3.0, True, sound=False)
                    st["was_freed"] = freed
                    v_ = sp.get("via")
                    if v_ and not st.get("via_done"):
                        say(head + (f"{v_['text']} (following {who_})" if freed else sp["text"]))
                        if freed and missions.inside(hpos, v_["at"], v_.get("r", 14)):
                            st["via_done"] = True
                            ev("the hostage is at the presents: she has a rifle")
                            try: (HERE / "state" / f"hostage_armed_{RUN}.flag").write_text("rifle")
                            except OSError: pass
                            pile_found("via")
                            banner(v_.get("banner", "She's Armed!"), 3.5, True)
                    else:
                        say(head + (f"{sp.get('text2', sp['text'])} (following {who_})" if freed else sp["text"]))
                    if freed and st.get("via_done", True) and missions.inside(hpos, sp["to"], sp["r"]):
                        ev("the hostage is safe"); banner("She's Safe!", 3.0, True)
                        p_ = st["hostage"][0]
                        threading.Thread(target=leave_then_kill, args=([p_], [st["hostage"][1]]), daemon=True).start()
                        return start_step()
                    if st["hostage"] and st["hostage"][0].poll() is not None and now - st["t0"] > 20:
                        ev("the hostage's ghost closed: starting her again")
                        st["hostage"] = start_ghost("hostage2", hs["char"], "easy", hs["name"], False, gname=hs["name"],
                                                    extra={"GHOST_HOSTAGE": "1", "GHOST_TEAM": "red", "GHOST_FEED": "0", "GHOST_HP": str(hs.get("hp", 40)), "GHOST_NO_ENTER": "",
                                                           "GHOST_SPAWN": ",".join(str(v) for v in (hostage_home() or hs["at"])), "GHOST_FRIENDS": ".*", **hostage_arms(),
                                                           **({"GHOST_MODEL": hs["armed_model"]} if st.get("via_done") and hostage_arms().get("GHOST_HOSTAGE_ARMED_MODEL") else
                                                              {"GHOST_MODEL": hs["model"]} if hs.get("model") and (HERE / "christmas" / hs["model"].upper()).exists() else {})})
                elif sp["type"] == "clones":
                    clones_join()
                    got_ = min(clones_killed(), sp["n"])
                    # (20 Nov, the user: each clone's health on the side, a line each, gone as it dies)
                    hp_lines = []
                    for j_, c_ in enumerate(st.get("clones") or []):
                        try: hm_ = re.findall(r"health ([-\d.]+)/(\d+)", Path(c_[1]).read_text(errors="replace"))
                        except OSError: hm_ = []
                        nm_ = c_[2] if len(c_) > 2 else f"{sp.get('name', 'Clone')} {j_ + 1}"
                        hp_lines.append(f"{nm_}: {max(0, round(float(hm_[-1][0]))):g}/{hm_[-1][1]}" if hm_ else f"{nm_}: {sp.get('hp', 6)}/{sp.get('hp', 6)}")
                    say(head + f"{sp['text']} ({got_}/{sp['n']})" + "".join("\n" + l_ for l_ in hp_lines))
                    if got_ >= sp["n"]:
                        ev(f"the clones are beaten ({got_})")
                        banner("The Clones Are Melted!", 3.0, True)
                        clones_leave()
                        return start_step()
                    while len(cur["bots"]) < sp.get("elves", 0): add_bot(cur["level"] or "normal")
                elif sp["type"] == "boss":
                    b = st["boss"][2]
                    down = boss_down()
                    # (25 Nov, the user: the Nutcracker General calls his troops) at each of his "calls" health marks, more of
                    #  his toy soldiers join the fight, on top of the step's own
                    for k_, (frac_, n_) in enumerate(b.get("calls") or []):
                        if not down and st.get("hp_frac", 1.0) <= frac_ and k_ not in st.setdefault("called", set()):
                            # (the user: "I never see any extra troops come" - the count already stood above the step's own 3,
                            #  so "3 + 3" added nothing: now n more than are in the fight right now, and they stay that many)
                            # (25 Nov, the user: they leave once killed, and wear white) n of his own toy soldiers, each with
                            #  one life (GHOST_ONE_LIFE) and the white-coat look (b["troop_model"]), kept apart from the
                            #  step's own enemies (st["troops"]) so none is put back when it goes down
                            st["called"].add(k_)
                            for _i in range(int(n_)):
                                fk_ = FORCE_KIND[0]; FORCE_KIND[0] = b.get("troops") or fk_
                                os.environ["GHOST_ONE_LIFE"] = "1"
                                tm_ = b.get("troop_model")
                                if tm_ and (HERE / "christmas" / tm_.upper()).exists() and (HERE / "christmas" / tm_.upper().replace(".NWX", ".SPX")).exists():
                                    os.environ["GHOST_TROOP_MODEL"] = tm_
                                try:
                                    add_bot(cur["level"] or "normal")
                                    st.setdefault("troops", []).append(cur["bots"].pop())
                                finally:
                                    FORCE_KIND[0] = fk_; os.environ.pop("GHOST_ONE_LIFE", None); os.environ.pop("GHOST_TROOP_MODEL", None)
                            ev(f"{b['name']} calls {n_} more troops ({st['hp_frac']:.0%} health)")
                            banner(b.get("call_banner", "Reinforcements!"), 3.0, True)
                    say(head + f"{sp['text']}{st['hp']}")
                    if down:
                        ev(f"{b['name']} is down")
                        banner(f"{b['name']} Is Down!", 3.0, True)
                        threading.Thread(target=leave_then_kill, args=([st["boss"][0]], [st["boss"][1]]), daemon=True).start()
                        tr_ = [t_ for t_ in st.get("troops") or [] if t_[1].poll() is None]
                        if tr_: threading.Thread(target=leave_then_kill, args=([t_[1] for t_ in tr_], [t_[2] for t_ in tr_]), daemon=True).start()
                        st["boss"] = None; st["troops"] = []; st["called"] = set()
                        return start_step()
                    st["troops"] = [t_ for t_ in st.get("troops") or [] if t_[1].poll() is None]     # (the ones killed have left)
                    while len(cur["bots"]) < sp.get("elves", 3): add_bot(cur["level"] or "normal")
                elif sp["type"] == "santa":
                    say(head + sp["text"])
                    down = False
                    try: down = bool(re.search(r"^died$", Path(santa["log"]).read_text(errors="replace"), re.M))
                    except (OSError, TypeError): pass
                    if down or (santa["proc"] is not None and santa["proc"].poll() is not None and now - santa["at"] > 20):
                        ev("SANTA IS DOWN"); return start_step()
                if now - st.get("saved", 0) > 3:
                    st["saved"] = now; save_ranked()
                return False
            return tick

        ended_flag = HERE / "state" / f"matchend_{RUN}.flag"
        ON_END.append(lambda: save_ranked(True))
        target = [win_target(1)]

        def write_live(final=False):
            """the live scoreboard (state/live_<run>.json, and state/live.json for the status page): scoreboard.py, the
            companion app and modserver's /live.json read it"""
            try:
                import livestats
                try:
                    tier = (HERE / "state" / f"tier_{RUN}.txt").read_text().strip()
                except OSError:
                    tier = ""
                board = livestats.build(list(logs), tier=tier, host=(a.player, a.character) if a.player else None,
                                        observer_text=observer_text(), mode=("Co-op: " + MISSION[0]["title"]) if MISSION[0] else "Christmas Horde" if XMAS else "Horde", map_name=a.map)
                board.update(run=RUN, final=final, target=target[0], team_kills=total_kills(), began=began)
                if MISSION[0]:
                    try:
                        board["objective"] = (HERE / "state" / f"obj_{RUN}.txt").read_text()
                    except OSError:
                        board["objective"] = ""
                    board.pop("target", None)
                livestats.write(board, HERE / "state" / f"live_{RUN}.json")
                livestats.write(board, HERE / "state" / "live.json")
                return board
            except Exception as e:
                print("live scoreboard:", e, flush=True)
                return None

        def live_loop():
            while not live_stop[0]:
                write_live()
                time.sleep(1.5)
        live_stop = [False]
        threading.Thread(target=live_loop, daemon=True).start()
        if not a.classic and (HERE / "scoreboard.py").exists():     # hold the ` key (left of 1) in the game: the scoreboard
            subprocess.Popen([sys.executable, str(HERE / "scoreboard.py"), RUN, str(os.getpid()), a.player or ""], cwd=str(HERE), creationflags=NOWIN)

        def final_live():
            if live_stop[0]:
                return
            live_stop[0] = True
            b = write_live(final=True)
            if b:
                try:
                    import livestats
                    livestats.save_summary(b, HERE / "state" / "match_summaries.json")
                    for k_, v_ in livestats.summary_lines(b):
                        ev(f"{k_}: {v_}")
                except Exception as e:
                    print("match summary:", e, flush=True)
        ON_END.insert(0, final_live)
        santa = {"proc": None, "log": None, "at": 0.0, "out": False}
        # the final boss: Santa in the Christmas Horde; Bob Graham (a jack-o'-lantern for a head) in the Horde. Not in the classic
        # style or Melee Zombies (no guns there). Dr. Death (ghost games): a healer mid-way, and at Bob Graham's side at the end.
        BOSS_ON = not MISSION[0] and (XMAS or (not a.classic and not MELEE and not a.ranked))      # (ranked games keep their rules)
        BOSS = ({"name": SANTA, "tag": "santa", "tier": "santa", "banner": "Santa Is Coming!"} if XMAS else
                {"name": "Headless Demon", "tag": "bobboss", "tier": "headless demon", "banner": "The Headless Demon Rises!"})
        doc = {"proc": None, "log": None, "down": False, "finale": False}

        def pumpkin_ok():
            """the jack-o'-lantern head only when every player's game has PUMPKIN.NWX: alone, or the mod server offers it"""
            if not (HERE / "zombie" / "PUMPKIN.NWX").exists() or not (HERE / "zombie" / "PUMPKIN.SPX").exists():
                return False
            if len(team_names) <= 1 and a.users <= 1:
                return True
            try:
                import urllib.request, json as _j
                with urllib.request.urlopen("http://127.0.0.1:8765/manifest.json", timeout=5) as r_:
                    man = _j.load(r_)
                return any(f.get("dest", "").upper() == "PUMPKIN.NWX" for m_ in man.get("mods", []) for f in m_.get("files", []))
            except Exception:
                return False

        def start_boss():
            if XMAS:
                return start("santa", "sanchez", "blue", "hell", display=SANTA, hold=True, behaviour="santa", release=False)
            pk = pumpkin_ok()
            ev("The Headless Demon (Bob Graham) " + ("gets his jack-o'-lantern head" if pk else "keeps his own head (a friend's game has no PUMPKIN.NWX: the launcher needs rebuilding)"))
            os.environ["BOT_PUMPKIN_HEAD"] = "1" if pk else "0"
            if a.ghosts:
                os.environ["BOT_BOSS_NO_END"] = "1"           # (the twin finale: this script ends the match when both are down)
            try:
                return start("bobboss", "bob", "blue", "hell", display="Headless Demon", hold=True, behaviour="pumpkin", release=False)
            finally:
                os.environ.pop("BOT_PUMPKIN_HEAD", None); os.environ.pop("BOT_BOSS_NO_END", None)

        def start_doc(finale):
            ev("THE HEALER (Dr. Death) " + ("returns for the twin-boss finale (he heals himself)" if finale else "joins the Horde: he heals the zombies near him"))
            extra = {"GHOST_HEALER": "1", "GHOST_HP": str(DOC_HP), "GHOST_FEED": "0", "GHOST_MOANS": "0"}     # (17 Nov: no zombie moans)
            if (HERE / "zombie" / "HEALER.NWX").exists() and (HERE / "zombie" / "HEALER.SPX").exists():
                extra["GHOST_MODEL"] = "healer.nwx"           # his own look, not a zombie's (zombie\HEALER.NWX/.SPX)
            extra["GHOST_ESCORT"] = SANTA if XMAS else "Headless Demon"     # (18 Nov: he keeps close to the boss once the boss is in)
            if finale:
                extra["GHOST_REGEN"] = str(DOC_REGEN)
            doc["proc"], doc["log"] = start_ghost("drdeath" + ("2" if finale else ""), "drdeath", "hell", "Healer", False, extra=extra, gname="Healer")
            doc["finale"] = finale
            if not finale:
                banner("The Healer Heals The Horde!", 4.0, XMAS)

        def show_boss_hp():
            """(17 Nov, the user: "show their health on the side as well") the Healer's and the Headless Demon's health under
            the tier label (tierhud.py reads state/bosshp_<run>.txt)"""
            lines = []
            if doc["proc"] is not None and not doc["down"]:
                try: hm = re.findall(r"health ([-\d.]+)/(\d+)", Path(doc["log"]).read_text(errors="replace"))
                except (OSError, TypeError): hm = []
                cur_, max_ = (float(hm[-1][0]), hm[-1][1]) if hm else (float(DOC_HP), f"{DOC_HP:g}")
                lines.append(f"HEALER: {max(0, round(cur_)):g}/{max_} HP")
            if santa["out"] and not santa.get("down_said"):
                try: hm = re.findall(r"BOSS HEALTH ([-\d.]+)/([\d.]+)", Path(santa["log"]).read_text(errors="replace"))
                except (OSError, TypeError): hm = []
                if hm: lines.append(f"HEADLESS DEMON: {max(0, round(float(hm[-1][0]))):g}/{hm[-1][1]} HP")
                else: lines.append("HEADLESS DEMON")
            txt = "\n".join(lines)
            if txt != doc.get("hp_shown"):
                doc["hp_shown"] = txt
                try: (HERE / "state" / f"bosshp_{RUN}.txt").write_text(txt)
                except OSError: pass

        def doc_down():
            try:
                return bool(re.search(r"^died\r?$", Path(doc["log"]).read_text(errors="replace"), re.M))
            except (OSError, TypeError):
                return False
        if not MISSION[0]:
            ev(f"the Survivors win at {target[0]} kills ({WIN_KILLS}, +{PER_PLAYER} for each other player on their team)")
        mission_tick = make_mission(santa) if MISSION[0] else None
        while time.time() < t_end:
            if mission_tick is not None:
                try:
                    done_ = mission_tick()
                except Exception:                          # (a mission bug must not end the game: log it, carry on)
                    import traceback
                    ev("MISSION ERROR (carrying on): " + traceback.format_exc().strip().replace("\n", " | ")[-900:])
                    done_ = False; time.sleep(2.0)
                if done_:
                    break
                time.sleep(0.5)
                continue
            k = total_kills() + (int((time.time() - t_start) / a.ramp) if a.ramp else 0)
            t_now = win_target(max(len(team_names), 1)); HUMANS[0] = max(1, len(team_names))
            if t_now != target[0]:
                target[0] = t_now
                ev(f"{len(team_names)} players on the Survivors team ({', '.join(sorted(team_names))}): they win at {t_now} kills")
            if ended_flag.exists() and k < target[0]:     # the game ended the match itself: only its time limit is left on
                ev(f"the game's time is up ({k} of {target[0]} kills)")
                break
            if BOSS_ON and a.ghosts and not XMAS and doc["proc"] is None and not doc["down"] and not santa["out"] and k >= min(DOC_AT, max(1, int(target[0]) - 1)):
                start_doc(finale=False)
            if doc["proc"] is not None and doc_down():
                ev("THE HEALER IS DOWN" + (" (the twin-boss finale)" if doc["finale"] else ": the zombies heal no more"))
                banner("The Healer Is Down!", 3.0, XMAS)
                threading.Thread(target=leave_then_kill, args=([doc["proc"]], [doc["log"]]), daemon=True).start()
                doc.update(proc=None, down=True)
            if BOSS_ON and not XMAS:
                show_boss_hp()
            boss_at = target[0] if XMAS else DEMON_AT
            if BOSS_ON and santa["proc"] is None and k >= boss_at - SANTA_EARLY:
                # the boss's game starts well before he is needed and waits in the lobby (a game copy takes a while to start),
                # so he arrives the moment the kill target is reached
                ev(f"{k} kills: {BOSS['name']}'s game is starting; he waits in the lobby until {boss_at} kills")
                santa["proc"], santa["log"] = start_boss()
            if BOSS_ON and santa["proc"] is not None and not santa["out"] and k >= boss_at - SANTA_LEAD:
                # at the kill target: the zombies leave and the boss comes out of the lobby (the banner covers his few seconds)
                santa["out"], santa["at"] = True, time.time()
                ev(f"{k} kills: {BOSS['name'].upper()} IS COMING (Hell, {'the Gatling' if XMAS else 'a double barrel that never needs reloading'}, 150 armor, 10 times Mary's health); the horde leaves; kill him to win")
                try:
                    (HERE / "state" / f"go_{RUN}_{BOSS['tag']}.flag").write_text("go")
                    (HERE / "state" / f"tier_{RUN}.txt").write_text(BOSS["tier"])
                    banner(BOSS["banner"], 4.0, XMAS)
                except OSError:
                    pass
                if a.ghosts and not XMAS:                     # the twin-boss finale: Dr. Death comes (back) at Bob Graham's side
                    def twin():
                        time.sleep(4.5)
                        if doc["proc"] is not None and doc["proc"].poll() is None:
                            doc["finale"] = True
                        else:
                            doc["down"] = False; start_doc(finale=True)
                        banner("Twin Terror: The Headless Demon And The Healer!", 4.0, False)
                    threading.Thread(target=twin, daemon=True).start()
                elves = [(p, lg) for _c, p, lg in cur["bots"]]
                cur["bots"] = []
                if elves:                                     # every elf leaves (through the pause menu), Santa is alone
                    threading.Thread(target=leave_then_kill, args=([p for p, _ in elves], [lg for _, lg in elves]), daemon=True).start()
            if BOSS_ON and santa["out"]:
                down = False
                try:                                          # the boss's own brain logs each death; the zombies (the observers) are gone
                    down = bool(re.search(r"^died$", Path(santa["log"]).read_text(errors="replace"), re.M))
                except OSError:
                    pass
                if down and not santa.get("down_said"):
                    santa["down_said"] = True
                    ev(f"{BOSS['name'].upper()} IS DOWN")
                    if not XMAS: banner("The Headless Demon Is Down!", 3.0, False)
                twin_left = a.ghosts and not XMAS and (doc["finale"] or time.time() - santa["at"] < 6.0) and not doc["down"]
                if down and not twin_left:
                    ev(f"the Survivors win ({k} kills)")
                    end_match("win")
                    break
                if santa["proc"].poll() is not None and time.time() - santa["at"] > 20 and not twin_left:
                    ev(f"{BOSS['name']}'s game closed by itself: the Survivors win")
                    end_match("win")
                    break
                time.sleep(0.25)
                if time.time() - santa.get("saved", 0) > 2:
                    santa["saved"] = time.time(); save_ranked()
                continue
            if k >= target[0]:
                ev(f"YOU WIN: {k} kills")
                end_match("win")
                break
            level, want = plan(k)
            if cur["level"] is not None and ORDER.index(level) < ORDER.index(cur["level"]):
                level = cur["level"]            # a tier is never taken back
            if level != cur["level"]:
                if cur["bots"]:
                    # The bots stay in the game and are raised to the new difficulty on the spot (no leaving, no standing in
                    # the pause menu); more bots join to make up the new count.
                    ev(f"{k} kills: the {cur['level']} bots become {level} bots, {max(0, want - len(cur['bots']))} more join")
                    for _, p_, lg in cur["bots"]:
                        try:
                            (HERE / "state" / f"level_{RUN}_{Path(lg).stem.rsplit('_', 1)[1]}.flag").write_text(level_flag(level, ghost=p_ in GHOSTS))
                        except (OSError, IndexError):
                            pass
                    if not a.hero:
                        reward(cur["level"], [p.pid for p in procs])
                    try:                                 # tell the player on screen
                        banner("Elves Grow Restless" if XMAS else "Horde Becomes Stronger", 3.5, XMAS)
                    except OSError:
                        pass
                cur["level"] = level
                try:                                     # the small tier label on screen (tierhud.py) reads this
                    (HERE / "state" / f"tier_{RUN}.txt").write_text(level)
                except OSError:
                    pass
            while len(cur["bots"]) < want:
                if cur["bots"]:
                    ev(f"{k} kills: another {level} bot joins")
                add_bot(level)
            near = BOSS_ON and santa["proc"] is not None and not santa["out"] and k >= (target[0] if XMAS else DEMON_AT) - 5
            time.sleep(0.5 if near else 2)                     # close to Santa's moment: count the kills more often
            save_ranked()
        else:
            ev("time is up")
            end_match("time")
        print("match over", flush=True)
    finally:
        try:
            final_live()
        except Exception:
            pass
        save_ranked()
        leave_then_kill([p for p, lg in zip(procs, logs) if not lg.name.endswith("_hd1.log")],
                        [lg for lg in logs if not lg.name.endswith("_hd1.log")], stagger=False)
        save_ranked(True)
        try:
            (HERE / "state" / f"stop_{RUN}").write_text("stop")
        except OSError:
            pass
        kept = None
        if KEEP_HOST[0]:                                 # the next mission goes on in the host bot's game: it stays
            kept = next(((p_, lg) for p_, lg in zip(procs, logs) if lg.name.endswith("_hd1.log") and p_.poll() is None
                         and getattr(p_, "stdout", None) is None), None)      # (only one whose output goes to its log, not to us)
        if kept:
            try:
                import json as _j
                # (the highest player id the host game has handed out so far: see adopt_host)
                top_id = max([int(x_) for lg_ in logs for x_ in re.findall(r"made this ghost player id (\d+)",
                              Path(lg_).read_text(errors="replace") if Path(lg_).exists() else "")] or [0])
                CHAIN_HOST.write_text(_j.dumps({"run": RUN, "pid": kept[0].pid, "log": str(kept[1]), "t": time.time(), "top_id": top_id}))
                ev("the host bot stays up for the next mission")
            except OSError:
                kept = None
        kill([p_ for p_ in procs if not kept or p_ is not kept[0]], [lg for lg in logs if not kept or lg != kept[1]])
        try:                                            # keep this run's logs: the next run overwrites them
            import shutil
            keep = LOGS / "runs" / time.strftime("%Y%m%d_%H%M%S", time.localtime(began))
            keep.mkdir(parents=True, exist_ok=True)
            for lg in logs:
                shutil.copy2(lg, keep / Path(lg).name)
            for old in sorted((LOGS / "runs").iterdir())[:-6]:      # the last six runs only
                shutil.rmtree(old, ignore_errors=True)
        except Exception:
            pass
        # (23 Nov, the user: two windows "Game is running; cannot change Common.kpf" / "Could not remove the zombie archive", and
        #  the next mission slow to come) the host bot kept for the next mission: the Christmas look, skins and map files stay in
        #  for it - nothing to restore, nothing to wait for
        if kept:
            return
        try:
            if teamcolors.dirty():
                ok = False
                for _ in range(5):                              # the bot game windows take a moment to close
                    time.sleep(3)
                    ok = teamcolors.set_theme("off", quiet=True)
                    if ok:
                        break
                if ok:
                    ev("team colors restored to red/blue")
                else:                                           # your own game window is still open: finish once it closes
                    ev("team colors will be restored when you close the game")
                    subprocess.Popen([sys.executable, str(HERE / "teamcolors.py"), "off", "--wait"], cwd=str(HERE),
                                     creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except Exception as e:
            ev(f"could not restore team colors: {e}")
        if a.dark or a.melee or XMAS:
            try:
                import darkitems
                for _ in range(5):
                    if darkitems.restore(): break
                    time.sleep(3)
            except Exception as e:
                ev(f"could not remove the Dark Mode map files: {e}")
        try:
            import zombieskins
            if zombieskins.installed():
                ok = False
                for _ in range(5):
                    ok = zombieskins.off()
                    if ok: break
                    time.sleep(3)
                if not ok:                                      # still in use: finish once the game closes
                    subprocess.Popen([sys.executable, str(HERE / "zombieskins.py"), "off", "--wait"], cwd=str(HERE),
                                     creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except Exception as e:
            ev(f"could not remove the zombie skins: {e}")


if __name__ == "__main__":
    main()
