"""Distant storm for Survival: python storm.py <run id> <horde.py pid>
Once a player is on the Survivors team, every minute or so: a flash of lightning over the screen, then thunder a moment later
(the game's own thunder sound, turned down). Stops when horde.py writes state\\stop_<run id> or ends. Never takes the focus."""
import random
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def main():
    run = sys.argv[1] if len(sys.argv) > 1 else ""
    parent = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    import ambient                                           # (alive())
    import announce                                          # (thunder())
    stop = HERE / "state" / f"stop_{run}"
    human = HERE / "state" / f"human_{run}.flag"
    over = HERE / "state" / f"music_stop_{run}"            # the match is over: the scoreboard is up
    while not human.exists():
        if stop.exists() or (parent and not ambient.alive(parent)):
            return
        time.sleep(0.5)
    try:
        import ctypes
        u = ctypes.windll.user32
        fg0 = u.GetForegroundWindow()
    except Exception:
        return
    import tkinter as tk
    root = tk.Tk()
    root.withdraw()
    root.overrideredirect(True)
    root.configure(bg="#c9cdd8")
    root.attributes("-topmost", True)
    root.attributes("-alpha", 0.0)
    root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}+0+0")
    root.update()
    try:
        hwnd = u.GetParent(root.winfo_id()) or root.winfo_id()
        style = u.GetWindowLongW(hwnd, -20)
        u.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x80 | 0x20 | 0x80000)    # no activate, tool window, click-through, layered
        u.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)
        u.ShowWindow(hwnd, 4)
        if fg0 and u.GetForegroundWindow() != fg0:
            u.SetForegroundWindow(fg0)
    except Exception:
        return
    state = {"next": time.time() + random.uniform(25, 45), "steps": [], "thunder_at": 0.0}
    FLASH = [(0.20, 0.06), (0.0, 0.08), (0.14, 0.06), (0.07, 0.07), (0.03, 0.08), (0.0, 0.0)]     # faint and see-through

    def refocus():
        try:
            if fg0 and u.GetForegroundWindow() != fg0 and u.GetForegroundWindow() == hwnd:
                u.SetForegroundWindow(fg0)
        except Exception:
            pass

    def step():
        if stop.exists() or over.exists() or (parent and not ambient.alive(parent)):
            root.destroy()
            return
        now = time.time()
        if state["steps"]:
            alpha, wait = state["steps"].pop(0)
            root.attributes("-alpha", alpha)
            refocus()
            root.after(int(wait * 1000) or 20, step)
            return
        if state["thunder_at"] and now >= state["thunder_at"]:
            state["thunder_at"] = 0.0
            announce.thunder(0.45)
        if now >= state["next"]:
            state["steps"] = list(FLASH)
            state["thunder_at"] = now + random.uniform(0.7, 2.4)        # the further the storm, the later the sound
            state["next"] = now + random.uniform(50, 110)
        root.after(100, step)

    root.after(100, step)
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
