@echo off
rem Network capture for the headless-player experiment (listens only, changes nothing).
rem 1. Run this file FIRST (it waits for game windows and attaches to each as soon as it starts: the join is recorded).
rem 2. Then start a LAN game with ONE bot from the launcher (host + bot), and play ~1 minute (move, turn, shoot).
rem It records 150 seconds by default: netcap.cmd 200 for longer.
rem Afterwards tell Claude it is done; the files are in state\netcap.
cd /d "%~dp0"
set "SECS=%~1"
if "%SECS%"=="" set "SECS=150"
".venv\Scripts\python.exe" -u netcap.py %SECS%
pause
