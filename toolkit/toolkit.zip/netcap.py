"""Network capture for the "headless player" experiment: attach to every OutlawsAHOM.exe and log every UDP/TCP message it
sends or receives (Winsock sendto / recvfrom / WSASendTo / WSARecvFrom / send / recv), with the time, which game copy, the
peer address and the bytes. Nothing is changed in the game; it only listens.

  python netcap.py [seconds]          (default 150; start it FIRST, then start the host and one bot: copies that start later are attached at once, so the join is recorded)
Writes state\\netcap\\<pid>.jsonl (one JSON object per message) and a summary netcap_summary.txt.
Which copy is the host: the one whose command line has no -userpath is you; the bots have -userpath."""
import json
import sys
import time
from pathlib import Path

import frida

HERE = Path(__file__).resolve().parent
OUT = HERE / "state" / "netcap"
SECS = float(sys.argv[1]) if len(sys.argv) > 1 else 150.0
MAXBYTES = 512

JS = r"""
const MAXB = %d;
function mod() { return Process.findModuleByName('ws2_32.dll') || Process.findModuleByName('WS2_32.dll'); }
const m = mod();
function sockaddr(p) {
  try {
    if (p.isNull()) return null;
    const fam = p.readU16();
    if (fam === 2) return p.add(4).readU8() + '.' + p.add(5).readU8() + '.' + p.add(6).readU8() + '.' + p.add(7).readU8() + ':' + ((p.add(2).readU8() << 8) | p.add(3).readU8());
    return 'fam' + fam;
  } catch (e) { return null; }
}
function hex(p, n) { try { return p.readByteArray(Math.min(n, MAXB)); } catch (e) { return null; } }
function emit(dir, api, sock, peer, buf, n) {
  if (n <= 0) return;
  send({ t: Date.now() / 1000, dir: dir, api: api, sock: sock, peer: peer, len: n }, hex(buf, n));
}
function hook(name, cb) {
  const a = m.findExportByName(name);
  if (!a) return;
  Interceptor.attach(a, cb);
}
hook('sendto', { onEnter(a) { emit('out', 'sendto', a[0].toInt32(), sockaddr(a[4]), a[1], a[2].toInt32()); } });
hook('send', { onEnter(a) { emit('out', 'send', a[0].toInt32(), null, a[1], a[2].toInt32()); } });
hook('recvfrom', {
  onEnter(a) { this.s = a[0].toInt32(); this.b = a[1]; this.f = a[4]; },
  onLeave(r) { const n = r.toInt32(); if (n > 0) emit('in', 'recvfrom', this.s, sockaddr(this.f), this.b, n); } });
hook('recv', {
  onEnter(a) { this.s = a[0].toInt32(); this.b = a[1]; },
  onLeave(r) { const n = r.toInt32(); if (n > 0) emit('in', 'recv', this.s, null, this.b, n); } });
hook('WSASendTo', { onEnter(a) { try { const c = a[2].toInt32(); const bufs = a[1]; for (let i = 0; i < c; i++) { const len = bufs.add(i * 16).readU32(); const p = bufs.add(i * 16 + 8).readPointer(); emit('out', 'WSASendTo', a[0].toInt32(), sockaddr(a[5]), p, len); } } catch (e) {} } });
hook('WSASend', { onEnter(a) { try { const c = a[2].toInt32(); const bufs = a[1]; for (let i = 0; i < c; i++) { const len = bufs.add(i * 16).readU32(); const p = bufs.add(i * 16 + 8).readPointer(); emit('out', 'WSASend', a[0].toInt32(), null, p, len); } } catch (e) {} } });
hook('WSARecvFrom', {
  onEnter(a) { this.s = a[0].toInt32(); this.bufs = a[1]; this.cnt = a[2].toInt32(); this.f = a[5]; this.nb = a[3]; },
  onLeave(r) { try { if (r.toInt32() !== 0 || this.nb.isNull()) return; const n = this.nb.readU32(); if (n > 0) emit('in', 'WSARecvFrom', this.s, sockaddr(this.f), this.bufs.add(8).readPointer(), n); } catch (e) {} } });
hook('WSARecv', {
  onEnter(a) { this.s = a[0].toInt32(); this.bufs = a[1]; this.nb = a[3]; },
  onLeave(r) { try { if (r.toInt32() !== 0 || this.nb.isNull()) return; const n = this.nb.readU32(); if (n > 0) emit('in', 'WSARecv', this.s, null, this.bufs.add(8).readPointer(), n); } catch (e) {} } });
send({ ready: true });
""" % MAXBYTES


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    dev = frida.get_local_device()
    files, sessions, counts, seen = {}, [], {}, set()

    def attach(p):
        f = open(OUT / f"{p.pid}.jsonl", "w", encoding="utf-8")
        files[p.pid] = f
        counts[p.pid] = [0, 0]
        s = dev.attach(p.pid)
        sc = s.create_script(JS)

        def on_msg(msg, data, pid=p.pid):
            if msg.get("type") != "send":
                if msg.get("type") == "error":
                    print("script error:", msg.get("description"))
                return
            pl = msg["payload"]
            if pl.get("ready"):
                return
            if data is not None:
                pl["hex"] = data.hex()
            pl["pid"] = pid
            files[pid].write(json.dumps(pl) + "\n")
            counts[pid][0 if pl["dir"] == "out" else 1] += 1
        sc.on("message", on_msg)
        sc.load()
        sessions.append(s)
        print(f"listening to game copy pid {p.pid}")

    print(f"waiting for game copies (also ones that start LATER, so the join is recorded); capturing for {SECS:.0f} s from now ...")
    t0 = time.time()
    try:
        while time.time() - t0 < SECS:
            for p in dev.enumerate_processes():
                if p.name.lower() == "outlawsahom.exe" and p.pid not in seen:
                    seen.add(p.pid)
                    try:
                        attach(p)
                    except Exception as e:
                        print("could not attach to", p.pid, e)
            time.sleep(0.3)
    except KeyboardInterrupt:
        pass
    for s in sessions:
        try:
            s.detach()
        except Exception:
            pass
    for f in files.values():
        f.close()
    lines = [f"pid {pid}: {c[0]} sent, {c[1]} received" for pid, c in counts.items()]
    (HERE / "netcap_summary.txt").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    print("done: state\\netcap\\*.jsonl and netcap_summary.txt")
    return 0


if __name__ == "__main__":
    sys.exit(main())
