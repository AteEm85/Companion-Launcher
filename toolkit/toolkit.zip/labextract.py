"""Copy chosen files out of a game .lab archive into botctl\\extract\\ (the archive itself is not changed).
  python labextract.py olremaster1.lab JAMES.SPX MARY.SPX ...      (default: the six character sprites)"""
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
GAME = HERE.parent
DEFAULT = ["JAMES.SPX", "MARY.SPX", "Bobgrahm.SPX", "DRDEATH.SPX", "SANCHEZ.SPX", "TWOFEATH.SPX"]
lab = sys.argv[1] if len(sys.argv) > 1 else "olremaster1.lab"
want = [w.lower() for w in (sys.argv[2:] or DEFAULT)]
dest = HERE / "extract"
dest.mkdir(exist_ok=True)
with (GAME / lab).open("rb") as f:
    head = f.read(16)
    cnt, = struct.unpack_from("<I", head, 8)
    ent = f.read(16 * cnt)
    blob = f.read(struct.unpack_from("<I", head, 12)[0])
    for i in range(cnt):
        no, off, size, _t = struct.unpack_from("<IIII", ent, 16 * i)
        nm = blob[no:blob.index(b"\0", no)].decode("latin1")
        if nm.lower() in want:
            f.seek(off)
            (dest / nm).write_bytes(f.read(size))
            print("extracted", nm, size)
print("done:", dest)
