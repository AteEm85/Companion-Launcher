@echo off
cd /d "%~dp0"
set HORDE_WINDOWS=visible
".venv\Scripts\python.exe" -u lms.py --map drygulch --bots 4 --minutes 8
exit
