@echo off
rem Look-while-dead probe (watches only, changes nothing in the game).
rem 1. Start a game and get into the match.
rem 2. Double-click this file. It watches your game for 4 minutes.
rem 3. Play: die a few times, and while dead move the mouse up and down (and left and right).
rem 4. When it says "done", tell Claude. The result is in state\lookprobe.txt.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u lookprobe.py %*
pause
