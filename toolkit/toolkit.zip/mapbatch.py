"""Test the community maps from https://github.com/outlawshub-arch/maps/releases with the bots.

    mapbatch.cmd                 every map not already tested, 1.5 minutes each
    mapbatch.cmd --limit 20      just the next 20 (a trial run)
    mapbatch.cmd --list          only fetch and print the list of maps it would test

For each zip it downloads the map, puts its .lab and .rcm into the game folder, plays three bots on it with
pathcheck.py, then removes the files again (nothing of yours is touched or overwritten). Maps you already have, and
maps already tested, are skipped. The remastered (_RM) version of a map is used when there is one.
It waits for any running pathcheck/sweep to finish first. Results go in the same files as the sweep:
pathcheck_report.txt, pathcheck_data.csv, sweep_log.txt; mapbatch_log.txt has one line per zip.
Resumes by itself: run it again and it carries on.
"""
import argparse
import io
import json
import re
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import lvt

GAME = lvt.GAME_DIR
REPO = "https://github.com/outlawshub-arch/maps"
TAGS = ["maps3", "maps", "maps2"]               # maps3 holds the remastered versions: first, so they win
ASSETS = HERE / "mapbatch_assets.json"
DONE = HERE / "mapbatch_done.txt"
LOG = HERE / "mapbatch_log.txt"
EXTRA = HERE / "maps_extra.json"
INSTALLED = HERE / "mapbatch_installed.txt"      # files put in the game folder right now (removed again if the run is cut short)
CACHE = HERE / "mapcache"


def get(url, tries=4):
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=120) as r:
                return r.read()
        except Exception as e:
            err = e
            time.sleep(3 * (k + 1))
    raise err


def fetch_assets():
    """{tag: [zip names]} from the release pages (cached in mapbatch_assets.json)."""
    out = {}
    for tag in TAGS:
        names, seen = [], set()
        for page in range(1, 40):
            html = get(f"{REPO}/releases/expanded_assets/{tag}?page={page}").decode("utf-8", "replace")
            found = [n for n in re.findall(r'/releases/download/[^/"]+/([^"?]+)"', html) if n.lower().endswith(".zip")]
            new = [n for n in found if n not in seen]
            if not new:
                break
            seen.update(new)
            names += new
        out[tag] = names
    ASSETS.write_text(json.dumps(out))
    return out


def stem(name):
    s = re.sub(r"\.zip$", "", name, flags=re.I)
    return re.sub(r"_RM$", "", s, flags=re.I).lower()


def plan(assets):
    chosen = {}
    for tag in TAGS:
        for n in assets.get(tag, []):
            chosen.setdefault(stem(n), (tag, n))
    return sorted(chosen.values(), key=lambda t: (stem(t[1]) )), len(chosen)


def waiting_for_other_runs():
    cmd = ["powershell", "-NoProfile", "-Command",
           "@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'pathcheck[.]py' }).Count"]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return int((r.stdout or "0").strip() or 0) > 0
    except Exception:
        return False


def have_keys():
    keys = {p.stem.lower() for p in GAME.glob("*.rcm")}
    keys |= {p.stem.lower() for p in GAME.glob("*.lab")}
    from botctl import MAPS
    keys |= {k.lower() for k in MAPS}
    f = HERE / "sweep_done.txt"
    if f.exists():
        keys |= {k.lower() for k in f.read_text().split()}
    return keys


def log(line):
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--minutes", type=float, default=1.5)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--lanes", type=int, default=1, help="how many maps to play at the same time (default 1)")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--only", help="a text file with lines 'tag zipname': test just those zips (the audit's flagged maps)")
    ap.add_argument("--refresh", action="store_true", help="fetch the list from GitHub again")
    args = ap.parse_args()
    assets = json.loads(ASSETS.read_text()) if ASSETS.exists() and not args.refresh else fetch_assets()
    todo, n = plan(assets)
    if args.only:
        want = {tuple(l.split()[:2]) for l in Path(args.only).read_text().splitlines() if len(l.split()) >= 2}
        order = [tuple(l.split()[:2]) for l in Path(args.only).read_text().splitlines() if len(l.split()) >= 2]
        have_zip = set(todo)
        todo = [t for t in order if t in have_zip]          # the file's order: worst-flagged first
    print(f"{n} distinct maps in the releases ({sum(len(v) for v in assets.values())} zips)")
    if args.list:
        for tag, name in todo:
            print(tag, name)
        return
    done = set(DONE.read_text().split("\n")) if DONE.exists() else set()
    CACHE.mkdir(exist_ok=True)
    import threading
    from concurrent.futures import ThreadPoolExecutor
    lock = threading.Lock()
    installed_now = {}                              # key -> files, for maps_extra.json
    lanes_free = list(range(args.lanes))
    lane_lock = threading.Lock()
    taken = {"n": 0}

    def write_extra():
        EXTRA.write_text(json.dumps(list(v[0] for v in installed_now.values())))
        INSTALLED.write_text("\n".join(str(p) for v in installed_now.values() for p in v[1]))

    def work(item):
        tag, name = item
        if name in done or stem(name) in done:
            return
        with lock:
            if args.limit and taken["n"] >= args.limit:
                return
        with lane_lock:
            lane = lanes_free.pop(0)
        zpath = CACHE / f"{tag}_{name}"
        installed, key = [], None
        try:
            zpath.write_bytes(get(f"{REPO}/releases/download/{tag}/{name}"))
            z = zipfile.ZipFile(zpath)
            labs = [i for i in z.infolist() if i.filename.lower().endswith(".lab")]
            rcms = [i for i in z.infolist() if i.filename.lower().endswith(".rcm")]
            if not labs or not rcms:
                log(f"{name}: skipped, no .lab/.rcm in the zip")
                done_add(name)
                return
            key = Path(rcms[0].filename).stem
            with lock:
                if key.lower() in have_keys() or key in installed_now:
                    log(f"{name}: skipped, {key} already tested or on this computer")
                    done_add(name)
                    return
                text = z.read(rcms[0]).decode("latin-1")
                nm = re.search(r"NAME:\s*(.+)", text)
                modes = re.search(r"MODES:\s*(\w+)", text)
                for info in labs[:1] + rcms[:1]:
                    dest = GAME / Path(info.filename).name
                    if dest.exists():
                        raise RuntimeError(f"{dest.name} already exists; not touching it")
                    dest.write_bytes(z.read(info))
                    installed.append(dest)
                installed_now[key] = ({"key": key, "name": nm.group(1).strip() if nm else key,
                                       "modes": modes.group(1).upper() if modes else ""}, installed)
                write_extra()
            with lock:
                taken["n"] += 1                     # --limit counts maps actually played, not skipped zips
            t0 = time.time()
            subprocess.run([sys.executable, "-u", str(HERE / "pathcheck.py"), "--keep", "--minutes", str(args.minutes),
                            "--lane", str(lane), "--no-global-kill", "--maps", key],
                           cwd=str(HERE), capture_output=True, text=True, errors="replace")
            last = [l for l in (HERE / "sweep_log.txt").read_text().splitlines() if l.startswith(key + " ")][-1:]
            ok = bool(last) and "FAILED" not in last[0]
            log(f"{name}: {key} ({installed_now[key][0]['modes'] or '?'}) lane {lane + 1} {'ok' if ok else 'FAILED to start'} {time.time() - t0:.0f}s")
            done_add(name)
        except Exception as e:
            log(f"{name}: error {e}")
        finally:
            for p in installed:
                try:
                    p.unlink()
                except OSError:
                    pass
            with lock:
                if key in installed_now:
                    del installed_now[key]
                write_extra()
            try:
                zpath.unlink()
            except OSError:
                pass
            with lane_lock:
                lanes_free.append(lane)

    while waiting_for_other_runs():
        print("a pathcheck run is still going; waiting...", flush=True)
        time.sleep(120)
    EXTRA.write_text("[]")
    if INSTALLED.exists():                          # left over from a run that was stopped: put the game folder back
        for line in INSTALLED.read_text(errors="replace").splitlines():
            line = line.strip().lstrip("\ufeff\x00")
            if len(line) < 5:
                continue
            try:
                Path(line).unlink()
            except Exception:
                pass
        INSTALLED.write_text("")
    with ThreadPoolExecutor(args.lanes) as ex:
        list(ex.map(work, todo))
    EXTRA.write_text("[]")
    log("mapbatch finished")


def done_add(name):
    with open(DONE, "a") as f:
        f.write(name + "\n")


if __name__ == "__main__":
    main()
