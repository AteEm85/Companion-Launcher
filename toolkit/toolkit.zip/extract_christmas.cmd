@echo off
rem Christmas lights: copies the Sanctuary tree sprite (TREE01.SPX) and the 40 building wall textures out of
rem olremaster1.lab into botctl\extract\ (about 23 MB). The archive itself is not changed. Run once, then tell Claude.
cd /d "%~dp0"
.venv\Scripts\python.exe labextract.py olremaster1.lab TREE01.SPX GWDRYG03.HDX GWTELEG2.HDX mwall2.HDX GWADOBE2.HDX FWware3.HDX mwall1.HDX GWMISS04.HDX GWWOODTN.HDX GWMISS02.HDX FWwareH2.HDX WWLOGH.HDX WWLOGV.HDX GWBARN3.HDX GWBRWN2.HDX mwall3.HDX GWWOODBK.HDX GWBANK01.HDX GWBOXBG1.HDX GWCOWPK2.HDX fWfence1.HDX fWbwar1.HDX GCGRNIT2.HDX fWbrnX04.HDX FWware6.HDX fWwarf.HDX GWCHAP3.HDX fWcrate3.HDX fFrotf.HDX GWBOXSML.HDX fCntop02.HDX fWmplnk2.HDX GWPOSTMN.HDX GWCrate1.HDX fWredwd2.HDX fWcraSM1.HDX GWTELEG1.HDX GCBGRAN.HDX GC_SHACK.HDX GFBRN2.HDX fCplnk01.HDX
pause
