@echo off
rem Next-map probe, round 4 (watches only, changes nothing). Takes up to 15 minutes.
rem 1. Start Outlaws yourself and stay in the main menu.  2. Double-click this file.
rem 3. Follow the steps it shows: host a LAN game (time limit 1 minute), play until it ends, then host once more on a different map,
rem    one menu screen at a time.
rem 4. When it says "done", tell Claude. The result is in state\mapprobe4.txt.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u mapprobe4.py %*
pause
