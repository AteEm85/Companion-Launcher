@echo off
rem Look up and down while dead, in YOUR game (not the bots). Leave this window open while you play; close it to turn it off.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u deadlook.py
pause
