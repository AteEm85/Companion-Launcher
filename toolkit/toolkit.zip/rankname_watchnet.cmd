@echo off
rem Which character is the host's own? Start the game, run this, then pick Sanchez, host, end; Mary, host, end; Bob, host, end. Claude reads state\rankname_log.txt.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u rankname.py --name T4H_WaRRioR --prefix "[12]" --watchnet
pause
