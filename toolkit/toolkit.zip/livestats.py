"""The live scoreboard's numbers, worked out from the ghosts' and bots' logs while a game runs.

    import livestats
    board = livestats.build(log_paths, tier="hard", host=("T4H_WaRRioR", "sanchez"))
    livestats.write(board, HERE / "state" / f"live_{run}.json")

What each log line gives (written by netre/ghost.py):
    FEED <time> $$code$$a$$b$$       the game's kill feed (the first ghost logs every kill message it gets, every ghost its own)
    kill message sent: $$..$$        a ghost's own death (older ghost.py without FEED lines)
    LIVE me <name>                   the ghost's own name (whose "ghost shot" lines these are)
    ghost shot N (w) at X: hit @d    a ghost's shot (its accuracy, its longest hit)
    hit by X! damage d, ... @d       a player's hit on a ghost (that player's hits and longest hit)
    PSHOT <time> <name>              a player started firing (their shots, roughly: see ghost.py)
    FMT: G A killed B!               an in-game bot's kill feed (horde without ghosts: used when no FEED line exists)

Rows: name, title, level, prestige, ghost (a bot), kills, deaths, suicides, streak (now), best_streak, shots, hits, acc (0-100 or
None), best_shot (the longest hit, in game feet) and the summary (MVP, most kills, longest streak, best shot) for the end card.
Nothing here needs more than the standard library (the companion app shares it)."""
import json
import os
import re
import time
from pathlib import Path

FEED_RE = re.compile(r"^FEED (\d+(?:\.\d+)?) \$\$(\d+)\$\$(.*?)\$\$(?:(.*?)\$\$)?\s*$")
SENT_RE = re.compile(r"^kill message sent: \$\$(\d+)\$\$(.*?)\$\$(?:(.*?)\$\$)?\s*$")
ME_RE = re.compile(r"^LIVE me (.+?)\s*$")
GSHOT_RE = re.compile(r"^ghost shot \d+ \(.*?\) at (.+?): (hit|miss)\w* @(\d+)")
HITBY_RE = re.compile(r"^hit by (.+?)! damage [\d.]+, health [-\d.]+/\d+(?: @(\d+))?")
PSHOT_RE = re.compile(r"^PSHOT (\d+(?:\.\d+)?) (.+?)\s*$")
FMT_RE = re.compile(r"^FMT: G (.+?) (?:killed|blew up) (.+?)!\s*$")
FMT_SELF_RE = re.compile(r"^FMT: G (.+?) (?:committed suicide|died from a fall|drowned|got crushed|got telefragged|self-destructed)!\s*$")
PREFIX_RE = re.compile(r"^\[(\d{1,2})([BSG]?)\](.*)$")
BOT_RE = re.compile(r"^((Zombie|Skeleton|Bot|Host Bot|Elf|Santa|Gingerbread|Snowman|Nutcracker|Present)( \d+| #\d{3}| No\. \d{3})?|GhostBot_\d+|GhostLan\d+|hd\d+)$", re.I)

# The rank titles, by level (1-50); a prestige puts its metal in front: "Silver Marshal"
TITLES = [(50, "Living Legend"), (45, "Outlaw King"), (40, "Desperado"), (35, "Gunslinger"), (30, "Marshal"), (25, "Sheriff"),
          (20, "Bounty Hunter"), (15, "Deputy"), (10, "Gunhand"), (5, "Drifter"), (1, "Greenhorn")]
METAL = {0: "", 1: "Bronze", 2: "Silver", 3: "Gold"}
MAP_LABELS = {"civpow2": "Buckshotville", "drygulch": "Dry Gulch", "fort": "The Fort", "granary": "The Granary",
              "hargrove": "Hargrove's Pattern Repair", "lilbatl": "Bunkers", "mltsimms": "Simms At Night", "orleans": "Orleans",
              "thudtowr": "Thud Tower", "town_2p": "Sanctuary", "wilderns": "Wilderness", "thedip1s": "The Dip", "stone": "Stone"}


def map_label(key):
    if not key:
        return ""
    k = str(key)
    if k.lower() in MAP_LABELS:
        return MAP_LABELS[k.lower()]
    try:                                              # custom maps: their names from maps_data.json (mapscan.py)
        for m in json.loads((Path(__file__).resolve().parent / "maps_data.json").read_text()):
            if str(m.get("key", m.get("map", ""))).lower() == k.lower() and m.get("name"):
                return m["name"]
    except (OSError, ValueError, AttributeError, TypeError):
        pass
    return k
LETTER_PRESTIGE = {"": 0, "B": 1, "S": 2, "G": 3}


def title(level, prestige=0):
    if not level:
        return ""
    t = next(n for lv, n in TITLES if level >= lv)
    return (METAL.get(prestige, "") + " " + t).strip()


def clean(name):
    """('T4H_WaRRioR', 12, 2) from '[12S]T4H_WaRRioR__' (the level prefix the launcher puts in front of a name)"""
    name = (name or "").rstrip("_").strip()
    m = PREFIX_RE.match(name)
    if m:
        return m.group(3).rstrip("_").strip() or name, int(m.group(1)), LETTER_PRESTIGE.get(m.group(2), 0)
    return name, 0, 0


def _read(path):
    try:
        return Path(path).read_text(errors="replace")
    except OSError:
        return ""


def events_from(texts):
    """[(t, kind, killer, victim)] in order, kind = kill / tnt / self, from the logs' FEED lines (the same message in two logs
    within 2 s counts once); logs without FEED lines give their 'kill message sent' and FMT lines instead (no times: put last)."""
    feed, loose = [], []
    for text in texts:
        has_feed = "\nFEED " in text or text.startswith("FEED ")
        n = 0
        for line in text.splitlines():
            line = line.rstrip("\r")
            m = FEED_RE.match(line)
            if m:
                feed.append((float(m.group(1)), m.group(2), m.group(3), m.group(4) or ""))
                continue
            if has_feed:
                continue
            m = SENT_RE.match(line)
            if m:
                n += 1
                loose.append((n, m.group(1), m.group(2), m.group(3) or ""))
                continue
    seen, out = [], []
    for t, code, a, b in sorted(feed):
        key = (code, a, b)
        if any(k == key and t - t0 < 2.0 for t0, k in seen[-40:]):
            continue
        seen.append((t, key))
        out.append(_event(t, code, a, b))
    last = out[-1][0] if out else 0.0
    for n, code, a, b in loose:
        out.append(_event(last + n * 1e-3, code, a, b))
    return [e for e in out if e]


def _event(t, code, a, b):
    a, b = clean(a)[0], clean(b)[0]
    if code in ("20059", "20044") or not b:
        return (t, "self", a, a)
    return (t, "tnt" if code == "20061" else "kill", a, b)


def fmt_events(text):
    """an in-game bot observer's kill feed (FMT lines), in order (no 'you' lines: the observer's name is not in its log)"""
    out = []
    for i, line in enumerate(text.splitlines()):
        line = line.rstrip("\r")
        m = FMT_SELF_RE.match(line)
        if m:
            a = clean(m.group(1))[0]
            out.append((i * 1e-3, "self", a, a)); continue
        m = FMT_RE.match(line)
        if m and m.group(2) != "you" and not m.group(1).endswith(" you"):
            out.append((i * 1e-3, "kill", clean(m.group(1))[0], clean(m.group(2))[0]))
    return out


def build(paths, **kw):
    """The board from these log files. host = (player, character) of the PC's own player for their title from the XP database;
    everyone else's title comes from the level prefix in their in-game name."""
    return build_texts([_read(p) for p in paths], **kw)


def build_texts(texts, tier="", host=None, ghost_names=(), observer_text="", mode="", map_name=""):
    ghosts = {clean(g)[0] for g in ghost_names}
    rows = {}
    levels = {}

    def row(name):
        r = rows.get(name)
        if r is None:
            r = rows[name] = {"name": name, "kills": 0, "deaths": 0, "suicides": 0, "streak": 0, "best_streak": 0,
                              "shots": 0, "hits": 0, "best_shot": 0, "ghost": False}
        return r

    def note_name(raw):
        n, lv, pr = clean(raw)
        if lv:
            levels[n] = (lv, pr)
        return n
    for text in texts:
        me = None
        for line in text.splitlines():
            line = line.rstrip("\r")
            m = ME_RE.match(line)
            if m:
                me = clean(m.group(1))[0]; ghosts.add(me); row(me)["ghost"] = True
                continue
            m = GSHOT_RE.match(line)
            if m and me:
                r = row(me); r["shots"] += 1
                if m.group(2) == "hit":
                    r["hits"] += 1; r["best_shot"] = max(r["best_shot"], int(m.group(3)))
                continue
            m = HITBY_RE.match(line)
            if m:
                r = row(note_name(m.group(1))); r["hits"] += 1
                if m.group(2):
                    r["best_shot"] = max(r["best_shot"], int(m.group(2)))
                continue
            m = PSHOT_RE.match(line)
            if m:
                row(note_name(m.group(2)))["shots"] += 1
                continue
            for raw in re.findall(r"\$\$\d+\$\$(.*?)\$\$(?:(.*?)\$\$)?", line) if line.startswith("FEED ") else ():
                for x in raw:
                    if x: note_name(x)
    evs = events_from(texts)
    if not evs and observer_text:
        evs = fmt_events(observer_text)
    for _t, kind, a, b in evs:
        if kind == "self":
            r = row(a); r["deaths"] += 1; r["suicides"] += 1; r["streak"] = 0
            continue
        k, v = row(a), row(b)
        k["kills"] += 1; k["streak"] += 1; k["best_streak"] = max(k["best_streak"], k["streak"])
        v["deaths"] += 1; v["streak"] = 0
    if host and host[0]:
        try:
            import xp
            st = xp.status(host[0], host[1])
            hn = clean(host[0])[0]
            for n in rows:
                if n.lower() == hn.lower():
                    levels[n] = (st["level"], st["prestige"])
        except Exception:
            pass
    out = []
    for n, r in rows.items():
        r["ghost"] = r["ghost"] or n in ghosts or bool(BOT_RE.match(n))
        r["shots"] = max(r["shots"], r["hits"])           # (a held trigger is one shot in the pose count: never under 100 %)
        r["acc"] = round(100.0 * r["hits"] / r["shots"]) if r["shots"] else None
        lv, pr = levels.get(n, (0, 0))
        r["level"], r["prestige"], r["title"] = lv, pr, title(lv, pr) if not r["ghost"] else ""
        if r["kills"] or r["deaths"] or r["shots"] or not r["ghost"]:
            out.append(r)
    out.sort(key=lambda r: (r["ghost"], -r["kills"], r["deaths"], r["name"].lower()))
    feed = [(f"{k_} blew up {v_}" if kind == "tnt" else f"{k_} killed {v_}" if kind == "kill" else f"{k_} died") for _t, kind, k_, v_ in evs[-8:]]
    return {"t": time.time(), "tier": tier, "mode": mode, "map": map_label(map_name), "map_key": map_name, "rows": out, "summary": summary(out),
            "feed": feed}


def summary(rows):
    """MVP (players first: kills x2 + best streak - deaths, then accuracy), most kills, longest streak, best shot"""
    if not rows:
        return {}
    people = [r for r in rows if not r["ghost"]] or rows

    def score(r):
        return (r["kills"] * 2 + r["best_streak"] - r["deaths"], r["acc"] or 0)
    mvp = max(people, key=score)
    most = max(rows, key=lambda r: (r["kills"], -r["deaths"]))
    streak = max(rows, key=lambda r: (r["best_streak"], r["kills"]))
    shot = max(rows, key=lambda r: r["best_shot"])
    s = {"mvp": mvp["name"], "mvp_line": f"{mvp['kills']} kills, {mvp['deaths']} deaths" + (f", {mvp['acc']}% accuracy" if mvp["acc"] is not None else "")}
    if most["kills"]:
        s["most_kills"] = [most["name"], most["kills"]]
    if streak["best_streak"] > 1:
        s["longest_streak"] = [streak["name"], streak["best_streak"]]
    if shot["best_shot"]:
        s["best_shot"] = [shot["name"], shot["best_shot"]]
    return s


def write(board, path):
    """written whole and then renamed, so a reader never sees half a file"""
    path = Path(path)
    tmp = path.with_suffix(".tmp")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_text(json.dumps(board))
        os.replace(tmp, path)
        return True
    except OSError:
        return False


def save_summary(board, path, keep=200):
    """the finished match's board and summary, added to a list of the last <keep> (state/match_summaries.json)"""
    path = Path(path)
    try:
        hist = json.loads(path.read_text())
        if not isinstance(hist, list):
            hist = []
    except (OSError, ValueError):
        hist = []
    entry = {k: board.get(k) for k in ("t", "began", "map", "mode", "tier", "rows", "summary", "team_kills", "target")}
    entry["t"] = time.time()
    hist.append(entry)
    write(hist[-keep:], path)
    return entry


def summary_lines(board):
    """the end-of-match card's lines (and the launcher's chat line)"""
    s = board.get("summary") or {}
    out = []
    if s.get("mvp"):
        out.append(("MVP", f"{s['mvp']}  ({s.get('mvp_line', '')})"))
    if s.get("most_kills"):
        out.append(("Most kills", f"{s['most_kills'][0]}  ({s['most_kills'][1]})"))
    if s.get("longest_streak"):
        out.append(("Longest streak", f"{s['longest_streak'][0]}  ({s['longest_streak'][1]} in a row)"))
    if s.get("best_shot"):
        out.append(("Best shot", f"{s['best_shot'][0]}  ({s['best_shot'][1]} ft)"))
    return out


if __name__ == "__main__":
    import sys
    b = build(sys.argv[1:])
    print(json.dumps(b, indent=1))
