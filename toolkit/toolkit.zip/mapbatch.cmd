@echo off
rem Tests the community maps from the GitHub releases (see mapbatch.py). Safe to stop and start again.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u mapbatch.py %*
pause
