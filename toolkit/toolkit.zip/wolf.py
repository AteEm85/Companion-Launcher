"""A wolf far off in the night: python wolf.py <run id> <horde.py pid>
Once a player is on the Survivors team, about every minute (45-90 s, never the same one twice in a row) one of
sounds\\wolf_howl.wav plays, quietly. Stops when the match ends or horde.py does."""
import random
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def main():
    run = sys.argv[1] if len(sys.argv) > 1 else ""
    parent = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    import ambient
    import winsound
    files = [f for f in (HERE / "sounds" / "wolf_howl.wav",) if f.exists()]
    if not files:
        return
    st = HERE / "state"
    stop, over, human = st / f"stop_{run}", st / f"music_stop_{run}", st / f"human_{run}.flag"

    def done():
        return stop.exists() or over.exists() or (parent and not ambient.alive(parent))
    while not human.exists():
        if done():
            return
        time.sleep(0.5)
    nxt = time.time() + random.uniform(35, 70)
    last = None
    while not done():
        if time.time() >= nxt:
            f = random.choice([x for x in files if x != last] or files)
            last = f
            winsound.PlaySound(str(f), winsound.SND_FILENAME | winsound.SND_ASYNC)
            nxt = time.time() + random.uniform(45, 90)
        time.sleep(1.0)
    winsound.PlaySound(None, winsound.SND_PURGE)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
