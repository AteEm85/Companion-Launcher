@echo off
rem Next-map probe, round 2 (watches only, changes nothing). Takes up to 15 minutes.
rem 1. Start Outlaws yourself and stay in the main menu.  2. Double-click this file.
rem 3. Follow the steps it shows: host a LAN game (time limit 1 minute), play until it ends, pick another map if the
rem    game lets you, then go back to the main menu and host once more on a different map.
rem 4. When it says "done", tell Claude. The result is in state\mapprobe2.txt.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u mapprobe2.py %*
pause
