@echo off
cd /d "%~dp0"
set BOT_TRACEFMT=1
set PATHCHECK_WINDOWS=visible
".venv\Scripts\python.exe" -u pathcheck.py --keep --minutes 3 --no-global-kill --maps drygulch
exit
