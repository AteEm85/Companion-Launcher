"""Outlaws bot launcher: a small window to set up the bots and start a LAN game.

Put BotLauncher.exe (or run this file) in the botctl folder, next to botctl.py and bots.cmd.
  Launch Game  - starts the bots (the first one hosts) with the settings below
  Join Game    - starts your own OutlawsAHOM.exe and joins the LAN game on this PC
Only the standard library is used, so it builds into one .exe with build_exe.cmd.
"""
import json
import os
import random
import subprocess
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, simpledialog, ttk
try:
    import modserver                      # lets friends' Outlaws Companion fetch the mods a hosted game needs
except Exception:
    modserver = None

# The folder with botctl.py: next to the .exe when frozen, else next to this file.
HERE = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
GAME_DIR = HERE.parent
GAME_EXE = GAME_DIR / "OutlawsAHOM.exe"
SETTINGS = HERE / "launcher_settings.json"
BOT_PRESETS = HERE / "bot_presets.json"
PRESET_SLOTS = 10

# ---- what the lists offer (edit here to add maps later) -------------------------------------------------------------
MAPS = [("Buckshotville", "civpow2"), ("Dry Gulch", "drygulch"), ("The Fort", "fort"), ("The Granary", "granary"),
        ("Hargrove's Pattern Repair", "hargrove"), ("Bunkers", "lilbatl"), ("Simms At Night", "mltsimms"), ("Orleans", "orleans"),
        ("Thud Tower", "thudtowr"), ("Sanctuary", "town_2p"), ("Wilderness", "wilderns"),
        ("The Dip (custom)", "TheDip1s"), ("Stone (custom)", "Stone")]      # (label, botctl --map value)
# The game modes each map has (from its .rcm file), by botctl --mode value.
_STD = {"dm", "ctf", "chicken", "team"}
MAP_MODES = {"civpow2": _STD, "drygulch": _STD, "fort": _STD, "granary": _STD, "hargrove": _STD, "lilbatl": {"dm", "chicken", "team"}, "mltsimms": _STD,
             "orleans": _STD, "thudtowr": {"dm", "team"}, "town_2p": {"dm", "ctf", "chicken", "tag"}, "wilderns": _STD,
             "TheDip1s": {"dm", "ctf", "chicken", "team"}, "Stone": {"dm", "ctf", "team"}}
# Every other map comes from maps_data.json next to the launcher (written by mapscan.py, which reads each map's .rcm:
# its name and game modes). Re-run mapscan.cmd after adding maps; no rebuild needed.
_LETTER_MODE = {"D": "dm", "M": "team", "C": "ctf", "T": "tag", "K": "chicken", "S": "doc"}
try:
    _have = {k for _, k in MAPS}
    _extra = []
    for _m in json.loads((HERE / "maps_data.json").read_text()):
        _modes = {_LETTER_MODE[c] for c in _m.get("modes", "") if c in _LETTER_MODE}
        if _m["key"] in MAP_MODES and _m["key"] in _have:
            if _modes:
                MAP_MODES[_m["key"]] = _modes              # the .rcm is the truth for the maps listed above too
            continue
        if _m.get("skip") or not _modes:
            continue
        MAP_MODES[_m["key"]] = _modes
        _extra.append((_m["name"] + (" (custom)" if _m.get("kind") == "custom" else ""), _m["key"]))
    MAPS = MAPS + sorted(_extra, key=lambda t: t[0].lower())
except Exception:
    pass
# Standard maps (the ones that come with the game) and custom maps are kept apart: the Map box has a group box beside it.
STANDARD_KEYS = {"civpow2", "drygulch", "fort", "granary", "hargrove", "lilbatl", "mltsimms", "orleans", "thudtowr",
                 "town_2p", "wilderns"}
_std = [(l, k) for l, k in MAPS if k in STANDARD_KEYS]
_cust, _seen = [], {l for l, _ in _std}
for _l, _k in MAPS:
    if _k in STANDARD_KEYS:
        continue
    _base = _l.replace(" (custom)", "").strip() or _k
    _lab = _base if _base not in _seen else f"{_base} ({_k})"       # two maps with one name: tell them apart
    _seen.add(_lab)
    _cust.append((_lab, _k))
_cust.sort(key=lambda t: t[0].lower())
MAPS = _std + _cust
MAP_GROUPS = {"Standard maps": [l for l, _ in _std], "Custom maps": [l for l, _ in _cust]}
MAP_KEY = {l: k for l, k in MAPS}


def horde_maps(names):
    """Survival Horde is a Team Deathmatch game: only the maps that have that mode. Sanctuary has none in its .rcm, but
    horde.py adds it for the length of the game."""
    return [n for n in names if "team" in MAP_MODES.get(MAP_KEY.get(n), ()) or MAP_KEY.get(n) == "town_2p"]


MODES = [("Deathmatch", "dm"), ("Team deathmatch", "team"), ("Capture the flag", "ctf"),
         ("Tag", "tag"), ("Chicken", "chicken"), ("Doc", "doc")]
RANKED_KEYS = {"Repair": "hargrove", "Dry Gulch": "drygulch", "Bunkers": "lilbatl"}
RANKED_LABELS = ["Repair", "Dry Gulch", "Bunkers"]
TEAM_MODES = ("ctf", "team", "doc")                              # modes where red/blue matters
CHARACTERS = [("Sanchez", "sanchez"), ("James Anderson", "james"), ("Two Feathers", "twofeathers"),
              ("Dr Death", "drdeath"), ("Bob", "bob"), ("Mary", "mary")]
BEHAVIOURS = ["default", "sapper", "dynamiter", "dotard", "legend", "allrounder", "rifleman", "shotgunner",
              "shotgunner_doc", "knifer", "sniper", "brawler", "pistolero"]
NIGHTMARE_CHARS = ["james", "mary", "bob", "drdeath"]     # Sanchez and Two Feathers (the chief) have no nightmare version
CHAR_RANDOM = "Random"      # with the real presets, picks from that preset's own characters
CHAR_DEFAULT = CHAR_RANDOM
BEH_DEFAULT = "Preset"
TEAMS = ["Auto", "Red", "Blue"]
SPLIT_PER_BOT = "Per-bot settings"
WINDOW_MODES = [("Hidden (off screen, no taskbar button)", "hidden"), ("Minimized", "minimized"),
                ("Visible, in the background", "visible")]

# The preset bots, in the order bot1 .. bot7 (name, behaviour, characters it picks from).
PRESETS = [
    ("Dotard", "dotard", ["james", "bob", "sanchez"]),
    ("DTG_Legend", "legend", ["sanchez"]),
    ("T4H_Dingle", "allrounder", ["drdeath", "mary", "bob", "sanchez"]),
    ("T4H_LadyOutlaw", "rifleman", ["james"]),
    ("WAC_Dirtyolero", "shotgunner", ["mary", "drdeath"]),
    ("creature9", "legend", ["sanchez"]),
    ("Noobke", "knifer", ["twofeathers"]),
    ("Bot 8", "default", ["sanchez", "james", "twofeathers", "drdeath", "bob", "mary"]),
    ("Bot 9", "default", ["sanchez", "james", "twofeathers", "drdeath", "bob", "mary"]),
    ("Bot 10", "default", ["sanchez", "james", "twofeathers", "drdeath", "bob", "mary"]),
]
PRESET_BEHAVIOUR = {("WAC_Dirtyolero", "drdeath"): "shotgunner_doc"}
CHAR_LABEL = {v: k for k, v in CHARACTERS}

# Weapons with a strength dropdown each: (label, slot). The sawed-off (6) isn't used by the bots.
WEAPONS = [("Fists", 1), ("Pistol", 2), ("Rifle", 3), ("Shotgun", 4), ("Double barrel", 5), ("TNT", 7),
           ("Knife", 8), ("Gatling", 9)]
LEVELS = ["Strong", "Average", "Weak"]
LEANS = [("No lean", None), ("Revolver", 2), ("Rifle", 3), ("Shotgun", 4), ("Double barrel", 5), ("Sawed-off", 6)]   # per bot, next game only
LETTER = {"Strong": "s", "Average": "a", "Weak": "w"}
# Each preset's strengths as designed (see brain.py). Untouched, the preset plays exactly as designed.
_S, _A, _W = "Strong", "Average", "Weak"
#            fists pistol rifle shotgun double TNT knife gatling
BASE_LEVELS = [                         # what the behaviours in brain.py already do
    [_W, _S, _S, _A, _S, _W, _W, _A],      # Dotard: rifle, pistol, double barrel
    [_W, _S, _A, _A, _A, _S, _W, _A],      # DTG_Legend: TNT first, strong pistol
    [_W, _S, _A, _S, _S, _W, _W, _A],      # T4H_Dingle: pistol and shotguns
    [_W, _A, _S, _A, _A, _W, _W, _A],      # T4H_LadyOutlaw: rifle
    [_W, _A, _A, _S, _S, _W, _W, _A],      # WAC_Dirtyolero: shotguns
    [_W, _S, _A, _A, _A, _S, _W, _A],      # creature9: TNT first, strong pistol
    [_W, _A, _A, _A, _A, _W, _S, _A],      # Noobke: knife
    [_W, _A, _A, _A, _A, _W, _W, _A],      # Bot 8-10: plain bots
    [_W, _A, _A, _A, _A, _W, _W, _A],      # Bot 8-10: plain bots
    [_W, _A, _A, _A, _A, _W, _W, _A],      # Bot 8-10: plain bots
]
# The window's defaults: the same, with changes you want on top (a change makes botctl reshape that bot's skill).
LEVELS_VER = 5                                        # bump when PRESET_LEVELS change
PRESET_LEVELS = [list(r) for r in BASE_LEVELS]
PRESET_LEVELS[1] = [_W, _S, _A, _A, _A, _S, _A, _A]   # DTG_Legend: knife average
PRESET_LEVELS[5] = [_W, _S, _A, _A, _A, _S, _A, _A]   # creature9: knife average
PRESET_LEVELS[2] = [_W, _S, _S, _S, _A, _A, _W, _A]   # T4H_Dingle: strong pistol, rifle, shotgun; average double barrel and TNT


DIFFICULTIES = ["Easiest", "Easy", "Normal", "Hard", "Nightmare", "Hell"]   # botctl's lv_easiest .. lv_hell
SHARP = ("Nightmare", "Hell")       # strong with every weapon, one of the nightmare characters
ALL_CHARS = ["sanchez", "james", "twofeathers", "drdeath", "bob", "mary"]


def preset_row(i, real):
    """(name, behaviour, characters) of bot i (1-based): the real presets, or a plain 'Bot i'."""
    return PRESETS[i - 1] if real else (f"Bot {i}", "default", ALL_CHARS)


def base_levels(i, real):
    return BASE_LEVELS[i - 1] if real else BASE_LEVELS[7]


def default_levels(i, real):
    return PRESET_LEVELS[i - 1] if real else BASE_LEVELS[7]


def clean_name(text, fallback):
    """The game keeps names to 15 characters; no ':' or '=' (they are botctl's separators)."""
    text = "".join(c for c in text if c not in ":=\"'").strip()[:15]
    return text or fallback


class CharPicker(ttk.Menubutton):
    """A dropdown for a bot's character that can gray out single entries (a ttk Combobox can't): the same get / set /
    configure(state=) as the Combobox it replaced, plus block(labels) for the entries to gray out."""

    def __init__(self, master, values, width=19):
        self.var = tk.StringVar(value=values[0])
        super().__init__(master, textvariable=self.var, width=width, direction="below")
        self.values, self.blocked = list(values), set()
        self.menu = tk.Menu(self, tearoff=0)
        self["menu"] = self.menu
        self._build()

    def _build(self):
        self.menu.delete(0, "end")
        for v in self.values:
            self.menu.add_command(label=v, command=lambda v=v: self.var.set(v),
                                  state="disabled" if v in self.blocked else "normal")

    def get(self):
        return self.var.get()

    def set(self, v):
        self.var.set(v)

    def block(self, labels):
        """Gray out these entries (and fall back to Random if one of them is the current pick)."""
        self.blocked = set(labels)
        self._build()
        if self.var.get() in self.blocked:
            self.var.set(CHAR_RANDOM)

    def configure(self, cnf=None, **kw):
        if "state" in kw:
            kw["state"] = "disabled" if kw["state"] == "disabled" else "normal"
        return super().configure(cnf, **kw) if cnf else super().configure(**kw)


def bot_spec(i, name, char_label, beh_label, team_label, mode, levels=None, tnt_only=False, difficulty="Normal",
             real=False, lean=None):
    """The botctl argument for bot i (1-based). With the real presets and nothing changed, a bot stays 'botN' so
    botctl picks the character (and its behaviour) at random the way it always did. `levels` is the list of
    strengths in WEAPONS order. Difficulty: tags the bot (lv_easiest .. lv_hell); Nightmare and Hell also make it
    strong with every weapon and one of James, Mary, Bob or Dr Death (TNT-only wins over it)."""
    import random
    preset_name, preset_beh, preset_chars = preset_row(i, real)
    name = clean_name(name, preset_name)
    team = team_label.lower() if (mode in TEAM_MODES and team_label in ("Red", "Blue")) else None
    lv = "lv_" + (difficulty or "Normal").lower()
    if tnt_only:                                            # everyone Sanchez, TNT then knife or fists
        return ":".join([f"bot{i}", "sanchez", "tnt_only"] + ([team] if team else []) + ([lv] if lv else [])) + "=" + name
    if difficulty in SHARP:                                 # sharp, strong with everything, one of four characters
        pick = dict(CHARACTERS).get(char_label)             # the one chosen, unless it isn't a nightmare character
        char = pick if pick in NIGHTMARE_CHARS else random.choice(NIGHTMARE_CHARS)
        lean_slot = dict(LEANS).get(lean) if lean else None
        return ":".join([f"bot{i}", char, "nightmare"] + ([team] if team else []) + [lv]
                        + ["wp_" + "".join(f"{slot}s" for _, slot in WEAPONS)]
                        + ([f"lean_{lean_slot}"] if lean_slot else [])) + "=" + name
    levels = levels or default_levels(i, real)
    changed = list(levels) != base_levels(i, real)
    lean_slot = dict(LEANS).get(lean) if lean else None
    plain = (not lean_slot and real and not lv and name == preset_name and char_label == CHAR_DEFAULT and beh_label == BEH_DEFAULT
             and not changed)
    if plain:
        return f"bot{i}" + (f":{team}" if team else "")
    if char_label == CHAR_RANDOM:
        char = random.choice(preset_chars)
    else:
        char = dict(CHARACTERS)[char_label]
    beh = PRESET_BEHAVIOUR.get((preset_name, char), preset_beh) if beh_label == BEH_DEFAULT else beh_label
    tags = [f"bot{i}", char, beh] + ([team] if team else []) + ([lv] if lv else [])
    if changed:
        tags.append("wp_" + "".join(f"{slot}{LETTER[lv_]}" for (_, slot), lv_ in zip(WEAPONS, levels)))
    if lean_slot:
        tags.append(f"lean_{lean_slot}")
    return ":".join(tags) + "=" + name


def melee_spec(i, name, team_label, mode, difficulty="Normal"):
    """Melee Only Deathmatch: the bots are Mary and Two Feathers (the chief), in turn. Mary is a boxer (her fists 7 times
    in 10, now and then the knife), the chief a brawler (the knife, and fists only when he has none); neither picks up
    or uses a gun or TNT. Nightmare and Hell bots are strong with the knife and the fists."""
    name = clean_name(name, f"Bot {i}")
    team = team_label.lower() if (mode in TEAM_MODES and team_label in ("Red", "Blue")) else None
    char, beh = ("mary", "boxer") if i % 2 else ("twofeathers", "brawler")
    sharp = difficulty in SHARP                 # ("nightmare" is a behaviour too: it goes first, so the melee one wins)
    tags = [f"bot{i}", char] + (["nightmare"] if sharp else []) + [beh] + ([team] if team else []) \
        + ["lv_" + (difficulty or "Normal").lower()] + (["wp_8s1s"] if sharp else [])
    return ":".join(tags) + "=" + name


def build_args(cfg):
    """botctl's command line from the window's settings (a plain dict, so it can be tested without a window)."""
    n = max(1, min(10, int(cfg["count"])))
    mode = cfg["mode"]
    specs = [melee_spec(i, b["name"], b["team"], mode, b.get("diff") or cfg.get("difficulty", "Normal"))
             if cfg.get("melee_only") else
             bot_spec(i, b["name"], b["char"], b["beh"], b["team"], mode, b.get("levels"), bool(cfg.get("tnt_only")),
                      b.get("diff") or cfg.get("difficulty", "Normal"), bool(cfg.get("real_names")), b.get("lean"))
             for i, b in enumerate(cfg["bots"][:n], 1)]
    users = int(cfg.get("wait_users") or (1 if cfg.get("wait_for_me") else 0))
    wait = (n - 1) + users
    args = specs + ["--host", "--mode", mode, "--map", cfg["map"], "--fight",
                    "--wait-for", str(wait), "--wait-max", "900" if users > 1 else "300" if users else "120",
                    "--size", cfg.get("size") or "320x180", "--fps", str(cfg.get("fps") or 60)]
    if str(cfg.get("timelimit", "")).strip():
        args += ["--timelimit", str(int(cfg["timelimit"]))]
    if str(cfg.get("fraglimit", "")).strip():
        args += ["--fraglimit", str(int(cfg["fraglimit"]))]
    if cfg.get("friendly_fire"):
        args.append("--friendly-fire")
    args += ["--window-mode", cfg.get("window_mode") or "hidden"]
    if not cfg.get("taunts", True):
        args.append("--no-taunts")
    if not cfg.get("marshall_law", True):
        args.append("--no-marshall-law")
    if cfg.get("private"):
        args.append("--private")          # only you and the bots: the game's own private lobby, not offered to friends
    return args


NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def own_game_pids():
    """Pids of OutlawsAHOM.exe copies that are yours: the bots' copies all run with -userpath. None if Windows
    can't be asked."""
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='OutlawsAHOM.exe'\" | "
          "ForEach-Object { '{0}|{1}' -f $_.ProcessId, $_.CommandLine }")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                           text=True, timeout=20, creationflags=NO_WINDOW)
    except (OSError, subprocess.SubprocessError):
        return None
    if r.returncode != 0:
        return None
    return [line.split("|", 1)[0] for line in r.stdout.splitlines()
            if line.strip() and "-userpath" not in line]


def bot_game_pids():
    """Pids of the bots' game copies (the ones with -userpath), or None if Windows can't be asked."""
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='OutlawsAHOM.exe'\" | "
          "ForEach-Object { '{0}|{1}' -f $_.ProcessId, $_.CommandLine }")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                           text=True, timeout=20, creationflags=NO_WINDOW)
    except (OSError, subprocess.SubprocessError):
        return None
    if r.returncode != 0:
        return None
    return [int(line.split("|", 1)[0]) for line in r.stdout.splitlines()
            if line.strip() and "-userpath" in line and line.split("|", 1)[0].isdigit()]


def trim_working_sets(pids):
    """Ask Windows to move each process's idle memory out of RAM (EmptyWorkingSet). What a bot needs comes
    back by itself; the rest stays in the page file. Returns how many processes were trimmed."""
    import ctypes
    from ctypes import wintypes
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    k32.OpenProcess.restype = wintypes.HANDLE
    k32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    k32.CloseHandle.argtypes = (wintypes.HANDLE,)
    psapi.EmptyWorkingSet.argtypes = (wintypes.HANDLE,)
    done = 0
    for pid in pids:
        h = k32.OpenProcess(0x0100 | 0x0400, False, pid)           # PROCESS_SET_QUOTA | PROCESS_QUERY_INFORMATION
        if h:
            if psapi.EmptyWorkingSet(h):
                done += 1
            k32.CloseHandle(h)
    return done


def zerotier_ip():
    """The IPv4 address of this PC's ZeroTier adapter, or None."""
    ps = ("Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -like '*ZeroTier*' } | "
          "Select-Object -First 1 -ExpandProperty IPAddress")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                           timeout=20, creationflags=NO_WINDOW)
    except (OSError, subprocess.SubprocessError):
        return None
    ip = (r.stdout or "").strip().splitlines()
    return ip[0].strip() if ip and ip[0].strip().count(".") == 3 else None


ZT_SERVICE = "ZeroTierOneService"
ZT_MSI = "https://download.zerotier.com/dist/ZeroTier%20One.msi"
ZT_CLI = Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "ZeroTier" / "One" / "zerotier-cli.bat"


def zt_state():
    """'missing' (not installed), 'on' or 'off'."""
    try:
        r = subprocess.run(["sc", "query", ZT_SERVICE], capture_output=True, text=True, timeout=15,
                           creationflags=NO_WINDOW)
    except (OSError, subprocess.SubprocessError):
        return "missing"
    if r.returncode != 0:
        return "missing"
    return "on" if "RUNNING" in (r.stdout or "") else "off"


def run_elevated(exe, args):
    """Run a program as administrator (Windows asks you to allow it) and wait for it to finish. `args` is one
    string, written exactly as it would be on a command line."""
    ps = (f"Start-Process -FilePath '{exe}' -ArgumentList '{args.replace(chr(39), chr(39) * 2)}' "
          "-Verb RunAs -Wait -WindowStyle Hidden")
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                       creationflags=NO_WINDOW)
    return r.returncode == 0


def download(url, dest):
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                                             "AppleWebKit/537.36 Chrome/124.0 Safari/537.36"})
    with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            f.write(chunk)


CHAR_NUMBER = {"Sanchez": 1, "James Anderson": 2, "Two Feathers": 3, "Dr Death": 4, "Bob": 5, "Mary": 6}      # mp_defaultChar (the character menu's order)


SCREEN_MODES = [("Window", "window"), ("Borderless window", "borderless"), ("Full screen", "full")]
SCREEN_ARGS = {                       # (flags, the game's v_windowmode: 0 windowed, 1 borderless, 2 fullscreen)
    "window": (["-window", "-width", "1280", "-height", "720"], "0"),
    "borderless": ([], "1"),
    "full": (["-fullscreen"], "2"),
}


def desktop_size():
    """The main screen's real resolution in pixels (not scaled by Windows' display scaling), or None."""
    try:
        import ctypes
        class DEVMODE(ctypes.Structure):
            _fields_ = [("dmDeviceName", ctypes.c_wchar * 32), ("dmSpecVersion", ctypes.c_ushort), ("dmDriverVersion", ctypes.c_ushort),
                        ("dmSize", ctypes.c_ushort), ("dmDriverExtra", ctypes.c_ushort), ("dmFields", ctypes.c_ulong),
                        ("dmPositionX", ctypes.c_long), ("dmPositionY", ctypes.c_long), ("dmDisplayOrientation", ctypes.c_ulong),
                        ("dmDisplayFixedOutput", ctypes.c_ulong), ("dmColor", ctypes.c_short), ("dmDuplex", ctypes.c_short),
                        ("dmYResolution", ctypes.c_short), ("dmTTOption", ctypes.c_short), ("dmCollate", ctypes.c_short),
                        ("dmFormName", ctypes.c_wchar * 32), ("dmLogPixels", ctypes.c_ushort), ("dmBitsPerPel", ctypes.c_ulong),
                        ("dmPelsWidth", ctypes.c_ulong), ("dmPelsHeight", ctypes.c_ulong), ("dmDisplayFlags", ctypes.c_ulong),
                        ("dmDisplayFrequency", ctypes.c_ulong)]
        dm = DEVMODE(); dm.dmSize = ctypes.sizeof(DEVMODE)
        if ctypes.windll.user32.EnumDisplaySettingsW(None, -1, ctypes.byref(dm)) and dm.dmPelsWidth >= 640:   # -1: current mode
            return int(dm.dmPelsWidth), int(dm.dmPelsHeight)
    except Exception:
        pass
    return None


def join_command(char=None, screen=None, horde=False):
    """Your own game: your normal profile and settings (no -userpath), joining the LAN game on this PC.
    char: a character name from CHARACTERS: the game starts with that character picked.
    screen: window / borderless / full: the display mode it starts in.
    horde: a Survival Horde game: the Survival look only exists in the Vulkan shaders, so the game runs on Vulkan, and
    full screen becomes borderless full screen (the banners can't be drawn over a game in exclusive full screen).
    The game reads ONE -setvar block (a second one is ignored, which lost the character before), so all go in one."""
    if horde and screen == "full":
        screen = "borderless"
    flags, winmode = SCREEN_ARGS.get(screen, ([], None))
    cmd = [str(GAME_EXE), "-netdriver", "lan", "-skipintromovies", "-join", "127.0.0.1"] + flags
    setvars = []
    if winmode is not None:
        setvars += ["v_windowmode", winmode]
        size = (1280, 720) if screen == "window" else desktop_size()   # the game keeps the last size it ran at (a window
        if size:                                                         # game saves 1280 x 720): always say the size
            setvars += ["v_width", str(size[0]), "v_height", str(size[1])]
    if char in CHAR_NUMBER:
        setvars += ["mp_defaultChar", str(CHAR_NUMBER[char])]
    if horde:
        setvars += ["r_rhirenderfamily", "vulkan"]
    return cmd + (["-setvar"] + setvars if setvars else [])


WIN_W, WIN_H = 1100, 1000
TITLE_CX = 418        # the title is centred between the window's left edge and the logo box (x = 836)
PARCH, SAND, INK, LEATHER, RUST = "#f1e4c3", "#f4e3b8", "#3b2a1a", "#3a2616", "#b5530f"

# ---- the window -----------------------------------------------------------------------------------------------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Outlaws Bot Launcher")
        self.resizable(False, False)
        pad = dict(padx=6, pady=3)
        saved = self.load()
        self.style_window()
        self.header()
        try:                                               # the taskbar / title-bar icon
            from icon_data import ICON_B64
            self.icon = tk.PhotoImage(data=ICON_B64)
            self.iconphoto(True, self.icon)
        except Exception:
            pass

        top = ttk.LabelFrame(self.body, text="Game")
        top.grid(row=1, column=0, sticky="ew", padx=8, pady=(8, 4))
        ttk.Label(top, text="Map").grid(row=0, column=0, sticky="w", **pad)
        mapf = ttk.Frame(top)
        mapf.grid(row=0, column=1, **pad)
        want = (saved.get("map") or "").replace(" (custom)", "")
        group = "Custom maps" if want in MAP_GROUPS["Custom maps"] else "Standard maps"
        self.map_group = ttk.Combobox(mapf, values=list(MAP_GROUPS), state="readonly", width=14)
        self.map_group.set(group)
        self.map_group.grid(row=0, column=0, padx=(0, 4))
        self.map = ttk.Combobox(mapf, values=MAP_GROUPS[group], state="readonly", width=26)
        self.map.set(want if want in MAP_GROUPS[group] else MAP_GROUPS[group][0])
        self.map.grid(row=0, column=1)
        self.map_group.bind("<<ComboboxSelected>>", lambda e: self.pick_map_group())
        ttk.Label(top, text="Game mode").grid(row=0, column=2, sticky="w", **pad)
        self.mode = ttk.Combobox(top, values=[m for m, _ in MODES], state="readonly", width=20)
        self.mode.set(saved.get("mode") or "Deathmatch")
        self.mode.grid(row=0, column=3, **pad)
        self.mode.bind("<<ComboboxSelected>>", lambda e: self.refresh_all())
        self.map.bind("<<ComboboxSelected>>", lambda e: self.update_modes())
        ttk.Label(top, text="Bots to play against").grid(row=1, column=0, sticky="w", **pad)
        self.count = tk.IntVar(value=int(saved.get("count", 6)))
        ttk.Spinbox(top, from_=1, to=10, width=5, textvariable=self.count, command=self.refresh_all).grid(
            row=1, column=1, sticky="w", **pad)
        self.count.trace_add("write", lambda *a: self.refresh_all())
        ttk.Label(top, text="Time limit (min)").grid(row=1, column=2, sticky="w", **pad)
        self.timelimit = tk.StringVar(value=str(saved.get("timelimit", "")))
        ttk.Entry(top, textvariable=self.timelimit, width=8).grid(row=1, column=3, sticky="w", **pad)
        ttk.Label(top, text="Score limit").grid(row=2, column=0, sticky="w", **pad)
        self.fraglimit = tk.StringVar(value=str(saved.get("fraglimit", "")))
        ttk.Entry(top, textvariable=self.fraglimit, width=8).grid(row=2, column=1, sticky="w", **pad)
        self.ff = tk.BooleanVar(value=bool(saved.get("friendly_fire", False)))
        ttk.Checkbutton(top, text="Friendly fire (team modes)", variable=self.ff).grid(
            row=2, column=2, columnspan=2, sticky="w", **pad)
        self.tnt_only = tk.BooleanVar(value=bool(saved.get("tnt_only", False)))
        ttk.Checkbutton(top, text="TNT-only game (all bots Sanchez: TNT, then knife or fists)",
                        variable=self.tnt_only, command=self.refresh_all).grid(
            row=3, column=0, columnspan=4, sticky="w", **pad)
        ttk.Label(top, text="Bot difficulty").grid(row=4, column=0, sticky="w", **pad)
        self.diff = ttk.Combobox(top, values=DIFFICULTIES + ["Custom"], state="readonly", width=12)
        self.last_base = saved.get("difficulty") if saved.get("difficulty") in DIFFICULTIES else "Normal"
        self.diff.set("Custom" if any((b or {}).get("diff") in DIFFICULTIES for b in (saved.get("bots") or [])) else self.last_base)
        self.diff.grid(row=4, column=1, sticky="w", **pad)
        self.diff.bind("<<ComboboxSelected>>", lambda e: self.diff_changed())
        self.private = tk.BooleanVar(value=bool(saved.get("private", False)))     # nobody can see or join it
        ttk.Checkbutton(top, text="Private game (only you and the bots)", variable=self.private).grid(
            row=4, column=2, columnspan=2, sticky="w", **pad)
        self.real = tk.BooleanVar(value=False)         # the real-name presets are gone: bots are plain "Bot N" until saved
        self.taunts = tk.BooleanVar(value=bool(saved.get("taunts", True)))
        ttk.Checkbutton(top, text="Bots taunt after a kill", variable=self.taunts).grid(
            row=5, column=0, columnspan=2, sticky="w", **pad)
        self.trim = tk.BooleanVar(value=bool(saved.get("trim_memory", True)))
        ttk.Checkbutton(top, text="Trim idle bot memory (lower RAM)", variable=self.trim).grid(
            row=5, column=2, columnspan=2, sticky="w", **pad)
        self.law = tk.BooleanVar(value=bool(saved.get("marshall_law", True)))
        ttk.Checkbutton(top, text="Marshall Law (bots avoid the badge and invisible cream)", variable=self.law).grid(
            row=6, column=0, columnspan=2, sticky="w", **pad)
        # You join automatically, so the match waits for you. Unticked, LAUNCH GAME starts only the bots.
        me_fr = ttk.Frame(top)
        me_fr.grid(row=6, column=2, columnspan=2, rowspan=1, sticky="nw", **pad)
        self.wait_me = tk.BooleanVar(value=bool(saved.get("wait_for_me", True)))
        ttk.Checkbutton(me_fr, text="I play too (my game starts and joins)", variable=self.wait_me).pack(anchor="w")
        # The display mode your own game starts in (every tab that starts your game uses it).
        scr = ttk.Frame(me_fr)
        scr.pack(anchor="w", pady=(4, 0))
        ttk.Label(scr, text="Screen size").pack(side="left", padx=(20, 6))
        self.screen = ttk.Combobox(scr, values=[l for l, _ in SCREEN_MODES], state="readonly", width=18)
        self.screen.set(next((l for l, v in SCREEN_MODES if v == saved.get("screen_mode")), "Full screen"))
        self.screen.pack(side="left")
        # Team split (team modes only): how many of the bots play on Red; the rest play on Blue, so 6 v 2 works.
        self.split_row = tk.Frame(top)
        self.split_row.grid(row=7, column=0, columnspan=4, sticky="w", **pad)
        def _num(v):
            return v if str(v).isdigit() else ""
        self.red_n = tk.StringVar(value=_num(saved.get("red_bots", "")))
        self.blue_n = tk.StringVar(value=_num(saved.get("blue_bots", "")))
        ttk.Label(self.split_row, text="Red Team").pack(side="left")
        ttk.Entry(self.split_row, textvariable=self.red_n, width=4).pack(side="left", padx=(4, 12))
        ttk.Label(self.split_row, text="Blue Team").pack(side="left")
        ttk.Entry(self.split_row, textvariable=self.blue_n, width=4).pack(side="left", padx=(4, 8))
        self.split_src, self.split_busy = "red", False

        def _typed(which):
            def f(*a):
                if not self.split_busy:
                    self.split_src = which
                    self.refresh_all()
            return f
        self.red_n.trace_add("write", _typed("red"))
        self.blue_n.trace_add("write", _typed("blue"))
        self.split_info = ttk.Label(self.split_row, text="")
        self.split_info.pack(side="left")

        mid = tk.Frame(self.body, bg=PARCH)
        mid.grid(row=2, column=0, sticky="ew")
        box = ttk.LabelFrame(mid, text="Bots (the first one hosts; scroll for the rest)")
        box.grid(row=0, column=0, sticky="n", padx=(8, 4), pady=4)
        canvas = tk.Canvas(box, width=700, height=250, highlightthickness=0)
        bar = ttk.Scrollbar(box, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=bar.set)
        canvas.grid(row=0, column=0)
        bar.grid(row=0, column=1, sticky="ns")
        inner = ttk.Frame(canvas)
        canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        def wheel(e):
            canvas.yview_scroll(-1 * (e.delta // 120 or (1 if e.delta > 0 else -1)), "units")
            return "break"
        canvas.bind_all("<MouseWheel>", wheel)
        self.bind_class("TCombobox", "<MouseWheel>", wheel)       # the wheel scrolls the list, it never changes a dropdown
        self.bind_class("TSpinbox", "<MouseWheel>", lambda e: "break")
        self.blocks = []
        sb = saved.get("bots", [])
        chars = [CHAR_RANDOM] + [k for k, _ in CHARACTERS]
        behs = [BEH_DEFAULT] + BEHAVIOURS[1:]
        for i in range(10):
            s = sb[i] if i < len(sb) else {}
            frame = ttk.Frame(inner, relief="groove", borderwidth=1)
            ttk.Label(frame, text=f"Bot {i + 1}").grid(row=0, column=0, sticky="w", padx=6, pady=2)
            name = tk.StringVar(value=s.get("name") or preset_row(i + 1, self.real.get())[0])
            ttk.Entry(frame, textvariable=name, width=18).grid(row=0, column=1, padx=4, pady=2)
            char = CharPicker(frame, chars)
            char.set(s.get("char") if s.get("char") in chars else CHAR_DEFAULT)
            char.grid(row=0, column=2, padx=4)
            beh = ttk.Combobox(frame, values=behs, state="readonly", width=14)
            beh.set(s.get("beh") if s.get("beh") in behs else BEH_DEFAULT)
            beh.grid(row=0, column=3, padx=4)
            team = ttk.Combobox(frame, values=TEAMS, state="readonly", width=7)
            team.set(s.get("team") if s.get("team") in TEAMS else "Auto")
            team.grid(row=0, column=4, padx=4)
            lean = ttk.Combobox(frame, values=[k for k, _ in LEANS], state="readonly", width=12)
            lean.set("No lean")                          # next game only: not remembered between launches
            lean.grid(row=0, column=5, padx=4)
            bdiff = ttk.Combobox(frame, values=["Same as above"] + DIFFICULTIES, state="readonly", width=13)
            bdiff.set(s.get("diff") if s.get("diff") in DIFFICULTIES else "Same as above")
            bdiff.grid(row=0, column=6, padx=4)
            bdiff.bind("<<ComboboxSelected>>", lambda e, b=bdiff: self.bot_diff_changed(b))
            wbox = ttk.Frame(frame)
            wbox.grid(row=1, column=0, columnspan=6, sticky="w", padx=6, pady=(0, 4))
            saved_levels = s.get("levels") if isinstance(s.get("levels"), list) and len(s.get("levels")) == len(WEAPONS) else None
            wcombos = []
            for k, (label, _slot) in enumerate(WEAPONS):
                r, c = divmod(k, 4)
                ttk.Label(wbox, text=label).grid(row=r, column=c * 2, sticky="e", padx=(4, 2), pady=1)
                cb = ttk.Combobox(wbox, values=LEVELS, state="readonly", width=8)
                dl = default_levels(i + 1, self.real.get())
                v = saved_levels[k] if saved_levels else dl[k]
                cb.set(v if v in LEVELS else dl[k])
                cb.grid(row=r, column=c * 2 + 1, padx=(0, 6), pady=1)
                wcombos.append(cb)
            self.blocks.append({"frame": frame, "name": name, "char": char, "beh": beh, "team": team,
                                "weapons": wcombos, "wbox": wbox, "lean": lean, "diff": bdiff})
        # Saved bot presets, mid-right: up to ten, each holding every bot's name, character, behaviour, team and strengths.
        pbox = ttk.LabelFrame(mid, text="Bot presets")
        pbox.grid(row=0, column=1, sticky="n", padx=(4, 8), pady=4)
        self.preset_data = self.read_presets()
        self.preset_list = tk.Listbox(pbox, height=PRESET_SLOTS, width=24, exportselection=False, activestyle="none",
                                      bg="#fbf5e3", fg=INK, selectbackground=LEATHER, font=("Segoe UI", 10))
        self.preset_list.grid(row=0, column=0, columnspan=2, padx=6, pady=(6, 4))
        self.preset_list.bind("<<ListboxSelect>>", lambda e: self.preset_buttons())
        self.load_btn = ttk.Button(pbox, text="Load Bot Preset", command=self.load_preset, state="disabled")
        self.load_btn.grid(row=1, column=0, padx=(6, 2), pady=(0, 6), sticky="ew")
        self.del_btn = ttk.Button(pbox, text="Delete", command=self.delete_preset, state="disabled", width=7)
        self.del_btn.grid(row=1, column=1, padx=(2, 6), pady=(0, 6))
        self.show_presets()
        under = tk.Frame(mid, bg=PARCH)                 # under the bots box only, so Reset sits with the bots, not the presets
        under.grid(row=1, column=0, sticky="ew", padx=(8, 4))
        ttk.Button(under, text="Save Bot Preset", command=self.save_preset).pack(side="left")
        ttk.Button(under, text="Reset bots", command=self.reset).pack(side="right")

        adv = ttk.LabelFrame(self.body, text="Bot windows (smaller = less RAM/VRAM)")
        adv.grid(row=4, column=0, sticky="ew", padx=8, pady=4)
        ttk.Label(adv, text="Size").grid(row=0, column=0, **pad)
        self.size = tk.StringVar(value=saved.get("size", "320x180"))
        ttk.Entry(adv, textvariable=self.size, width=10).grid(row=0, column=1, **pad)
        ttk.Label(adv, text="FPS").grid(row=0, column=2, **pad)
        self.fps = tk.StringVar(value=str(saved.get("fps", 60)))
        ttk.Entry(adv, textvariable=self.fps, width=6).grid(row=0, column=3, **pad)
        ttk.Label(adv, text="Window").grid(row=0, column=4, **pad)
        self.wmode = ttk.Combobox(adv, values=[m for m, _ in WINDOW_MODES], state="readonly", width=36)
        self.wmode.set(saved.get("window_mode_label") or WINDOW_MODES[0][0])
        self.wmode.grid(row=0, column=5, **pad)

        btns = ttk.Frame(self.body)
        btns.grid(row=5, column=0, pady=6)
        self.launch_btn = ttk.Button(btns, text="LAUNCH GAME", command=self.launch, width=18, style="Launch.TButton")
        self.launch_btn.grid(row=0, column=0, padx=6)
        self.launch_btns = [(self.launch_btn, "LAUNCH GAME")]
        ttk.Button(btns, text="Close all game windows", command=self.kill, width=22).grid(row=0, column=1, padx=6)

        self.log = tk.Text(self.body, height=4, width=92, state="disabled", bg="#fbf5e3", fg=INK, relief="flat",
                           font=("Consolas", 9))
        self.log.grid(row=6, column=0, padx=8, pady=(0, 4))
        upd_btns = self.upd_btns = []
        for tab in (self.body, self.zt, self.gm, self.rot, self.st):     # the same button, bottom right, on every tab
            b = ttk.Button(tab, text="Update Launcher", command=self.update_launcher, width=16)
            b.place(relx=1.0, rely=1.0, anchor="se", x=-10, y=-8)
            upd_btns.append(b)
        self.gm_close = ttk.Button(self.gm, text="Close all game windows", command=self.kill, width=22)
        self.gm_close.place(relx=1.0, rely=1.0, anchor="se", x=-170, y=-8)      # left of Update Launcher
        upd_btns.append(self.gm_close)
        self.build_zerotier(saved)
        self.build_stats(saved)
        self.build_modes(saved)
        def _flush_online():                       # ranked games that couldn't be pushed last time go out now
            try:
                if str(HERE) not in sys.path:
                    sys.path.insert(0, str(HERE))
                import onlinerank
                onlinerank.flush_outbox()
            except Exception:
                pass
        threading.Thread(target=_flush_online, daemon=True).start()
        self.build_gungame(saved)
        self.build_rotation(saved)
        for b in upd_btns:
            b.lift()                                   # above the tab's other widgets
        self.update_modes()
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.start_bugshot()

    # -- Map Rotation tab: a list of matches the bots go through (rotation.py), one after the other in the same game copies
    def build_rotation(self, saved):
        pad = dict(padx=8, pady=4)
        g, sv = self.rot, saved.get("rotation", {})
        ttk.Label(g, wraplength=820, justify="left", text=(
            "When a match ends, the host bot hosts the next map on the list and the other bots join it, without restarting "
            "their game copies. The bots, difficulty and windows come from the Bots Setup tab. You stay on the score "
            "screen: press Continue, then join the LAN game again from the game's multiplayer menu.")).grid(
            row=0, column=0, columnspan=2, sticky="w", **pad)
        add = ttk.LabelFrame(g, text="Add a match")
        add.grid(row=1, column=0, columnspan=2, sticky="ew", padx=12, pady=4)
        self.rot_group = ttk.Combobox(add, values=list(MAP_GROUPS), state="readonly", width=14)
        self.rot_group.set("Standard maps")
        self.rot_group.grid(row=0, column=0, **pad)
        self.rot_map = ttk.Combobox(add, values=MAP_GROUPS["Standard maps"], state="readonly", width=26)
        self.rot_map.set(MAP_GROUPS["Standard maps"][0])
        self.rot_map.grid(row=0, column=1, **pad)
        self.rot_mode = ttk.Combobox(add, state="readonly", width=18)
        self.rot_mode.grid(row=0, column=2, **pad)
        ttk.Label(add, text="Minutes").grid(row=0, column=3, **pad)
        self.rot_min = tk.StringVar(value="10")
        ttk.Entry(add, textvariable=self.rot_min, width=5).grid(row=0, column=4, **pad)
        ttk.Label(add, text="Kills").grid(row=0, column=5, **pad)
        self.rot_kills = tk.StringVar(value="")
        ttk.Entry(add, textvariable=self.rot_kills, width=5).grid(row=0, column=6, **pad)
        ttk.Button(add, text="Add", command=self.rot_add).grid(row=0, column=7, **pad)

        def pick_group(_e=None):
            names = MAP_GROUPS.get(self.rot_group.get()) or MAP_GROUPS["Standard maps"]
            self.rot_map.configure(values=names)
            self.rot_map.set(names[0])
            pick_map()

        def pick_map(_e=None):
            have = MAP_MODES.get(dict(MAPS).get(self.rot_map.get(), ""))
            labels = [m for m, v in MODES if have is None or v in have]
            self.rot_mode.configure(values=labels)
            if self.rot_mode.get() not in labels:
                self.rot_mode.set(labels[0])
        self.rot_group.bind("<<ComboboxSelected>>", pick_group)
        self.rot_map.bind("<<ComboboxSelected>>", pick_map)
        pick_map()
        cols = ("#", "Map", "Mode", "Minutes", "Kills")
        self.rot_tree = ttk.Treeview(g, columns=cols, show="headings", height=8, selectmode="browse")
        for c, w in zip(cols, (40, 260, 160, 80, 80)):
            self.rot_tree.heading(c, text=c)
            self.rot_tree.column(c, width=w, anchor="w" if c in ("Map", "Mode") else "center")
        self.rot_tree.grid(row=2, column=0, sticky="w", padx=12, pady=4)
        side = ttk.Frame(g)
        side.grid(row=2, column=1, sticky="nw", pady=4)
        for text, cmd in (("Up", lambda: self.rot_move(-1)), ("Down", lambda: self.rot_move(1)),
                          ("Remove", self.rot_remove), ("Clear", self.rot_clear)):
            ttk.Button(side, text=text, command=cmd, width=10).pack(pady=2)
        keys = {k for _, k in MAPS}
        self.rot_entries = [e for e in sv.get("entries", []) if isinstance(e, dict) and e.get("map") in keys
                            and e.get("mode") in dict((v, m) for m, v in MODES)]
        self.rot_show()
        opts = ttk.Frame(g)
        opts.grid(row=3, column=0, columnspan=2, sticky="w", padx=12, pady=2)
        self.rot_loop = tk.BooleanVar(value=bool(sv.get("loop", True)))
        ttk.Checkbutton(opts, text="Start over after the last map", variable=self.rot_loop).pack(side="left")
        self.rot_shuffle = tk.BooleanVar(value=bool(sv.get("shuffle", False)))
        ttk.Checkbutton(opts, text="Shuffle (the first map stays first)", variable=self.rot_shuffle).pack(side="left", padx=(16, 0))
        ttk.Label(opts, text="Seconds on the score screen").pack(side="left", padx=(16, 4))
        self.rot_wait = tk.StringVar(value=str(sv.get("score_wait", 10)))
        ttk.Spinbox(opts, from_=3, to=120, width=5, textvariable=self.rot_wait).pack(side="left")
        self.rot_you = tk.BooleanVar(value=bool(sv.get("you", True)))
        ttk.Checkbutton(g, text="I play too (my game starts and joins the first map; untick to start only the bots)",
                        variable=self.rot_you).grid(row=4, column=0, columnspan=2, sticky="w", padx=12, pady=2)
        b = ttk.Button(g, text="LAUNCH ROTATION", command=lambda: self.launch(rotation=True), width=22,
                       style="Launch.TButton")
        b.grid(row=5, column=0, columnspan=2, pady=12)
        self.launch_btns.append((b, "LAUNCH ROTATION"))

    def rot_show(self, select=None):
        labels = {k: l for l, k in MAPS}
        modes = {v: m for m, v in MODES}
        self.rot_tree.delete(*self.rot_tree.get_children())
        for i, e in enumerate(self.rot_entries):
            self.rot_tree.insert("", "end", iid=str(i), values=(i + 1, labels.get(e["map"], e["map"]), modes[e["mode"]],
                                                                e.get("timelimit") or "-", e.get("fraglimit") or "-"))
        if select is not None and 0 <= select < len(self.rot_entries):
            self.rot_tree.selection_set(str(select))
            self.rot_tree.see(str(select))

    def rot_wait_s(self):
        v = self.rot_wait.get().strip()
        return min(120, max(3, int(v))) if v.isdigit() else 10

    def rot_selected(self):
        sel = self.rot_tree.selection()
        return int(sel[0]) if sel else None

    def rot_add(self):
        tl, fl = self.rot_min.get().strip(), self.rot_kills.get().strip()
        if tl and not (tl.isdigit() and int(tl) <= 120) or fl and not (fl.isdigit() and int(fl) <= 100):
            messagebox.showerror("Check the numbers", "Minutes must be 0-120 and kills 0-100 (or left empty).")
            return
        self.rot_entries.append({"map": dict(MAPS)[self.rot_map.get()], "mode": dict(MODES)[self.rot_mode.get()],
                                 "timelimit": tl, "fraglimit": fl})
        self.rot_show(select=len(self.rot_entries) - 1)

    def rot_move(self, d):
        i = self.rot_selected()
        if i is None or not 0 <= i + d < len(self.rot_entries):
            return
        e = self.rot_entries
        e[i], e[i + d] = e[i + d], e[i]
        self.rot_show(select=i + d)

    def rot_remove(self):
        i = self.rot_selected()
        if i is not None:
            del self.rot_entries[i]
            self.rot_show(select=min(i, len(self.rot_entries) - 1))

    def rot_clear(self):
        if self.rot_entries and messagebox.askyesno("Map rotation", "Remove every map from the list?"):
            self.rot_entries = []
            self.rot_show()

    def rot_write(self):
        """rotation.txt for rotation.py: one 'map mode minutes kills' line per match ('-' = keep the setting)."""
        lines = ["# written by the launcher's Map Rotation tab: map mode minutes kills"]
        for e in self.rot_entries:
            lines.append(f"{e['map']} {e['mode']} {e.get('timelimit') or '-'} {e.get('fraglimit') or '-'}")
        (HERE / "rotation.txt").write_text("\n".join(lines) + "\n")

    def run_rotation(self, args):
        """rotation.py next to the bots: it waits for the host's match, then moves everyone from map to map."""
        venv_python = HERE / ".venv" / "Scripts" / "python.exe"
        for _ in range(300):                       # bots.cmd may still be making the venv (first run)
            if venv_python.exists() or not getattr(sys, "frozen", False) or self.cancel:
                break
            time.sleep(1)
        py = str(venv_python) if venv_python.exists() else sys.executable
        try:
            p = subprocess.Popen([py, "-u", str(HERE / "rotation.py")] + args, cwd=str(HERE),
                                 env=dict(os.environ, PYTHONUNBUFFERED="1"), stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, errors="replace", creationflags=NO_WINDOW)
            for line in p.stdout:
                self.say("[rotation] " + line)
        except OSError as e:
            self.say(f"could not start the map rotation: {e}")

    # -- ZeroTier tab
    def build_zerotier(self, saved):
        pad = dict(padx=8, pady=4)
        z = self.zt
        ttk.Label(z, text="Host a LAN game that friends join over ZeroTier. Everyone joins the same ZeroTier network; "
                          "your ZeroTier IP is your game's address.", wraplength=820, justify="left").grid(
            row=0, column=0, columnspan=2, sticky="w", **pad)
        box = ttk.LabelFrame(z, text="Your address")
        box.grid(row=1, column=0, columnspan=2, sticky="ew", padx=12, pady=6)
        ttk.Label(box, text="ZeroTier network ID").grid(row=0, column=0, sticky="w", **pad)
        self.zt_net = tk.StringVar(value=saved.get("zt_network", ""))
        ttk.Entry(box, textvariable=self.zt_net, width=22).grid(row=0, column=1, sticky="w", **pad)
        ttk.Label(box, text="ZeroTier IP (saved)").grid(row=1, column=0, sticky="w", **pad)
        self.zt_ip = tk.StringVar(value=saved.get("zt_ip", ""))
        ttk.Entry(box, textvariable=self.zt_ip, width=22, font=("Consolas", 12, "bold")).grid(
            row=1, column=1, sticky="w", **pad)
        row = ttk.Frame(box)
        row.grid(row=2, column=0, columnspan=2, sticky="w", **pad)
        ttk.Button(row, text="Copy address", command=self.zt_copy_ip).grid(row=0, column=0, padx=4)
        ttk.Button(row, text="Copy join instructions", command=self.zt_copy_help).grid(row=0, column=1, padx=4)
        ttk.Button(row, text="Detect my ZeroTier IP", command=self.zt_detect).grid(row=0, column=2, padx=4)
        row2 = ttk.Frame(box)
        row2.grid(row=2, column=2, sticky="w", **pad)
        self.zt_btn = ttk.Button(row2, text="Checking ZeroTier...", command=self.zt_toggle, width=34)
        self.zt_btn.grid(row=0, column=0)
        self.zt_msg = tk.StringVar(value="")
        ttk.Label(box, textvariable=self.zt_msg).grid(row=3, column=0, columnspan=2, sticky="w", **pad)
        ttk.Label(box, wraplength=780, justify="left", text=(
            "The IP is saved here and found again each time the launcher opens. For an address that never changes, "
            "open your network in my.zerotier.com, find your PC under Members and give it a fixed IP under "
            "'Managed IPs' (or tick 'Do not auto-assign IPs' and type one). Then click Detect.")).grid(
            row=4, column=0, columnspan=2, sticky="w", **pad)
        opt = ttk.LabelFrame(z, text="Game")
        opt.grid(row=2, column=0, columnspan=2, sticky="ew", padx=12, pady=6)
        ttk.Label(opt, text="Bots wait to start until this many players have joined (you count as one)").grid(
            row=0, column=0, sticky="w", **pad)
        self.zt_users = tk.IntVar(value=max(2, int(saved.get("zt_users", 2) or 2)))
        ttk.Spinbox(opt, from_=2, to=10, width=5, textvariable=self.zt_users).grid(row=0, column=1, **pad)
        ttk.Label(opt, wraplength=780, justify="left", text=(
            "The bots, mode, map and all other settings come from the Bots tab. If you leave the game, it stays up "
            "for your friends; use 'Close all game windows' to end it.")).grid(
            row=1, column=0, columnspan=2, sticky="w", **pad)
        b2 = ttk.Button(z, text="LAUNCH ZEROTIER GAME", command=lambda: self.launch(zerotier=True), width=26,
                        style="Launch.TButton")
        b2.grid(row=3, column=0, columnspan=2, pady=14)
        self.launch_btns.append((b2, "LAUNCH ZEROTIER GAME"))
        ttk.Label(z, text="Windows Firewall must allow OutlawsAHOM.exe on the ZeroTier network, and friends join with "
                          "the address above.", wraplength=820, justify="left").grid(
            row=4, column=0, columnspan=2, sticky="w", **pad)
        self.zt_detect(quiet=True)
        self.zt_refresh_button()

    # -- Gun-Game tab
    GG_WEAPONS = [("Double-barrel", 5), ("Shotgun", 4), ("Rifle", 3), ("Gatling gun", 9), ("Sawed-off", 6),
                  ("Pistol", 2), ("TNT", 7), ("Knife", 8)]
    GG_ORDERS = ["Default (TNT and knife last)", "Randomized", "Custom"]

    def build_gungame(self, saved):
        pad = dict(padx=8, pady=4)
        g, sv = self.gg, saved.get("gungame", {})
        ttk.Label(g, wraplength=820, justify="left", text=(
            "Gun game: everyone starts with the first weapon on the ladder and can only use that weapon. A kill moves "
            "you up a weapon; dying drops you back one. Kill someone with the last weapon to win. The bots use the "
            "all-weapons cheat to get each weapon, so the host turns on 'Allow Cheats'.")).grid(
            row=0, column=0, columnspan=2, sticky="w", **pad)
        box = ttk.LabelFrame(g, text="Game")
        box.grid(row=1, column=0, sticky="ew", padx=12, pady=6)
        ttk.Label(box, text="Map").grid(row=0, column=0, sticky="w", **pad)
        mf = ttk.Frame(box)
        mf.grid(row=0, column=1, sticky="w", **pad)
        want = (sv.get("map") or "").replace(" (custom)", "")
        grp = "Custom maps" if want in MAP_GROUPS["Custom maps"] else "Standard maps"
        self.gg_group = ttk.Combobox(mf, values=list(MAP_GROUPS), state="readonly", width=14)
        self.gg_group.set(grp)
        self.gg_group.grid(row=0, column=0, padx=(0, 4))
        self.gg_map = ttk.Combobox(mf, values=MAP_GROUPS[grp], state="readonly", width=26)
        self.gg_map.set(want if want in MAP_GROUPS[grp] else MAP_GROUPS[grp][0])
        self.gg_map.grid(row=0, column=1)

        def pick_group(_e=None):
            names = MAP_GROUPS.get(self.gg_group.get()) or MAP_GROUPS["Standard maps"]
            self.gg_map.configure(values=names)
            self.gg_map.set(names[0])
        self.gg_group.bind("<<ComboboxSelected>>", pick_group)
        ttk.Label(box, text="Bots to play against").grid(row=1, column=0, sticky="w", **pad)
        self.gg_count = tk.IntVar(value=int(sv.get("count", 3)))
        ttk.Spinbox(box, from_=1, to=10, width=5, textvariable=self.gg_count).grid(row=1, column=1, sticky="w", **pad)
        ttk.Label(box, text="Bot difficulty").grid(row=2, column=0, sticky="w", **pad)
        self.gg_diff = ttk.Combobox(box, values=DIFFICULTIES + ["Custom"], state="readonly", width=12)
        saved_pb = sv.get("bot_diffs") or []
        any_pb = any(x in DIFFICULTIES for x in saved_pb)
        self.gg_last_base = sv.get("difficulty") if sv.get("difficulty") in DIFFICULTIES else "Normal"
        self.gg_diff.set("Custom" if (any_pb or sv.get("difficulty") == "Custom") else self.gg_last_base)
        self.gg_diff.grid(row=2, column=1, sticky="w", **pad)
        ttk.Label(box, text="Per-bot difficulty").grid(row=3, column=0, sticky="nw", **pad)
        pf = ttk.Frame(box)
        pf.grid(row=3, column=1, sticky="w", **pad)
        self.gg_bot_diffs = []
        self.gg_bot_rows = []
        for i in range(10):
            lb = ttk.Label(pf, text=f"Bot {i + 1}")
            cb = ttk.Combobox(pf, values=["Same as above"] + DIFFICULTIES, state="readonly", width=13)
            cb.set(saved_pb[i] if i < len(saved_pb) and saved_pb[i] in DIFFICULTIES else "Same as above")
            cb.bind("<<ComboboxSelected>>", lambda e, i=i: self.gg_pb_changed(i))
            self.gg_bot_diffs.append(cb)
            self.gg_bot_rows.append((lb, cb))
        self.gg_diff.bind("<<ComboboxSelected>>", lambda e: self.gg_diff_changed())
        self.gg_count.trace_add("write", lambda *_: self.gg_pb_refresh())
        self.gg_pb_refresh()
        gun = ttk.LabelFrame(g, text="Weapons")
        gun.grid(row=2, column=0, sticky="ew", padx=12, pady=6)
        ttk.Label(gun, text="Weapon order").grid(row=0, column=0, sticky="w", **pad)
        self.gg_order = ttk.Combobox(gun, values=self.GG_ORDERS, state="readonly", width=28)
        self.gg_order.set(sv.get("order") if sv.get("order") in self.GG_ORDERS else self.GG_ORDERS[0])
        self.gg_order.grid(row=0, column=1, sticky="w", **pad)
        self.gg_order.bind("<<ComboboxSelected>>", lambda e: self.gg_refresh())
        self.gg_gat = tk.BooleanVar(value=bool(sv.get("gatling", True)))
        ttk.Checkbutton(gun, text="Include the gatling gun",
                        variable=self.gg_gat, command=self.gg_refresh).grid(
            row=1, column=0, columnspan=2, sticky="w", **pad)
        ttk.Label(gun, wraplength=760, justify="left", text=(
            "Players holding the gatling gun stand still while using it. Tick the box below to use the STINNETT cheat "
            "so everyone can move with it (the game then flashes characters yellow as cheaters).")).grid(
            row=2, column=0, columnspan=2, sticky="w", padx=8)
        self.gg_stin = tk.BooleanVar(value=bool(sv.get("stinnett", False)))
        ttk.Checkbutton(gun, text="Player can move while using gatling gun (uses STINNETT, flashes yellow)",
                        variable=self.gg_stin).grid(row=4, column=0, columnspan=2, sticky="w", padx=8, pady=4)
        self.gg_custom = ttk.Frame(gun)
        self.gg_custom.grid(row=3, column=0, columnspan=2, sticky="w", padx=8, pady=4)
        names = [n for n, _ in self.GG_WEAPONS]
        saved_c = sv.get("custom") if isinstance(sv.get("custom"), list) and len(sv.get("custom")) == len(names) else names
        self.gg_slots = []
        for i in range(len(names)):
            r, c = divmod(i, 4)
            ttk.Label(self.gg_custom, text=f"{i + 1}.").grid(row=r, column=c * 2, sticky="e", padx=(4, 2), pady=2)
            cb = ttk.Combobox(self.gg_custom, values=names, state="readonly", width=14)
            cb.set(saved_c[i] if saved_c[i] in names else names[i])
            cb.grid(row=r, column=c * 2 + 1, padx=(0, 8), pady=2)
            self.gg_slots.append(cb)
        b = ttk.Button(g, text="LAUNCH GUN-GAME", command=lambda: self.launch(gungame=True), width=26,
                       style="Launch.TButton")
        b.grid(row=3, column=0, pady=14)
        self.launch_btns.append((b, "LAUNCH GUN-GAME"))
        ttk.Label(g, wraplength=820, justify="left", text=(
            "Bot names, characters and strengths come from the Bots Setup tab. Your own game joins automatically "
            "while 'I play too' is ticked there.")).grid(
            row=4, column=0, sticky="w", **pad)
        self.gg_refresh()

    # -- Stats tab
    def build_stats(self, saved):
        pad = dict(padx=8, pady=4)
        g = self.st
        ttk.Label(g, wraplength=820, justify="left", text=(
            "Your Survival Horde results, saved on this PC (ranked.db next to the launcher): games played, kills, deaths "
            "and suicides, read from the game's own kill messages (suicide, fall, drowned, crushed, telefrag, "
            "blew yourself up, self-destruct). Deaths by cause are listed under the totals.")).grid(
            row=0, column=0, columnspan=3, sticky="w", **pad)
        ttk.Label(g, text="Your name").grid(row=1, column=0, sticky="e", **pad)
        self.stats_name = tk.StringVar(value=saved.get("stats_player") or (saved.get("modes") or {}).get("player", ""))
        ttk.Entry(g, textvariable=self.stats_name, width=22).grid(row=1, column=1, sticky="w", **pad)
        bf = ttk.Frame(g)
        bf.grid(row=1, column=2, sticky="w", **pad)
        ttk.Button(bf, text="Refresh", command=self.stats_refresh).pack(side="left")
        ttk.Button(bf, text="Reset Stats", command=self.stats_reset).pack(side="left", padx=(8, 0))
        self.stats_sum = tk.StringVar()
        ttk.Label(g, textvariable=self.stats_sum, justify="left", font=("TkDefaultFont", 11, "bold")).grid(
            row=2, column=0, columnspan=3, sticky="w", **pad)
        cols = ("Map", "Games", "Kills", "Deaths", "Suicides", "K/D")
        self.stats_tree = ttk.Treeview(g, columns=cols, show="headings", height=10)
        for c, w in zip(cols, (180, 70, 70, 70, 80, 70)):
            self.stats_tree.heading(c, text=c)
            self.stats_tree.column(c, width=w, anchor="center" if c != "Map" else "w")
        self.stats_tree.grid(row=3, column=0, columnspan=3, sticky="w", padx=12, pady=6)
        self.stats_refresh()

    def stats_reset(self):
        """Reset Stats button: after a confirmation, delete this player's saved games (back to zero)."""
        name = self.stats_name.get().strip()
        if not name:
            messagebox.showinfo("Reset Stats", "Type your name first.")
            return
        if not messagebox.askyesno("Reset Stats", "Are You Sure You Want To Reset Your Stats?", icon="warning", default="no"):
            return
        try:
            if str(HERE) not in sys.path:
                sys.path.insert(0, str(HERE))
            import ranked
            ranked.reset_player(name)
        except Exception as e:
            messagebox.showerror("Reset Stats", f"Could not reset the stats:\n{e}")
            return
        self.stats_refresh()

    def stats_refresh(self):
        """Fill the Stats tab from the local database."""
        name = self.stats_name.get().strip()
        for i in self.stats_tree.get_children():
            self.stats_tree.delete(i)
        if not name:
            self.stats_sum.set("Type your name above, then play Survival Horde.")
            return
        try:
            if str(HERE) not in sys.path:
                sys.path.insert(0, str(HERE))
            import ranked
            tot, per = ranked.player_stats(name)
        except Exception as e:
            self.stats_sum.set(f"Stats unavailable: {e}")
            return
        if not tot["games"]:
            self.stats_sum.set(f"No games saved for {name} yet.")
            return
        self.stats_sum.set(f"{name}: {tot['games']} games, {tot['kills']} kills, {tot['deaths']} deaths, "
                           f"{tot['suicides']} suicides, K/D {tot['kd']}, {tot['minutes']} min played"
                           + (f", favourite character {tot['favourite']}" if tot["favourite"] else "")
                           + ("\nDeaths by cause: " + ", ".join(f"{k} {v}" for k, v in sorted(tot.get("causes", {}).items(), key=lambda a: -a[1]))
                              if tot.get("causes") else ""))
        labels = {k: lab.replace(" (custom)", "") for lab, k in MAPS}
        for row in per:
            self.stats_tree.insert("", "end", values=(labels.get(row[0], row[0]),) + tuple(row[1:]))

    # -- Game Modes tab: Survival Horde, Last Man Standing
    GM_MODES = {
        "Survival Horde": "Test your skills in a game of survival. The further you progress the harder the challenge will become.",
        "Gun-Game": "Everyone starts with the first weapon on the ladder; a kill moves you up a weapon, dying drops you back one. Kill someone with the last weapon to win.",
        "Last Man Standing": "Free for all, one life each. A bot that dies stays dead; the last one alive wins and the game ends. (You aren't held to the rule: stop playing when you die.)",
    }
    GM_LEVELS = ["Mixed (nightmare to easiest)"] + DIFFICULTIES
    GM_HMODES = ["Normal", "Challenge", "Melee Zombies"]

    def build_modes(self, saved):
        pad = dict(padx=8, pady=4)
        g, sv = self.gm, saved.get("modes", {})
        self.gm_mode = ttk.Combobox(g, values=list(self.GM_MODES), state="readonly", width=24)
        self.gm_mode.set(sv.get("mode") if sv.get("mode") in self.GM_MODES else "Survival Horde")
        mode_lbl = ttk.Label(g, text="Game mode")
        mode_lbl.grid(row=0, column=0, sticky="w", **pad)
        self.gm_mode.grid(row=0, column=1, sticky="w", **pad)
        self.gm_info = tk.StringVar()
        info_lbl = ttk.Label(g, textvariable=self.gm_info, wraplength=820, justify="left")
        info_lbl.grid(row=1, column=0, columnspan=2, sticky="w", **pad)
        ttk.Label(g, text="Map").grid(row=2, column=0, sticky="w", **pad)
        mf = ttk.Frame(g)
        mf.grid(row=2, column=1, sticky="w", **pad)
        want = (sv.get("map") or "").replace(" (custom)", "")
        grp = "Custom maps" if want in MAP_GROUPS["Custom maps"] else "Standard maps"
        self.gm_group = ttk.Combobox(mf, values=list(MAP_GROUPS), state="readonly", width=14)
        self.gm_group.set(grp)
        self.gm_group.grid(row=0, column=0, padx=(0, 4))
        self.gm_map = ttk.Combobox(mf, values=MAP_GROUPS[grp], state="readonly", width=26)
        self.gm_map.set(want if want in MAP_GROUPS[grp] else MAP_GROUPS[grp][0])
        self.gm_map.grid(row=0, column=1)

        def pick_group(_e=None):
            names = MAP_GROUPS.get(self.gm_group.get()) or MAP_GROUPS["Standard maps"]
            if self.gm_mode.get() == "Survival Horde":
                names = horde_maps(names) or names
            self.gm_map.configure(values=names)
            self.gm_map.set(names[0])
        self.gm_group.bind("<<ComboboxSelected>>", pick_group)
        self.gm_vars = {}
        rows = [("bots", "Last Man Standing: bots", 4, 2, 7),
                ("lives", "Last Man Standing: lives each", 1, 1, 5)]
        lms_only = []                                  # Last Man Standing settings: hidden for Survival Horde
        for r, (key, label, default, lo, hi) in enumerate(rows, 3):
            lb = ttk.Label(g, text=label)
            lb.grid(row=r, column=0, sticky="w", **pad)
            v = tk.IntVar(value=int(sv.get(key, default)))
            sp = ttk.Spinbox(g, from_=lo, to=hi, width=6, textvariable=v)
            sp.grid(row=r, column=1, sticky="w", **pad)
            lms_only += [lb, sp]
            self.gm_vars[key] = v
        lvl_lbl = ttk.Label(g, text="Bot difficulty (Last Man Standing)")
        lvl_lbl.grid(row=7, column=0, sticky="w", **pad)
        lms_only.append(lvl_lbl)
        self.gm_level = ttk.Combobox(g, values=self.GM_LEVELS, state="readonly", width=24)
        lms_only.append(self.gm_level)
        self.gm_level.set(sv.get("level") if sv.get("level") in self.GM_LEVELS else self.GM_LEVELS[0])
        self.gm_level.grid(row=7, column=1, sticky="w", **pad)
        self.gm_you = tk.BooleanVar(value=bool(sv.get("you", True)))
        ttk.Checkbutton(g, text="I play too (my game joins automatically)", variable=self.gm_you).grid(
            row=8, column=0, columnspan=2, sticky="w", **pad)
        chars = [k for k, _ in CHARACTERS]
        char_fr = ttk.Frame(g)
        char_fr.grid(row=9, column=0, columnspan=2, sticky="w", **pad)
        ttk.Label(char_fr, text="Your character").grid(row=0, column=0, sticky="w")
        self.gm_char = ttk.Combobox(char_fr, values=chars, state="readonly", width=16)
        self.gm_char.set(sv.get("character") if sv.get("character") in chars else chars[1])
        self.gm_char.grid(row=0, column=1, padx=8)
        ttk.Label(char_fr, text="(picked for you, and you join the Survivors automatically)").grid(row=0, column=2, sticky="w")
        ttk.Label(char_fr, text="Horde mode").grid(row=1, column=0, sticky="w", pady=(4, 0))
        self.gm_hmode = ttk.Combobox(char_fr, values=self.GM_HMODES, state="readonly", width=16)
        self.gm_hmode.set(sv.get("horde_mode") if sv.get("horde_mode") in self.GM_HMODES else "Normal")
        self.gm_hmode.grid(row=1, column=1, padx=8, pady=(4, 0))
        ttk.Label(char_fr, text="(Challenge: Normal bots to start, Hard at 5 kills, Nightmare at 10, Hell at 15. Melee Zombies: Mary and Two Feathers, knives and fists only. Not for ranked)", wraplength=520, justify="left").grid(
            row=1, column=2, sticky="w", pady=(4, 0))
        self.gm_classic = tk.BooleanVar(value=bool(sv.get("classic", False)))
        self.gm_hell = tk.BooleanVar(value=bool(sv.get("hell", False)))
        hell_cb = ttk.Checkbutton(g, text="Include Hell: at 25 kills the bots become Hell bots (no aim wobble, no reaction time)",
                                  variable=self.gm_hell)
        hell_cb.grid(row=10, column=0, columnspan=2, sticky="w", **pad)
        self.gm_private = tk.BooleanVar(value=bool(sv.get("private", False)))
        private_cb = ttk.Checkbutton(g, text="Private game (only you and the bots: nobody can see or join it)", variable=self.gm_private)
        private_cb.grid(row=15, column=0, columnspan=2, sticky="w", **pad)
        classic_cb = ttk.Checkbutton(g, text="Classic Outlaws style (no mods: no zombie skins, team colours, darkness, music or storms; bots are "
                                     "named Bot 1, Bot 2 ...; only the HORDE BECOMES STRONGER banner and thunder stay)",
                                     variable=self.gm_classic)
        classic_cb.grid(row=11, column=0, columnspan=2, sticky="w", **pad)
        rk = ttk.LabelFrame(g, text="Survival Horde: ranked")
        rk.grid(row=12, column=0, columnspan=2, sticky="ew", padx=12, pady=4)
        self.gm_ranked = tk.BooleanVar(value=False)         # always unticked when the launcher opens: only you tick it on
        ttk.Checkbutton(rk, text="Ranked Game (saves your kills, deaths, character and map; maps limited to Repair, "
                        "Dry Gulch, Bunkers)", variable=self.gm_ranked, command=self.gm_ranked_changed).grid(
            row=0, column=0, columnspan=4, sticky="w", **pad)
        self.rk_labels = [ttk.Label(rk, text="Played under the name on the Stats tab"), ttk.Label(rk, text="Ranked map")]
        self.rk_labels[0].grid(row=1, column=0, columnspan=2, sticky="w", **pad)
        self.rk_labels[1].grid(row=2, column=0, sticky="e", **pad)
        self.gm_rank_map = ttk.Combobox(rk, values=list(RANKED_LABELS), state="readonly", width=16)
        self.gm_rank_map.set(RANKED_LABELS[0])
        self.gm_rank_map.grid(row=2, column=1, sticky="w", **pad)
        self.gm_show_rank = ttk.Button(rk, text="Show rankings", command=self.show_rankings)
        self.gm_show_rank.grid(row=2, column=2, columnspan=2, sticky="w", **pad)
        self.gm_top = tk.StringVar()
        ttk.Label(rk, textvariable=self.gm_top, justify="left").grid(row=3, column=0, columnspan=4, sticky="w", **pad)
        self.gm_map.bind("<<ComboboxSelected>>", lambda e: self.gm_refresh_top(), add="+")
        self.gm_rank_map.bind("<<ComboboxSelected>>", lambda e: self.gm_refresh_top(from_box=True), add="+")
        self.gm_ranked_changed()
        self.gm_refresh_top()
        b = ttk.Button(g, text="LAUNCH GAME MODE", command=self.launch_mode, width=26, style="Launch.TButton")
        b.grid(row=13, column=0, columnspan=2, pady=14)
        self.launch_btns.append((b, "LAUNCH GAME MODE"))
        surv_note = ttk.Label(g, wraplength=820, justify="left", text=(
            "Test your skills in a game of survival. The further you progress the harder the challenge will become.\n"
            "Ranked games record your game stats (kills, deaths, character and map) to the rankings."))
        surv_note.grid(row=14, column=0, columnspan=2, sticky="w", padx=12, pady=(4, 10))
        surv_only = [rk, surv_note, classic_cb, char_fr, hell_cb, private_cb]                    # shown only for Survival Horde

        keep = {mode_lbl, self.gm_mode, info_lbl, self.gg, *self.upd_btns}   # (the Update Launcher button is placed, not gridded)

        def show(_e=None):
            self.gm_info.set(self.GM_MODES[self.gm_mode.get()])
            gun = self.gm_mode.get() == "Gun-Game"       # Gun-Game swaps in its own settings and launch button
            for w in g.winfo_children():
                if w in keep:
                    continue
                surv = self.gm_mode.get() == "Survival Horde"
                if gun or (w in lms_only and surv) or (w in surv_only and not surv):
                    w.grid_remove()
                else:
                    w.grid()
            if gun:
                self.gg.grid(row=2, column=0, columnspan=2, sticky="nw")
            else:
                self.gg.grid_remove()
        self.gm_mode.bind("<<ComboboxSelected>>", lambda e: (show(), self.gm_ranked_changed()))
        show()

    def gm_refresh_top(self, from_box=False):
        """The top 3 players of the selected map (the Rankings-for box, or the map chosen for the game)."""
        from_box = from_box or bool(self.gm_ranked.get())
        label = self.gm_rank_map.get() if from_box or self.gm_map.get() not in RANKED_KEYS else self.gm_map.get()
        if not from_box and self.gm_map.get() in RANKED_KEYS:
            self.gm_rank_map.set(label)
        try:
            if str(HERE) not in sys.path:
                sys.path.insert(0, str(HERE))
            import ranked
            rows = ranked.best_leaderboard(RANKED_KEYS[label], limit=3)
        except Exception as e:
            self.gm_top.set(f"Top 3 on {label}: rankings unavailable ({e})")
            return
        medals = ["1st", "2nd", "3rd"]
        lines = [f"{medals[r[0] - 1]}  {r[1]}   K/D {r[4]}  ({r[2]} kills, {r[3]} deaths, {r[6] or 'no character'})" for r in rows]
        self.gm_top.set(f"Top 3 on {label} ({getattr(ranked, 'LAST_SOURCE', '')}):\n" + ("\n".join(lines) if lines else "no ranked games yet"))

    def gm_ranked_changed(self):
        """Ranked games: only Repair, Dry Gulch and Bunkers. Everything else in the ranked box stays grayed
        out until the Ranked Game box is ticked."""
        on = bool(self.gm_ranked.get())
        try:                                    # ranked games are always the normal climb
            if on:
                self.gm_hmode.set("Normal")
            self.gm_hmode.configure(state="disabled" if on else "readonly")
        except (tk.TclError, AttributeError):
            pass
        for w, normal in ((self.gm_rank_map, "readonly"), (self.gm_show_rank, "normal")):
            try:
                w.configure(state=normal if on else "disabled")
            except tk.TclError:
                pass
        for lb in getattr(self, "rk_labels", []):
            try:
                lb.configure(state="normal" if on else "disabled")
            except tk.TclError:
                pass
        if on and self.gm_mode.get() == "Survival Horde":
            # A ranked game is played on the map picked in the ranked box, so the regular map lists are grayed out.
            self.gm_group.configure(state="disabled")
            self.gm_map.configure(state="disabled")
        else:
            self.gm_group.configure(state="readonly")
            names = MAP_GROUPS.get(self.gm_group.get()) or MAP_GROUPS["Standard maps"]
            if self.gm_mode.get() == "Survival Horde":
                names = horde_maps(names) or names                 # only maps with Team Deathmatch
            self.gm_map.configure(state="readonly", values=names)
            if self.gm_map.get() not in names and self.gm_map.get() not in RANKED_KEYS:
                self.gm_map.set(names[0])
            if self.gm_map.get() in RANKED_KEYS and self.gm_map.get() not in dict(MAPS):    # a ranked short name ("Repair")
                full = next((n for n, k in MAPS if k == RANKED_KEYS[self.gm_map.get()]), None)
                if full:
                    self.gm_map.set(full)
        if hasattr(self, "gm_top"):
            self.gm_refresh_top(from_box=True)

    def show_rankings(self):
        """A window with the kill/death rankings of the chosen map."""
        try:
            if str(HERE) not in sys.path:
                sys.path.insert(0, str(HERE))
            import ranked
            rows = ranked.best_leaderboard(RANKED_KEYS[self.gm_rank_map.get()])
        except Exception as e:
            messagebox.showerror("Rankings", f"Could not read the rankings database:\n{e}")
            return
        win = tk.Toplevel(self)
        win.title(f"Survival rankings: {self.gm_rank_map.get()} ({getattr(ranked, 'LAST_SOURCE', '')})")
        cols = ("Rank", "Player", "Kills", "Deaths", "K/D", "Games", "Favourite character")
        tree = ttk.Treeview(win, columns=cols, show="headings", height=min(max(len(rows), 5), 20))
        for c, w in zip(cols, (50, 160, 60, 60, 60, 60, 150)):
            tree.heading(c, text=c)
            tree.column(c, width=w, anchor="center" if c != "Player" else "w")
        for r in rows:
            tree.insert("", "end", values=r)
        tree.pack(fill="both", expand=True, padx=8, pady=8)
        if not rows:
            ttk.Label(win, text="No ranked games on this map yet.").pack(pady=(0, 8))

    def mode_args(self):
        """The command line (after python) of the chosen mode's script."""
        mode = self.gm_mode.get()
        label = self.gm_map.get()
        mp = (RANKED_KEYS.get(self.gm_rank_map.get()) if self.gm_ranked.get() and mode == "Survival Horde" else None) \
            or dict(MAPS).get(label) or RANKED_KEYS.get(label) or "drygulch"      # "Repair" etc. can linger after unticking Ranked
        n = int(self.gm_vars["bots"].get())
        users = "1" if self.gm_you.get() else "0"
        lv = self.gm_level.get()
        if lv.startswith("Mixed"):
            levels = "nightmare,hard,easy,easiest"
        else:
            levels = lv.lower()
        if mode == "Survival Horde":
            extra = []
            if self.gm_ranked.get():
                extra = ["--ranked"]
            if self.gm_classic.get():
                extra += ["--classic"]
            if self.gm_hell.get():
                extra += ["--hell"]
            if self.gm_hmode.get() == "Challenge" and not self.gm_ranked.get():
                extra += ["--challenge"]
            if self.gm_hmode.get() == "Melee Zombies" and not self.gm_ranked.get():
                extra += ["--melee"]                       # Mary and Two Feathers, knives and fists only
            if self.gm_private.get():
                extra += ["--private"]
            extra += ["--player", self.stats_name.get().strip() or "Player"]
            extra += ["--character", self.gm_char.get()]
            return ["horde.py", "--map", mp, "--minutes", "30", "--users", users] + extra
        return ["lms.py", "--map", mp, "--bots", str(max(2, n)), "--levels", levels, "--lives", str(self.gm_vars["lives"].get()),
                    "--minutes", "30", "--users", users]

    def launch_mode(self):
        if not (HERE / "horde.py").exists():
            messagebox.showerror("Not found", f"The game mode scripts are not next to the launcher:\n{HERE}")
            return
        self.save()
        try:
            _a = self.mode_args()
            self.serve_mods("horde" if _a[0] == "horde.py" else "lms", _a[_a.index("--map") + 1], melee="--melee" in _a, private="--private" in _a)
        except Exception:
            pass
        for b, _ in self.launch_btns:
            b.configure(text="Loading...", state="disabled")
        self.zerotier = False
        self.cancel = False
        self.launching = True
        self.gg_env = {}
        self.play_char = self.gm_char.get() if self.gm_mode.get() == "Survival Horde" else None   # Survival: your character and the Survivors team are picked for you
        self.play_horde = self.gm_mode.get() == "Survival Horde" and not self.gm_classic.get()   # (Vulkan for the Survival look)
        self.minimize_new_consoles()
        threading.Thread(target=self.run_mode, args=(self.mode_args(), self.gm_you.get()), daemon=True).start()

    def close_new_consoles(self):
        """The game is over: close the console (cmd) windows that opened after the launch button was pressed, so none has to
        be closed by hand. The game's own window (its title says Outlaws) is left alone."""
        try:
            import ctypes
            u = ctypes.windll.user32
            for h in list(getattr(self, "new_consoles", ())):
                if not u.IsWindow(h):
                    continue
                buf = ctypes.create_unicode_buffer(256)
                u.GetWindowTextW(h, buf, 256)
                if "outlaws" in buf.value.lower():
                    continue
                u.PostMessageW(h, 0x0010, 0, 0)               # WM_CLOSE
            self.new_consoles = set()
        except Exception:
            pass

    def minimize_new_consoles(self, seconds=3 * 3600):
        """Any console (cmd) window that opens after the launch button is pressed is minimized, so it isn't left in the middle
        of the screen: the game opens one of its own. Only windows that were not there when the button was pressed."""
        def work():
            try:
                import ctypes
                from ctypes import wintypes
                u = ctypes.windll.user32
                classes = {"ConsoleWindowClass", "CASCADIA_HOSTING_WINDOW_CLASS"}
                proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

                def consoles():
                    found = []

                    def cb(h, _):
                        if u.IsWindowVisible(h):
                            buf = ctypes.create_unicode_buffer(64)
                            u.GetClassNameW(h, buf, 64)
                            if buf.value in classes:
                                found.append(h)
                        return True
                    u.EnumWindows(proc(cb), 0)
                    return found
                before, done = set(consoles()), set()
                self.new_consoles = done
                end = time.time() + seconds
                while time.time() < end:
                    time.sleep(0.4)
                    for h in consoles():
                        if h not in before and h not in done:
                            done.add(h)
                            u.ShowWindow(h, 7)                    # SW_SHOWMINNOACTIVE: minimized, the game keeps the focus
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    def run_mode(self, args, you):
        self.say("ending any game copies left over from before...")
        self.kill_all()
        time.sleep(2)
        venv_python = HERE / ".venv" / "Scripts" / "python.exe"
        py = str(venv_python) if venv_python.exists() else sys.executable
        joined = False
        try:
            p = subprocess.Popen([py, "-u", str(HERE / args[0])] + args[1:], cwd=str(HERE),
                                 env=dict(os.environ, PYTHONUNBUFFERED="1"), stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, errors="replace", creationflags=NO_WINDOW)
            self.bots_proc = p
            for line in p.stdout:
                if self.cancel:
                    break
                self.say(line)
                if you and not joined and "lobby up" in line:
                    joined = True
                    self.say("the game is hosted; joining it...")
                    threading.Thread(target=self.join_and_watch, daemon=True).start()
            if self.cancel:
                try:
                    p.kill()
                except OSError:
                    pass
            else:
                p.wait()
                time.sleep(3)
                self.close_new_consoles()
        except OSError as e:
            self.say(f"could not start the game mode: {e}")
        if not joined:
            self.ready()

    def gg_pb_refresh(self):
        """One per-bot box for each bot to play against (the Bots to play against number)."""
        try:
            n = max(0, min(10, int(self.gg_count.get())))
        except (ValueError, tk.TclError):
            return
        for i, (lb, cb) in enumerate(self.gg_bot_rows):
            if i < n:
                lb.grid(row=i % 5, column=(i // 5) * 2, sticky="e", padx=(8, 2), pady=1)
                cb.grid(row=i % 5, column=(i // 5) * 2 + 1, pady=1)
            else:
                lb.grid_remove()
                cb.grid_remove()

    def gg_diff_changed(self):
        """Picking a general difficulty clears the per-bot choices; "Custom" keeps them."""
        d = self.gg_diff.get()
        if d in DIFFICULTIES:
            self.gg_last_base = d
            for cb in self.gg_bot_diffs:
                cb.set("Same as above")

    def gg_pb_changed(self, i):
        """A bot's own difficulty was changed: the general difficulty becomes Custom. The bots still on "Same as
        above" keep the difficulty they had, spelled out."""
        base = self.gg_diff.get()
        if base in DIFFICULTIES:
            self.gg_last_base = base
        for j, cb in enumerate(self.gg_bot_diffs):
            if j != i and cb.get() not in DIFFICULTIES:
                cb.set(self.gg_last_base)
        self.gg_diff.set("Custom")

    def gg_refresh(self):
        """Custom order boxes only in Custom mode; the gatling gun only when included."""
        custom = self.gg_order.get() == "Custom"
        for cb in self.gg_slots:
            cb.configure(state="readonly" if custom else "disabled")

    def gg_ladder(self):
        """The slot order for this game: default, shuffled (the knife stays last) or the custom boxes."""
        import random
        by_name = dict(self.GG_WEAPONS)
        mode = self.gg_order.get()
        if mode == "Custom":
            order = [by_name[cb.get()] for cb in self.gg_slots]
            order = list(dict.fromkeys(order))                  # a weapon twice counts once
        else:
            order = [5, 4, 3, 9, 6, 2, 7, 8]
            if mode == "Randomized":
                rest = order[:-1]
                random.shuffle(rest)
                order = rest + [8]
        if not self.gg_gat.get():
            order = [s for s in order if s != 9]
        return order or [8]

    def zt_say(self, text):
        self.after(0, lambda: self.zt_msg.set(text))

    def zt_refresh_button(self):
        def work():
            st = zt_state()
            label = {"missing": "Install and turn on ZeroTier", "off": "Turn ON ZeroTier",
                     "on": "Turn OFF ZeroTier"}[st]
            self.after(0, lambda: self.zt_btn.configure(text=label, state="normal"))
        threading.Thread(target=work, daemon=True).start()

    def zt_toggle(self):
        st = zt_state()
        if st == "missing" and not messagebox.askyesno(
                "Install ZeroTier", "ZeroTier One isn't installed.\n\nDownload it from download.zerotier.com and install "
                "it now? Windows will ask you to allow the installer."):
            return
        self.zt_btn.configure(state="disabled", text="Working, please wait...")
        threading.Thread(target=self.zt_work, args=(st,), daemon=True).start()

    def zt_work(self, st):
        try:
            if st == "on":
                self.zt_say("turning ZeroTier off (allow the Windows prompt)...")
                run_elevated("cmd", f"/c sc stop {ZT_SERVICE}")
                time.sleep(2)
                self.zt_say("ZeroTier is off" if zt_state() != "on" else "could not turn ZeroTier off")
                return
            if st == "missing":
                import tempfile
                msi = Path(tempfile.gettempdir()) / "ZeroTierOne.msi"
                ok = False
                try:
                    self.zt_say("downloading ZeroTier...")
                    download(ZT_MSI, msi)
                    ok = msi.stat().st_size > 1_000_000 and msi.read_bytes()[:8] == bytes.fromhex("d0cf11e0a1b11ae1")
                    if ok:
                        self.zt_say("installing ZeroTier (allow the Windows prompt)...")
                        run_elevated("msiexec", f'/i "{msi}" /qn /norestart')
                except Exception as e:                         # noqa: BLE001
                    self.zt_say(f"direct download failed ({e}); trying winget...")
                for _ in range(30):
                    if zt_state() != "missing":
                        break
                    time.sleep(1)
                if zt_state() == "missing":                    # the download or install didn't work: try winget
                    self.zt_say("installing ZeroTier with winget (allow the Windows prompt; this can take a minute)...")
                    run_elevated("cmd", "/c winget install -e --id ZeroTier.ZeroTierOne --silent "
                                        "--accept-package-agreements --accept-source-agreements")
                    for _ in range(60):
                        if zt_state() != "missing":
                            break
                        time.sleep(1)
                if zt_state() == "missing":
                    import webbrowser
                    webbrowser.open("https://www.zerotier.com/download")
                    self.zt_say("could not install it automatically: I opened zerotier.com/download. Install it there, "
                                "then click this button again.")
                    return
            if zt_state() != "on":
                self.zt_say("starting ZeroTier (allow the Windows prompt)...")
                run_elevated("cmd", f"/c sc start {ZT_SERVICE}")
                for _ in range(15):
                    if zt_state() == "on":
                        break
                    time.sleep(1)
            if zt_state() != "on":
                self.zt_say("could not start ZeroTier")
                return
            net = self.zt_net.get().strip()
            if net and ZT_CLI.exists():
                self.zt_say(f"joining network {net}...")
                run_elevated("cmd", f'/c ""{ZT_CLI}" join {net}"')
            elif not net:
                self.zt_say("ZeroTier is on; type your network ID above and turn it on again to join it")
            for _ in range(20):                                # the adapter needs a moment (and your authorisation)
                ip = zerotier_ip()
                if ip:
                    self.after(0, lambda ip=ip: self.zt_ip.set(ip))
                    self.zt_say(f"ZeroTier is on; your IP is {ip}")
                    return
                time.sleep(2)
            self.zt_say("ZeroTier is on; no IP yet: authorise this PC in my.zerotier.com (Members), then click Detect")
        except Exception as e:                                 # noqa: BLE001 - show anything to the user
            self.zt_say(f"ZeroTier: {e}")
        finally:
            self.zt_refresh_button()

    def zt_detect(self, quiet=False):
        def work():
            ip = zerotier_ip()
            def done():
                if ip:
                    self.zt_ip.set(ip)
                    self.zt_msg.set(f"found your ZeroTier IP: {ip}")
                elif not quiet:
                    self.zt_msg.set("no ZeroTier adapter found: is ZeroTier One running and joined to a network?")
            try:
                self.after(0, done)
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    def zt_clip(self, text, msg):
        self.clipboard_clear()
        self.clipboard_append(text)
        self.update()
        self.zt_msg.set(msg)

    def zt_copy_ip(self):
        ip = self.zt_ip.get().strip()
        if not ip:
            self.zt_msg.set("no IP yet: type it or click Detect")
            return
        self.zt_clip(ip, f"copied {ip}")

    def zt_copy_help(self):
        ip = self.zt_ip.get().strip()
        if not ip:
            self.zt_msg.set("no IP yet: type it or click Detect")
            return
        net = self.zt_net.get().strip()
        text = ((f"1. Install ZeroTier One and join network {net} (I'll authorise you).\n" if net else
                 "1. Install ZeroTier One and join my network (I'll authorise you).\n")
                + f"2. Start Outlaws with: OutlawsAHOM.exe -netdriver lan -skipintromovies -join {ip}\n"
                + f"   (or in the LAN game list, join {ip})")
        self.zt_clip(text, "copied the join instructions")

    # -- look
    def style_window(self):
        """A parchment-and-leather look on the clam theme."""
        self.configure(bg=PARCH)
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            return
        st.configure(".", background=PARCH, foreground=INK, fieldbackground="white", bordercolor=LEATHER)
        st.configure("TLabelframe", background=PARCH, bordercolor=LEATHER)
        st.configure("TLabelframe.Label", background=PARCH, foreground=RUST, font=("Segoe UI", 9, "bold"))
        st.configure("TCheckbutton", background=PARCH, foreground=INK)
        st.map("TCheckbutton", background=[("active", PARCH)])
        st.configure("TButton", background=LEATHER, foreground=SAND, padding=(10, 5), borderwidth=0,
                     font=("Segoe UI", 9, "bold"))
        st.map("TButton", background=[("active", RUST), ("pressed", RUST)])
        st.configure("Launch.TButton", background=RUST, foreground="white", padding=(14, 8),
                     font=("Segoe UI", 11, "bold"))
        st.map("Launch.TButton", background=[("active", "#d9731a"), ("pressed", "#d9731a")])
        st.configure("TNotebook", background=LEATHER, borderwidth=0, tabmargins=(6, 4, 6, 0))
        st.configure("TNotebook.Tab", background="#7a5a3a", foreground=SAND, padding=(16, 6), font=("Segoe UI", 10, "bold"))
        st.map("TNotebook.Tab", background=[("selected", PARCH)], foreground=[("selected", RUST)])
        st.configure("TCombobox", arrowcolor=LEATHER)
        st.map("TCombobox", fieldbackground=[("readonly", "white"), ("disabled", "#e6dcc3")],
               foreground=[("disabled", "#8a7a5c")])

    def header(self):
        """The leather background with the title and the game logo (top right) drawn on a canvas; the controls
        sit in self.body on a parchment card in the middle, so the dynamite and the knife peek out at the sides."""
        self.geometry(f"{WIN_W}x{WIN_H}")
        self.bg = self.logo = None
        try:
            from bg_data import BG_B64
            self.bg = tk.PhotoImage(data=BG_B64)
        except Exception:
            pass
        cv = tk.Canvas(self, width=WIN_W, height=WIN_H, highlightthickness=0, bg="#a8631a")
        cv.pack(fill="both", expand=True)
        if self.bg is not None:
            cv.create_image(0, 0, image=self.bg, anchor="nw")
        # The title: the logo's yellow-to-orange gradient with a dark outline, centred in the header band.
        try:
            from title_data import TITLE_B64
            self.title_img = tk.PhotoImage(data=TITLE_B64)
            cv.create_image(TITLE_CX, 96, image=self.title_img, anchor="center")
        except Exception:
            for dx, dy, col in ((3, 3, "#1c1109"), (0, 0, "#f2b90d")):
                cv.create_text(TITLE_CX + dx, 96 + dy, text="BOT LAUNCHER", anchor="center", fill=col,
                               font=("Georgia", 34, "bold"))
        for dx, dy, col in ((2, 2, "#1c1109"), (0, 0, "#f2d27a")):          # credit line under the title
            cv.create_text(TITLE_CX + dx, 162 + dy, text="By T4H_WaRRioR & Dotard", anchor="center", fill=col,
                           font=("Georgia", 13, "bold"))
        try:
            from logo_data import LOGO_B64
            self.logo = tk.PhotoImage(data=LOGO_B64)
        except Exception:
            pass
        if self.logo is not None:
            lw, lh = self.logo.width(), self.logo.height()
            x1, y0 = WIN_W - 18, 12
            cv.create_rectangle(x1 - lw - 16, y0, x1, y0 + lh + 12, fill="#2a1a0d", outline=SAND, width=2)
            cv.create_image(x1 - 8, y0 + 6, image=self.logo, anchor="ne")
        shell = tk.Frame(cv, bg=PARCH, highlightbackground=LEATHER, highlightcolor=LEATHER, highlightthickness=4)
        cv.create_window(WIN_W // 2, 190, window=shell, anchor="n")
        self.nb = ttk.Notebook(shell)
        self.nb.pack(fill="both", expand=True)
        self.body = tk.Frame(self.nb, bg=PARCH)            # the "Bots" tab
        self.zt = tk.Frame(self.nb, bg=PARCH)              # the "ZeroTier LAN" tab
        self.nb.add(self.body, text="  Bots Setup  ")
        self.nb.add(self.zt, text="  ZeroTier  ")
        self.gm = tk.Frame(self.nb, bg=PARCH)              # the "New Game Modes" tab
        self.nb.add(self.gm, text="  New Game Modes  ")
        self.gg = tk.Frame(self.gm, bg=PARCH)              # Gun-Game: shown inside that tab when its mode is chosen
        self.rot = tk.Frame(self.nb, bg=PARCH)             # the "Map Rotation" tab
        self.nb.add(self.rot, text="  Map Rotation  ")
        self.st = tk.Frame(self.nb, bg=PARCH)              # the "Stats" tab
        self.nb.add(self.st, text="  Stats  ")

    def pick_map_group(self):
        """Show the standard or the custom maps in the Map box."""
        names = MAP_GROUPS.get(self.map_group.get()) or MAP_GROUPS["Standard maps"]
        self.map.configure(values=names)
        self.map.set(names[0])
        self.update_modes()

    def update_modes(self):
        """Offer only the game modes the chosen map has; a mode it lacks falls back to Deathmatch."""
        have = MAP_MODES.get(dict(MAPS).get(self.map.get(), "hargrove"))
        labels = [m for m, v in MODES if have is None or v in have]
        self.mode.configure(values=labels)
        if self.mode.get() not in labels:
            self.mode.set(labels[0])
        self.refresh_all()

    # -- rows
    @property
    def screen_value(self):
        return dict(SCREEN_MODES).get(self.screen.get(), "full")

    def base_diff(self):
        """The general difficulty; while the box says Custom, the one it had before."""
        d = self.diff.get()
        return d if d in DIFFICULTIES else self.last_base

    def diff_changed(self):
        """Picking a general difficulty clears the per-bot choices; "Custom" keeps them."""
        d = self.diff.get()
        if d in DIFFICULTIES:
            self.last_base = d
            for b in self.blocks:
                b["diff"].set("Same as above")
        self.refresh_all()

    def bot_diff_changed(self, changed):
        """One bot got its own difficulty: the general box says Custom. The other bots keep the difficulty they had,
        spelled out."""
        d = self.diff.get()
        if d in DIFFICULTIES:
            self.last_base = d
            for b in self.blocks:
                if b["diff"] is not changed and b["diff"].get() not in DIFFICULTIES:
                    b["diff"].set(self.last_base)
        self.diff.set("Custom")
        self.refresh_all()

    def refresh_all(self):
        try:
            n = max(1, min(10, int(self.count.get())))
        except (tk.TclError, ValueError):
            n = 1
        team_mode = self.mode_value() in TEAM_MODES
        self.apply_split(n, team_mode)
        base = self.base_diff()
        only = self.tnt_only.get() or base in SHARP
        for i, b in enumerate(self.blocks):
            if i < n:
                b["frame"].grid(row=i, column=0, sticky="ew", padx=2, pady=2)
            else:
                b["frame"].grid_remove()
            b["team"].configure(state="readonly" if team_mode else "disabled")
            own = b["diff"].get()
            nightmare = (own if own in DIFFICULTIES else base) in SHARP and not self.tnt_only.get()
            b["char"].block([k for k, v in CHARACTERS if v not in NIGHTMARE_CHARS] if nightmare else [])
            b["char"].configure(state="disabled" if self.tnt_only.get() else "normal")
            b["beh"].configure(state="disabled" if only else "readonly")
            for cb in b["weapons"]:
                cb.configure(state="disabled" if only else "readonly")

    def apply_split(self, n, team_mode):
        """Team modes: with a number chosen, the first that many bots go Red and the rest Blue (6 v 2 and so on)."""
        row = getattr(self, "split_row", None)
        if row is None:
            return
        if not team_mode:
            row.grid_remove()
            return
        row.grid()
        r, bl = self.red_n.get().strip(), self.blue_n.get().strip()
        src = getattr(self, "split_src", "red")
        typed = bl if src == "blue" else r
        if not typed.isdigit():
            if not (r.isdigit() or bl.isdigit()):
                self.split_info.configure(
                    text="(fill in Red or Blue, the other fills itself; blank = each bot's own team box below)")
            return                          # (never rewrite the box being typed in, it fights the keyboard)
        if src == "blue":
            blue = min(int(bl), n)
            red = n - blue
            other, other_var = red, self.red_n
        else:
            red = min(int(r), n)
            blue = n - red
            other, other_var = blue, self.blue_n
        self.split_busy = True              # (setting the other box must not count as the user typing)
        try:
            if other_var.get() != str(other):
                other_var.set(str(other))
        finally:
            self.split_busy = False
        for i, b in enumerate(self.blocks):
            if i < n:
                b["team"].set("Red" if i < red else "Blue")
        self.split_info.configure(text=f"-> {red} bot(s) on Red, {blue} on Blue (you pick your side in the lobby)")

    # -- saved bot presets
    def read_presets(self):
        try:
            data = json.loads(BOT_PRESETS.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return (data + [None] * PRESET_SLOTS)[:PRESET_SLOTS]
        except (OSError, ValueError):
            pass
        return [None] * PRESET_SLOTS

    def write_presets(self):
        try:
            BOT_PRESETS.write_text(json.dumps(self.preset_data, indent=1), encoding="utf-8")
        except OSError as e:
            messagebox.showerror("Could not save", f"The presets file could not be written:\n{e}")

    def show_presets(self, select=None):
        self.preset_list.delete(0, "end")
        for k, p in enumerate(self.preset_data):
            self.preset_list.insert("end", f"{k + 1}.  " + (p.get("name", "Preset") if p else "(empty)"))
        if select is not None:
            self.preset_list.selection_set(select)
        self.preset_buttons()

    def chosen_slot(self):
        sel = self.preset_list.curselection()
        return sel[0] if sel else None

    def preset_buttons(self):
        k = self.chosen_slot()
        full = k is not None and self.preset_data[k] is not None
        self.load_btn.configure(state="normal" if full else "disabled")
        self.del_btn.configure(state="normal" if full else "disabled")

    def save_preset(self):
        k = self.chosen_slot()
        if k is None:
            k = next((i for i, p in enumerate(self.preset_data) if p is None), None)
        if k is None:
            messagebox.showinfo("Presets full", "All 10 slots are used. Click a slot in the list to replace it, "
                                "or delete one first.")
            return
        old = self.preset_data[k]
        if old and not messagebox.askyesno("Replace preset", f"Replace \"{old.get('name', 'Preset')}\" in slot {k + 1}?"):
            return
        name = simpledialog.askstring("Save Bot Preset", f"Name for slot {k + 1}:",
                                      initialvalue=(old or {}).get("name", f"Preset {k + 1}"), parent=self)
        if not name or not name.strip():
            return
        cfg = self.settings()
        self.preset_data[k] = {"name": name.strip()[:24], "count": cfg["count"], "bots": cfg["bots"]}
        self.write_presets()
        self.show_presets(k)
        self.say(f"saved bot preset {k + 1}: {name.strip()}")

    def load_preset(self):
        k = self.chosen_slot()
        p = k is not None and self.preset_data[k]
        if not p:
            return
        chars = [CHAR_RANDOM] + [kk for kk, _ in CHARACTERS]
        behs = [BEH_DEFAULT] + BEHAVIOURS[1:]
        for i, b in enumerate(self.blocks):
            s = p["bots"][i] if i < len(p.get("bots", [])) else {}
            b["name"].set(s.get("name") or f"Bot {i + 1}")
            b["char"].set(s.get("char") if s.get("char") in chars else CHAR_DEFAULT)
            b["beh"].set(s.get("beh") if s.get("beh") in behs else BEH_DEFAULT)
            b["team"].set(s.get("team") if s.get("team") in TEAMS else "Auto")
            lv = s.get("levels")
            dl = default_levels(i + 1, False)
            for j, cb in enumerate(b["weapons"]):
                v = lv[j] if isinstance(lv, list) and j < len(lv) else dl[j]
                cb.set(v if v in LEVELS else dl[j])
        try:
            self.count.set(max(1, min(10, int(p.get("count", 6)))))
        except (tk.TclError, ValueError):
            pass
        self.refresh_all()
        self.say(f"loaded bot preset {k + 1}: {p.get('name')}")

    def delete_preset(self):
        k = self.chosen_slot()
        if k is None or not self.preset_data[k]:
            return
        if messagebox.askyesno("Delete preset", f"Delete \"{self.preset_data[k].get('name')}\"?"):
            self.preset_data[k] = None
            self.write_presets()
            self.show_presets()

    def reset(self):
        for i, b in enumerate(self.blocks):
            b["name"].set(preset_row(i + 1, self.real.get())[0])
            b["char"].set(CHAR_DEFAULT)
            b["beh"].set(BEH_DEFAULT)
            b["team"].set("Auto")
            b["lean"].set("No lean")
            for cb, v in zip(b["weapons"], default_levels(i + 1, self.real.get())):
                cb.set(v)

    # -- settings
    def mode_value(self):
        return dict(MODES).get(self.mode.get(), "dm")

    def settings(self):
        return {
            "map": dict(MAPS).get(self.map.get(), "hargrove"), "mode": self.mode_value(),
            "count": self.count.get(), "timelimit": self.timelimit.get(), "fraglimit": self.fraglimit.get(),
            "friendly_fire": self.ff.get(), "wait_for_me": self.wait_me.get(), "screen_mode": self.screen_value, "private": self.private.get(), "tnt_only": self.tnt_only.get(), "difficulty": self.base_diff(),
            "zt_network": self.zt_net.get().strip(), "zt_ip": self.zt_ip.get().strip(),
            "zt_users": self.zt_users.get(), "red_bots": self.red_n.get(), "blue_bots": self.blue_n.get(),
            "taunts": self.taunts.get(), "marshall_law": self.law.get(), "trim_memory": self.trim.get(), "window_mode": dict(WINDOW_MODES).get(self.wmode.get(), "hidden"),
            "size": self.size.get().strip(), "fps": self.fps.get().strip(),
            "bots": [{"name": b["name"].get(), "char": b["char"].get(), "beh": b["beh"].get(),
                      "team": b["team"].get(), "levels": [cb.get() for cb in b["weapons"]],
                      "lean": b["lean"].get(),
                      "diff": b["diff"].get() if b["diff"].get() in DIFFICULTIES else None}
                     for b in self.blocks],
        }

    def load(self):
        try:
            saved = json.loads(SETTINGS.read_text())
        except (OSError, ValueError):
            return {}
        if saved.get("levels_ver") != LEVELS_VER:          # the preset strengths changed: start from the new ones
            for b in saved.get("bots", []):
                for k in ("name", "char", "levels", "beh"):
                    b.pop(k, None)
        return saved

    def save(self):
        s = self.settings()
        s["map"], s["mode"] = self.map.get(), self.mode.get()
        s["window_mode_label"] = self.wmode.get()
        s["levels_ver"] = LEVELS_VER
        s["stats_player"] = self.stats_name.get()
        s["modes"] = {"mode": self.gm_mode.get(), "map": self.gm_map.get(), "level": self.gm_level.get(), "you": self.gm_you.get(),
                      "ranked": self.gm_ranked.get(), "character": self.gm_char.get(), "classic": self.gm_classic.get(), "hell": self.gm_hell.get(), "horde_mode": self.gm_hmode.get(),
                      **{k: v.get() for k, v in self.gm_vars.items()}}
        s["gungame"] = {"map": self.gg_map.get(), "count": self.gg_count.get(), "difficulty": self.gg_diff.get(),
                        "order": self.gg_order.get(), "gatling": self.gg_gat.get(), "stinnett": self.gg_stin.get(),
                        "bot_diffs": [cb.get() for cb in self.gg_bot_diffs],
                        "custom": [cb.get() for cb in self.gg_slots]}
        s["rotation"] = {"entries": self.rot_entries, "loop": self.rot_loop.get(), "shuffle": self.rot_shuffle.get(),
                         "score_wait": self.rot_wait_s(), "you": self.rot_you.get()}
        try:
            SETTINGS.write_text(json.dumps(s, indent=1))
        except OSError:
            pass

    def update_launcher(self):
        """Rebuild BotLauncher.exe from the newest launcher.py (update_launcher.cmd), then start it again. This window
        closes: the old exe can't be replaced while it runs."""
        from tkinter import messagebox
        script = HERE / "update_launcher.cmd"
        if not script.exists():
            messagebox.showerror("Update Launcher", f"{script.name} is missing from {HERE}.")
            return
        import hashlib
        stamp = HERE / ".build" / "built.sha"
        try:
            # What the build covers: launcher.py and the build script itself.
            now_hashes = [hashlib.sha256((HERE / n).read_bytes()).hexdigest() for n in ("launcher.py", "update_launcher.cmd")]
        except OSError:
            messagebox.showerror("Update Launcher", f"launcher.py or update_launcher.cmd is missing from {HERE}.")
            return
        try:
            built = [ln.strip().lower() for ln in stamp.read_text().splitlines() if ln.strip()]
        except OSError:
            built = []                      # never built with a stamp: can't tell, so offer it
        if built == now_hashes:
            messagebox.showinfo("Update Launcher", "This launcher is already up to date. Nothing has changed since "
                                "it was last built.")
            return
        if not messagebox.askyesno("Update Launcher",
                                   "A newer launcher.py is waiting.\n\nBuild it now?\n\nThis window closes, a build "
                                   "window runs for a minute or two, and the new launcher opens by itself."):
            return
        # The frozen exe points TCL_LIBRARY/TK_LIBRARY into its own temp folder, which is deleted when it closes; the
        # build must not inherit them or PyInstaller sees no Tcl/Tk and leaves tkinter out of the new exe.
        env = {k: v for k, v in os.environ.items() if k not in ("TCL_LIBRARY", "TK_LIBRARY")}
        try:
            subprocess.Popen(["cmd", "/c", "start", "Updating the launcher", "/D", str(HERE), str(script)],
                             cwd=str(HERE), env=env, creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
                             | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except OSError as e:
            messagebox.showerror("Update Launcher", f"Could not start the build: {e}")
            return
        self.close()

    def start_bugshot(self):
        """Ctrl+Alt+PgDn anywhere saves a screenshot + system report into the screenshots folder."""
        self.recent = []
        try:
            import bugshot
            self.bugshot = bugshot.Listener(
                extra_log=lambda: self.recent[-120:],
                on_done=lambda png, txt: self.say(f"bug capture saved: screenshots\\{png.name} (+ report)"),
                on_error=self.say)
            if self.bugshot.start():
                self.say(f"Bug capture ready: press {bugshot.HOTKEY} in the game to save a screenshot + report to "
                         "the screenshots folder.")
            else:
                self.say(f"Bug capture off: {self.bugshot.error}")
        except Exception as e:
            self.bugshot = None
            self.say(f"Bug capture unavailable: {e}")

    def close(self):
        self.save()
        if getattr(self, "bugshot", None):
            self.bugshot.stop()
        self.destroy()

    # -- log
    def say(self, text):
        if hasattr(self, "recent"):
            self.recent.append(text.rstrip("\n"))
        def add():
            self.log.configure(state="normal")
            self.log.insert("end", text.rstrip("\n") + "\n")
            self.log.see("end")
            self.log.configure(state="disabled")
        self.after(0, add)

    # -- actions
    def launch(self, zerotier=False, gungame=False, rotation=False):
        if zerotier:
            st = zt_state()
            if st != "on":
                messagebox.showerror("ZeroTier is off", "Turn on ZeroTier before launching a game"
                                     + ("\n\n(ZeroTier One isn't installed on this PC.)" if st == "missing" else ""))
                return
        if not (HERE / "botctl.py").exists():
            messagebox.showerror("Not found", f"botctl.py is not next to the launcher:\n{HERE}")
            return
        self.rotation_args = None
        self.play_char, self.play_horde = None, False    # (a Survival game before this one picked them)
        # Start your own copy and join it, or only the bots: the Bots Setup and Map Rotation tabs each have an
        # "I play too" box; ZeroTier and Gun-Game games always start yours.
        self.join_me = self.rot_you.get() if rotation else self.wait_me.get() if not (zerotier or gungame) else True
        if rotation:
            if not self.rot_entries:
                messagebox.showinfo("Map rotation", "Add at least one map to the list first.")
                return
            if not (HERE / "rotation.py").exists():
                messagebox.showerror("Not found", f"rotation.py is not next to the launcher:\n{HERE}")
                return
            try:
                self.rot_write()
            except OSError as e:
                messagebox.showerror("Map rotation", f"Could not write rotation.txt:\n{e}")
                return
            self.rotation_args = (["rotation.txt", "--score-wait", str(self.rot_wait_s())]
                                  + ([] if self.rot_loop.get() else ["--once"])
                                  + (["--shuffle"] if self.rot_shuffle.get() else []))
        try:
            cfg = self.settings()
            if rotation:                           # the bots start on the first map of the list
                first = self.rot_entries[0]
                cfg.update(map=first["map"], mode=first["mode"], timelimit=first.get("timelimit") or "",
                           fraglimit=first.get("fraglimit") or "", wait_for_me=self.join_me)
            self.gg_env = {}
            if self.stats_name.get().strip():
                self.gg_env = {"BOT_STATS_PLAYER": self.stats_name.get().strip()}       # the Stats tab: every launcher game
            if gungame:
                cfg.update(map=dict(MAPS).get(self.gg_map.get(), "hargrove"), mode="dm", count=self.gg_count.get(), wait_for_me=True,
                           difficulty=(self.gg_diff.get() if self.gg_diff.get() in DIFFICULTIES else self.gg_last_base), tnt_only=False, timelimit="", fraglimit="")
                pb = [cb.get() for cb in self.gg_bot_diffs]
                cfg["bots"] = [dict(b, diff=(pb[i] if i < len(pb) and pb[i] in DIFFICULTIES else None)) for i, b in enumerate(cfg["bots"])]
                order = self.gg_ladder()
                self.gg_env.update({"BOT_GUNGAME": "1", "BOT_GG_ORDER": ",".join(map(str, order))})
                if 9 in order and self.gg_stin.get():
                    self.gg_env["BOT_GG_STINNETT"] = "1"
            if zerotier:                                    # the count includes you, unless you don't play
                cfg["wait_users"] = max(2, int(self.zt_users.get())) - (0 if cfg["wait_for_me"] else 1)
            cfg["private"] = bool(self.private.get()) and not zerotier     # (a ZeroTier game is for friends)
            if cfg["private"]:
                cfg["wait_users"] = 1 if cfg["wait_for_me"] else 0
            args = build_args(cfg)
        except ValueError:
            messagebox.showerror("Check the numbers", "Time limit, score limit and FPS must be whole numbers.")
            return
        self.save()
        self.serve_mods("gungame" if gungame else cfg["mode"], cfg["map"], private=cfg["private"])
        if gungame:
            self.say("gun game ladder (slots): " + self.gg_env["BOT_GG_ORDER"])
        for b in self.blocks:
            b["lean"].set("No lean")            # a lean is for this game only
        for b, _ in self.launch_btns:
            b.configure(text="Loading, Please Wait", state="disabled")
        self.say("starting: " + " ".join(args))
        self.zerotier = zerotier
        self.join_me = cfg["wait_for_me"]      # start your own game once the bots' game is up
        self.cancel = False                   # set by "Close all game windows" while loading
        self.launching = True
        threading.Thread(target=self.run_bots, args=(args,), daemon=True).start()
        if self.trim.get():
            threading.Thread(target=self.trim_loop, daemon=True).start()

    def serve_mods(self, mode, map_key, **kw):
        """Friends using the Outlaws Companion fetch this game's mods (zombie skins, custom maps) from here.
        kw: melee / private, as modserver.start takes them."""
        try:
            if modserver and modserver.start(mode, map_key, **kw):
                self.say("mod server up (port %d): friends' companion apps can fetch this game's mods" % modserver.PORT)
        except Exception as e:
            self.say("mod server not started: %s" % e)

    def ready(self):
        """Put the Launch button back (called from worker threads)."""
        self.launching = False
        try:
            self.after(0, lambda: [b.configure(text=t, state="normal") for b, t in self.launch_btns])
        except Exception:
            pass

    def trim_loop(self):
        """Every 30 seconds, trim the bots' idle memory, until their game copies are gone."""
        seen, missing, first = False, 0, True
        started = time.time()
        for _ in range(60 * 60 * 24):
            time.sleep(30)
            pids = bot_game_pids()
            if pids is None:
                continue
            if pids:
                seen, missing = True, 0
                try:
                    n = trim_working_sets(pids)
                except OSError:
                    n = 0
                if first:
                    self.say(f"trimming idle memory of {n} of {len(pids)} bot windows (every 30 s)")
                    first = False
            else:
                missing += 1
                if (seen and missing >= 3) or (not seen and time.time() - started > 600):
                    return

    def run_bots(self, args):
        env = dict(os.environ, PYTHONUNBUFFERED="1", **getattr(self, "gg_env", {}))
        joined = False
        self.say("ending any game copies left over from before...")
        self.kill_all()                       # leftovers from an earlier game make bots fail to join
        time.sleep(2)
        self.clear_bot_logs()                 # this run's logs start empty, not mixed with older games
        if self.cancel:
            self.ready()
            return
        if getattr(self, "rotation_args", None):   # after kill_all, which would end it too
            threading.Thread(target=self.run_rotation, args=(self.rotation_args,), daemon=True).start()
        try:
            venv_python = HERE / ".venv" / "Scripts" / "python.exe"
            if venv_python.exists():
                cmd = [str(venv_python), "-u", str(HERE / "botctl.py")] + args
            else:                                  # first run: bots.cmd makes the venv (quotes: cmd /c strips the outer pair)
                cmd = f'cmd /c ""{HERE / "bots.cmd"}" {subprocess.list2cmdline(args)}"'
            p = subprocess.Popen(cmd, cwd=str(HERE), env=env,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace",
                                 creationflags=NO_WINDOW)
            self.bots_proc = p
            for line in p.stdout:
                if self.cancel:
                    break
                self.say(line)
                # With a single bot this process is the host itself; its "waiting for N player(s)" line says
                # the lobby is up. With several, this process only starts them and exits (below).
                if not joined and not self.cancel and "waiting for" in line and "player" in line and "waiting for the host" not in line:
                    joined = True
                    if self.join_me:
                        self.say("the game is hosted; joining it...")
                        threading.Thread(target=self.join_and_watch, daemon=True).start()
                    else:
                        self.hosted_no_join()
            if self.cancel:
                try:
                    p.kill()
                except OSError:
                    pass
                self.ready()
                return
            code = p.wait()
        except OSError as e:
            self.say(f"could not start the bots: {e}")
            self.ready()
            return
        if self.cancel:
            self.ready()
            return
        if joined:
            return
        if code != 0:
            self.say(f"the bots did not start (code {code}); not joining")
            self.ready()
            return
        if not getattr(self, "join_me", True):
            self.hosted_no_join()
            return
        self.say("the bots are in and the game is hosted; joining it...")
        self.join_and_watch()

    def hosted_no_join(self):
        """'I play too' is unticked: the bots play on their own; nothing ends the game when you leave."""
        self.say("the game is hosted; your own game isn't started ('I play too' is off). Join it yourself from the "
                 "game's LAN menu if you like; 'Close all game windows' ends it.")
        self.ready()

    def join_and_watch(self):
        try:
            self._join_and_watch()
        finally:
            self.ready()

    def _join_and_watch(self):
        if self.cancel:
            return
        """Start your own game (your normal profile), which joins the LAN game on this PC. When you leave, i.e.
        when no copy of the game without -userpath (the bots' mark) is left, end every OutlawsAHOM.exe."""
        if not GAME_EXE.exists():
            self.say(f"OutlawsAHOM.exe not found: {GAME_EXE}")
            return
        char = getattr(self, "play_char", None)
        try:
            game = subprocess.Popen(join_command(char, getattr(self, "screen_value", None), getattr(self, "play_horde", False)),
                                    cwd=str(GAME_DIR))
        except OSError as e:
            self.say(f"could not start your game: {e}")
            return
        if char and (HERE / "autojoin.py").exists():            # Survival: the Survivors team is picked for you, so nobody joins the Horde by mistake
            venv_python = HERE / ".venv" / "Scripts" / "python.exe"
            py = str(venv_python) if venv_python.exists() else sys.executable
            try:
                subprocess.Popen([py, "-u", str(HERE / "autojoin.py"), str(game.pid), "red", str(HERE / "horde_logs" / "autojoin_log.txt")],
                                 cwd=str(HERE), creationflags=NO_WINDOW)
                self.say(f"your game is starting as {char} and joins the Survivors team by itself")
            except OSError:
                self.say("your game is starting and joins the LAN game (pick your team in the lobby)")
        else:
            self.say("your game is starting and joins the LAN game (pick your team in the lobby)")
        seen, gone = False, 0
        for _ in range(60 * 60 * 12):                          # up to 12 hours, a look every 2 seconds
            time.sleep(2)
            if self.cancel:
                return
            mine = own_game_pids()
            if mine is None:
                continue                                        # couldn't ask Windows; look again
            if mine:
                seen, gone = True, 0
                self.launching = False             # your game is up: loading is over
            else:
                gone += 1
            if seen and gone >= 2:                              # gone for 4 seconds
                if getattr(self, "zerotier", False):
                    self.say("you left the game; it stays up for your friends (Close all game windows ends it)")
                    return
                self.say("you left the game: closing everything")
                self.kill_all()
                return
            if not seen and gone >= 60:                         # never showed up in two minutes
                self.say("your game never showed up; leaving the bots running")
                return

    def kill_all(self):
        """Close the bots' consoles (and the botctl programs in them), then end every OutlawsAHOM.exe. Two passes, a
        second apart, so a console or game copy that was just being started doesn't escape."""
        self.archive_bot_logs()               # keep this game's bot logs (botreports\\) before the next game overwrites them
        ps = ("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'botctl\\.py|horde\\.py|lms\\.py|rotation\\.py' } | "
              "ForEach-Object { taskkill /PID $_.ProcessId /T /F | Out-Null }")
        out = ""
        for k in range(2):
            try:
                subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                               timeout=60, creationflags=NO_WINDOW)
            except (OSError, subprocess.SubprocessError):
                pass
            r = subprocess.run(["taskkill", "/IM", "OutlawsAHOM.exe", "/F"], capture_output=True, text=True,
                               creationflags=NO_WINDOW)
            out = (r.stdout or r.stderr).strip() or "done"
            if k == 0:
                time.sleep(1)
        self.say("bot consoles closed; " + out)
        self.restore_team_colors()

    def restore_team_colors(self):
        """Survival installs its Survivors/Horde colors in Common.kpf; put the normal red/blue back (no-op when not installed)."""
        if not (HERE / "teamcolors.py").exists():
            return
        venv_python = HERE / ".venv" / "Scripts" / "python.exe"
        py = str(venv_python) if venv_python.exists() else sys.executable
        try:
            time.sleep(2)
            subprocess.run([py, str(HERE / "teamcolors.py"), "off", "--wait"], cwd=str(HERE), capture_output=True, timeout=120,
                           creationflags=NO_WINDOW)
        except (OSError, subprocess.SubprocessError):
            pass
        if (HERE / "zombieskins.py").exists():           # the zombie skins go too (waits for the game to close if needed)
            try:
                subprocess.Popen([py, str(HERE / "zombieskins.py"), "off", "--wait"], cwd=str(HERE), creationflags=NO_WINDOW)
            except OSError:
                pass

    def clear_bot_logs(self):
        """Start of a run: delete every folder in botreports\\ and every log in botlogs\\, so reports and bug
        reports only hold this run's bots."""
        try:
            import shutil
            for d in (HERE / "botreports").glob("*"):
                if d.is_dir():
                    shutil.rmtree(d, ignore_errors=True)
            for f in (HERE / "botlogs").glob("*.log"):
                try:
                    f.unlink()
                except OSError:
                    pass
        except Exception as e:
            self.say(f"could not clear the old bot logs: {e}")

    def archive_bot_logs(self):
        """Copy every bot's log from botlogs\\ into botreports\\<date>_<map>\\ (testing aid; see botreport.py)."""
        try:
            import botreport
            out, self.report_sig = botreport.archive(HERE / "botlogs", HERE / "botreports",
                                                    list(getattr(self, "recent", []))[-200:],
                                                    getattr(self, "report_sig", None))
            if out is not None:
                self.say(f"bot logs saved: botreports\\{out.name}")
        except Exception as e:
            self.say(f"could not save the bot logs: {e}")

    def kill(self):
        """Close all game windows. While a game is loading this is immediate (no question): it stops the bots from
        joining, closes the host and runs taskkill /IM OutlawsAHOM.exe /F."""
        if getattr(self, "launching", False):
            self.cancel = True
            self.say("stopping: no more bots will join; closing the host and every game copy...")
            def work():
                self.kill_all()
                self.say("stopped")
                self.ready()
            threading.Thread(target=work, daemon=True).start()
            return
        if messagebox.askyesno("Close games", "End every OutlawsAHOM.exe, the bots' and yours?"):
            threading.Thread(target=self.kill_all, daemon=True).start()


if __name__ == "__main__":
    App().mainloop()
