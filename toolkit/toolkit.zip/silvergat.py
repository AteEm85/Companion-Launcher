"""Gold Gatling gun for the Juggernaut game. The game draws the ground Gatling from its HD sprite GGATGUN.SPX (olremaster1.lab,
8 directions); silver\\GGATGUN.SPX is the same file recoloured gold (barrel and tripod); silver\\IGATGUN.SPX is the gun in your hands, gold too. It is packed into one archive of our own
(modlab.py, olremaster<N>.lab, which the game loads on top of its own files) like the zombie skins, and removed again by off().
Only one Gatling is left on the map in that game (darkitems.patch_juggernaut), so recolouring the whole sprite is enough.
  python silvergat.py on | off"""
import os, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
GAME = HERE.parent
sys.path.insert(0, str(HERE))
OUT = HERE / "silver"


JMARK = b"OUTLAWS-JUGGERNAUT-GOLD"      # our own trailer: zombieskins.py / modlab.find_ours() don't know it, so their cleanup leaves the archive alone


def _mine():
    out = []
    try:
        for p in GAME.iterdir():
            n = p.name.lower()
            if n.startswith("olremaster") and n.endswith(".lab") and n[10:-4].isdigit():
                with open(p, "rb") as f:
                    f.seek(-len(JMARK), 2)
                    if f.read() == JMARK:
                        out.append(p)
    except OSError:
        pass
    return out


def _note(text):
    try:
        import time
        (HERE / "state").mkdir(exist_ok=True)
        with open(HERE / "state" / "jug_setup.txt", "a") as f:
            f.write(time.strftime("%H:%M:%S ") + text + "\n")
    except OSError:
        pass


def on(map_key="hargrove"):
    import modlab
    off()
    files = [(n, OUT / n) for n in ("GGATGUN.SPX", "IGATGUN.SPX")]      # on the ground, and in the Juggernaut's hands
    for n, p in files:
        if not p.exists():
            raise RuntimeError(f"silver\\{n} is missing")
    path = modlab.build(str(GAME), [(n, str(p)) for n, p in files])
    with open(path, "rb") as f:
        data = f.read()
    if data.endswith(modlab.MARK):
        data = data[:-len(modlab.MARK)] + JMARK
    with open(path, "wb") as f:
        f.write(data)
    _note(f"archive {os.path.basename(path)} written for {map_key}")
    return True


def off():
    ok = True
    for p in _mine():
        try:
            p.unlink()
        except OSError:
            ok = False
    return ok


if __name__ == "__main__":
    c = sys.argv[1] if len(sys.argv) > 1 else "on"
    if c == "on": print(on())
    elif c == "off": print(off())
