@echo off
rem Christmas Horde test on Buckshotville (before the app has the Christmas option): you join the LAN game yourself on the Survivors.
rem First every game window is closed and anything left over from an earlier test is taken out.
rem Add --ramp 10 to the horde.py line to fake a kill every 10 s and see Santa arrive sooner.
cd /d "%~dp0"
echo Closing any open game windows...
taskkill /IM OutlawsAHOM.exe /F >nul 2>&1
timeout /t 3 /nobreak >nul
.venv\Scripts\python.exe companionhost.py --cleanup
.venv\Scripts\python.exe -u horde.py --map civpow2 --christmas --users 1
pause
