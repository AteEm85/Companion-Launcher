"""Navigation over an Outlaws level's sector graph (from its LVT file).

Two sectors connect through a wall whose ADJOIN points at the other one ("portal"). A portal can be walked
through when the opening is wide and tall enough for a player, and the floor on the far side is not too high to
step (or jump) up, nor too far down. Routes are found with A* over the portals we enter sectors by (a sector can
be entered in more than one place), then walked waypoint by waypoint.

Inside a sector we don't just walk straight from portal to portal: big outdoor sectors wrap round buildings,
rooms hold tables and posts. A straight line is checked by marching it through the sector and on through
"open" portals (flat, full height, no door: the seams of a floor split into patches); anything else it meets
blocks it, and it must pass jutting corners at PLAYER_RADIUS. Where it's blocked, the way goes round `corner`
points set just off each jutting corner (found across open portals, so a post between two stair steps counts).

Doors come from the level's .INF: sector items with an ELEVATOR class that opens on a nudge (EVENT_MASK 16/32,
or a nudge trigger on the door's own walls; no KEY). Two shapes:
- Panels (MORPH_SPIN/MORPH_MOVE): a thin sector standing in a doorway that swings or slides. The geometry
  around it is open, so routes go straight through; a route segment crossing a panel's closed position
  carries `door` (the panel centre) on its waypoint, and the brain presses E there when it stalls.
- Doorway sectors (MOVE_CEILING, DOOR, ...): the passage itself moves. Edges use the open height, and the
  waypoint into one carries `door`.
Panels that a nudge doesn't open (locked, or worked by a switch) still let routes through, as before, without
`door`. Unnamed thin slabs with sector flag SLAB_DOOR standing in a doorway are taken for doors too (unverified).
Walls flagged IMPASSABLE (0x800: arena boundaries, fences, bars, glass) are not crossed, except breakable glass
(SHATTER 0x4000), which costs extra and marks its waypoint `window` so the brain can shoot it out first.
Low openings above a ledge (open windows with a sill) need a crouch-jump: their waypoint carries
`crouch_jump`, and the brain crouches before jumping and stays crouched through it.
Sloped ceilings (SLOPEDCEILING, the space under a ramp or a lean-to roof) are followed: a portal is only used
over the stretch that's tall enough, a sector is only crossed where the line between its portals has room,
and wander spots under the low end of a ramp are skipped.

Limits:
- Lifts and other moving floors are treated as the static geometry in the file. Whether a door is open
  isn't known: pressing E on an open one closes it, so the brain only nudges when stalled in front of one.
- Corner points keep CORNER_CLEAR off the corner itself, but a line between two of them can still pass a
  straight wall closer than PLAYER_RADIUS; the game slides us along it.
- The first routes on a big map fill the portal-to-portal cache (up to about a second, once).
- Damage floors aren't interpreted yet.

Water (Orleans' river): the water itself is sectors with flag WATER, layer -1, floor at the river bed. Where it
opens to the air, VADJOIN links it with the sector above, whose floor is the water's surface ("splash" floor
sound); under docks the water has a solid ceiling instead. The graph treats a surface sector as floor at the
surface (so routes can swim across, at WATER_COST) and has no way up out of the water itself: the brain routes
from the surface above it (air_point) and does the swimming.
"""
import heapq
import itertools
import math
import os
from dataclasses import dataclass

import lvt

PLAYER_RADIUS = 1.5
PLAYER_HEIGHT = 5.6               # standing clearance needed (actor height is 5.5)
CROUCH_HEIGHT = 3.0               # clearance when crouched: HEIGHT / CROUCH_DIV is 3.0-4.5 by character
                                  # (the character data's CROUCH_DIV). Items lie under 3-high tables on hargrove.
                                  # The default; Level takes the bot's own crouched height.
STEP_UP = 2.0                     # highest step walked up without jumping (estimate, to be measured)
JUMP_UP = 4.5                     # highest ledge reachable with a jump (estimate; crates are 4.13)
CROUCH_STEP_UP = 1.0              # a low opening above a ledge higher than this gets a crouch-jump (a window
                                  # sill); lower ones are stepped up crouched
CROUCH_JUMP_UP = 4.5              # highest sill under a low opening reachable with a crouch-jump
                                  # (estimate, to be measured)
MAX_DROP = 16.0                   # largest drop we're willing to take (falling hurts)
MAP_JUMP_UP = {"billhmre": 9.0}   # maps built from 8-high blocks and ledges (Bill's Homestead Remastered: the blocks up to the roofs
MAP_MAX_DROP = {"billhmre": 26.0}  # and the 24-high ring ledge): a longer jump up, and a drop off the ledge (user: it won't kill them
LOW_HP = 5.0                      # unless they are already low) ...
LOW_HP_DROP = 10.0                # ... so at or below this health (of 10) a bot takes no drop higher than this
DROP_COST = 0.4                   # route cost per unit dropped beyond STEP_UP, so we only jump down to save a walk
PORTAL_INSET = 0.5                # aim this far inside a portal from its ends
PORTAL_SAMPLES = 16               # points checked along a portal for headroom (sloped ceilings vary along it)
CORNER_CLEAR = 3.0                    # (handover step 4: 3 off corners; was PLAYER_RADIUS + 0.6)    # how far a walking point around a corner keeps off both of its walls
START_NEAR = 1.0                  # corners this close to where we stand don't block lines from it
GOAL_NEAR = 2.0                   # ... to the goal (items lie in corners)
PORTAL_NEAR = 1.0                 # ... to a portal midpoint; a portal's own two ends never block lines to it
WAYPOINT_NEAR = 3.5               # ... to a waypoint whose portal ends we don't know (clear_line)
POST_BERTH = 3.2                  # in an indoor room with posts along its walls, keep this far off every post (the
POST_DENSE = 4                    # middle of the room: posts catch bots); a room counts with this many jutting corners
POST_ROOM_HEIGHT = 20.0           # ... and a ceiling no higher than this (outdoor sectors have 32+)
CORNER_SCALES = (1.0, 0.7, 0.45)  # corner offsets tried, tightest last (narrow corridors, door frames)
NO_INNER_COST = 100.0             # extra cost when no way round is found from where we stand (straight line; handover: 100)
DROP_TRAP_CHECK = False            # off: it removed drops on maps that were tuned by hand, and didn't fix The Dip pocket
HEIGHT_COST = 0.5                 # route cost per unit of height change across a portal (handover step 3)
MIN_CROUCH_WIDTH = 4.0            # crouch gaps narrower than this (between table legs) are skipped: a
                                  # crouched player is 3 wide and rarely lines up exactly
NARROW = 6.0                      # openings narrower than this cost extra and get a straight-on approach
NARROW_COST = 5.0                 # route cost per unit of width below NARROW
APPROACH = 2.5                    # how far in front of a narrow opening to line up
BEYOND = 1.0                      # a portal waypoint's `beyond` point lies this far past it
SLOPE_UNITS = 16384.0             # SLOPEDFLOOR angle units per full turn (assumed, like headings)
IMPASSABLE = 0x800                # wall flag: can't walk through (every hargrove arena-boundary wall has it)
SHATTER = 0x4000                  # wall flag: breakable glass (the *WIN.ATX window textures)
WINDOW_COST = 40.0                # extra route cost through a window that has to be shot out first
AVOID_COST = 400.0                # extra route cost through a portal the brain gave up on (see Brain.give_up)
NUDGE_EVENTS = 16 | 32            # INF EVENT_MASK bits: nudged from the front / from inside
SLAB_DOOR = 0x100                 # sector flag on unnamed door slabs (hideout, ranch, wharf, mill); the doorway
                                  # behind has 0x200. Meaning inferred from the geometry, not verified in game
WATER = 0x80                      # sector flag: under water (Orleans' river; PALETTE uwater, GRAVITY -10)
# Swimming that isn't wanted (no item in the water, no one to flee): a route takes the water only when the way
# round on land is longer than this. The river splits Orleans in two, so a hard ban (BOT_STRICT_WATER=1) strands
# bots on one bank or down on the docks.
NO_SWIM_COST = WATER_COST_DEFAULT = 10.0   # crossing water to get somewhere is fine: no extra penalty by default
STRICT_WATER = os.environ.get("BOT_STRICT_WATER") == "1"
WATER_COST = 10.0                 # extra route cost for swimming onto open water: slow, no guns, drowning.
                                  # Kept small: at 60 the bots stopped going in at all
WATER_CLIMB = 5.5                 # highest ledge we jump out onto from the water's surface (the quays are 5 up;
                                  # the user says jumping out works, the height is a guess)
# Climbing out of the water onto a ledge (a jump edge: Orleans' quays are 5 up) is a hard climb; where the river has
# stairs or low banks routes swim on to those instead unless they are very far:
HIGH_EXIT_COST = 400.0            # routes swim on to a low ledge (1 up) instead unless it is very far
SURFACE_MARGIN = 1.5              # feet this far above a water surface still count as on the water (bobbing,
                                  # a hop)
PANEL_DOORS = {"MORPH_SPIN1", "MORPH_SPIN2", "MORPH_MOVE1", "MORPH_MOVE2"}
DOORWAY_DOORS = {"MOVE_CEILING", "DOOR", "DOOR_INV", "DOOR_MID"}


@dataclass
class Edge:
    to: int                       # sector index on the other side
    x: float                      # portal midpoint
    z: float
    width: float
    jump: bool                    # needs a jump to get up
    crouch: bool                  # only passable crouched
    crouch_jump: bool = False     # a low opening above a ledge (a window): crouch first, then jump
    window: bool = False          # through breakable glass
    mid_y: float = 0.0            # middle of the opening's height (where to shoot a window)
    door: tuple = None            # (x, z) of a doorway door we walk into
    approach: tuple = None        # (x, z) in front of a narrow opening, to go through it straight on
    ends: tuple = ()              # ((x, z), (x, z)): the wall's two ends (the door frame)
    drop: float = 0.0             # how far the floor drops on the far side
    beyond: tuple = None          # (x, z) a step past the portal, inside the sector it leads to
    free: tuple = ()              # corners let off for lines to or from the portal point (see Level._visible)
    free_target: tuple = ()       # the same for the point we head for: the line-up point if there is one
    key: tuple = ()               # (from sector, to sector, x, z): names the portal for the brain to avoid
    inner: tuple = ()             # the corners between the walls of an opening made of several (Level._add_runs)
    leap: tuple = None            # (x, z): crouch there, then jump and move on (a hole in a roof, see LEAPS)
    gap: tuple = None             # (x, z): run up and jump from here across a gap (a window to a ledge, see GAPS)
    gap_y: float = None           # the floor height at that spot


# Orleans' west building: the stairs up to its roof (and the items up there) are reachable only from the pool inside it
# (water sector 89 at its surface, 90 below it), and the pool only by diving under the building from the open river
# (the dock water, sector 140, has a roof 3 below the surface). `zone_from` is the first stair sector, `exit` a spot
# on it by the pool's edge, `mouth` a spot on the open river by the dock's south entrance, `inside` a spot in the pool.
POOLS = {"orleans": {"zone_from": 100, "surface": 89, "exit": (-99.0, 87.0), "mouth": (-99.0, 130.0),
                     "inside": (-99.0, 92.0), "south": (-99.0, 108.0), "water": (89, 90, 99)}}

# Jumps up through a hole in a roof that the sector data can't express (10 up). Orleans' north building: the hole is
# sector 76 in the attic; the bot goes under its middle, crouches, jumps and moves on to the roof south of it (sector
# 121). (hole sector, roof sector, landing (x, z), spot under the hole (x, z))
HIGH_JUMPS = {"lilbatl": [(139, 74), (74, 140)]}      # (sector, sector): a jump up this far (user: from Bunkers' big crate, 8 high, onto the
HIGH_JUMP_UP = 8.5                        # ledge, 7 above it, is one bots can make) that JUMP_UP alone would rule out
LEAPS = {"orleans": [(76, 121, (-18.5, 314.0), (-18.5, 320.5))],
         # Hargrove's badge shelf (sector 29, 12.13 up): from the table beside it (sector 32, 4.13 up) crouch under
         # nothing, jump and move on, landing on the shelf (user). Spot at the table's east corner.
         "hargrove": [(32, 29, (422.0, 436.4), (416.6, 434.3))]}

# Running jumps out of a window across to a ledge, by level: (window sector, ledge sector, landing (x, z), spot at
# the sill (x, z)). Dry Gulch: the second-floor window on the west wall of the west building (sector 40, 13.25 up)
# to the ledge with the badge (sector 178, 10 up) (user).
GAPS = {"drygulch": [(40, 178, (39.0, 421.0), (56.7, 421.0))],
        # 5points: out of the east window on the second floor (sector 156, the one nearest the door wall) onto the
        # crates outside (158; 160 and 159 below it, then the ground).
        "5points": [(156, 158, (-1.5, -254.0), (-5.4, -253.0))],
        # Bill's Homestead Remastered (user): the railing round the west building (sector 12, 16.5 up) to the lower
        # north ledge (79, 16) and up onto the north roof (15, 25); from the roof's corner out to the upper ledge
        # (132, 24). On the east side the stair top (80, 18) out to the lower east ledge (78, 16); 78 and 79
        # meet the upper ledge (132) along their edges.
        "billhmre": [(12, 79, (-52.0, 38.5), (-46.5, 18.5)), (12, 15, (-16.0, 18.5), (-19.5, 18.5)),
                     (16, 132, (29.4, 39.0), (17.0, 23.0)), (80, 78, (90.6, -129.7), (81.0, -117.0))]}
# Edges that only work one way. 5points: the door of the room at the south end shuts behind you and the inside has
# no handle (user), so bots go in through it but leave by the second-floor window (GAPS).
ONE_WAY = {"5points": [(24, 25)]}

# High ground bots prefer when they wander or pick a camp (floor height at or above this): Thud Tower's raised walkways,
# which look out over most of the map. Wandering picks them 85% of the time.
HIGH_GROUND = {"thudtowr": 20.0}
HIGH_WANDER = 0.85

# Sectors bots never route into, by level (found with pathcheck.py). Sanctuary: the pocket under the bar counter
# (sector 126, 3.25 high) is a crouch gap on paper, but bots kept getting stuck there; the bar top stays jumpable.
# Also Sanctuary's cellar (144, 119, 108 and the outdoor ramp 120): getting out of it means an 8-unit jump out of a hole
# or a crouch up a ramp, and bots gave up there, so they don't go in.
CELLAR = {"town_2p": {144, 119, 108, 120}}        # bots down here can't route out: brain.cellar_escape
NO_GO = {"town_2p": {126} | CELLAR["town_2p"],
         "lilbatl": {46},      # Bunkers: the small crate (user: skip it, jump from the ground straight onto the big one)
         # Wilderness: the railing round the stairwell down from the west platform (82 its top, 83 the gap under it,
         # 69 a 0.25-wide strip at the rim). Routes down jumped onto it and dropped 11 into the stairwell, but bots
         # ended up perched on the rim (y 13 over step 31) heading for the cellar under them (pathcheck.py). Down
         # the stairs instead (16, 49, 29).
         # Also the two elixir closets (52 in the east building by the steps, 74 in the west one): their doors swing
         # out into the room, hinged at the end away from the side wall (user), and bots coming from that end
         # walked into the open door.
         "wilderns": {69, 82, 83, 52, 74}}
# Sectors that look like a room with posts (POST_DENSE jutting corners under POST_ROOM_HEIGHT) but aren't, by level.
# Wilderness: the winding passage (150, about 6 wide) from the open ground south of it up to 126, the east side's only
# way back west: no line through it kept POST_BERTH off its bends, so no route crossed it. Also the gap under the table
# with the Gatling (71, 5 wide, its legs the "posts"): routes ran straight past a leg instead of round it.
NOT_POST_ROOMS = {"wilderns": {150, 71}}


class Level:
    def __init__(self, sectors, inf=(), crouch_height=CROUCH_HEIGHT, name=None):
        self.no_go = set(NO_GO.get((name or "").lower(), ()))
        self.high_min = HIGH_GROUND.get((name or "").lower())
        self.cellar = set(CELLAR.get((name or "").lower(), ()))
        self.not_post_rooms = set(NOT_POST_ROOMS.get((name or "").lower(), ()))
        self.high_jumps = set(HIGH_JUMPS.get((name or "").lower(), ()))
        self.jump_up = MAP_JUMP_UP.get((name or "").lower(), JUMP_UP)
        self.max_drop = MAP_MAX_DROP.get((name or "").lower(), MAX_DROP)
        self.sectors = sectors
        self.crouch_height = crouch_height
        self._slopes = {}         # sector index -> (hinge x, z, unit normal nx, nz, slope tan)
        self._ceil_slopes = {}    # the same for sloped ceilings (the space under a ramp or roof)
        for s in sectors:
            if s.floor_slope:
                self._slopes[s.index] = self._slope(s, s.floor_slope)
            if s.ceiling_slope:
                self._ceil_slopes[s.index] = self._slope(s, s.ceiling_slope)
        self._outlines = {}       # sector index -> its walls, jutting corners and corner points (see _outline)
        self._vwalls = {}         # sector index -> walls meeting at each vertex (see _vertex_walls)
        self._shapes = {}         # sector index -> _outline plus which corners see each other (see _shape)
        self._legs = {}           # (id(edge in), id(edge out)) -> the way across a sector between them
        self._reach_cache = {}    # (id(edge), at its target) -> corners seen from its portal point
        self.panels = []          # door panels: {x, z (centre), a, b (closed-position axis ends), sector}
        self.shut_panels = set()  # sector indices of door panels that a nudge doesn't open
        self.doorways = {}        # sector index -> (x, z) for doors the passage itself belongs to
        self.open_ceiling = {}    # sector index -> ceiling when its door is open
        self._load_doors(inf)
        self._load_slab_doors()
        # Water sectors, and the sectors whose floor is the surface of one (VADJOIN from either side).
        self.water = [s.index for s in sectors if s.flags & WATER and s.walls]
        self.water_surfaces = {sectors[i].vadjoin for i in self.water if 0 <= sectors[i].vadjoin < len(sectors)}
        self._air_gates = None    # (x1, z1, x2, z2) walls leading from roofed water into open water
        self.edges = {s.index: [] for s in sectors}
        # (sector, wall index) of portals we walk straight through without noticing: flat, full height, no
        # door. Big floors are often split into patches like that, and lines of sight run on through them.
        self._open = set()
        door_sectors = set(self.doorways) | {p["sector"] for p in self.panels}
        made = set()              # (sector, wall index, sector on the other side) that got an edge
        for s in sectors:
            for wi, w in enumerate(s.walls):
                for other in (w.adjoin, w.dadjoin):
                    if 0 <= other < len(sectors):
                        e = self._edge(s, w, sectors[other])
                        if e:
                            self.edges[s.index].append(e)
                            made.add((s.index, wi, other))
                            if (other == w.adjoin and w.dadjoin < 0 and not (e.jump or e.crouch or e.window)
                                    and other not in door_sectors and s.index not in door_sectors
                                    and abs(e.width - math.dist(*e.ends)) < 0.01
                                    and all(abs(self.floor_at(other, *pt) - self.floor_at(s.index, *pt)) <= STEP_UP
                                            for pt in e.ends)):
                                self._open.add((s.index, wi))
        self._add_runs(made)
        for es in self.edges.values():
            for e in es:
                e.free = self._portal_free(e, e.x, e.z)
                e.free_target = self._portal_free(e, *(e.approach or (e.x, e.z)))
        for a, b, land, hole in LEAPS.get(name, ()):
            if a < len(sectors) and b < len(sectors):
                e = Edge(b, land[0], land[1], 4.0, jump=True, crouch=True, approach=hole, leap=hole,
                         key=(a, b, land[0], land[1]))
                e.free, e.free_target = self._portal_free(e, e.x, e.z), self._portal_free(e, *hole)
                self.edges[a].append(e)
        for a, b, land, sill in GAPS.get(name, ()):
            if a < len(sectors) and b < len(sectors):
                e = Edge(b, land[0], land[1], 4.0, jump=True, crouch=False, approach=sill, gap=sill,
                         gap_y=self.floor_at(a, sill[0], sill[1]), key=(a, b, land[0], land[1]))
                e.free, e.free_target = self._portal_free(e, e.x, e.z), self._portal_free(e, *sill)
                self.edges[a].append(e)
        for a, b in ONE_WAY.get(name, ()):
            if a < len(sectors):
                self.edges[a] = [e for e in self.edges[a] if e.to != b]
        self._panel_sectors = {p["sector"] for p in self.panels} | self.shut_panels
        self._drop_traps()
        self.main = self._keep_in_main()
        self.pool = None
        if name in POOLS and POOLS[name]["zone_from"] < len(sectors):
            zone, todo = {POOLS[name]["zone_from"]}, [POOLS[name]["zone_from"]]
            while todo:
                for e in self.edges[todo.pop()]:
                    if e.to not in zone and not sectors[e.to].flags & WATER:
                        zone.add(e.to)
                        todo.append(e.to)
            self.pool = dict(POOLS[name], zone=zone)
        # A door panel swings or slides out of the way (the brain presses E), so lines run through it too.
        self._panel_sectors = {p["sector"] for p in self.panels} | self.shut_panels
        for i in self._panel_sectors:
            for wi, w in enumerate(sectors[i].walls):
                if 0 <= w.adjoin < len(sectors):
                    self._open.add((i, wi))
                    for wj, w2 in enumerate(sectors[w.adjoin].walls):
                        if w2.adjoin == i:
                            self._open.add((w.adjoin, wj))

    def _load_doors(self, inf):
        by_name = {}
        for s in self.sectors:
            if s.name:
                by_name.setdefault(s.name.upper(), []).append(s)
        for e in inf:
            # A door with no nudge bits of its own still opens on E when a trigger on its walls moves it
            # (lvt.InfElevator.nudge_line; from one side only, maybe: the brain gives up after DOOR_TRIES).
            if e.key or (e.event_mask is not None and not e.event_mask & NUDGE_EVENTS and not e.nudge_line):
                if e.kind in PANEL_DOORS:
                    # Locked, or opened by something else (a switch): no use pressing E, but routes still go
                    # through its doorway, as they always have.
                    self.shut_panels |= {s.index for s in by_name.get(e.sector, [])}
                continue
            for s in by_name.get(e.sector, []):
                if not s.vertices:
                    continue
                cx = sum(v[0] for v in s.vertices) / len(s.vertices)
                cz = sum(v[1] for v in s.vertices) / len(s.vertices)
                if e.kind in PANEL_DOORS:
                    # The panel's long axis: the two vertices furthest apart.
                    a, b = max(((p, q) for p in s.vertices for q in s.vertices),
                               key=lambda pq: (pq[0][0] - pq[1][0]) ** 2 + (pq[0][1] - pq[1][1]) ** 2)
                    self.panels.append({"x": cx, "z": cz, "a": a, "b": b, "sector": s.index})
                elif e.kind in DOORWAY_DOORS:
                    self.doorways[s.index] = (cx, cz)
                    neighbours = [self.sectors[w.adjoin].ceiling for w in s.walls
                                  if 0 <= w.adjoin < len(self.sectors)]
                    if e.kind == "MOVE_CEILING" and e.stops:
                        top = max(e.stops)
                    else:
                        top = min(neighbours) if neighbours else s.ceiling
                    self.open_ceiling[s.index] = max(s.ceiling, top)

    def _load_slab_doors(self):
        """Unnamed doors: a thin slab sector (sector flag SLAB_DOOR) standing in a doorway that, closed, fills
        it, with the doorway passage right behind it. No INF drives them, so presumably the engine opens them
        from the flag (unverified). Treated like panels: routes may go through, and the brain presses E when
        it stalls in front of one."""
        known = {p["sector"] for p in self.panels}
        for s in self.sectors:
            if not s.vertices or s.index in known or not s.flags & SLAB_DOOR:
                continue
            xs, zs = [v[0] for v in s.vertices], [v[1] for v in s.vertices]
            if min(max(xs) - min(xs), max(zs) - min(zs)) > 1.0:
                continue
            below = [self.sectors[w.adjoin].floor for w in s.walls if 0 <= w.adjoin < len(self.sectors)]
            if not below:
                continue
            # Closed, it fills the doorway: its floor raised to the door's top (hideout), or its ceiling
            # down near the floor (wharf).
            if s.floor - min(below) < PLAYER_HEIGHT and s.ceiling - s.floor >= self.crouch_height:
                continue
            a, b = max(((p, q) for p in s.vertices for q in s.vertices),
                       key=lambda pq: (pq[0][0] - pq[1][0]) ** 2 + (pq[0][1] - pq[1][1]) ** 2)
            self.panels.append({"x": sum(xs) / len(xs), "z": sum(zs) / len(zs), "a": a, "b": b,
                                "sector": s.index, "slab": True})

    def _add_runs(self, made):
        """An opening built from several short walls in a row (a tunnel mouth, an arch, the side of an
        octagon) has every wall too narrow to pass on its own, so no edge goes through it (Sanctuary's crawl
        tunnel from the jail cellar out to the well). Where none of the walls of such a run got an edge to the
        sector beyond, try the run as one opening: its width is the straight line between its ends."""
        for s in self.sectors:
            prev = {w.v2: wi for wi, w in enumerate(s.walls)}
            nxt = {w.v1: wi for wi, w in enumerate(s.walls)}

            def same(k, w):
                o = s.walls[k]
                return (o.adjoin, o.dadjoin, o.flags & (IMPASSABLE | SHATTER)) == (w.adjoin, w.dadjoin,
                                                                                  w.flags & (IMPASSABLE | SHATTER))
            done = set()
            for wi, w in enumerate(s.walls):
                if wi in done or w.adjoin < 0:
                    continue
                start, seen = wi, {wi}
                while True:                   # back to the start of the run
                    k = prev.get(s.walls[start].v1)
                    if k is None or k in seen or not same(k, w):
                        break
                    start = k
                    seen.add(k)
                chain = [start]
                while True:
                    k = nxt.get(s.walls[chain[-1]].v2)
                    if k is None or k in chain or not same(k, w):
                        break
                    chain.append(k)
                done |= set(chain)
                if len(chain) < 2:
                    continue
                run = [s.vertices[s.walls[chain[0]].v1]] + [s.vertices[s.walls[k].v2] for k in chain]
                arc = sum(math.dist(p, q) for p, q in zip(run, run[1:]))
                if math.dist(run[0], run[-1]) < 0.5 * arc:
                    continue                  # round a corner or a closed loop, not one opening
                for other in (w.adjoin, w.dadjoin):
                    if 0 <= other < len(self.sectors) and not any((s.index, k, other) in made for k in chain):
                        e = self._edge(s, w, self.sectors[other], run)
                        if e:
                            self.edges[s.index].append(e)

    TRAP_CELLS = 4000                 # grid cells used to look for walled-off floor areas inside one sector

    def _drop_traps(self):
        """Handover step 3 (floor areas inside one sector): a sector can hold several separate floor areas, e.g.
        a pocket walled off by a raised block or stair island. The sector graph can't tell them apart, so a drop
        into a pocket looked fine, but there is no way out of it (The Dip, the corner west of the stairs: the
        way back up is a jump just too high). For each drop onto a sector, flood the floor area where we'd land
        (grid cells at least PLAYER_RADIUS off every solid wall); if no portal is anywhere near it, the drop is
        a trap and its edge is removed."""
        removed = 0
        if not DROP_TRAP_CHECK:
            self.trap_edges_removed = 0
            return
        for a, es in self.edges.items():
            keep = []
            for e in es:
                if e.drop > STEP_UP and not e.jump and self._lands_in_trap(e):
                    removed += 1
                    continue
                keep.append(e)
            self.edges[a] = keep
        self.trap_edges_removed = removed
        # The outlines worked out above were built before the door panels were known (_open is still incomplete):
        # throw them away so they are rebuilt properly on first use.
        self._outlines.clear()
        self._vwalls.clear()
        self._shapes.clear()
        self._legs.clear()
        self._reach_cache.clear()

    def _lands_in_trap(self, e):
        t = e.to
        s = self.sectors[t]
        if not s.vertices or t in self._panel_sectors:
            return False
        xs = [v[0] for v in s.vertices]
        zs = [v[1] for v in s.vertices]
        x0, x1, z0, z1 = min(xs), max(xs), min(zs), max(zs)
        res = max(1.0, math.sqrt(max(1.0, (x1 - x0) * (z1 - z0)) / self.TRAP_CELLS))
        out = self._outline(t)
        segs = out["segs"]
        if not segs:
            return False
        nx, nz = int((x1 - x0) / res) + 2, int((z1 - z0) / res) + 2

        def centre(i, j):
            return x0 + (i + 0.5) * res, z0 + (j + 0.5) * res

        cache = {}

        def walkable(i, j):
            if not (0 <= i < nx and 0 <= j < nz):
                return False
            v = cache.get((i, j))
            if v is None:
                px, pz = centre(i, j)
                v = s.contains(px, pz) and all(point_seg((px, pz), a, b) >= PLAYER_RADIUS for a, b in segs)
                cache[(i, j)] = v
            return v

        seeds = []
        r = int(2.5 / res) + 1
        ci, cj = int((e.x - x0) / res), int((e.z - z0) / res)
        for di in range(-r, r + 1):
            for dj in range(-r, r + 1):
                i, j = ci + di, cj + dj
                if math.hypot(centre(i, j)[0] - e.x, centre(i, j)[1] - e.z) <= 2.5 + res and walkable(i, j):
                    seeds.append((i, j))
        if not seeds:
            return False                              # can't tell: leave the edge alone
        seen = set(seeds)
        stack = list(seeds)
        while stack:
            i, j = stack.pop()
            for di, dj in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (i + di, j + dj)
                if n not in seen and walkable(*n):
                    seen.add(n)
                    stack.append(n)
        # The area has a way out if a portal lies near it: any edge of this sector, or an open (flat) wall.
        reach = res * 1.5 + PLAYER_RADIUS + 1.0
        targets = [(e2.x, e2.z) for e2 in self.edges[t]]
        for wi, w in enumerate(s.walls):
            if (t, wi) in self._open:
                a, b = s.vertices[w.v1], s.vertices[w.v2]
                targets.append(((a[0] + b[0]) / 2, (a[1] + b[1]) / 2))
                targets.append(a)
                targets.append(b)
        cells = [centre(i, j) for i, j in seen]
        for tx, tz in targets:
            if any(abs(cx - tx) <= reach and abs(cz - tz) <= reach and math.hypot(cx - tx, cz - tz) <= reach
                   for cx, cz in cells):
                return False
        return True

    def _panel_sectors_early(self):
        return {p["sector"] for p in self.panels} | self.shut_panels

    def _keep_in_main(self):
        """Drop edges that leave the level's main area for somewhere with no way back: the strip outside an
        arena wall (Sanctuary's south wall top drops to the ground outside), a pit. A bot that falls in there
        is stranded for good. The main area is the largest set of sectors that can all reach each other; edges
        out of other areas are kept, so a bot that is somewhere odd can still find its way. Returns the main
        area's sector indices."""
        comp = strongly_connected(self.edges)
        sizes = {}
        for c in comp.values():
            sizes[c] = sizes.get(c, 0) + 1
        main = max(sizes, key=sizes.get)
        inside = {i for i, c in comp.items() if c == main}
        for i in inside:
            self.edges[i] = [e for e in self.edges[i] if e.to in inside]
        return inside

    def ceiling(self, index):
        return self.open_ceiling.get(index, self.sectors[index].ceiling)

    # -- geometry -------------------------------------------------------------------------------------
    def _slope(self, sector, slope):
        """Floor plane of a sloped sector: hinged on wall `slope[1]` of sector `slope[0]`, rising at
        `slope[2]` (angle units) into this sector. The hinge sits at this sector's FLOOR Y."""
        ref = self.sectors[slope[0]] if 0 <= slope[0] < len(self.sectors) else sector
        w = ref.walls[slope[1]] if 0 <= slope[1] < len(ref.walls) else ref.walls[0]
        (x1, z1), (x2, z2) = ref.vertices[w.v1], ref.vertices[w.v2]
        length = math.hypot(x2 - x1, z2 - z1) or 1.0
        nx, nz = -(z2 - z1) / length, (x2 - x1) / length          # perpendicular to the hinge
        cx = sum(v[0] for v in sector.vertices) / len(sector.vertices)
        cz = sum(v[1] for v in sector.vertices) / len(sector.vertices)
        if (cx - x1) * nx + (cz - z1) * nz < 0:                    # point the normal into the sector
            nx, nz = -nx, -nz
        return x1, z1, nx, nz, math.tan(slope[2] / SLOPE_UNITS * 2 * math.pi)

    def floor_at(self, index, x, z):
        s = self.sectors[index]
        if index in self._slopes:
            hx, hz, nx, nz, t = self._slopes[index]
            return s.floor + ((x - hx) * nx + (z - hz) * nz) * t
        return s.floor

    def ceiling_at(self, index, x, z):
        """Ceiling height at a point. Under a ramp it slopes down to the floor."""
        top = self.ceiling(index)
        if index in self._ceil_slopes:
            hx, hz, nx, nz, t = self._ceil_slopes[index]
            top += ((x - hx) * nx + (z - hz) * nz) * t
        return top

    def headroom(self, index, x, z):
        return self.ceiling_at(index, x, z) - self.floor_at(index, x, z)

    def _opening(self, a, b, x, z):
        """Clear height of the portal between sectors a and b at one point along it."""
        return (min(self.ceiling_at(a, x, z), self.ceiling_at(b, x, z))
                - max(self.floor_at(a, x, z), self.floor_at(b, x, z)))

    def _clear_run(self, a, b, x1, z1, x2, z2, need):
        """The longest stretch (t0, t1) of the portal, as fractions of its length, where the opening is at
        least `need`. Under a sloped ceiling only part of a portal is tall enough."""
        n = PORTAL_SAMPLES
        ok = [self._opening(a, b, x1 + (x2 - x1) * i / n, z1 + (z2 - z1) * i / n) >= need for i in range(n + 1)]
        best, start = None, None
        for i, good in enumerate(ok + [False]):
            if good and start is None:
                start = i
            elif not good and start is not None:
                if best is None or i - 1 - start > best[1] - best[0]:
                    best = (start, i - 1)
                start = None
        return None if best is None else (best[0] / n, best[1] / n)

    def _edge(self, a, wall, b, run=None):
        """The edge through `wall` of sector a into b, or None. With `run` (the points of several walls in a
        row, see _add_runs), through all of them as one opening."""
        window = False
        if self.no_go and (a.index in self.no_go or b.index in self.no_go):
            return None
        if wall.flags & IMPASSABLE:
            if not wall.flags & SHATTER:
                return None
            window = True
        (x1, z1), (x2, z2) = (run[0], run[-1]) if run else (a.vertices[wall.v1], a.vertices[wall.v2])
        length = math.hypot(x2 - x1, z2 - z1)
        if length < 2 * PLAYER_RADIUS:
            return None
        # The part of the portal we fit through: standing if it's wide enough, otherwise crouched.
        crouch = False
        span = self._clear_run(a.index, b.index, x1, z1, x2, z2, PLAYER_HEIGHT)
        if span is None or (span[1] - span[0]) * length < 2 * PLAYER_RADIUS:
            crouch = True
            span = self._clear_run(a.index, b.index, x1, z1, x2, z2, self.crouch_height)
            if span is None or (span[1] - span[0]) * length < max(2 * PLAYER_RADIUS, MIN_CROUCH_WIDTH):
                return None
        width = (span[1] - span[0]) * length
        tm = (span[0] + span[1]) / 2
        mx, mz = x1 + (x2 - x1) * tm, z1 + (z2 - z1) * tm
        if run:
            # Onto the walls themselves: the line between the run's ends may cut across either sector.
            mx, mz = min((closest((mx, mz), p, q) for p, q in zip(run, run[1:])),
                         key=lambda c: math.dist(c, (mx, mz)))
        fa, fb = self.floor_at(a.index, mx, mz), self.floor_at(b.index, mx, mz)
        top = min(self.ceiling_at(a.index, mx, mz), self.ceiling_at(b.index, mx, mz))
        rise = fb - fa
        reach = HIGH_JUMP_UP if (a.index, b.index) in self.high_jumps else self.jump_up
        if rise > (WATER_CLIMB if a.index in self.water_surfaces else reach) or -rise > self.max_drop:
            return None
        crouch_jump = crouch and rise > CROUCH_STEP_UP
        if crouch_jump and rise > CROUCH_JUMP_UP:
            return None
        approach = None
        if width < NARROW or crouch_jump:      # crouch-jumps also go straight on
            # A point straight out from the opening on our side, if it's inside this sector.
            nx, nz = -(z2 - z1) / length, (x2 - x1) / length
            for sign in (1, -1):
                ax, az = mx + sign * nx * APPROACH, mz + sign * nz * APPROACH
                if a.contains(ax, az):
                    approach = (ax, az)
                    break
        return Edge(b.index, mx, mz, width, jump=rise > STEP_UP or crouch_jump, crouch=crouch,
                    crouch_jump=crouch_jump, window=window,
                    mid_y=(top + max(fa, fb)) / 2, door=self.doorways.get(b.index), approach=approach,
                    ends=((x1, z1), (x2, z2)), drop=max(0.0, -rise), beyond=self._beyond(b, mx, mz, x1, z1, x2, z2),
                    key=(a.index, b.index, round(mx, 2), round(mz, 2)), inner=tuple(run[1:-1]) if run else ())

    @staticmethod
    def _beyond(b, mx, mz, x1, z1, x2, z2):
        """A point BEYOND straight across a portal from its midpoint, inside sector b (None if that misses, or if
        it's too close to a solid wall of b to stand on: the brain heads for it and would walk into the wall.
        Wilderness: a 1-deep strip along a building front, whose point lay on the wall between two doors, and the
        gap under a table, whose point lay against a leg)."""
        length = math.hypot(x2 - x1, z2 - z1)
        nx, nz = -(z2 - z1) / length, (x2 - x1) / length
        for sign in (1, -1):
            bx, bz = mx + sign * nx * BEYOND, mz + sign * nz * BEYOND
            if b.contains(bx, bz):
                if any((w.adjoin < 0 or w.flags & IMPASSABLE)
                       and point_seg((bx, bz), b.vertices[w.v1], b.vertices[w.v2]) < PLAYER_RADIUS for w in b.walls):
                    return None
                return bx, bz
        return None

    def locate(self, x, y, z):
        """Sector index containing a point, preferring the floor just below it (stacked sectors)."""
        best, best_gap = None, None
        for s in self.sectors:
            if not s.walls or not s.contains(x, z):
                continue
            gap = y - self.floor_at(s.index, x, z)
            if gap < -1.0 or y > self.ceiling_at(s.index, x, z) + 1.0:
                continue
            if best_gap is None or gap < best_gap:
                best, best_gap = s.index, gap
        if best is None:
            # In no sector: standing where an open door is when closed (a door panel is a hole in the room
            # round it, and the map data only has it closed), or right on a seam. Without a sector there's
            # no route and the brain would stand there for good, so take the nearest one we're level with.
            near = PLAYER_RADIUS
            for s in self.sectors:
                if not s.walls:
                    continue
                gap = y - self.floor_at(s.index, x, z)
                if gap < -1.0 or y > self.ceiling_at(s.index, x, z) + 1.0:
                    continue
                d = min(point_seg((x, z), s.vertices[w.v1], s.vertices[w.v2]) for w in s.walls)
                if d < near:
                    best, near = s.index, d
        return best

    # -- water ----------------------------------------------------------------------------------------
    def water_at(self, x, y, z):
        """The water sector a point is in (below its surface or roof), or None."""
        for i in self.water:
            s = self.sectors[i]
            if s.floor - 1.0 <= y < s.ceiling and s.contains(x, z):
                return i
        return None

    def in_water(self, x, y, z):
        """Feet (y) in the water, or floating or treading on top of it: up to SURFACE_MARGIN above the surface
        of a surface sector."""
        if self.water_at(x, y + 0.3, z) is not None:
            return True
        for i in self.water_surfaces:
            s = self.sectors[i]
            if s.floor - 1.0 <= y <= s.floor + SURFACE_MARGIN and s.contains(x, z):
                return True
        return False

    def air_point(self, x, y, z):
        """Where to come up for air from a point in the water: (x, z, surface y, open), or None out of the
        water. In open water that's straight up (`open` True). Under a roof (water below the docks) it's
        just inside the nearest stretch of open water, at its surface."""
        i = self.water_at(x, y, z)
        if i is None:
            return None
        if self.sectors[i].vadjoin >= 0:
            return x, z, self.sectors[i].ceiling, True
        if self._air_gates is None:
            # The portals between roofed and open water, with the open side's surface.
            self._air_gates = []
            for j in self.water:
                s = self.sectors[j]
                if s.vadjoin < 0:
                    continue
                for w in s.walls:
                    if w.adjoin in self.water and self.sectors[w.adjoin].vadjoin < 0:
                        self._air_gates.append((s.vertices[w.v1], s.vertices[w.v2], s.ceiling, j))
        best = None
        for a, b, top, j in self._air_gates:
            cx, cz = closest((x, z), a, b)
            d = math.hypot(cx - x, cz - z)
            if best is None or d < best[0]:
                best = (d, cx, cz, top, j)
        if best is None:
            return None
        d, cx, cz, top, j = best
        # A couple of units on past the portal, into the open water (when that point is in it).
        if d > 1e-6:
            px, pz = cx + (cx - x) / d * 2.5, cz + (cz - z) / d * 2.5
            if self.sectors[j].contains(px, pz):
                cx, cz = px, pz
        return cx, cz, top, False

    # -- inside a sector -----------------------------------------------------------------------------
    def _outline(self, index):
        """A sector's obstacles, worked out on first use:
        - walls: (x1, z1, x2, z2, min x, max x, min z, max z, open, adjoin) per wall, for _march.
        - segs: the walls we can't just walk through (everything but open portals, see _open).
        - reflex: vertices where something juts into the sector (a building corner in an outdoor sector, a
          post, a table). A convex sector has none.
        - corners: a walking point just off each reflex vertex, CORNER_CLEAR from both of its walls. It may
          lie in an open neighbour."""
        out = self._outlines.get(index)
        if out is not None:
            return out
        s = self.sectors[index]
        if index in self._panel_sectors:
            # A door panel: what stands inside it (the bars of a jail door, Sanctuary's cells) moves with it
            # when it opens, so only its outline counts, and that's all open.
            walls = [(x1, z1, x2, z2, min(x1, x2), max(x1, x2), min(z1, z2), max(z1, z2), True, w.adjoin)
                     for w, ((x1, z1), (x2, z2)) in ((w, (s.vertices[w.v1], s.vertices[w.v2])) for w in s.walls)
                     if 0 <= w.adjoin < len(self.sectors)]
            out = self._outlines[index] = {"walls": walls, "segs": [], "reflex": [], "corners": [], "berth": PLAYER_RADIUS}
            return out
        walls = []
        for wi, w in enumerate(s.walls):
            (x1, z1), (x2, z2) = s.vertices[w.v1], s.vertices[w.v2]
            walls.append((x1, z1, x2, z2, min(x1, x2), max(x1, x2), min(z1, z2), max(z1, z2),
                          (index, wi) in self._open, w.adjoin))
        segs = [(s.vertices[w.v1], s.vertices[w.v2]) for wi, w in enumerate(s.walls) if (index, wi) not in self._open]
        nxt, prv = {}, {}                     # vertex -> (next vertex, wall index), (previous vertex, wall index)
        for wi, w in enumerate(s.walls):
            nxt.setdefault(w.v1, (w.v2, wi))
            prv.setdefault(w.v2, (w.v1, wi))
        neighbours = [self.sectors[w.adjoin] for wi, w in enumerate(s.walls) if (index, wi) in self._open]
        near_segs = segs + [seg for n in neighbours for seg in self._solid_segs(n.index)]
        reflex, corners = [], []
        berth = PLAYER_RADIUS
        if s.ceiling - s.floor <= POST_ROOM_HEIGHT and index not in self.not_post_rooms:
            jut = 0
            for v in nxt:
                if v in prv:
                    f = self._fan(index, s.vertices[v])
                    if f is not None and f[0] > 180.5:
                        jut += 1
            if jut >= POST_DENSE:
                berth = POST_BERTH
        for v in nxt:
            if v not in prv:
                continue
            vx, vz = s.vertices[v]
            fan = self._fan(index, (vx, vz))
            if fan is None:
                continue
            free, e1, e2 = fan
            if free <= 180.5:
                continue                      # nothing juts in here: an inside corner or a straight wall
            # Something juts in, bounded by the walls along e1 and e2; its wedge is the narrower angle between
            # them. The corner point goes the other way, off both walls.
            reflex.append((vx, vz))
            hx, hz = e1[0] + e2[0], e1[1] + e2[1]
            h = math.hypot(hx, hz)
            if h < 1e-3:
                continue
            hx, hz = hx / h, hz / h
            half = math.radians(360.0 - free) / 2
            off = (berth + 0.6) / max(0.35, math.sin(half))
            for scale in CORNER_SCALES:           # closer in where a passage is too tight for the full offset
                cx, cz = vx - hx * off * scale, vz - hz * off * scale
                home = s if s.contains(cx, cz) else next((n for n in neighbours if n.contains(cx, cz)), None)
                if (home is not None and self.headroom(home.index, cx, cz) >= self.crouch_height
                        and all(point_seg((cx, cz), a, b) >= PLAYER_RADIUS * scale for a, b in near_segs)):
                    corners.append((cx, cz))
                    break
        out = self._outlines[index] = {"walls": walls, "segs": segs, "reflex": reflex, "corners": corners, "berth": berth}
        return out

    def _solid_segs(self, index):
        s = self.sectors[index]
        if index in self._panel_sectors:
            return []                         # see _outline
        return [(s.vertices[w.v1], s.vertices[w.v2]) for wi, w in enumerate(s.walls) if (index, wi) not in self._open]

    def _vertex_walls(self, index):
        """{(x, z) rounded: (previous vertex, wall in, next vertex, wall out)} for a sector's vertices."""
        out = self._vwalls.get(index)
        if out is None:
            s = self.sectors[index]
            out = {}
            ins = {}
            for wi, w in enumerate(s.walls):
                ins.setdefault(w.v2, (s.vertices[w.v1], wi))
            for wi, w in enumerate(s.walls):
                if w.v1 in ins:
                    x, z = s.vertices[w.v1]
                    out.setdefault((round(x, 3), round(z, 3)), (ins[w.v1][0], ins[w.v1][1], s.vertices[w.v2], wi))
            self._vwalls[index] = out
        return out

    def _inside_angle(self, index, v, a, b):
        """A sector's own angle (degrees) at vertex v between its walls toward a and b."""
        la, lb = math.hypot(a[0] - v[0], a[1] - v[1]), math.hypot(b[0] - v[0], b[1] - v[1])
        if la < 1e-6 or lb < 1e-6:
            return 180.0
        ua, ub = ((a[0] - v[0]) / la, (a[1] - v[1]) / la), ((b[0] - v[0]) / lb, (b[1] - v[1]) / lb)
        theta = math.degrees(math.acos(max(-1.0, min(1.0, ua[0] * ub[0] + ua[1] * ub[1]))))
        hx, hz = ua[0] + ub[0], ua[1] + ub[1]
        h = math.hypot(hx, hz)
        if h < 1e-3:
            return 180.0
        inside = self.sectors[index].contains(v[0] + hx / h * 0.05, v[1] + hz / h * 0.05)
        return theta if inside else 360.0 - theta

    def _fan(self, index, v):
        """The free angle round vertex v: this sector's own, plus that of the sectors beyond any open portal
        meeting at v, and so on round. Returns (degrees, e1, e2) with e1 / e2 unit vectors along the walls
        that bound it on either side, or None when it's free all the way round."""
        info = self._vertex_walls(index).get((round(v[0], 3), round(v[1], 3)))
        if info is None:
            return None
        a, win, b, wout = info
        total = self._inside_angle(index, v, a, b)
        ends = []
        for wall, other in ((win, a), (wout, b)):
            k, seen = index, {index}
            while True:
                if (k, wall) not in self._open:
                    d = math.hypot(other[0] - v[0], other[1] - v[1]) or 1.0
                    ends.append(((other[0] - v[0]) / d, (other[1] - v[1]) / d))
                    break
                j = self.sectors[k].walls[wall].adjoin
                if j in seen:
                    return None               # round the full circle through open portals
                seen.add(j)
                vj = self._vertex_walls(j).get((round(v[0], 3), round(v[1], 3)))
                if vj is None:
                    d = math.hypot(other[0] - v[0], other[1] - v[1]) or 1.0
                    ends.append(((other[0] - v[0]) / d, (other[1] - v[1]) / d))
                    break
                aj, win_j, bj, wout_j = vj
                total += self._inside_angle(j, v, aj, bj)
                # Carry on through j's other wall at v (not the one shared with k).
                if math.hypot(aj[0] - other[0], aj[1] - other[1]) < 1e-3:
                    k, wall, other = j, wout_j, bj
                else:
                    k, wall, other = j, win_j, aj
        # Up to 360: the end of a thin wall (the side of a ramp, where the foot of it is open).
        return min(total, 360.0), ends[0], ends[1]

    def _shape(self, index):
        """_outline plus `vis`: for each corner, the other corners it can walk straight to, with distances.
        Worked out on first use (the expensive part)."""
        sh = self._shapes.get(index)
        if sh is not None:
            return sh
        sh = dict(self._outline(index), vis=[])
        self._shapes[index] = sh
        corners = sh["corners"]
        for i, c in enumerate(corners):
            sh["vis"].append([(j, math.hypot(d[0] - c[0], d[1] - c[1])) for j, d in enumerate(corners)
                              if j != i and self._visible(index, c, d, (), ())])
        return sh

    def _march(self, index, p, q):
        """The sectors a straight line p->q runs through, starting in sector `index` and going on through open
        portals only; None if it runs into a wall, ledge, table or other portal we can't just walk through."""
        length = math.hypot(q[0] - p[0], q[1] - p[1])
        if length < 0.01:
            return [index]
        s = self.sectors[index]
        step = min(0.05, length / 2)
        sx, sz = p[0] + (q[0] - p[0]) / length * step, p[1] + (q[1] - p[1]) / length * step
        cur = index
        if not s.contains(sx, sz):
            # p is on the sector's edge (a portal), or in an open neighbour (a corner point), and the line
            # heads out of the sector: carry on from there if we can walk through.
            cur = None
            for wi, w in enumerate(s.walls):
                if (index, wi) in self._open and (self.sectors[w.adjoin].contains(sx, sz)):
                    cur = w.adjoin
                    break
            if cur is None:
                return None
        path, t0 = [cur], 0.0
        px, pz = p
        dx, dz = q[0] - px, q[1] - pz
        lox, hix = min(px, q[0]) - 1e-6, max(px, q[0]) + 1e-6
        loz, hiz = min(pz, q[1]) - 1e-6, max(pz, q[1]) + 1e-6
        for _ in range(64):
            best_t, best = None, None
            for wall in self._outline(cur)["walls"]:
                x1, z1, x2, z2, mnx, mxx, mnz, mxz = wall[:8]
                if mxx < lox or mnx > hix or mxz < loz or mnz > hiz:
                    continue
                sx, sz = x2 - x1, z2 - z1
                den = dx * sz - dz * sx
                if -1e-9 < den < 1e-9:
                    continue
                wx, wz = x1 - px, z1 - pz
                u = (wx * dz - wz * dx) / den
                if u < -1e-6 or u > 1 + 1e-6:
                    continue
                t = (wx * sz - wz * sx) / den
                if t0 + 1e-4 < t < 1 - 1e-4 and (best_t is None or t < best_t):
                    best_t, best = t, wall
            if best is None:
                return path
            if not best[8]:
                return None
            t0, cur = best_t, best[9]
            path.append(cur)
        return None

    def _visible(self, index, p, q, free_p, free_q, clearance=True):
        """Whether we can walk straight from p to q, starting in a sector: the line runs into nothing (it may
        go on through open portals, see _march) and (with `clearance`) passes no jutting corner closer than
        PLAYER_RADIUS. free_p / free_q are (x, z, r) circles at either end whose corners are let off: a
        doorway's own frame, or a corner we're already standing at."""
        path = self._march(index, p, q)
        if path is None:
            return False
        if not clearance:
            return True
        free = free_p + free_q
        lox, hix = min(p[0], q[0]) - POST_BERTH, max(p[0], q[0]) + POST_BERTH
        loz, hiz = min(p[1], q[1]) - POST_BERTH, max(p[1], q[1]) + POST_BERTH
        for sec in set(path):
            out = self._outline(sec)
            berth = out.get("berth", PLAYER_RADIUS)
            for v in out["reflex"]:
                if not (lox <= v[0] <= hix and loz <= v[1] <= hiz):
                    continue
                if any(math.hypot(v[0] - x, v[1] - z) < r for x, z, r in free):
                    continue
                if point_seg(v, p, q) < berth:
                    return False
        return True

    @staticmethod
    def _portal_free(e, x, z):
        """Corners let off for a line to or from a portal point: its own two ends and anything right at it."""
        return ((x, z, PORTAL_NEAR),) + tuple((ex, ez, 0.05) for ex, ez in e.ends + e.inner)

    def clear_line(self, index, a, b):
        """Whether we can walk straight from where we stand (a) to waypoint b, both dicts with x, z."""
        return self._visible(index, (a["x"], a["z"]), (b["x"], b["z"]),
                             ((a["x"], a["z"], START_NEAR),), ((b["x"], b["z"], WAYPOINT_NEAR),))

    def blocked(self, index, a, b):
        """Whether walking straight from a to b (dicts with x, z) runs into a solid wall or post of sector
        `index`. Portals don't count, so b may lie beyond one."""
        s = self.sectors[index]
        p, q = (a["x"], a["z"]), (b["x"], b["z"])
        return any((w.adjoin < 0 or w.flags & IMPASSABLE) and crosses(p, q, s.vertices[w.v1], s.vertices[w.v2])
                   for w in s.walls)

    def _inner(self, index, p, q, free_p, free_q, reach_p=None, reach_q=None):
        """The way from p to q inside a sector, around whatever juts into it: (corner points, length), or None
        when there's no way round. Shortest path over the sector's corners. reach_p / reach_q are the corners
        seen from p / q (see _reach), when already known."""
        if self._visible(index, p, q, free_p, free_q):
            return [], math.hypot(q[0] - p[0], q[1] - p[1])
        sh = self._shape(index)
        cs = sh["corners"]
        if not cs:
            from_p = to_q = {}
        else:
            from_p = reach_p if reach_p is not None else self._reach(index, p, free_p)
            to_q = reach_q if reach_q is not None else self._reach(index, q, free_q)
        dist, back, heap = {}, {}, []
        for i, d in from_p.items():
            dist[i], back[i] = d, None
            heapq.heappush(heap, (d, i))
        done = set()
        best = (math.inf, None)                 # (total length, last corner)
        while heap:
            d, i = heapq.heappop(heap)
            if i in done:
                continue
            if d >= best[0]:
                break
            done.add(i)
            if i in to_q and d + to_q[i] < best[0]:
                best = (d + to_q[i], i)
            for j, dj in sh["vis"][i]:
                if d + dj < dist.get(j, math.inf):
                    dist[j], back[j] = d + dj, i
                    heapq.heappush(heap, (d + dj, j))
        if best[1] is not None:
            chain, i = [], best[1]
            while i is not None:
                chain.append(cs[i])
                i = back[i]
            return chain[::-1], best[0]
        if self._visible(index, p, q, free_p, free_q, clearance=False):
            # Too tight to keep clear of every corner, but the line runs through no wall: a narrow passage
            # that we squeeze along.
            return [], math.hypot(q[0] - p[0], q[1] - p[1])
        return None

    def _reach(self, index, p, free_p):
        """{corner index: distance} for the sector's corners we can walk straight to from p."""
        return {i: math.hypot(c[0] - p[0], c[1] - p[1]) for i, c in enumerate(self._outline(index)["corners"])
                if self._visible(index, p, c, free_p, ())}

    def _edge_reach(self, sector, e, target):
        """_reach from an edge's portal point in `sector` (the sector it leads into), or from its target (the
        point we head for in the sector it leaves: the line-up point if it has one). Cached: they never
        change."""
        key = (id(e), target)
        out = self._reach_cache.get(key)
        if out is None:
            p = (e.approach or (e.x, e.z)) if target else (e.x, e.z)
            out = self._reach_cache[key] = self._reach(sector, p, e.free_target if target else e.free)
        return out

    def _leg(self, index, p, q, free_p, free_q, strict=False, reach_p=None, reach_q=None):
        """Corners to walk round from p to q in a sector, its length, whether it's too low to stand on the
        way, and False when it can't be walked at all: too low to crouch, or (when `strict`) no way round
        what's in between (a window behind a crate). Otherwise a leg with no way round is walked straight,
        at a cost: where we stand may be odd, and the brain's stuck handling takes over."""
        inner = self._inner(index, p, q, free_p, free_q, reach_p, reach_q)
        if inner is None and strict:
            return [], 0.0, False, False
        corners, length = inner if inner else ([], math.hypot(q[0] - p[0], q[1] - p[1]) + NO_INNER_COST)
        low = False
        if index in self._ceil_slopes:
            # Under a sloped ceiling the way across the sector can run where it's too low.
            pts = [p] + corners + [q]
            room = min(self._min_headroom(index, *a, *b) for a, b in zip(pts, pts[1:]))
            if room < self.crouch_height:
                return corners, length, False, False
            low = room < PLAYER_HEIGHT
        return corners, length, low, True

    def _portal_leg(self, sector, ein, eout):
        """_leg across a sector from the portal we came in by to the one we leave by (to its line-up point if
        it has one), with the walk on to the portal added. Cached: it never changes."""
        key = (id(ein), id(eout))
        out = self._legs.get(key)
        if out is None:
            q = eout.approach or (eout.x, eout.z)
            corners, walk, low, ok = self._leg(sector, (ein.x, ein.z), q, ein.free, eout.free_target, strict=True,
                                               reach_p=self._edge_reach(sector, ein, False),
                                               reach_q=self._edge_reach(sector, eout, True))
            if eout.approach:
                walk += math.hypot(eout.x - q[0], eout.z - q[1])
            out = self._legs[key] = (corners, walk, low, ok)
        return out

    def _corner_wps(self, index, corners, low):
        return [{"x": x, "y": self.floor_at(index, x, z), "z": z, "jump": False, "crouch": low,
                 "sector": index, "corner": True} for x, z in corners]

    # -- search ---------------------------------------------------------------------------------------
    def _search(self, start, goals, avoid=(), water=True, drop_limit=None):
        """Best ways from start to each of `goals` (dicts with x, y, z): a list with, per goal, None or
        (cost, walking distance, node, corners, low) for its last leg; plus the search's `prev` links.

        A node is (sector, the edge we came in by), so a sector can be entered in more than one place (the
        way across it depends on where we come in). Costs are the distance walked, round corners inside
        sectors, plus penalties for jumps, crouching and windows, and AVOID_COST for portals whose key is in
        `avoid` (ones the brain failed to get through). With one goal it's A*; with several it's one
        Dijkstra for them all."""
        sa = self.locate(start["x"], start["y"], start["z"])
        if sa is None:
            return [None] * len(goals), {}
        sp = (start["x"], start["z"])
        free_start = ((*sp, START_NEAR),)
        reach_start = None
        in_sector = {}                                  # sector -> [(goal index, point, free circle)]
        for k, goal in enumerate(goals):
            sb = self.locate(goal["x"], goal["y"], goal["z"])
            if sb is not None:
                gp = (goal["x"], goal["z"])
                in_sector.setdefault(sb, []).append((k, gp, ((*gp, GOAL_NEAR),)))
        found = [None] * len(goals)
        if not in_sector:
            return found, {}
        aim = (goals[0]["x"], goals[0]["z"]) if len(goals) == 1 else None
        unsettled = sum(len(v) for v in in_sector.values())
        reach_goal = {}

        start_node = (sa, 0)
        edge_of = {start_node: None}
        g, walked = {start_node: 0.0}, {start_node: 0.0}
        prev = {start_node: None}     # node -> (previous node, edge taken, corners on the way, too low to stand)
        frontier = [(0.0, 0, start_node)]               # (estimate, tiebreak, node)
        tie = itertools.count(1)
        closed = set()
        while frontier:
            f, _, node = heapq.heappop(frontier)
            if node in closed:
                continue
            # A goal's best cost is settled once nothing cheaper is left to expand.
            if aim is not None and found[0] is not None and f >= found[0][0]:
                break
            if aim is None and unsettled == 0 and all(r is None or r[0] <= f for r in found):
                break
            closed.add(node)
            sec, ein = node[0], edge_of[node]
            if ein is None:
                p, free_p = sp, free_start
                if reach_start is None:
                    reach_start = self._reach(sa, sp, free_start) if self._outline(sa)["corners"] else {}
                reach_p = reach_start
            else:
                p, free_p, reach_p = (ein.x, ein.z), ein.free, None
            for k, gp, free_goal in in_sector.get(sec, ()):
                if ein is not None and reach_p is None:
                    reach_p = self._edge_reach(sec, ein, False)
                if k not in reach_goal:
                    reach_goal[k] = self._reach(sec, gp, free_goal) if self._outline(sec)["corners"] else {}
                corners, walk, low, ok = self._leg(sec, p, gp, free_p, free_goal, reach_p=reach_p,
                                                   reach_q=reach_goal[k])
                c = g[node] + walk + (6.0 if low else 0.0)
                if ok and (found[k] is None or c < found[k][0]):
                    if found[k] is None:
                        unsettled -= 1
                    found[k] = (c, walked[node] + walk, node, corners, low)
            for e in self.edges[sec]:
                nxt = (e.to, id(e))
                if nxt in closed:
                    continue
                if drop_limit is not None and e.drop > drop_limit:
                    continue                  # hurt: no jumping off the high ledges
                swim = e.to in self.water_surfaces and sec not in self.water_surfaces
                if not water and swim and STRICT_WATER:
                    continue                  # swimming not wanted at all: no way into open water from dry land
                if ein is None:
                    q = e.approach or (e.x, e.z)
                    corners, walk, low, ok = self._leg(sec, p, q, free_p, e.free_target, reach_p=reach_p,
                                                       reach_q=self._edge_reach(sec, e, True))
                    if e.approach:
                        walk += math.hypot(e.x - q[0], e.z - q[1])
                else:
                    corners, walk, low, ok = self._portal_leg(sec, ein, e)
                if not ok:
                    continue
                c = (g[node] + walk + (8.0 if e.jump else 0.0)
                     + (6.0 if e.crouch or low else 0.0) + (WINDOW_COST if e.window else 0.0)
                     + max(0.0, NARROW - e.width) * NARROW_COST + max(0.0, e.drop - STEP_UP) * DROP_COST
                     + HEIGHT_COST * abs(self.floor_at(e.to, e.x, e.z) - self.floor_at(sec, e.x, e.z))
                     + (AVOID_COST if e.key in avoid else 0.0)
                     + ((WATER_COST if water else NO_SWIM_COST) if swim else 0.0)
                     + (HIGH_EXIT_COST if e.jump and sec in self.water_surfaces
                        and e.to not in self.water_surfaces else 0.0))
                if c < g.get(nxt, math.inf):
                    g[nxt], walked[nxt], prev[nxt], edge_of[nxt] = c, walked[node] + walk, (node, e, corners, low), e
                    h = math.hypot(aim[0] - e.x, aim[1] - e.z) if aim else 0.0
                    heapq.heappush(frontier, (c + h, next(tie), nxt))
        return found, prev

    def route(self, start, goal, avoid=(), water=True, drop_limit=None):
        """Waypoints [{x, y, z, jump, sector}] from start to goal (dicts with x, y, z), or None.
        Waypoints are portal midpoints, plus `corner` points to walk round whatever juts into a sector (the
        building in an outdoor sector); the last one is the goal itself. Portal waypoints (and their line-up
        points) carry the portal's `edge` key; portals with a key in `avoid` are used only as a last resort."""
        found, prev = self._search(start, [goal], avoid, water, drop_limit)
        if found[0] is None:
            return None
        _, _, node, corners, low = found[0]
        legs = []
        while prev[node] is not None:
            legs.append(prev[node])
            node = prev[node][0]
        path = []
        for frm, e, leg_corners, leg_low in reversed(legs):
            path += self._corner_wps(frm[0], leg_corners, leg_low)
            if e.approach:
                # Line up in front of the opening first.
                path.append({"x": e.approach[0], "y": self.floor_at(frm[0], *e.approach), "z": e.approach[1],
                             "jump": False, "crouch": e.crouch, "sector": frm[0], "approach": True, "edge": e.key})
            wp = {"x": e.x, "y": self.floor_at(e.to, e.x, e.z), "z": e.z, "jump": e.jump, "width": e.width,
                  "crouch": e.crouch or leg_low, "sector": e.to, "edge": e.key}
            if e.beyond:
                wp["beyond"] = {"x": e.beyond[0], "z": e.beyond[1]}
            if e.crouch_jump:
                wp["crouch_jump"] = True
            if e.leap:
                wp["leap"] = e.leap
            if e.gap:
                wp["gap"] = e.gap
                wp["gap_y"] = e.gap_y
            if e.window:
                wp["window"] = {"x": e.x, "y": e.mid_y, "z": e.z}
            if e.door:
                wp["door"] = {"x": e.door[0], "z": e.door[1]}
            path.append(wp)
        sb = found[0][2][0]
        path += self._corner_wps(sb, corners, low)
        path.append(dict(goal, jump=False, crouch=self._crouch_only(sb, goal["x"], goal["z"]), sector=sb))
        self._mark_panels(start, path)
        return path

    def route_lengths(self, start, goals, avoid=(), water=True):
        """Walking distance from start to each goal by route (None where there's none), in one search."""
        found, _ = self._search(start, goals, avoid, water)
        return [None if r is None else r[1] for r in found]

    def double_door(self, x, z):
        """(panel, sibling) for the door panel centred at (x, z): the sibling is the other half of a double door
        (side by side along one wall, like the saloon's swing doors), or None for a single door; (None, None)
        if there is no panel there."""
        panel = next((p for p in self.panels if abs(p["x"] - x) < 0.5 and abs(p["z"] - z) < 0.5), None)
        if panel is None:
            return None, None
        sib = next((p for p in self.panels if p is not panel and math.hypot(p["x"] - panel["x"], p["z"] - panel["z"]) < 8.0
                    and abs(p["z"] - panel["z"]) < 1.5), None)
        return panel, sib

    def nudge_aim(self, x, z, bx, bz, k=0):
        """Where to aim the E nudge at the door panel centred at (x, z) when standing at (bx, bz): the face of its
        k-th nearest solid bar or post, for a grate (the jail doors: bars with gaps between, where a nudge aimed
        at the middle passes through a gap and hits nothing). None for a solid panel (aim at its middle)."""
        panel = next((p for p in self.panels if abs(p["x"] - x) < 0.5 and abs(p["z"] - z) < 0.5), None)
        if panel is None:
            return None
        sec = self.sectors[panel["sector"]]
        solid = [(point_seg((bx, bz), sec.vertices[w.v1], sec.vertices[w.v2]), sec.vertices[w.v1], sec.vertices[w.v2])
                 for w in sec.walls if w.adjoin < 0]
        if not solid:
            return None
        solid.sort(key=lambda t: t[0])
        spots = []
        for _, a, b in solid:
            c = closest((bx, bz), a, b)
            if all(math.hypot(c[0] - o[0], c[1] - o[1]) > 1.2 for o in spots):
                spots.append(c)
        c = spots[min(k, len(spots) - 1)]
        return {"x": c[0], "z": c[1]}

    def _mark_panels(self, start, path):
        """Give each waypoint whose approach crosses a door panel's closed position a `door`."""
        if not self.panels:
            return
        px, pz = start["x"], start["z"]
        for wp in path:
            for panel in self.panels:
                if seg_dist((px, pz), (wp["x"], wp["z"]), panel["a"], panel["b"]) < PLAYER_RADIUS:
                    wp.setdefault("door", {"x": panel["x"], "z": panel["z"]})
                    break
            px, pz = wp["x"], wp["z"]

    def _min_headroom(self, index, x1, z1, x2, z2):
        """Lowest headroom along a straight line inside a sector (about one sample per unit)."""
        n = max(1, int(math.hypot(x2 - x1, z2 - z1)))
        return min(self.headroom(index, x1 + (x2 - x1) * i / n, z1 + (z2 - z1) * i / n) for i in range(n + 1))

    def _crouch_only(self, index, x=None, z=None):
        """Too low to stand: at (x, z) if given, otherwise at the sector's centre."""
        if x is None:
            s = self.sectors[index]
            x = sum(v[0] for v in s.vertices) / len(s.vertices)
            z = sum(v[1] for v in s.vertices) / len(s.vertices)
        return self.headroom(index, x, z) < PLAYER_HEIGHT

    def _thin(self, index):
        """Narrower than a player: a wall top (Sanctuary's perimeter wall, a 1-wide ledge with a 6 drop to
        the outside), a stair step, a railing. Area over perimeter is about half the width of a strip."""
        s = self.sectors[index]
        area = perimeter = 0.0
        for w in s.walls:
            (x1, z1), (x2, z2) = s.vertices[w.v1], s.vertices[w.v2]
            area += x1 * z2 - x2 * z1
            perimeter += math.hypot(x2 - x1, z2 - z1)
        return perimeter == 0 or abs(area) / perimeter < PLAYER_RADIUS

    def length(self, start, path):
        """Walking distance along a route."""
        total, x, z = 0.0, start["x"], start["z"]
        for p in path:
            total += math.hypot(p["x"] - x, p["z"] - z)
            x, z = p["x"], p["z"]
        return total

    def spots(self, start):
        """Every sector centre reachable from start (not a crouch-only or thin one), as {x, y, z, exits}: exits is how
        many ways lead out of the sector (1 = a dead end), for finding a corner to camp in."""
        sa = self.locate(start["x"], start["y"], start["z"])
        if sa is None:
            return []
        seen, stack = {sa}, [sa]
        while stack:
            for e in self.edges[stack.pop()]:
                if e.to not in seen and not e.crouch:
                    seen.add(e.to)
                    stack.append(e.to)
        out = []
        for i in seen:
            if i == sa or self._crouch_only(i) or self._thin(i) or i in self.water:
                continue
            s = self.sectors[i]
            x = sum(v[0] for v in s.vertices) / len(s.vertices)
            z = sum(v[1] for v in s.vertices) / len(s.vertices)
            y = self.floor_at(i, x, z)
            if self.locate(x, y + 0.5, z) != i or self.headroom(i, x, z) < PLAYER_HEIGHT:
                continue
            out.append({"x": x, "y": y, "z": z, "index": i, "exits": len({e.to for e in self.edges[i]})})
        return out

    def walk_out(self, index, me, reach=4.5):
        """For a bot down in a sector of the cellar set (where routes don't go): the point to walk to for a way out on
        foot, or None. Walks the sector graph over shared walls, stepping up at most `reach` at each, to the first
        sector outside the cellar set, and returns the middle of the first wall on that path."""
        from collections import deque
        seen, queue = {index: None}, deque([index])
        while queue:
            cur = queue.popleft()
            s = self.sectors[cur]
            for w in s.walls:
                nxt = w.adjoin
                if nxt < 0 or nxt in seen or nxt in self.no_go - self.cellar:
                    continue
                a, b = s.vertices[w.v1], s.vertices[w.v2]
                mx, mz = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
                if self.floor_at(nxt, mx, mz) - self.floor_at(cur, mx, mz) > reach:
                    continue                          # a ledge too high to climb
                seen[nxt] = (cur, (mx, mz)) if cur != index else (None, (mx, mz))
                if nxt not in self.cellar:
                    node = nxt
                    while seen[node][0] is not None:
                        node = seen[node][0]
                    return seen[node][1]
                queue.append(nxt)
        return None

    def sees(self, a, b, reach=140.0):
        """Whether spot a (a dict from spots(), with its sector index) has a straight, open line to point b (x, z)
        within reach: the line runs through open portals only (_march)."""
        if math.hypot(b["x"] - a["x"], b["z"] - a["z"]) > reach:
            return False
        return self._march(a["index"], (a["x"], a["z"]), (b["x"], b["z"])) is not None

    def random_spot(self, rng, start):
        """Centre of a random sector reachable from start, for wandering (None if it misses)."""
        sa = self.locate(start["x"], start["y"], start["z"])
        if sa is None:
            return None
        seen, stack = {sa}, [sa]
        while stack:
            for e in self.edges[stack.pop()]:
                if e.to not in seen and not e.crouch:
                    seen.add(e.to)
                    stack.append(e.to)
        choices = [i for i in seen if i != sa and not self._crouch_only(i) and not self._thin(i)]
        if not choices:
            return None
        if self.high_min is not None:
            high = [i for i in choices if self.sectors[i].floor >= self.high_min and i in self.main]
            if high and rng.random() < HIGH_WANDER:
                choices = high
        s = self.sectors[rng.choice(choices)]
        x = sum(v[0] for v in s.vertices) / len(s.vertices)
        z = sum(v[1] for v in s.vertices) / len(s.vertices)
        y = self.floor_at(s.index, x, z)
        if self.locate(x, y + 0.5, z) != s.index:
            return None                   # centre falls outside a non-convex sector: try again later
        if self.headroom(s.index, x, z) < PLAYER_HEIGHT:
            return None                   # under the low end of a ramp
        return {"x": x, "y": y, "z": z}


def strongly_connected(edges):
    """{node: component id} for a graph {node: [edge with .to]} (Tarjan's algorithm, without recursion)."""
    index, low, comp = {}, {}, {}
    stack, on_stack = [], set()
    counter = itertools.count()
    for root in edges:
        if root in index:
            continue
        work = [(root, iter(edges[root]))]
        index[root] = low[root] = next(counter)
        stack.append(root)
        on_stack.add(root)
        while work:
            node, it = work[-1]
            for e in it:
                if e.to not in index:
                    index[e.to] = low[e.to] = next(counter)
                    stack.append(e.to)
                    on_stack.add(e.to)
                    work.append((e.to, iter(edges.get(e.to, ()))))
                    break
                if e.to in on_stack:
                    low[node] = min(low[node], index[e.to])
            else:
                work.pop()
                if work:
                    low[work[-1][0]] = min(low[work[-1][0]], low[node])
                if low[node] == index[node]:
                    while True:
                        n = stack.pop()
                        on_stack.discard(n)
                        comp[n] = node
                        if n == node:
                            break
    return comp


def closest(p, a, b):
    """The point of segment a-b nearest p (2D)."""
    dx, dz = b[0] - a[0], b[1] - a[1]
    length2 = dx * dx + dz * dz
    t = 0.0 if length2 == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dz) / length2))
    return a[0] + t * dx, a[1] + t * dz


def point_seg(p, a, b):
    """Distance from point p to segment a-b (2D)."""
    dx, dz = b[0] - a[0], b[1] - a[1]
    length2 = dx * dx + dz * dz
    t = 0.0 if length2 == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dz) / length2))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dz)


def cross_t(p, q, a, b):
    """Where along p->q (0..1) the line meets segment a-b, or None (also when they run parallel)."""
    rx, rz = q[0] - p[0], q[1] - p[1]
    sx, sz = b[0] - a[0], b[1] - a[1]
    den = rx * sz - rz * sx
    if abs(den) < 1e-9:
        return None
    wx, wz = a[0] - p[0], a[1] - p[1]
    u = (wx * rz - wz * rx) / den
    if not -1e-6 <= u <= 1 + 1e-6:
        return None
    return (wx * sz - wz * sx) / den


def crosses(p, q, a, b):
    """Whether walking p->q runs through wall a-b. Touching it at p or q (a portal we start or end on)
    doesn't count, nor does running along it."""
    rx, rz = q[0] - p[0], q[1] - p[1]
    sx, sz = b[0] - a[0], b[1] - a[1]
    den = rx * sz - rz * sx
    if abs(den) < 1e-9:
        return False
    wx, wz = a[0] - p[0], a[1] - p[1]
    t = (wx * sz - wz * sx) / den
    u = (wx * rz - wz * rx) / den
    return 1e-4 < t < 1 - 1e-4 and -1e-6 <= u <= 1 + 1e-6


def seg_dist(p1, p2, q1, q2):
    """Shortest distance between segments p1-p2 and q1-q2 (2D)."""
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    d1, d2 = cross(q1, q2, p1), cross(q1, q2, p2)
    d3, d4 = cross(p1, p2, q1), cross(p1, p2, q2)
    if (d1 > 0) != (d2 > 0) and (d3 > 0) != (d4 > 0):
        return 0.0
    return min(point_seg(p1, q1, q2), point_seg(p2, q1, q2), point_seg(q1, p1, p2), point_seg(q2, p1, p2))


def identify(points, candidates=None, prefer=None):
    """Guess the loaded level from live positions: (name, sectors). `points` are dicts with x, y, z, kind
    ('player' or 'item'). Players must stand on a flat floor; items may float up to 3 units above one."""
    best = (None, None, -1)
    names = list(candidates or lvt.list_levels())
    if prefer and prefer.lower() in [x.lower() for x in names]:
        # The map is known (BOT_MAP / the host's setting): try it first and stop if it fits, instead of
        # parsing every one of the hundreds of maps.
        pn = next(x for x in names if x.lower() == prefer.lower())
        names.remove(pn)
        names.insert(0, pn)
        prefer = pn
    first = True
    for name in names:
        try:
            sectors = lvt.load(name)
        except (FileNotFoundError, ValueError):
            continue
        score = 0
        for p in points:
            hi = 0.6 if p.get("kind") == "player" else 3.0
            for s in sectors:
                if s.walls and s.contains(p["x"], p["z"]) and (
                        s.floor_slope is not None and s.floor - 1 <= p["y"] <= s.ceiling
                        or s.floor_slope is None and -0.6 <= p["y"] - s.floor <= hi):
                    score += 1
                    break
        if first and name == prefer and len(points) >= 4 and score >= 0.8 * len(points):
            identify.ties = 1
            return (name, sectors, score)
        first = False
        if score > best[2]:
            best = (name, sectors, score)
            identify.ties = 1
        elif score == best[2]:
            identify.ties += 1                      # a tie: too few points to tell these maps apart yet
            if name == prefer:
                best = (name, sectors, score)
    return best


identify.ties = 1
