"""Team balance for team games: a bot on the bigger team sits out (stays dead) instead of respawning.

Who counts: every player, bot or human. A team's size is the most players seen alive on it at once during
a recent window, so players who are briefly dead still count, and a bot that sits out drops out of the count
once the window has passed. Lobby players (team 0) and corpses don't count.

The rule, checked when a bot dies (it never vanishes mid-fight): sit out if respawning would make our team
bigger than the other, i.e. our other living teammates >= the other team. 4 v 3 becomes 3 v 3; 3 v 3 stays.
A sitting-out bot comes back once the other team is bigger than our team without us.

Both decisions err on the side of changing nothing. A human may stay dead for a while (first live test,
2026-10-15: a human on blue died, dropped out of the 10 s count, and the blue bot sitting out came back,
making blue 4 v 3 once the human respawned). So the side that argues for a change is counted over the
short WINDOW and the side that argues against it over LONG_WINDOW:
- sit out if teammates (WINDOW) >= other team (LONG_WINDOW): a dead enemy human still counts;
- come back if teammates (LONG_WINDOW) < other team (WINDOW): a dead teammate human still counts.
The short window keeps a bot that just sat out from padding its team's count for long.

The bots run as separate processes, one per game copy, all on this PC. They share one roster file
(state/bench.json, changed only under state/bench.lock) of who is sitting out:
    {"cooldown_until": t, "out": {name: {"team": 1|2, "since": t, "seen": t}}}
- After any bot sits out or comes back, nobody else does for COOLDOWN seconds (longer than WINDOW), so the
  counts have caught up before the next decision. Two bots dying at once can't both sit out.
- Taking turns: a bot that dies on a team with a teammate sitting out for longer than `turn` seconds takes
  its place, and that teammate comes back. The counts don't change.
- A sitting-out bot refreshes its "seen" time every few seconds. Entries not refreshed for STALE seconds
  (botctl was closed) are dropped.
Bots joining a host on another PC, or several LAN games on one PC, aren't coordinated with each other.
"""
import json
import os
import time
from collections import deque
from pathlib import Path

TEAM_MODES = {1, 4, 5}
RED, BLUE = 1, 2
WINDOW = 10.0          # seconds of living-player history for the side that argues for a change
LONG_WINDOW = 45.0     # ... and for the side that argues against it (a human may stay dead a while)
COOLDOWN = 14.0        # seconds after a change before the next one
GRACE = 30.0           # seconds into a level before anyone sits out (players are still joining)
CHECK_EVERY = 1.0      # seconds between checks while sitting out
STALE = 15.0           # roster entries not refreshed for this long are dropped
LOCK_STALE = 5.0       # a lock file older than this was left by a crashed process

STATE_DIR = Path(__file__).resolve().parent / "state"


class Bench:
    def __init__(self, name, turn=180.0, log=print, state_dir=STATE_DIR, clock=time.time):
        self.name = name
        self.turn = turn                   # seconds a bot sits out before a teammate takes its place (0 = never)
        self.log = log
        self.dir = Path(state_dir)
        self.clock = clock
        self.history = deque()             # (time, {team: living others})
        self.level_key = None
        self.level_since = None
        self.game = {}
        self.out = False                  # sitting out right now
        self.next_check = 0.0
        self.last_view = None              # what still_out last logged (it logs changes only)

    # -- counting -------------------------------------------------------------------------------------
    def note(self, now, players, game, level_key):
        """Every tick: record how many other players are alive on each team. `players` is the agent's
        full player list (the local one is skipped)."""
        if level_key != self.level_key:
            self.level_key, self.level_since = level_key, now
            self.history.clear()
        counts = {RED: 0, BLUE: 0, 0: 0}       # 0: living players on neither team (for the log only)
        for p in players or []:
            if not p.get("local") and not p.get("dead"):
                counts[p.get("team") if p.get("team") in (RED, BLUE) else 0] += 1
        self.history.append((now, counts))
        while self.history and now - self.history[0][0] > LONG_WINDOW:
            self.history.popleft()
        if game and game.get("mode") is not None:     # a failed read keeps the last known mode
            self.game = game

    def size(self, now, team, window):
        """The most players seen alive at once on `team` (us excluded) within the last `window` seconds."""
        return max((c[team] for t, c in self.history if now - t <= window), default=0)

    def active(self, now, team):
        return (team in (RED, BLUE) and self.game.get("mode") in TEAM_MODES
                and self.level_since is not None and now - self.level_since >= GRACE)

    # -- decisions ------------------------------------------------------------------------------------
    def at_death(self, now, team):
        """Called once per death, before respawning. Returns whether to sit out."""
        if not self.active(now, team):
            return False
        other = BLUE if team == RED else RED
        mates, others = self.size(now, team, WINDOW), self.size(now, other, LONG_WINDOW)
        with self.roster() as r:
            t = self.clock()
            out = r["out"]
            if mates >= others and t >= r["cooldown_until"]:
                out[self.name] = {"team": team, "since": t, "seen": t}
                r["cooldown_until"] = t + COOLDOWN
                self.log(f"sitting out to balance the teams: {mates + 1} v {others} otherwise")
                return self.sit(now)
            if self.turn > 0:
                waiting = [(e["since"], n) for n, e in out.items()
                           if e["team"] == team and n != self.name and t - e["since"] >= self.turn]
                if waiting:
                    _, mate = min(waiting)
                    del out[mate]
                    out[self.name] = {"team": team, "since": t, "seen": t}
                    # Until the teammate has respawned our team looks one short: without the cooldown we'd
                    # come straight back in and both of us would play (seen in the simulation).
                    r["cooldown_until"] = max(r["cooldown_until"], t + COOLDOWN)
                    self.log(f"sitting out: taking over from {mate}")
                    return self.sit(now)
        return False

    def still_out(self, now, team):
        """While sitting out: whether to keep sitting out. Comes back when taken over by a teammate, when
        our team without us is smaller than the other, or when the game is no longer a team game."""
        if not self.out:
            return False
        if now < self.next_check:
            return True
        self.next_check = now + CHECK_EVERY
        other = BLUE if team == RED else RED
        mates, others = self.size(now, team, LONG_WINDOW), self.size(now, other, WINDOW)
        if self.history:
            alive = self.history[-1][1]
            view = (mates, others, alive[0] > 0)      # what decides, plus "someone on no team"
            if view != self.last_view:
                self.last_view = view
                self.log(f"sitting out, seen: our team {mates} (alive now {alive[team]}), other team {others} "
                         f"(alive now {alive[other]})" + (f", {alive[0]} alive on no team" if alive[0] else ""))
        with self.roster() as r:
            t = self.clock()
            mine = r["out"].get(self.name)
            if mine is None:
                self.log("back in: a teammate took over")
                return self.unsit()
            if self.game.get("mode") not in TEAM_MODES:
                del r["out"][self.name]
                self.log("back in: not a team game any more")
                return self.unsit()
            if mates < others and t >= r["cooldown_until"]:
                del r["out"][self.name]
                r["cooldown_until"] = t + COOLDOWN
                self.log(f"back in to balance the teams: {mates + 1} v {others}")
                return self.unsit()
            mine["seen"] = t
        return True

    def leave(self):
        """We're alive again (a new level) or stopping: drop our roster entry if we have one."""
        if not self.out:
            return
        with self.roster() as r:
            r["out"].pop(self.name, None)
        self.out = False

    def sit(self, now):
        self.out, self.next_check, self.last_view = True, now + CHECK_EVERY, None
        return True

    def unsit(self):
        self.out = False
        return False

    # -- the shared roster ----------------------------------------------------------------------------
    def roster(self):
        return _Roster(self.dir, self.clock)


class _Roster:
    """`with` block: holds the lock, loads the roster, and writes it back on a clean exit."""

    def __init__(self, folder, clock):
        self.dir, self.clock = folder, clock
        self.path = folder / "bench.json"
        self.lock = folder / "bench.lock"

    def __enter__(self):
        self.dir.mkdir(exist_ok=True)
        deadline = time.time() + 2.0
        while True:
            try:
                os.close(os.open(self.lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
                break
            except FileExistsError:
                try:
                    if time.time() - self.lock.stat().st_mtime > LOCK_STALE:
                        self.lock.unlink()
                        continue
                except FileNotFoundError:
                    continue
                if time.time() > deadline:
                    raise TimeoutError(f"{self.lock} stays locked")
                time.sleep(0.01)
        try:
            data = json.loads(self.path.read_text())
        except (FileNotFoundError, ValueError):
            data = {}
        t = self.clock()
        self.data = {"cooldown_until": float(data.get("cooldown_until", 0.0)),
                     "out": {n: e for n, e in (data.get("out") or {}).items() if t - e.get("seen", 0) < STALE}}
        if self.data["cooldown_until"] > t + COOLDOWN:      # from a clock that has since been set back
            self.data["cooldown_until"] = 0.0
        return self.data

    def __exit__(self, exc_type, *_):
        try:
            if exc_type is None:
                tmp = self.path.with_suffix(".tmp")
                tmp.write_text(json.dumps(self.data, indent=1))
                for _ in range(50):
                    try:
                        os.replace(tmp, self.path)
                        break
                    except PermissionError:      # a virus scanner peeking at it
                        time.sleep(0.01)
        finally:
            try:
                self.lock.unlink()
            except FileNotFoundError:
                pass
        return False
