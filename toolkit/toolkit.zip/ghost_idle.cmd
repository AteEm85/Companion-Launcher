@echo off
rem Shot-decoding test: the ghost stands still at its spawn point (and just looks up/down now and then) for 100 seconds.
rem Host a LAN game ALONE, run this, then follow Claude's shooting instructions. Log: state\ghost\ghost_rx.jsonl
cd /d "%~dp0"
set GHOST_ROUTE=0,0
set GHOST_STAY=100
".venv\Scripts\python.exe" -u ghost.py %*
pause
