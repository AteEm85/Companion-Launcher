"""Map rotation: when a match ends, the host bot hosts the next map from a list and the other bots join it, in the
same game copies (no restart).

  python rotation.py rotation.txt -- sanchez mary bob --fight     # start the bots on line 1 (botctl.py, hosting),
                                                                   # then go down the list
  python rotation.py rotation.txt                                  # the bots are already playing line 1
                                                                   # (the launcher's Map Rotation tab does this)

rotation.txt, one match per line (# starts a comment; '-' or nothing keeps the setting the host had):
  # map       mode   minutes  kills
  fort        ctf    15       5
  drygulch    dm     10       25
  town_2p     tag
Maps are botctl's --map names (botctl.py --help lists them), modes dm team ctf tag chicken doc. Each line is
checked against the map's own modes before anything starts.

Each bot's brain writes state\\status_<profile>.json once a second (game state, whether a LAN lobby exists) and
takes one step at a time from state\\session_<profile>.json: continue (Enter on the score screen), host, join.
A match is over when the host's lobby goes away after it had one. Then: --score-wait seconds on the score
screen, everyone to the main menu, the host hosts the next line, the others join it one by one.
You (a person) are not driven: press Continue on the score screen, then join the LAN game again.
--once stops after the last line; --shuffle plays the list in a random order (a new one each time round).
"""
import argparse
import json
import os
import random
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
STATE = HERE / "state"
sys.path.insert(0, str(HERE))
from botctl import JOIN_STAGGER, MAPS, MODES, map_modes  # noqa: E402

MODE_LABEL = {"dm": "Deathmatch", "team": "Team deathmatch", "ctf": "Capture the flag", "tag": "Tag",
              "chicken": "Chicken", "doc": "Doc"}
FRESH = 10.0              # a status file older than this: that bot's botctl is gone
PLAYING, MENU = 2, 0      # game states (input_agent.js): 2 in a match or on its score screen, 0 the main menu


def ev(msg):
    print(f"{time.strftime('%H:%M:%S')} {msg}", flush=True)


def parse(path):
    """The list as [{map, mode, timelimit, fraglimit}], or exit with what is wrong (file line numbers)."""
    out, errors = [], []
    try:
        lines = Path(path).read_text(encoding="utf-8-sig").splitlines()
    except OSError as e:
        sys.exit(f"cannot read {path}: {e}")
    for n, line in enumerate(lines, 1):
        words = line.split("#", 1)[0].split()
        if not words:
            continue
        level = next((k for k in MAPS if k.lower() == words[0].lower()), None)
        mode = words[1].lower() if len(words) > 1 and words[1] != "-" else "dm"
        if level is None:
            errors.append(f"line {n}: unknown map {words[0]!r}")
            continue
        if mode not in MODES:
            errors.append(f"line {n}: unknown mode {mode!r} (dm team ctf tag chicken doc)")
            continue
        have = map_modes(level)
        if have and MODES[mode][1] not in have:
            errors.append(f"line {n}: {MAPS[level]} has no {mode}; it has "
                          + " ".join(k for k, (_, letter) in MODES.items() if letter in have))
            continue
        limits = []
        for i, top in ((2, 120), (3, 100)):
            w = words[i] if len(words) > i else "-"
            if w == "-":
                limits.append(None)
            elif w.isdigit() and int(w) <= top:
                limits.append(int(w))
            else:
                errors.append(f"line {n}: {'minutes' if i == 2 else 'kills'} must be 0-{top} or -, not {w!r}")
        if len(limits) == 2:
            out.append({"map": level, "mode": mode, "timelimit": limits[0], "fraglimit": limits[1]})
    if errors:
        sys.exit("rotation list: " + "; ".join(errors))
    if not out:
        sys.exit(f"rotation list {path} has no maps")
    return out


def describe(e):
    limits = [f"{e['timelimit']} min" if e["timelimit"] is not None else "",
              f"{e['fraglimit']} kills" if e["fraglimit"] is not None else ""]
    return f"{MAPS[e['map']]} ({MODE_LABEL[e['mode']]}" + "".join(", " + x for x in limits if x) + ")"


def bots():
    """{profile: status} of every bot whose brain wrote its status in the last FRESH seconds."""
    out = {}
    for f in STATE.glob("status_*.json"):
        try:
            s = json.loads(f.read_text())
        except (OSError, ValueError):
            continue
        if time.time() - s.get("t", 0) < FRESH:
            out[f.stem[len("status_"):]] = s
    return out


def step(profile, **d):
    (STATE / f"session_{profile}.json").write_text(json.dumps(dict(d, t=time.time())))


def wait(test, timeout, every=0.5):
    """Call test(bots()) until it returns something true (returned), or None after timeout seconds."""
    end = time.time() + timeout
    while time.time() < end:
        r = test(bots())
        if r:
            return r
        time.sleep(every)
    return None


def start_bots(first, botargs):
    """Start botctl.py hosting the first line, with the bots and options after '--'."""
    cmd = [sys.executable, "-u", str(HERE / "botctl.py")] + botargs + ["--host", "--map", first["map"], "--mode", first["mode"]]
    cmd += ["--timelimit", str(first["timelimit"])] if first["timelimit"] is not None else []
    cmd += ["--fraglimit", str(first["fraglimit"])] if first["fraglimit"] is not None else []
    ev("starting: " + subprocess.list2cmdline(cmd[2:]))
    subprocess.Popen(cmd, cwd=str(HERE))


def one_change(entry, score_wait):
    """The match that is on has ended: score screen, menu, host the next map, the others join. False if it broke."""
    time.sleep(score_wait)
    for attempt in range(2):                              # Enter on the score screen; once more for whoever missed it
        for p, s in bots().items():
            if s.get("state") != MENU:
                step(p, action="continue")
        if wait(lambda b: b and all(s.get("state") == MENU for s in b.values()), 12):
            break
    else:
        stuck = [p for p, s in bots().items() if s.get("state") != MENU]
        ev(f"not everyone reached the main menu ({', '.join(stuck)}); going on without them")
    time.sleep(3)
    host = next((p for p, s in bots().items() if s.get("host")), None)
    if host is None:
        ev("the host bot is gone; stopping")
        return False
    for attempt in range(2):
        step(host, action="host", map=entry["map"], mode=MODES[entry["mode"]][0], timelimit=entry["timelimit"],
             fraglimit=entry["fraglimit"])
        # the host is through loading once it is in the lobby (8) or the match (2)
        if wait(lambda b: b.get(host, {}).get("lobby") and b[host].get("state") in (8, PLAYING), 30):
            break
        ev(f"the host's lobby didn't come up{'; trying again' if attempt == 0 else ''}")
    else:
        return False
    ev(f"next map is up: {describe(entry)}. Players: Continue on the score screen, then join the LAN game")
    time.sleep(2)
    joiners = sorted(p for p, s in bots().items() if not s.get("host") and s.get("state") == MENU)
    for p in joiners:
        step(p, action="join", address="127.0.0.1", map=entry["map"])
        time.sleep(JOIN_STAGGER)
    missing = []
    for p in joiners:
        if not wait(lambda b: b.get(p, {}).get("state") in (8, PLAYING) and b[p].get("lobby"), 30):
            missing.append(p)
    for p in missing:                                      # one more try each, if it is still at the menu
        if bots().get(p, {}).get("state") == MENU:
            step(p, action="join", address="127.0.0.1", map=entry["map"])
    if missing and not wait(lambda b: all(b.get(p, {}).get("state") in (8, PLAYING) for p in missing), 30):
        ev("not every bot made it into the new match: "
           + ", ".join(p for p in missing if bots().get(p, {}).get("state") not in (8, PLAYING)))
    return True


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("list", help="the rotation list (see above)")
    ap.add_argument("--once", action="store_true", help="stop after the last line instead of starting over")
    ap.add_argument("--shuffle", action="store_true", help="a random order, a new one each time round")
    ap.add_argument("--score-wait", type=float, default=10.0, help="seconds on the score screen (default 10)")
    ap.add_argument("--startup-max", type=float, default=900.0,
                    help="seconds to wait for the host bot's first match (default 900)")
    argv = sys.argv[1:]
    botargs = argv[argv.index("--") + 1:] if "--" in argv else None
    a = ap.parse_args(argv[:argv.index("--")] if "--" in argv else argv)
    entries = parse(a.list)
    STATE.mkdir(exist_ok=True)
    for f in STATE.glob("session_*.json"):                 # steps left over from an earlier run
        f.unlink(missing_ok=True)
    order = entries[:]
    if a.shuffle and botargs is not None:
        random.shuffle(order)
    elif a.shuffle:                                        # line 1 is already being played: shuffle the rest
        rest = order[1:]
        random.shuffle(rest)
        order[1:] = rest
    ev("rotation: " + " -> ".join(describe(e) for e in order) + ("" if a.once else " -> (again)"))
    if botargs is not None:
        start_bots(order[0], botargs)
    ev("waiting for the host bot's match...")
    if not wait(lambda b: any(s.get("host") and s.get("lobby") and s.get("state") == PLAYING for s in b.values()),
                a.startup_max, every=2):
        sys.exit("the host bot never started a match (it must run with --fight; is a botctl console open?)")
    i = 0
    while True:
        ev(f"playing {describe(order[i])}")
        # The match is over when the host's lobby goes away (it sits on the score screen, or someone pressed Continue).
        while True:
            b = bots()
            host = next((s for s in b.values() if s.get("host")), None)
            if host is None:
                time.sleep(3)
                if not any(s.get("host") for s in bots().values()):
                    ev("the host bot is gone; rotation over")
                    return
                continue
            if not host.get("lobby") and host.get("state") in (PLAYING, MENU):
                break
            time.sleep(1)
        ev("match over")
        i += 1
        if i >= len(order):
            if a.once:
                ev("that was the last map; rotation over")
                return
            last = order[-1]
            if a.shuffle:
                random.shuffle(order)
                if len(order) > 1 and order[0] == last:     # not the same map twice in a row
                    order.append(order.pop(0))
            i = 0
        if not one_change(order[i], a.score_wait):
            ev("could not start the next map; rotation stopped (the bots stay where they are)")
            return


if __name__ == "__main__":
    main()
