@echo off
rem Mission 3 (Thin Ice) clones test: see clonetest.py. Log: state\clonetest.txt
cd /d "%~dp0"
".venv\Scripts\python.exe" -u clonetest.py
