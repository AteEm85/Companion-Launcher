@echo off
rem Plays every map in sweep_maps.txt for 1.5 minutes each and records where the bots get stuck.
rem Safe to stop and start again: finished maps are listed in sweep_done.txt and skipped.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u pathcheck.py --minutes 1.5 --maps-file sweep_maps.txt --resume
echo DONE> sweep_done_flag.txt
