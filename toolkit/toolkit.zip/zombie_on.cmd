@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" zombieskins.py on
echo.
echo Now start a game and play as (or against) any character. Run zombie_off.cmd afterwards.
pause
