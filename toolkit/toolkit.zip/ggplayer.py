"""Gun game for the human player: keep your game on the ladder.

  python ggplayer.py <launcher pid>

Attaches the bot agent to the one OutlawsAHOM.exe that isn't a bot (its command line has no -userpath), then
  - counts your kills (the game's own kill feed) and your deaths (health reaching 0): a kill is up a rung, a death is down one,
    a knife kill wins the round exactly as it does for a bot (state\\gg_ladder.json, the banner and the freeze),
  - hands you the rung's weapon (and ammo) with the game's own pickup function, selects it, and takes every other weapon
    out of your inventory again (the fists stay), so a pickup off the floor lasts a fraction of a second,
  - picks up the other players' rounds: when somebody else wins, you start again from the bottom with the new order.
Leaves your game alone again when the launcher closes or the game does.  Log: ggplayer_log.txt"""
import os
import re
import subprocess
import sys
import time
from pathlib import Path

import frida

import gungame

HERE = Path(__file__).resolve().parent
STATE = HERE / "state"
LOG = HERE / "ggplayer_log.txt"
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
NAME = (os.environ.get("BOT_STATS_PLAYER") or "").strip()
OVER_FILE = STATE / "gg_over.json"          # the human won the last round: a bot ends the game (the host's kill limit)


def log(msg):
    line = time.strftime("%H:%M:%S ") + msg
    try:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def alive(pid):
    try:
        out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True, creationflags=NOWIN).stdout
        return str(pid) in out
    except Exception:
        return True


def human_pid():
    """The OutlawsAHOM.exe that isn't one of the bots' copies (those are started with -userpath)."""
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='OutlawsAHOM.exe'\" | Where-Object { $_.CommandLine -notmatch 'userpath' } "
          "| ForEach-Object { $_.ProcessId }")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=20,
                             creationflags=NOWIN).stdout.split()
        pids = [int(x) for x in out if x.isdigit()]
        return pids[0] if len(pids) == 1 else None
    except Exception:
        return None


def bot_names():
    names = set()
    for f in STATE.glob("name_*.txt"):
        try:
            names.add(f.read_text().strip())
        except OSError:
            pass
    return names


class Player:
    def __init__(self, api):
        self.api = api
        self.rung = 0
        self.round_seen = None
        self.hp = None
        self.last = {"give": 0.0, "key": 0.0, "strip": 0.0, "feed": 0.0, "poll": 0.0, "top": 0.0}
        self.was_frozen = False
        self.spawn_at = 0.0
        self.done = 0
        self.key_tries = 0

    # -- the ladder ---------------------------------------------------------------------------------------------
    def move(self, step, why):
        old = self.rung
        self.rung = max(0, old + step)
        if self.rung >= len(gungame.LADDER):
            log(f"WIN with the knife ({why})")
            self.rung = 0
            who = NAME or "Player"
            self.round_seen, self.done = gungame.next_round(gungame.RANDOM)
            log(f"round {self.done} of {gungame.ROUNDS} won; ladder from here: " + ", ".join(gungame.NAMES[s] for s in gungame.LADDER))
            if gungame.LAUNCH:
                gungame.announce_round(self.done, who, self.done >= gungame.ROUNDS)
            if self.done >= gungame.ROUNDS:
                try:
                    import json
                    OVER_FILE.write_text(json.dumps({"launch": gungame.LAUNCH, "at": time.time() + (gungame.HOLD if gungame.LAUNCH else 0.0)}))
                except OSError:
                    pass
        elif self.rung != old:
            log(f"rung {old} -> {self.rung} ({gungame.NAMES[gungame.slot_for(self.rung)]}) {why}")

    def feed(self, now):
        if now - self.last["feed"] < 0.5:
            return
        self.last["feed"] = now
        try:
            lines = self.api.drain_formats() or []
        except Exception:
            return
        for line in lines:
            if not line.startswith("G "):
                continue
            text = line[2:].strip()
            log("FEED: " + text)
            m = re.match(r"^(.+?) (?:killed|blew up) (.+)!$", text)
            if not m:
                continue
            killer, victim = m.group(1), m.group(2)
            if victim == "you" or killer == victim:
                continue
            mine = killer.lower() == "you" or (NAME and killer == NAME) or \
                (not NAME and killer not in bot_names() and not re.match(r"^(Zombie|Bot|Host Bot)( \d+)?$", killer))
            if mine and not gungame.frozen():
                self.move(+1, f"killed {victim}")

    # -- the weapon ---------------------------------------------------------------------------------------------
    def tap(self, digit):
        sc, kc = 30 + (digit - 1) % 10, ord(str(digit))
        self.api.key(sc, kc, True)
        time.sleep(0.06)
        self.api.key(sc, kc, False)

    def step(self, now):
        if now - self.last["poll"] > 1.0:                      # somebody else won: their new order, from the bottom
            self.last["poll"] = now
            new = gungame.poll_round(self.round_seen)
            if new:
                self.round_seen = new[0]
                gungame.LADDER[:] = new[1]
                self.rung = 0
                log("new game, ladder: " + ", ".join(gungame.NAMES[s] for s in gungame.LADDER))
        w = self.api.world()
        me = (w or {}).get("self") or {}
        hp = me.get("health")
        if hp is not None:
            if self.hp is not None and self.hp > 0 >= hp:
                if not gungame.frozen():
                    self.move(-1, "died")
            if self.hp is not None and self.hp <= 0 < hp:
                self.spawn_at = now
            self.hp = hp
        self.feed(now)
        if not w or not w.get("ok") or not hp or hp <= 0 or gungame.frozen():
            return
        inv = me.get("inventory") or {}
        want = gungame.slot_for(self.rung)
        owned = {x["slot"]: x for x in inv.get("weapons") or []}
        carried = inv.get("carried") or {}
        cur = inv.get("slot")
        have = owned.get(want)
        short = False
        if want in (7, 8):
            short = carried.get("IDYNAM" if want == 7 else "IKNIFE", 0) < 2
        elif have is not None and have.get("capacity"):
            short = (have.get("loaded") or 0) + (have.get("reserve") or 0) < 2 * have["capacity"]
        if (have is None or short) and now - self.last["give"] > (1.5 if have is None else 4.0):
            self.last["give"] = now
            res = self.api.give(gungame.GIVE.get(want, []))
            log(f"gave {gungame.NAMES[want]}: {res.get('ok') if isinstance(res, dict) else res}")
            if have is not None:
                self.last["give"] = now + 21.0                  # a top-up, not a missing weapon: not again for 25 s
            log(f"ammo set: {gungame.fill(self.api, want)}; carried {({k: v for k, v in carried.items() if k.startswith('I') and k[1:] in ('BULLIT', 'CART', 'SHELLS', 'CLIP', 'DYNAM', 'KNIFE')})}"
                f"; weapons {[(x['slot'], x.get('loaded'), x.get('reserve'), x.get('capacity')) for x in inv.get('weapons') or []]}")
            return
        if have is None:
            return
        if cur != want:
            if now - self.last["key"] > 0.5:
                self.last["key"] = now
                self.tap(want)
            return
        extra = [s for s in owned if s not in (1, want, gungame.KEEP_ALSO.get(want))]
        if extra and now - self.last["strip"] > 0.15:
            self.last["strip"] = now
            res = self.api.strip_weapons(want, gungame.KEEP_ALSO.get(want, 0))
            log(f"took away {[gungame.NAMES.get(s, s) for s in extra]}: {res}")


def run(pid, parent):
    dev = frida.get_local_device()
    session = dev.attach(pid)
    script = session.create_script((HERE / "input_agent.js").read_text(encoding="utf-8"))
    script.on("message", lambda m, d: None)
    script.load()
    api = script.exports_sync
    log(f"attached to pid {pid}; ladder: " + ", ".join(gungame.NAMES[s] for s in gungame.LADDER) + f"; name {NAME or '(unknown)'}")
    try:
        api.trace_format()
        p = Player(api)
        while alive(pid) and (not parent or alive(parent)):
            try:
                p.step(time.time())
            except frida.InvalidOperationError:
                break
            except Exception as e:
                log(f"step failed: {e}")
            time.sleep(0.2)
    finally:
        try:
            api.release()
            api.shutdown()
            time.sleep(0.5)
        except Exception:
            pass
        try:
            session.detach()
        except Exception:
            pass
        log("let go of the game")


def main():
    parent = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    while not parent or alive(parent):
        pid = human_pid()
        if pid:
            try:
                run(pid, parent)
            except Exception as e:
                log(f"could not attach: {e}")
            time.sleep(5)
        else:
            time.sleep(3)


if __name__ == "__main__":
    main()
