@echo off
cd /d "%~dp0"
del gungame_rounds_done.txt >nul 2>&1
del state\gg_ladder.json >nul 2>&1
set BOT_GUNGAME=1
set BOT_GG_RANDOM=1
set BOT_GG_ROUNDS=3
set BOT_GG_LAUNCH=roundstest
echo 3 rounds on Buckshotville, random ladder each round > gungame_rounds_run.txt
start "" /b ".venv\Scripts\python.exe" -u botctl.py bot1:lv_normal bot2:lv_normal bot3:lv_normal --host --mode dm --map civpow2 --fight --wait-for 2 --wait-max 120 --size 320x180 --fps 60 --no-taunts --window-mode hidden >> gungame_rounds_run.txt 2>&1
rem the game ends itself after the third knife win; stop everything after 30 minutes at the latest
timeout /t 1800 /nobreak >nul
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'botctl[.]py' -or ($_.Name -eq 'OutlawsAHOM.exe' -and $_.CommandLine -match 'userpath') } | ForEach-Object { taskkill /PID $_.ProcessId /T /F | Out-Null }" >nul 2>&1
echo finished > gungame_rounds_done.txt
