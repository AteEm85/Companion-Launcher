"""Look-while-dead probe: finds the game code that turns the mouse into looking up/down, and what stops it while you are dead.

Attaches to YOUR game copy only (the one without -userpath; the bots' copies are left alone), finds your player in memory the
way the bots' agent does (the player physics routine's first argument), and puts two hardware watchpoints on it: one on the
pitch (up/down) and one on the heading (left/right). Every time the game writes either one it notes which instruction did it
(and the calls that led there), separately for alive and dead. Once a second it notes whether you are dead and where you look.

Nothing in the game is changed: it only watches. Writes state\\lookprobe.txt.

  python lookprobe.py [seconds]      (default 240)
"""
import json
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

import frida

HERE = Path(__file__).resolve().parent
OUT = HERE / "state" / "lookprobe.txt"
SECS = float(sys.argv[1]) if len(sys.argv) > 1 else 240.0

JS = r"""
const BUILDS = { 0x6a39efd0: { name: 'GOG', physics: 0xb66e0 }, 0x6a39ed68: { name: 'Steam', physics: 0xb68f0 } };
const exe = Process.mainModule;
const stamp = exe.base.add(exe.base.add(0x3c).readU32() + 8).readU32();
const build = BUILDS[stamp];
if (!build) { send({ kind: 'error', message: 'unknown game build 0x' + stamp.toString(16) }); }
let actor = null, armed = null, lastP = null, lastH = null;
const counts = {};
function rva(p) { try { return '0x' + p.sub(exe.base).toString(16); } catch (e) { return String(p); } }
function inExe(p) { return p.compare(exe.base) >= 0 && p.compare(exe.base.add(exe.size)) < 0; }
function arm(a) {
  let n = 0, bad = 0;
  for (const t of Process.enumerateThreads()) {
    try {
      if (armed) { try { t.unsetHardwareWatchpoint(0); t.unsetHardwareWatchpoint(1); } catch (e) {} }
      t.setHardwareWatchpoint(0, a.add(0x44), 2, 'w');
      t.setHardwareWatchpoint(1, a.add(0x46), 2, 'w');
      n++;
    } catch (e) { bad++; }
  }
  armed = a;
  send({ kind: 'armed', actor: a.toString(), threads: n, failed: bad });
}
Process.setExceptionHandler(function (d) {
  if (d.type !== 'single-step' || actor === null) return false;
  try {
    const p = actor.add(0x44).readS16(), h = actor.add(0x46).readU16();
    const dead = (actor.add(0x10).readU32() & 0x4000) !== 0;
    const which = (p !== lastP && h !== lastH) ? 'both' : (p !== lastP ? 'pitch' : (h !== lastH ? 'heading' : 'same'));
    lastP = p; lastH = h;
    let bt = [];
    try { bt = Thread.backtrace(d.context, Backtracer.FUZZY).filter(inExe).slice(0, 6).map(rva); } catch (e) {}
    const key = [dead ? 'dead' : 'alive', which, rva(d.context.pc), bt.join(' < ')].join(' | ');
    counts[key] = (counts[key] || 0) + 1;
  } catch (e) {}
  return true;
});
Interceptor.attach(exe.base.add(build.physics), {
  onEnter(args) {
    const a = args[0];
    if (actor === null || !a.equals(actor)) { actor = a; arm(a); }
  }
});
setInterval(function () {
  if (actor === null) { send({ kind: 'tick', actor: null }); return; }
  let dead = null, p = null, h = null;
  try { dead = (actor.add(0x10).readU32() & 0x4000) !== 0; p = actor.add(0x44).readS16(); h = actor.add(0x46).readU16() & 0x3fff; } catch (e) {}
  const c = Object.assign({}, counts);
  for (const k in counts) delete counts[k];
  send({ kind: 'tick', dead: dead, pitch: p, heading: h, writes: c });
}, 1000);
send({ kind: 'ready', build: build ? build.name : '?' });
"""


def own_game_pid():
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='OutlawsAHOM.exe'\" | "
          "ForEach-Object { '{0}|{1}' -f $_.ProcessId, $_.CommandLine }")
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True, timeout=30)
    mine = [int(l.split("|", 1)[0]) for l in r.stdout.splitlines() if l.strip() and "-userpath" not in l]
    return mine[0] if mine else None


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    print("waiting for your own game (start it, get into a match)...")
    pid = None
    for _ in range(300):
        pid = own_game_pid()
        if pid:
            break
        time.sleep(2)
    if not pid:
        print("your game was not found"); return
    print(f"watching your game (pid {pid}) for {SECS:.0f} s: die a few times and move the mouse up and down while dead")
    log = open(OUT, "w", encoding="utf-8")
    total = Counter(); last_state = [None]

    def on_msg(msg, data):
        if msg.get("type") == "error":
            print("script error:", msg.get("description")); log.write("script error: %s\n" % msg.get("description")); return
        pl = msg.get("payload") or {}
        k = pl.get("kind")
        if k in ("ready", "armed", "error"):
            print(k, {x: y for x, y in pl.items() if x != "kind"}); log.write(json.dumps(pl) + "\n"); log.flush(); return
        if k == "tick":
            st = "dead" if pl.get("dead") else "alive"
            if st != last_state[0]:
                print(f"you are {st}"); last_state[0] = st
            n = sum((pl.get("writes") or {}).values())
            log.write(f"{time.strftime('%H:%M:%S')} {st:5s} pitch {pl.get('pitch')} heading {pl.get('heading')} writes {n}\n")
            for kk, v in (pl.get("writes") or {}).items():
                total[kk] += v
            log.flush()

    s = frida.get_local_device().attach(pid)
    sc = s.create_script(JS)
    sc.on("message", on_msg)
    sc.load()
    t_end = time.time() + SECS
    try:
        while time.time() < t_end:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    log.write("\n== writes (alive/dead | which changed | instruction after the write | calls that led there): count\n")
    for kk, v in total.most_common(80):
        log.write(f"{v:7d}  {kk}\n")
    log.close()
    try:
        sc.unload(); s.detach()
    except Exception:
        pass
    print(f"done: {OUT}")


if __name__ == "__main__":
    main()
