"""Which ground items a bot wants, and how much.

Ground items are named by their item file (agent: world().items, name without ".ITM"). What each one gives
comes from the g*.itm files in the game's .lab archives (PICKUP and COUNT fields), e.g. GAMBOXB gives 12
IBULLIT. Values are rough priorities. The brain divides them by distance to pick the best item.

A behaviour (brain.BEHAVIOURS) shifts them: `favorite` is the weapon slot it fights with first (its weapon and ammo
are worth more), `melee_only` makes guns and ammo worthless (the brawler).
"""
import math
import os

CLOSE_ONLY = bool(os.environ.get("BOT_DARK"))      # Dark Mode: no ranged weapons (set by horde.py --dark)
CLOSE_SLOTS = {4, 5, 6}                            # shotgun, double-barrel, sawed-off

# Ammo pickups: ground item -> ammo item it gives.
AMMO = {
    "GAMBOXB": "IBULLIT", "GAMBELT": "IBULLIT", "GBULLIT": "IBULLIT", "GSATCHEL": "IBULLIT",
    "GAMBOXC": "ICART", "GCART": "ICART",
    "GAMBOXS": "ISHELLS", "GSHELLS": "ISHELLS",
    "GCLIP": "ICLIP",
}
# GDROP1-6 (and the knife variants) drop bullets; GDROP7, 8, 9 and 99 drop rifle cartridges.
DROP_CART = {"GDROP7", "GDROP8", "GDROP9", "GDROP99"}
# Weapon pickups: ground item -> weapon slot. The sawed-off (GSAWGUN) is deliberately missing, and TNT is only
# wanted by a bot whose favourite it is (TNT_PICKUPS).
WEAPONS = {"GDBSGUN": 5, "GSGUN": 4, "GRIFLE": 3, "GGATGUN": 9, "GPISTOL": 2}
TNT_SLOT = 7
TNT_PICKUPS = {"GDYNAM": 1, "GAMBOXT": 10}   # ground item -> sticks (IDYNAM) it gives; GDYNAM is a stick lying
                                             # about (shot_ProjectileDispatch logic, but not lit)
MAX_TNT = 50
GOOD_SLOTS = {5, 4, 3, 9}         # the weapons worth fighting with
ARMOR = {"GBPLATE1": 150, "GBPLATE2": 100, "GBPLATE3": 50}   # boiler plates -> IBPLATE they give
ARMOR_VALUE = {150: 220.0, 100: 150.0, 50: 100.0}            # what each is worth with no armour (user: plates,
                                                             # the heavy one most, beat nearly everything)
HEALTH = {"GCANTEEN", "GELIXIR"}  # used on pickup, only taken when hurt
MEDBAG = "GDOCBAG"                # gives IDOCBAG (3 uses, max 15), kept and used later with USE
KNIFE = "GKNIFE"                  # slot 8: the only weapon that works under water. Its value comes from the
KNIFE_SLOT = 8                    # brain (`knife`): nothing on a dry map, more on a map with water.
MAX_HEALTH = 10.0
MAX_ARMOR = 150
MAX_MEDBAGS = 15


def ammo_given(name):
    if name in AMMO:
        return AMMO[name]
    if name.startswith("GDROP"):
        return "ICART" if name in DROP_CART else "IBULLIT"
    return None


def ammo_need(inventory, ammo, favorite=None):
    """How badly we need this ammo type: 0 (useless) .. 50 (nearly out for a good weapon), 75 for our favourite."""
    best = 0.0
    for w in inventory["weapons"]:
        if w["ammo"] != ammo:
            continue
        total = w["loaded"] + (w["reserve"] or 0)
        clip = max(w["capacity"], 1)
        need = 50 if total <= clip else 30 if total <= 3 * clip else 8
        if w["slot"] == favorite:
            need *= 1.5
        elif w["slot"] not in GOOD_SLOTS:
            need *= 0.5                   # pistol ammo matters less
        best = max(best, need)
    return best or 2.0                    # ammo for a gun we don't have yet: barely worth a detour


def tnt_count(inventory):
    """Sticks of TNT we carry (the IDYNAM count; it's its own ammo)."""
    carried = (inventory.get("carried") or {}).get("IDYNAM")
    if carried is not None:
        return carried
    w = next((w for w in inventory["weapons"] if w["slot"] == TNT_SLOT), None)
    return 0 if w is None else w["loaded"] + (w["reserve"] or 0)


def armor_value(name, inventory):
    """What a boiler plate is worth: its ARMOR_VALUE, down to 40% of that when we already have most of what it
    gives, and nothing at full armour."""
    amount = ARMOR[name]
    missing = MAX_ARMOR - (inventory.get("armor") or 0)
    if missing <= 0:
        return 0.0
    return ARMOR_VALUE[amount] * (0.4 + 0.6 * min(1.0, missing / amount))


def value(item, inventory, health, knife=0.0, favorite=None, melee_only=False, sawed=True):
    """How much we want this item right now (0 = leave it). `knife` is what a knife is worth while we have none;
    `favorite` and `melee_only` come from the bot's behaviour."""
    name = item["name"]
    owned = {w["slot"] for w in inventory["weapons"]}
    if name == KNIFE:
        return 0.0 if KNIFE_SLOT in owned else knife
    if name.startswith("GBADGE"):                 # only seen as an item without Marshall Law (botctl --no-marshall-law)
        return 0.0 if inventory.get("hasBadge") else 260.0     # huge damage boost and damage reduction: beats even a heavy plate (220)
    if "POTION" in name:                # the invisible cream: not wanted under Marshall Law (sawed is False then)
        return 60.0 if sawed else 0.0
    if name in TNT_PICKUPS:
        if favorite != TNT_SLOT:
            return 0.0
        sticks = tnt_count(inventory)
        return 0.0 if sticks >= MAX_TNT else 90.0 if sticks == 0 else 45.0 if sticks < 5 else 10.0
    if melee_only and (name in WEAPONS or ammo_given(name)):
        return 0.0
    if CLOSE_ONLY:                                  # Dark Mode: shotguns and their shells only (and the knife, above)
        if name in WEAPONS and WEAPONS[name] not in CLOSE_SLOTS:
            return 0.0
        if ammo_given(name) not in (None, "ISHELLS"):
            return 0.0
    if "SAW" in name and not sawed:         # Marshall Law: nobody uses the sawed-off, so it isn't worth a step
        return 0.0
    if name in WEAPONS or "SAW" in name:       # the sawed-off's ground name isn't known for sure: anything with SAW in it
        slot = WEAPONS.get(name, 6)
        if slot not in owned:
            return 120.0 if slot == favorite else 90.0 if slot in GOOD_SLOTS else 15.0
        weapon = next(w for w in inventory["weapons"] if w["slot"] == slot)
        return 0.6 * ammo_need(inventory, weapon["ammo"], favorite) if weapon["ammo"] else 0.0
    ammo = ammo_given(name)
    if ammo:
        return ammo_need(inventory, ammo, favorite)
    if name in ARMOR:
        return armor_value(name, inventory)
    if name in HEALTH and health is not None and health < MAX_HEALTH:
        return 80.0 * (1 - health / MAX_HEALTH) + (20.0 if health < 5 else 0.0)
    if name == MEDBAG:
        bags = inventory.get("carried", {}).get("IDOCBAG") or 0
        if bags >= MAX_MEDBAGS:
            return 0.0
        return (40.0 if bags == 0 else 12.0) + (30.0 if health is not None and health < 5 else 0.0)
    return 0.0


def desperate(inventory, melee_only=False):
    """True when we have nothing good to fight with: no usable good weapon, and little pistol ammo. Never for a
    bot that only fights hand to hand."""
    if melee_only:
        return False
    for w in inventory["weapons"]:
        total = w["loaded"] + (w["reserve"] or 0)
        if w["slot"] in (CLOSE_SLOTS if CLOSE_ONLY else GOOD_SLOTS) and total > 0:
            return False
        if w["slot"] == 2 and total >= 6 and not CLOSE_ONLY:
            return False
    return True


# Handover step 5: gates an item has to pass before it is even scored.
SEE_RANGE = 67.0                  # only items within this straight distance ...
SEE_HEIGHT = 8.0                  # ... and this far up or down
ROUTE_MAX = 167.0                 # ... and no further than this by route
HEALTH_BELOW = 7.0                # health items only when hurt below 70% (health is of 10)
AMMO_NEAR = 27.0                  # ammo: when under half full, or anything this near


def ammo_fraction(inventory, ammo):
    """Fullest share of its capacity we hold of this ammo for any gun that uses it (1.0 when we have no such gun)."""
    best = None
    for w in inventory["weapons"]:
        if w["ammo"] != ammo:
            continue
        cap = max(w["capacity"], 1)
        frac = (w["loaded"] + (w["reserve"] or 0)) / (cap * 4.0)     # reserve is carried in clips: ~4 clips full
        best = frac if best is None else max(best, frac)
    return 1.0 if best is None else min(best, 1.0)


def passes_gates(it, me, inventory, route):
    flat = math.hypot(it["x"] - me["x"], it["z"] - me["z"])
    if flat > SEE_RANGE or abs(it["y"] - me["y"]) > SEE_HEIGHT or route > ROUTE_MAX:
        return False
    name = it["name"]
    health = me.get("health")
    if name in HEALTH and health is not None and health >= HEALTH_BELOW:
        return False
    ammo = ammo_given(name)
    if ammo and flat > AMMO_NEAR and ammo_fraction(inventory, ammo) >= 0.5:
        return False
    return True


def pick(items, me, inventory, badges, ignored, now, cost=None, max_climb=3.0, max_drop=6.0, badge_margin=8.0,
         knife=0.0, favorite=None, melee_only=False, sawed=True, weapon_limit=None, supply_limit=None, gates=True):
    """Best item to go for, or None. `cost(addr)` gives the walking distance along a route (None when
    unreachable). Without it, items too far above or below us are skipped and straight-line distance is
    used. Items near a badge and items we recently gave up on are skipped either way."""
    best, best_score = None, 0.0
    for it in items:
        if ignored.get(it["addr"], 0) > now:
            continue
        if cost is None:
            dy = it["y"] - me["y"]
            if dy > max_climb or dy < -max_drop:
                continue
            d = math.hypot(it["x"] - me["x"], it["z"] - me["z"])
        else:
            d = cost(it["addr"])
            if d is None:
                continue
        if any(math.hypot(it["x"] - b["x"], it["z"] - b["z"]) < badge_margin for b in badges):
            continue
        if weapon_limit is not None and (it["name"] in WEAPONS or "SAW" in it["name"]) and d > weapon_limit:
            continue                       # a bot down to its pistol dies on a long walk: a closer weapon will turn up
        if supply_limit is not None and (it["name"] in ARMOR or it["name"] == MEDBAG) and d > supply_limit:
            continue                       # plates and medbags far across the map cost more lives than they save
        if gates and not passes_gates(it, me, inventory, d):
            continue
        v = value(it, inventory, me.get("health"), knife, favorite, melee_only, sawed)
        if v <= 0:
            continue
        score = v / (d + 15.0)
        if score > best_score:
            best, best_score = dict(it, value=v, dist=d), score
    return best
