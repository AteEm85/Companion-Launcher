@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File stop_tests.ps1
