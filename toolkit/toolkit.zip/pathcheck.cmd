@echo off
rem Pathing check on every map; see pathcheck.py. Example: pathcheck.cmd --minutes 2 --maps hargrove fort
cd /d "%~dp0"
".venv\Scripts\python.exe" pathcheck.py %*
pause
