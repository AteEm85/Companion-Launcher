@echo off
rem Look-while-dead probe, round 2 (watches only, changes nothing).
rem 1. Start a game and get into the match.  2. Double-click this file (4 minutes).
rem 3. Die a few times; while dead move the mouse up and down. Also move it up and down while alive.
rem 4. When it says "done", tell Claude. The result is in state\lookprobe2.txt.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u lookprobe2.py %*
pause
