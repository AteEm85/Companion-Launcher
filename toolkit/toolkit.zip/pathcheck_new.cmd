@echo off
rem Two-minute pathing check on the maps not done yet; progress goes to pathcheck_run.txt, pathcheck_done.txt appears at the end.
cd /d "%~dp0"
del pathcheck_done.txt >nul 2>&1
".venv\Scripts\python.exe" -u pathcheck.py --minutes 2 --maps civpow2 drygulch fort granary mltsimms orleans thudtowr wilderns > pathcheck_run.txt 2>&1
echo finished > pathcheck_done.txt
