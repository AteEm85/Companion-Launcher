"""Dark Mode map items: no ranged weapons lying about.
Writes loose copies of the map's object lists (<map>.obt text and <map>.obb compiled) into the game folder with
  rifles, pistols             -> a shotgun or a double-barrel
  gatling guns                -> a knife or a stick of TNT
  rifle cartridges            -> a box of TNT, a stick of TNT or a knife
  rifle scopes, pistol ammo, gatling clips -> shotgun shells (or a knife)
Nothing in the game's archives is touched: restore() deletes the loose copies again (horde.py does it when the game ends, and
at the start of the next one in case of a crash). A loose file of the same name that was already there is never overwritten.
  python darkitems.py on <map> | off | status"""
import os, sys, re, json, random, hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
GAME = HERE.parent
STATE = HERE / "state" / "darkitems.json"
sys.path.insert(0, str(HERE))

# placed object (N...) and ground item (G...) names -> the choices that replace them
SHOTGUNS = ["NSGUN1", "NDBSGUN1", "NDBSGUN1"]
MELEE = ["NKNIFE1", "NDYNAM1"]
SWAP = {
    "NRIFLE1": SHOTGUNS, "NHRIFLE1": SHOTGUNS, "NPISTOL1": SHOTGUNS,
    "NGATGUN": MELEE,
    "NAMBOXC1": ["NAMBOXT1", "NDYNAM1", "NKNIFE1"],
    "NAMBOXB1": ["NAMBOXS1"], "NAMBELT1": ["NAMBOXS1"], "NCLIP": ["NAMBOXS1", "NKNIFE1"], "NSCOPE": ["NAMBOXS1"],
}
SWAP.update({k.replace("N", "G", 1): [v.replace("N", "G", 1) for v in vs] for k, vs in list(SWAP.items())
             if k not in ("NAMBOXC1", "NAMBOXB1", "NAMBELT1")})
SWAP.update({"GAMBOXC": ["GAMBOXT", "GDYNAM", "GKNIFE"], "GAMBOXB": ["GAMBOXS"], "GAMBELT": ["GAMBOXS"],
             "GSATCHEL": ["GAMBOXS"], "GRIFLE": ["GSGUN", "GDBSGUN"], "GPISTOL": ["GSGUN"], "GGATGUN": ["GKNIFE", "GDYNAM"]})


# Melee Zombies (horde.py --melee): every ammo box but the TNT boxes becomes a knife, a stick of TNT or a canteen, at random.
# The guns stay.
_AMMO_N = ["NAMBELT1", "NAMBOXB1", "NAMBOXC1", "NAMBOXS1", "NCLIP"]          # boxes of TNT stay as they are
_AMMO_G = ["GAMBELT", "GAMBOXB", "GAMBOXC", "GAMBOXS", "GCLIP"]
AMMO_SWAP = {**{k: ["NKNIFE1", "NDYNAM1", "NCANTEE1"] for k in _AMMO_N}, **{k: ["GKNIFE", "GDYNAM", "GCANTEEN"] for k in _AMMO_G}}

# Every gun, TNT and every kind of ammo becomes a knife (not used now; patch(mode="knives")).
_MELEE_N = ["NRIFLE1", "NHRIFLE1", "NPISTOL1", "NGATGUN", "NSGUN1", "NDBSGUN1", "NSAWGUN1", "NDYNAM1",
            "NAMBELT1", "NAMBOXB1", "NAMBOXC1", "NAMBOXS1", "NAMBOXT", "NAMBOXT1", "NCLIP", "NSCOPE"]
_MELEE_G = ["GRIFLE", "GHRIFLE", "GPISTOL", "GGATGUN", "GSGUN", "GDBSGUN", "GSAWGUN", "GDYNAM",
            "GAMBELT", "GAMBOXB", "GAMBOXC", "GAMBOXS", "GAMBOXT", "GCLIP", "GSCOPE", "GSATCHEL", "GBULLIT", "GCART", "GSHELLS"]
MELEE_SWAP = {**{k: ["NKNIFE1"] for k in _MELEE_N}, **{k: ["GKNIFE"] for k in _MELEE_G}}


def _text(data, table=None):
    table = SWAP if table is None else table
    if not table:
        return data, 0
    n = [0]
    pat = re.compile(rb"(NAME:\s+)(" + b"|".join(re.escape(k.encode()) for k in sorted(table, key=len, reverse=True)) + rb")(\s)")
    def sub(m):
        n[0] += 1
        return m.group(1) + random.choice(table[m.group(2).decode()]).encode() + m.group(3)
    return pat.sub(sub, data), n[0]


def _binary(data, table=None):
    table = SWAP if table is None else table
    if not table:
        return data, 0
    n = [0]
    pat = re.compile(rb"\x0b(" + b"|".join(re.escape(k.encode()) for k in sorted(table, key=len, reverse=True)) + rb")\x00")
    def sub(m):
        n[0] += 1
        return b"\x0b" + random.choice(table[m.group(1).decode()]).encode() + b"\x00"
    return pat.sub(sub, data), n[0]


def _lock_doors(text, names):
    """the INF with these doors locked: they run only on someone walking into their sector (EVENT_MASK 4, not a "use"), and their
    last stop TERMINATEs (once open they stay open)"""
    out, cur = [], None
    for line in text.splitlines(keepends=True):
        m = re.match(r"\s*ITEM:\s*SECTOR\s+NAME:\s*(\S+)", line)
        if m:
            cur = m.group(1).upper() if m.group(1).upper() in {n.upper() for n in names} else None
        elif cur and re.match(r"\s*EVENT_MASK:", line):
            line = re.sub(r"EVENT_MASK:\s*\d+", "EVENT_MASK: 4", line)
        elif cur and re.match(r"\s*SEQEND", line):
            for k in range(len(out) - 1, -1, -1):                 # the last stop: TERMINATE
                if re.match(r"\s*STOP:", out[k]):
                    out[k] = re.sub(r"\bHOLD\b", "TERMINATE", out[k]); break
            cur = None
        out.append(line)
    return "".join(out)


def _open_doors(text, names):
    """the INF with these doors gone for good: each starts at its open stop (an elevator is put at its first stop when the level
    starts) and nothing moves it again (EVENT_MASK 0, that one stop only)"""
    out, cur, stops = [], None, []
    for line in text.splitlines(keepends=True):
        m = re.match(r"\s*ITEM:\s*SECTOR\s+NAME:\s*(\S+)", line)
        if m:
            cur = m.group(1).upper() if m.group(1).upper() in {n.upper() for n in names} else None; stops = []
        elif cur and re.match(r"\s*EVENT_MASK:", line):
            line = re.sub(r"EVENT_MASK:\s*\d+", "EVENT_MASK: 0", line)
        elif cur and re.match(r"\s*STOP:", line):
            mv = re.match(r"(\s*STOP:\s*)(-?[\d.]+)", line)
            if mv: stops.append((abs(float(mv.group(2))), mv.group(1), mv.group(2), "\r\n" if line.endswith("\r\n") else "\n"))
            continue                                              # (written back at SEQEND: the open one only)
        elif cur and re.match(r"\s*SEQEND", line):
            if stops:
                _, pre, val, nl = max(stops)
                out.append(f"{pre}{val} HOLD{nl}")
            cur = None
        out.append(line)
    return "".join(out)


def _dead_lines(text, names):
    """the INF with these switches (ITEM: LINE) dead: nothing a player does to them sets anything off (EVENT_MASK 0) - the mission
    opens what they opened itself, when its step allows (Mission 1's warehouse gate)"""
    out, cur = [], False
    for line in text.splitlines(keepends=True):
        m = re.match(r"\s*ITEM:\s*(\w+)\s+NAME:\s*(\S+)", line)
        if m:
            cur = m.group(1).upper() == "LINE" and m.group(2).upper() in {n.upper() for n in names}
        elif cur and re.match(r"\s*EVENT_MASK:", line):
            line = re.sub(r"EVENT_MASK:\s*\d+", "EVENT_MASK: 0", line)
        out.append(line)
    return "".join(out)


def _near_any(x, z, pts):
    return any(abs(x - px) < 0.6 and abs(z - pz) < 0.6 for px, pz in pts)


def _drop_starts_text(data, pts):
    text = data.decode("latin-1"); nlc = "\r\n" if "\r\n" in text else "\n"; lines = text.split(nlc); out, k = [], 0
    for l in lines:
        m = re.match(r"^\s*NAME:\s+STARTPOS\b.*?X:\s*(\S+)\s+Y:\s*\S+\s+Z:\s*(\S+)", l)
        if m and _near_any(float(m.group(1)), float(m.group(2)), pts):
            k += 1; continue
        out.append(l)
    text = nlc.join(out)
    if k: text = re.sub(r"^OBJECTS (\d+)", lambda m: "OBJECTS %d" % (int(m.group(1)) - k), text, count=1, flags=re.M)
    return text.encode("latin-1"), k


def _drop_starts_binary(data, pts):
    import struct
    ms = list(_REC.finditer(data))
    if not ms or ms[0].start() < 4 or struct.unpack_from("<I", data, ms[0].start() - 4)[0] != len(ms):
        return data, 0
    for a, b in zip(ms, ms[1:]):
        if b.start() != a.end() + 40:
            return data, 0
    drop = set()
    for i, m in enumerate(ms):
        if m.group(1) == b"STARTPOS":
            x, y, z = struct.unpack_from("<3f", data, m.end() + 8)
            if _near_any(x, z, pts): drop.add(i)
    if not drop: return data, 0
    out = bytearray(data[:ms[0].start()])
    struct.pack_into("<I", out, ms[0].start() - 4, len(ms) - len(drop))
    for i, m in enumerate(ms):
        if i not in drop: out += data[m.start():m.end() + 40]
    out += data[ms[-1].end() + 40:]
    return bytes(out), len(drop)


def _load():
    try: return json.loads(STATE.read_text())
    except Exception: return {}


def restore():
    """Delete the loose files we wrote (only if they're still ours). True when none is left."""
    st = _load(); ok = True
    for name, digest in list(st.items()):
        p = GAME / name
        try:
            if p.exists() and hashlib.sha1(p.read_bytes()).hexdigest() == digest:
                p.unlink()
            st.pop(name)
        except OSError:
            ok = False
    try:
        if st: STATE.write_text(json.dumps(st))
        elif STATE.exists(): STATE.unlink()
    except OSError:
        pass
    return ok


def patch(map_key, log=print, mode="dark", mission=False, keep_others=False):
    """Write the swapped object lists for this map. Returns the number of objects swapped (0 = nothing written).
    mode='dark': Dark Mode's swaps (no ranged weapons). mode='melee': every ammo box becomes a knife, TNT or a canteen.
    mode='knives': every gun, TNT and ammo becomes a knife. mode='christmas': nothing swapped, Christmas trees added
    (christmas\\trees.json); christmas_melee: the trees and Melee Zombies' swaps."""
    table = {"melee": AMMO_SWAP, "knives": MELEE_SWAP, "christmas": {}, "christmas_melee": AMMO_SWAP, "halloween": {}}.get(mode, SWAP)
    trees = []
    if mode == "halloween":          # the Horde's Halloween props (zombie\halloween.json): jack-o'-lanterns, pumpkins, cobwebs
        try:
            trees = [tuple(t) for t in json.loads((HERE / "zombie" / "halloween.json").read_text()).get(map_key.lower(), [])]
        except (OSError, ValueError):
            trees = []
    if mode.startswith("christmas"):
        try:
            trees = [tuple(t) for t in json.loads((HERE / "christmas" / "trees.json").read_text()).get(map_key.lower(), [])]
        except (OSError, ValueError):
            trees = []
        if mission:      # a Co-op Mission: some trees knocked over, a wrecked sleigh, the red markers of a hold zone
            try:
                mp_ = json.loads((HERE / "christmas" / "mission_props.json").read_text()).get(map_key.lower())
                if mp_:
                    trees = [tuple(t) for t in mp_]
            except (OSError, ValueError):
                pass
        try:             # the lit wall textures swapped for their flashing copies (every wall using them, inside and out),
            import zombieskins                           # only when the Christmas files are there to go in the archive
            lights = zombieskins.available(True)         # (without them the walls would show the game's DEFAULT texture)
        except Exception:
            lights = False
        if not lights:
            log("christmas: no Christmas files: the walls keep their own textures")
    else:
        lights = False
    import lvt
    # keep_others (23 Nov): the later Co-op Missions' maps written as well, before the games start - the game only sees loose
    # files that were there when it started (the next mission's toys and Mrs. Claus's sleigh never showed when written later)
    if not keep_others:
        restore()
    st, total = (_load() if keep_others else {}), 0
    jobs = [("obt", _text), ("obb", _binary)]
    tweak = {}
    if mission:                                          # (missions.MAP_TWEAKS: locked doors, spawn points taken out)
        try:
            import missions
            tweak = missions.MAP_TWEAKS.get(map_key.lower(), {})
        except Exception:
            tweak = {}
        if tweak.get("lock_doors") or tweak.get("dead_lines") or tweak.get("open_doors"):
            jobs.append(("inf", lambda d, t: (_open_doors(_dead_lines(_lock_doors(d.decode("latin-1"), tweak.get("lock_doors", [])),
                                                                      tweak.get("dead_lines", [])), tweak.get("open_doors", [])), 0)))
    if lights:
        import xmaslights
        jobs += [("lvt", lambda d, t: xmaslights.flash_lvt(d.decode("latin-1"), map_key)),
                 ("lvb", lambda d, t: (xmaslights.flash_lvb(d, map_key), 0))]
    for ext, fn in jobs:
        name = f"{map_key}.{ext}"
        dest = GAME / name
        if any(p.name.lower() == name.lower() for p in GAME.iterdir() if p.is_file()):
            log(f"dark items: {name} already exists in the game folder; leaving it alone")
            continue
        data = lvt.read_from_labs(name.lower())
        if data is None:
            log(f"dark items: no {name} found for this map")
            continue
        new, n = fn(data, table)
        if ext in ("obt", "obb") and tweak.get("no_starts"):
            new, k_ = (_drop_starts_text if ext == "obt" else _drop_starts_binary)(new, tweak["no_starts"])
            if k_: log(f"mission: {name}: {k_} spawn points taken out"); n += k_
        if ext == "inf":
            if new is None or new == data.decode("latin-1"):
                log(f"mission: {name}: the doors to lock were not found"); continue
            new = new.encode("latin-1"); dest.write_bytes(new); st[name] = hashlib.sha1(new).hexdigest()
            log(f"mission: {name}: {', '.join(tweak.get('lock_doors', []) + tweak.get('dead_lines', []))} locked"
                + (f"; {', '.join(tweak['open_doors'])} gone (open for good)" if tweak.get("open_doors") else "")); continue
        if ext in ("lvt", "lvb"):
            if new is None:
                log(f"christmas: {name}: could not add the lights"); continue
            new = new.encode("latin-1") if isinstance(new, str) else new
            dest.write_bytes(new)
            st[name] = hashlib.sha1(new).hexdigest()
            log(f"christmas: {name}: flashing Christmas lights on the building walls")
            continue
        if trees:
            import xmastrees
            added = (xmastrees.add_text(new.decode("latin-1"), trees).encode("latin-1") if ext == "obt"
                     else xmastrees.add_binary(new, trees))
            if added is not None and added != new:
                new, n = added, n + len(trees)
                log(f"{mode}: {name}: {len(trees)} " + ("Halloween props" if mode == "halloween" else "Christmas trees"))
        if n:
            dest.write_bytes(new)
            st[name] = hashlib.sha1(new).hexdigest()
            total = max(total, n)
            log(f"{mode} items: {name}: {n} objects swapped")
    if st:
        STATE.parent.mkdir(exist_ok=True)
        STATE.write_text(json.dumps(st))
    return total


# Gun game: every weapon, ammo box and stick of TNT is taken off the map (the ladder hands them out); health and armor stay,
# and a boiler plate and a med bag are put in the very middle as bait.
_GUN_RE = re.compile(r"^N(RIFLE|HRIFLE|PISTOL|GATGUN|SGUN|DBSGUN|SAWGUN|DYNAM|KNIFE|AMBELT|AMBOX[A-Z]|CLIP|SCOPE|SATCHEL|BULLIT|CART|SHELLS)\d*$", re.I)
_ITEM_FLAGS = (0, 4026531840)
_REC = re.compile(rb"\x03\x00\x00\x00\x0b([A-Za-z0-9_]+)\x00")


def _gun_text(data):
    text = data.decode("latin-1")
    nlc = "\r\n" if "\r\n" in text else "\n"
    out, n = [], 0
    for line in text.split(nlc):
        m = re.match(r"^\s*NAME:\s+(\S+)\s+ID:", line)
        if m and _GUN_RE.match(m.group(1)):
            n += 1
            continue
        out.append(line)
    text = nlc.join(out)
    text = re.sub(r"^OBJECTS (\d+)", lambda m: "OBJECTS %d" % (int(m.group(1)) - n), text, count=1, flags=re.M)
    return text.encode("latin-1"), n


def _gun_binary(data):
    """The compiled list: records '03 00 00 00 0b NAME 00' + 40 bytes, back to back, the count just before the first.
    Only touched when the layout is exactly that."""
    import struct
    ms = list(_REC.finditer(data))
    if not ms or ms[0].start() < 4:
        return data, 0
    for a, b in zip(ms, ms[1:]):
        if b.start() != a.end() + 40:
            return data, 0
    if struct.unpack_from("<I", data, ms[0].start() - 4)[0] != len(ms):
        return data, 0
    keep = [m for m in ms if not _GUN_RE.match(m.group(1).decode())]
    gone = len(ms) - len(keep)
    if not gone:
        return data, 0
    out = bytearray(data[:ms[0].start()])
    struct.pack_into("<I", out, ms[0].start() - 4, len(keep))
    for m in keep:
        out += data[m.start():m.end() + 40]
    out += data[ms[-1].end() + 40:]
    return bytes(out), gone


def _centre(map_key, lvt_text):
    """(sector id, x, y, z) of the middle of the map's play area (the spawn points' centre), or None."""
    import lvt
    ids = [int(m.group(1), 16) for m in re.finditer(r"^SECTOR\s+([0-9A-Fa-f]+)\s+#", lvt_text, re.M)]
    secs = lvt.parse(lvt_text)
    if not secs or len(ids) != len(secs):
        return None
    return secs, ids


def _bait(map_key, lvt_bytes, obt_text):
    import math
    got = _centre(map_key, lvt_bytes.decode("latin-1"))
    if got is None:
        return []
    secs, ids = got
    pts = [(float(m.group(1)), float(m.group(2))) for m in re.finditer(r"NAME:\s+STARTPOS\b.*?X:\s*(\S+)\s+Y:\s*\S+\s+Z:\s*(\S+)", obt_text)]
    if not pts:
        xs = [v[0] for s in secs for v in s.vertices]; zs = [v[1] for s in secs for v in s.vertices]
        pts = [((min(xs) + max(xs)) / 2, (min(zs) + max(zs)) / 2)]
    cx, cz = sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)
    def ok(s):
        return s.vertices and s.ceiling - s.floor >= 6.0 and len(s.walls) >= 3
    best = None
    for s in secs:
        if ok(s) and s.contains(cx, cz):
            best = s; break
    if best is None:
        cand = [s for s in secs if ok(s)]
        def d(s):
            sx = sum(v[0] for v in s.vertices) / len(s.vertices); sz = sum(v[1] for v in s.vertices) / len(s.vertices)
            return math.hypot(sx - cx, sz - cz)
        best = min(cand, key=d) if cand else None
        if best is None:
            return []
        cx, cz = sum(v[0] for v in best.vertices) / len(best.vertices), sum(v[1] for v in best.vertices) / len(best.vertices)
        if not best.contains(cx, cz):
            return []
    sid = ids[best.index]
    y = best.floor
    spots = [(cx - 1.5, cz), (cx + 1.5, cz)]
    if not all(best.contains(x, z) for x, z in spots):
        spots = [(cx, cz), (cx, cz)]
    return [("NBPLATE1", sid, spots[0][0], y, spots[0][1]), ("NDOCBAG1", sid, spots[1][0], y, spots[1][1])]


def patch_gungame(map_key, log=print):
    """Loose copies of the map's object lists without weapons, ammo or TNT, with a boiler plate and a med bag in the middle.
    restore() puts the map back. Returns the number of objects removed (0 = nothing written)."""
    import lvt
    restore()
    lv = lvt.read_from_labs(map_key + ".lvt")
    st, total, added = {}, 0, []
    for ext in ("obt", "obb"):
        name = f"{map_key}.{ext}"
        if any(p.name.lower() == name.lower() for p in GAME.iterdir() if p.is_file()):
            log(f"gun game items: {name} already exists in the game folder; leaving it alone")
            continue
        data = lvt.read_from_labs(name.lower())
        if data is None:
            log(f"gun game items: no {name} found for this map")
            continue
        new, n = (_gun_text if ext == "obt" else _gun_binary)(data)
        if lv is not None and not added:
            try:
                added = _bait(map_key, lv, data.decode("latin-1") if ext == "obt" else (lvt.read_from_labs(map_key + ".obt") or b"").decode("latin-1"))
            except Exception as e:
                log(f"gun game items: no bait: {e}")
        if added:
            import xmastrees
            more = (xmastrees.add_text(new.decode("latin-1"), added, flags=_ITEM_FLAGS, keep_case=True).encode("latin-1")
                    if ext == "obt" else xmastrees.add_binary(new, added, flags=_ITEM_FLAGS, keep_case=True))
            if more is not None and more != new:
                new = more
                n += 0
                log(f"gun game items: {name}: {', '.join(a[0] for a in added)} in the middle")
        if new != data:
            (GAME / name).write_bytes(new)
            st[name] = hashlib.sha1(new).hexdigest()
            total = max(total, n)
            log(f"gun game items: {name}: {n} weapons, ammo and TNT removed")
    if st:
        STATE.parent.mkdir(exist_ok=True)
        STATE.write_text(json.dumps(st))
    return total


# Juggernaut: every Gatling gun (the generators NGATGUN and the ground guns GGATGUN) is taken off the map except ONE random one,
# which stays as a plain ground GGATGUN, drawn gold (silvergat.py): whoever picks it up is the first Juggernaut. It is a plain ground item,
# so nothing generates it again. A map without a Gatling gets the silver one in the middle.
_GAT_RE = re.compile(r"^[NG]GATGUN\d*$", re.I)
_NOPE_RE = re.compile(r"^[NG](AMBELT|AMBOX[A-Z]|CLIP|BULLIT|CART|SHELLS|SATCHEL|BPLATE)\d*$", re.I)   # ammo and boiler plates: gone in Juggernaut
SILVER = "GGATGUN"          # the one left keeps the game's own name (always as a ground gun, never the generator); its sprite is the gold one


def _jug_text(data, frac, keep_one=True):
    text = data.decode("latin-1")
    nlc = "\r\n" if "\r\n" in text else "\n"
    lines = text.split(nlc)
    idx = [i for i, l in enumerate(lines) if (m := re.match(r"^\s*NAME:\s+(\S+)\s+ID:", l)) and _GAT_RE.match(m.group(1))]
    nope = [i for i, l in enumerate(lines) if (m := re.match(r"^\s*NAME:\s+(\S+)\s+ID:", l)) and _NOPE_RE.match(m.group(1))]
    if not idx and not nope:
        return data, 0, 0
    keep = idx[min(int(frac * len(idx)), len(idx) - 1)] if (keep_one and idx) else -1
    out = []
    for i, l in enumerate(lines):
        if i in nope:
            continue
        if i in idx:
            if i != keep:
                continue
            l = re.sub(r"(NAME:\s+)\S+", lambda m: m.group(1) + SILVER, l, count=1)
        out.append(l)
    text = nlc.join(out)
    text = re.sub(r"^OBJECTS (\d+)", lambda m: "OBJECTS %d" % (int(m.group(1)) - len(idx) - len(nope) + (1 if keep >= 0 else 0)), text, count=1, flags=re.M)
    return text.encode("latin-1"), len(idx), 1


def _jug_binary(data, frac, keep_one=True):
    import struct
    ms = list(_REC.finditer(data))
    if not ms or ms[0].start() < 4:
        return data, 0, 0
    for a, b in zip(ms, ms[1:]):
        if b.start() != a.end() + 40:
            return data, 0, 0
    if struct.unpack_from("<I", data, ms[0].start() - 4)[0] != len(ms):
        return data, 0, 0
    gat = [i for i, m in enumerate(ms) if _GAT_RE.match(m.group(1).decode())]
    nope = {i for i, m in enumerate(ms) if _NOPE_RE.match(m.group(1).decode())}
    if not gat and not nope:
        return data, 0, 0
    keep = gat[min(int(frac * len(gat)), len(gat) - 1)] if (keep_one and gat) else -1
    out = bytearray(data[:ms[0].start()])
    struct.pack_into("<I", out, ms[0].start() - 4, len(ms) - len(gat) - len(nope) + (1 if keep >= 0 else 0))
    for i, m in enumerate(ms):
        if i in nope or (i in gat and i != keep):
            continue
        if i == keep:
            out += data[m.start():m.start() + 4] + b"\x0b" + SILVER.encode() + b"\x00" + data[m.end():m.end() + 40]
        else:
            out += data[m.start():m.end() + 40]
    out += data[ms[-1].end() + 40:]
    return bytes(out), len(gat), 1


def _area(s):
    v = s.vertices
    return abs(sum(v[i][0] * v[(i + 1) % len(v)][1] - v[(i + 1) % len(v)][0] * v[i][1] for i in range(len(v)))) / 2.0


def _near_wall(s, x, z):
    """Distance from (x, z) to the nearest wall of the sector."""
    best = 1e9
    for w in s.walls:
        (x1, z1), (x2, z2) = s.vertices[w.v1], s.vertices[w.v2]
        dx, dz = x2 - x1, z2 - z1
        t = 0.0 if not (dx or dz) else max(0.0, min(1.0, ((x - x1) * dx + (z - z1) * dz) / (dx * dx + dz * dz)))
        best = min(best, ((x - x1 - t * dx) ** 2 + (z - z1 - t * dz) ** 2) ** 0.5)
    return best


def _random_spot(map_key, lv_bytes, obt_text, avoid, rng=random):
    """(sector id, x, y, z) of a random place that can be walked to from the spawn points, clear of the walls and at least
    60 units (then 40, 25) from every spot in `avoid` ([(x, z)]: where the map's own Gatling guns were). None when nothing fits."""
    got = _centre(map_key, lv_bytes.decode("latin-1"))
    if got is None:
        return None
    secs, ids = got
    try:
        import nav
        no_go, water = set(nav.NO_GO.get(map_key.lower(), ())), nav.WATER
    except Exception:
        no_go, water = set(), 0x80
    starts = {int(m.group(1), 16) for m in re.finditer(r"NAME:\s+STARTPOS\b.*?SECTOR:\s*([0-9A-Fa-f]+)", obt_text)}
    seen = [i for i, sid in enumerate(ids) if sid in starts]
    if not seen:
        seen = list(range(len(secs)))
    todo, reach = list(seen), set(seen)
    while todo:                                                   # the sectors a player can walk or jump (4.5) up to from there
        a = secs[todo.pop()]
        for w in a.walls:
            b = w.adjoin
            if 0 <= b < len(secs) and b not in reach and b not in no_go:
                sb = secs[b]
                if sb.floor - a.floor <= 4.5 and min(sb.ceiling, a.ceiling) - max(sb.floor, a.floor) >= 4.0 and not sb.flags & water:
                    reach.add(b); todo.append(b)
    cand = [secs[i] for i in sorted(reach) if i not in no_go and secs[i].vertices and secs[i].floor_slope is None
            and secs[i].ceiling - secs[i].floor >= 6.0 and not secs[i].flags & water and len(secs[i].walls) >= 3 and _area(secs[i]) >= 40]
    if not cand:
        return None
    weights = [_area(c) for c in cand]
    for far in (60.0, 40.0, 25.0, 0.0):
        for _ in range(400):
            s = rng.choices(cand, weights)[0]
            xs = [v[0] for v in s.vertices]; zs = [v[1] for v in s.vertices]
            x, z = rng.uniform(min(xs), max(xs)), rng.uniform(min(zs), max(zs))
            if s.contains(x, z) and _near_wall(s, x, z) >= 3.0 and all((x - ax) ** 2 + (z - az) ** 2 >= far * far for ax, az in avoid):
                return ids[s.index], round(x, 2), s.floor, round(z, 2)
    return None


def patch_juggernaut(map_key, log=print):
    """Loose copies of the map's object lists with every Gatling gun taken off and ONE put in a random place that is walkable from
    the spawn points and at least 60 units from where the map's own Gatling guns were (drawn gold: silvergat.py).
    If no such place is found, one of the map's own Gatling guns is left where it was (or one is put in the middle when it has none).
    restore() puts the map back. Returns the number of Gatling guns found or -1 when nothing was written."""
    import lvt
    restore()
    lv = lvt.read_from_labs(map_key + ".lvt")
    otxt = (lvt.read_from_labs(map_key + ".obt") or b"").decode("latin-1")
    avoid = [(float(m.group(1)), float(m.group(2))) for m in re.finditer(
        r"NAME:\s+[NG]GATGUN\d*\s+ID:.*?X:\s*(\S+)\s+Y:\s*\S+\s+Z:\s*(\S+)", otxt, re.I)]
    spot = None
    if lv is not None:
        try:
            spot = _random_spot(map_key, lv, otxt, avoid)
        except Exception as e:
            log(f"juggernaut items: no random place ({e})")
    if spot:
        log(f"juggernaut items: the gold Gatling is at sector {spot[0]:X} ({spot[1]}, {spot[3]})")
    frac = random.random()
    st, found, wrote = {}, 0, False
    for ext in ("obt", "obb"):
        name = f"{map_key}.{ext}"
        if any(p.name.lower() == name.lower() for p in GAME.iterdir() if p.is_file()):
            log(f"juggernaut items: {name} already exists in the game folder; leaving it alone")
            continue
        data = lvt.read_from_labs(name.lower())
        if data is None:
            log(f"juggernaut items: no {name} found for this map")
            continue
        new, n, k = (_jug_text if ext == "obt" else _jug_binary)(data, frac, keep_one=not spot)
        add = []
        if spot:
            add = [(SILVER,) + tuple(spot)]
        elif not n and not found and lv is not None:
            try:
                b = _bait(map_key, lv, otxt)
                if b:
                    add = [(SILVER,) + tuple(b[0][1:])]
                    log(f"juggernaut items: {name}: no Gatling on this map, the gold one is in the middle")
            except Exception as e:
                log(f"juggernaut items: could not add a Gatling: {e}")
        if add:
            import xmastrees
            more = (xmastrees.add_text(new.decode("latin-1"), add, flags=_ITEM_FLAGS, keep_case=True).encode("latin-1")
                    if ext == "obt" else xmastrees.add_binary(new, add, flags=_ITEM_FLAGS, keep_case=True))
            if more is not None:
                new = more
            else:
                log(f"juggernaut items: could not add the Gatling to {name}")
        found = max(found, n)
        if new != data:
            (GAME / name).write_bytes(new)
            st[name] = hashlib.sha1(new).hexdigest()
            wrote = True
            log(f"juggernaut items: {name}: {n} Gatling guns found, one gold one {'moved' if spot else 'left'}")
    if st:
        STATE.parent.mkdir(exist_ok=True)
        STATE.write_text(json.dumps(st))
    return found if wrote else -1


if __name__ == "__main__":
    c = sys.argv[1] if len(sys.argv) > 1 else "status"
    if c == "on": patch(sys.argv[2])
    elif c == "melee": patch(sys.argv[2], mode="melee")
    elif c == "christmas": patch(sys.argv[2], mode="christmas")
    elif c == "gungame": print(patch_gungame(sys.argv[2]))
    elif c == "jug": print(patch_juggernaut(sys.argv[2]))
    elif c == "off": print("removed" if restore() else "could not remove everything")
    else: print(_load() or "nothing installed")
