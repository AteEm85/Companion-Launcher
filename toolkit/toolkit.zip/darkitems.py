"""Dark Mode map items: no ranged weapons lying about.
Writes loose copies of the map's object lists (<map>.obt text and <map>.obb compiled) into the game folder with
  rifles, pistols             -> a shotgun or a double-barrel
  gatling guns                -> a knife or a stick of TNT
  rifle cartridges            -> a box of TNT, a stick of TNT or a knife
  rifle scopes, pistol ammo, gatling clips -> shotgun shells (or a knife)
Nothing in the game's archives is touched: restore() deletes the loose copies again (horde.py does it when the game ends, and
at the start of the next one in case of a crash). A loose file of the same name that was already there is never overwritten.
  python darkitems.py on <map> | off | status"""
import os, sys, re, json, random, hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
GAME = HERE.parent
STATE = HERE / "state" / "darkitems.json"
sys.path.insert(0, str(HERE))

# placed object (N...) and ground item (G...) names -> the choices that replace them
SHOTGUNS = ["NSGUN1", "NDBSGUN1", "NDBSGUN1"]
MELEE = ["NKNIFE1", "NDYNAM1"]
SWAP = {
    "NRIFLE1": SHOTGUNS, "NHRIFLE1": SHOTGUNS, "NPISTOL1": SHOTGUNS,
    "NGATGUN": MELEE,
    "NAMBOXC1": ["NAMBOXT1", "NDYNAM1", "NKNIFE1"],
    "NAMBOXB1": ["NAMBOXS1"], "NAMBELT1": ["NAMBOXS1"], "NCLIP": ["NAMBOXS1", "NKNIFE1"], "NSCOPE": ["NAMBOXS1"],
}
SWAP.update({k.replace("N", "G", 1): [v.replace("N", "G", 1) for v in vs] for k, vs in list(SWAP.items())
             if k not in ("NAMBOXC1", "NAMBOXB1", "NAMBELT1")})
SWAP.update({"GAMBOXC": ["GAMBOXT", "GDYNAM", "GKNIFE"], "GAMBOXB": ["GAMBOXS"], "GAMBELT": ["GAMBOXS"],
             "GSATCHEL": ["GAMBOXS"], "GRIFLE": ["GSGUN", "GDBSGUN"], "GPISTOL": ["GSGUN"], "GGATGUN": ["GKNIFE", "GDYNAM"]})


# Melee Zombies (horde.py --melee): every ammo box but the TNT boxes becomes a knife, a stick of TNT or a canteen, at random.
# The guns stay.
_AMMO_N = ["NAMBELT1", "NAMBOXB1", "NAMBOXC1", "NAMBOXS1", "NCLIP"]          # boxes of TNT stay as they are
_AMMO_G = ["GAMBELT", "GAMBOXB", "GAMBOXC", "GAMBOXS", "GCLIP"]
AMMO_SWAP = {**{k: ["NKNIFE1", "NDYNAM1", "NCANTEE1"] for k in _AMMO_N}, **{k: ["GKNIFE", "GDYNAM", "GCANTEEN"] for k in _AMMO_G}}

# Every gun, TNT and every kind of ammo becomes a knife (not used now; patch(mode="knives")).
_MELEE_N = ["NRIFLE1", "NHRIFLE1", "NPISTOL1", "NGATGUN", "NSGUN1", "NDBSGUN1", "NSAWGUN1", "NDYNAM1",
            "NAMBELT1", "NAMBOXB1", "NAMBOXC1", "NAMBOXS1", "NAMBOXT", "NAMBOXT1", "NCLIP", "NSCOPE"]
_MELEE_G = ["GRIFLE", "GHRIFLE", "GPISTOL", "GGATGUN", "GSGUN", "GDBSGUN", "GSAWGUN", "GDYNAM",
            "GAMBELT", "GAMBOXB", "GAMBOXC", "GAMBOXS", "GAMBOXT", "GCLIP", "GSCOPE", "GSATCHEL", "GBULLIT", "GCART", "GSHELLS"]
MELEE_SWAP = {**{k: ["NKNIFE1"] for k in _MELEE_N}, **{k: ["GKNIFE"] for k in _MELEE_G}}


def _text(data, table=None):
    table = SWAP if table is None else table
    if not table:
        return data, 0
    n = [0]
    pat = re.compile(rb"(NAME:\s+)(" + b"|".join(re.escape(k.encode()) for k in sorted(table, key=len, reverse=True)) + rb")(\s)")
    def sub(m):
        n[0] += 1
        return m.group(1) + random.choice(table[m.group(2).decode()]).encode() + m.group(3)
    return pat.sub(sub, data), n[0]


def _binary(data, table=None):
    table = SWAP if table is None else table
    if not table:
        return data, 0
    n = [0]
    pat = re.compile(rb"\x0b(" + b"|".join(re.escape(k.encode()) for k in sorted(table, key=len, reverse=True)) + rb")\x00")
    def sub(m):
        n[0] += 1
        return b"\x0b" + random.choice(table[m.group(1).decode()]).encode() + b"\x00"
    return pat.sub(sub, data), n[0]


def _load():
    try: return json.loads(STATE.read_text())
    except Exception: return {}


def restore():
    """Delete the loose files we wrote (only if they're still ours). True when none is left."""
    st = _load(); ok = True
    for name, digest in list(st.items()):
        p = GAME / name
        try:
            if p.exists() and hashlib.sha1(p.read_bytes()).hexdigest() == digest:
                p.unlink()
            st.pop(name)
        except OSError:
            ok = False
    try:
        if st: STATE.write_text(json.dumps(st))
        elif STATE.exists(): STATE.unlink()
    except OSError:
        pass
    return ok


def patch(map_key, log=print, mode="dark"):
    """Write the swapped object lists for this map. Returns the number of objects swapped (0 = nothing written).
    mode='dark': Dark Mode's swaps (no ranged weapons). mode='melee': every ammo box becomes a knife, TNT or a canteen.
    mode='knives': every gun, TNT and ammo becomes a knife."""
    table = {"melee": AMMO_SWAP, "knives": MELEE_SWAP}.get(mode, SWAP)
    import lvt
    restore()
    st, total = {}, 0
    for ext, fn in (("obt", _text), ("obb", _binary)):
        name = f"{map_key}.{ext}"
        dest = GAME / name
        if any(p.name.lower() == name.lower() for p in GAME.iterdir() if p.is_file()):
            log(f"dark items: {name} already exists in the game folder; leaving it alone")
            continue
        data = lvt.read_from_labs(name.lower())
        if data is None:
            log(f"dark items: no {name} found for this map")
            continue
        new, n = fn(data, table)
        if n:
            dest.write_bytes(new)
            st[name] = hashlib.sha1(new).hexdigest()
            total = max(total, n)
            log(f"{mode} items: {name}: {n} objects swapped")
    if st:
        STATE.parent.mkdir(exist_ok=True)
        STATE.write_text(json.dumps(st))
    return total


# Gun game: every weapon, ammo box and stick of TNT is taken off the map (the ladder hands them out); health and armor stay,
# and a boiler plate and a med bag are put in the very middle as bait.
_GUN_RE = re.compile(r"^N(RIFLE|HRIFLE|PISTOL|GATGUN|SGUN|DBSGUN|SAWGUN|DYNAM|KNIFE|AMBELT|AMBOX[A-Z]|CLIP|SCOPE|SATCHEL|BULLIT|CART|SHELLS)\d*$", re.I)
_ITEM_FLAGS = (0, 4026531840)
_REC = re.compile(rb"\x03\x00\x00\x00\x0b([A-Za-z0-9_]+)\x00")


def _gun_text(data):
    text = data.decode("latin-1")
    nlc = "\r\n" if "\r\n" in text else "\n"
    out, n = [], 0
    for line in text.split(nlc):
        m = re.match(r"^\s*NAME:\s+(\S+)\s+ID:", line)
        if m and _GUN_RE.match(m.group(1)):
            n += 1
            continue
        out.append(line)
    text = nlc.join(out)
    text = re.sub(r"^OBJECTS (\d+)", lambda m: "OBJECTS %d" % (int(m.group(1)) - n), text, count=1, flags=re.M)
    return text.encode("latin-1"), n


def _gun_binary(data):
    """The compiled list: records '03 00 00 00 0b NAME 00' + 40 bytes, back to back, the count just before the first.
    Only touched when the layout is exactly that."""
    import struct
    ms = list(_REC.finditer(data))
    if not ms or ms[0].start() < 4:
        return data, 0
    for a, b in zip(ms, ms[1:]):
        if b.start() != a.end() + 40:
            return data, 0
    if struct.unpack_from("<I", data, ms[0].start() - 4)[0] != len(ms):
        return data, 0
    keep = [m for m in ms if not _GUN_RE.match(m.group(1).decode())]
    gone = len(ms) - len(keep)
    if not gone:
        return data, 0
    out = bytearray(data[:ms[0].start()])
    struct.pack_into("<I", out, ms[0].start() - 4, len(keep))
    for m in keep:
        out += data[m.start():m.end() + 40]
    out += data[ms[-1].end() + 40:]
    return bytes(out), gone


def _centre(map_key, lvt_text):
    """(sector id, x, y, z) of the middle of the map's play area (the spawn points' centre), or None."""
    import lvt
    ids = [int(m.group(1), 16) for m in re.finditer(r"^SECTOR\s+([0-9A-Fa-f]+)\s+#", lvt_text, re.M)]
    secs = lvt.parse(lvt_text)
    if not secs or len(ids) != len(secs):
        return None
    return secs, ids


def _bait(map_key, lvt_bytes, obt_text):
    import math
    got = _centre(map_key, lvt_bytes.decode("latin-1"))
    if got is None:
        return []
    secs, ids = got
    pts = [(float(m.group(1)), float(m.group(2))) for m in re.finditer(r"NAME:\s+STARTPOS\b.*?X:\s*(\S+)\s+Y:\s*\S+\s+Z:\s*(\S+)", obt_text)]
    if not pts:
        xs = [v[0] for s in secs for v in s.vertices]; zs = [v[1] for s in secs for v in s.vertices]
        pts = [((min(xs) + max(xs)) / 2, (min(zs) + max(zs)) / 2)]
    cx, cz = sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)
    def ok(s):
        return s.vertices and s.ceiling - s.floor >= 6.0 and len(s.walls) >= 3
    best = None
    for s in secs:
        if ok(s) and s.contains(cx, cz):
            best = s; break
    if best is None:
        cand = [s for s in secs if ok(s)]
        def d(s):
            sx = sum(v[0] for v in s.vertices) / len(s.vertices); sz = sum(v[1] for v in s.vertices) / len(s.vertices)
            return math.hypot(sx - cx, sz - cz)
        best = min(cand, key=d) if cand else None
        if best is None:
            return []
        cx, cz = sum(v[0] for v in best.vertices) / len(best.vertices), sum(v[1] for v in best.vertices) / len(best.vertices)
        if not best.contains(cx, cz):
            return []
    sid = ids[best.index]
    y = best.floor
    spots = [(cx - 1.5, cz), (cx + 1.5, cz)]
    if not all(best.contains(x, z) for x, z in spots):
        spots = [(cx, cz), (cx, cz)]
    return [("NBPLATE1", sid, spots[0][0], y, spots[0][1]), ("NDOCBAG1", sid, spots[1][0], y, spots[1][1])]


def patch_gungame(map_key, log=print):
    """Loose copies of the map's object lists without weapons, ammo or TNT, with a boiler plate and a med bag in the middle.
    restore() puts the map back. Returns the number of objects removed (0 = nothing written)."""
    import lvt
    restore()
    lv = lvt.read_from_labs(map_key + ".lvt")
    st, total, added = {}, 0, []
    for ext in ("obt", "obb"):
        name = f"{map_key}.{ext}"
        if any(p.name.lower() == name.lower() for p in GAME.iterdir() if p.is_file()):
            log(f"gun game items: {name} already exists in the game folder; leaving it alone")
            continue
        data = lvt.read_from_labs(name.lower())
        if data is None:
            log(f"gun game items: no {name} found for this map")
            continue
        new, n = (_gun_text if ext == "obt" else _gun_binary)(data)
        if lv is not None and not added:
            try:
                added = _bait(map_key, lv, data.decode("latin-1") if ext == "obt" else (lvt.read_from_labs(map_key + ".obt") or b"").decode("latin-1"))
            except Exception as e:
                log(f"gun game items: no bait: {e}")
        if added:
            import objadd
            more = (objadd.add_text(new.decode("latin-1"), added, flags=_ITEM_FLAGS, keep_case=True).encode("latin-1")
                    if ext == "obt" else objadd.add_binary(new, added, flags=_ITEM_FLAGS, keep_case=True))
            if more is not None and more != new:
                new = more
                n += 0
                log(f"gun game items: {name}: {', '.join(a[0] for a in added)} in the middle")
        if new != data:
            (GAME / name).write_bytes(new)
            st[name] = hashlib.sha1(new).hexdigest()
            total = max(total, n)
            log(f"gun game items: {name}: {n} weapons, ammo and TNT removed")
    if st:
        STATE.parent.mkdir(exist_ok=True)
        STATE.write_text(json.dumps(st))
    return total


if __name__ == "__main__":
    c = sys.argv[1] if len(sys.argv) > 1 else "status"
    if c == "on": patch(sys.argv[2])
    elif c == "melee": patch(sys.argv[2], mode="melee")
    elif c == "gungame": print(patch_gungame(sys.argv[2]))
    elif c == "off": print("removed" if restore() else "could not remove everything")
    else: print(_load() or "nothing installed")
