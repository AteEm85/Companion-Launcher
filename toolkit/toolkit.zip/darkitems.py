"""Dark Mode map items: no ranged weapons lying about.
Writes loose copies of the map's object lists (<map>.obt text and <map>.obb compiled) into the game folder with
  rifles, pistols             -> a shotgun or a double-barrel
  gatling guns                -> a knife or a stick of TNT
  rifle cartridges            -> a box of TNT, a stick of TNT or a knife
  rifle scopes, pistol ammo, gatling clips -> shotgun shells (or a knife)
Nothing in the game's archives is touched: restore() deletes the loose copies again (horde.py does it when the game ends, and
at the start of the next one in case of a crash). A loose file of the same name that was already there is never overwritten.
  python darkitems.py on <map> | off | status"""
import os, sys, re, json, random, hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
GAME = HERE.parent
STATE = HERE / "state" / "darkitems.json"
sys.path.insert(0, str(HERE))

# placed object (N...) and ground item (G...) names -> the choices that replace them
SHOTGUNS = ["NSGUN1", "NDBSGUN1", "NDBSGUN1"]
MELEE = ["NKNIFE1", "NDYNAM1"]
SWAP = {
    "NRIFLE1": SHOTGUNS, "NHRIFLE1": SHOTGUNS, "NPISTOL1": SHOTGUNS,
    "NGATGUN": MELEE,
    "NAMBOXC1": ["NAMBOXT1", "NDYNAM1", "NKNIFE1"],
    "NAMBOXB1": ["NAMBOXS1"], "NAMBELT1": ["NAMBOXS1"], "NCLIP": ["NAMBOXS1", "NKNIFE1"], "NSCOPE": ["NAMBOXS1"],
}
SWAP.update({k.replace("N", "G", 1): [v.replace("N", "G", 1) for v in vs] for k, vs in list(SWAP.items())
             if k not in ("NAMBOXC1", "NAMBOXB1", "NAMBELT1")})
SWAP.update({"GAMBOXC": ["GAMBOXT", "GDYNAM", "GKNIFE"], "GAMBOXB": ["GAMBOXS"], "GAMBELT": ["GAMBOXS"],
             "GSATCHEL": ["GAMBOXS"], "GRIFLE": ["GSGUN", "GDBSGUN"], "GPISTOL": ["GSGUN"], "GGATGUN": ["GKNIFE", "GDYNAM"]})


def _text(data):
    n = [0]
    pat = re.compile(rb"(NAME:\s+)(" + b"|".join(re.escape(k.encode()) for k in sorted(SWAP, key=len, reverse=True)) + rb")(\s)")
    def sub(m):
        n[0] += 1
        return m.group(1) + random.choice(SWAP[m.group(2).decode()]).encode() + m.group(3)
    return pat.sub(sub, data), n[0]


def _binary(data):
    n = [0]
    pat = re.compile(rb"\x0b(" + b"|".join(re.escape(k.encode()) for k in sorted(SWAP, key=len, reverse=True)) + rb")\x00")
    def sub(m):
        n[0] += 1
        return b"\x0b" + random.choice(SWAP[m.group(1).decode()]).encode() + b"\x00"
    return pat.sub(sub, data), n[0]


def _load():
    try: return json.loads(STATE.read_text())
    except Exception: return {}


def restore():
    """Delete the loose files we wrote (only if they're still ours). True when none is left."""
    st = _load(); ok = True
    for name, digest in list(st.items()):
        p = GAME / name
        try:
            if p.exists() and hashlib.sha1(p.read_bytes()).hexdigest() == digest:
                p.unlink()
            st.pop(name)
        except OSError:
            ok = False
    try:
        if st: STATE.write_text(json.dumps(st))
        elif STATE.exists(): STATE.unlink()
    except OSError:
        pass
    return ok


def patch(map_key, log=print):
    """Write the swapped object lists for this map. Returns the number of objects swapped (0 = nothing written)."""
    import lvt
    restore()
    st, total = {}, 0
    for ext, fn in (("obt", _text), ("obb", _binary)):
        name = f"{map_key}.{ext}"
        dest = GAME / name
        if any(p.name.lower() == name.lower() for p in GAME.iterdir() if p.is_file()):
            log(f"dark items: {name} already exists in the game folder; leaving it alone")
            continue
        data = lvt.read_from_labs(name.lower())
        if data is None:
            log(f"dark items: no {name} found for this map")
            continue
        new, n = fn(data)
        if n:
            dest.write_bytes(new)
            st[name] = hashlib.sha1(new).hexdigest()
            total = max(total, n)
            log(f"dark items: {name}: {n} objects swapped")
    if st:
        STATE.parent.mkdir(exist_ok=True)
        STATE.write_text(json.dumps(st))
    return total


if __name__ == "__main__":
    c = sys.argv[1] if len(sys.argv) > 1 else "status"
    if c == "on": patch(sys.argv[2])
    elif c == "off": print("removed" if restore() else "could not remove everything")
    else: print(_load() or "nothing installed")
