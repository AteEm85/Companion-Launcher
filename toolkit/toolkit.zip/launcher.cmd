@echo off
rem Starts the launcher window without building the exe.
cd /d "%~dp0"
start "" pythonw "%~dp0launcher.py" 2>nul || start "" pyw -3 "%~dp0launcher.py"
