@echo off
rem Runs the new Companion from its source (companion_app.py -> launcher.py with OUTLAWS_COMPANION=1), with this folder's .venv.
cd /d "%~dp0"
set "OUTLAWS_COMPANION=1"
set "BOT_HOME=%~dp0."
"%~dp0.venv\Scripts\python.exe" launcher.py --companion
if errorlevel 1 pause
