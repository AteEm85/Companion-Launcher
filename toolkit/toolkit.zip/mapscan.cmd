@echo off
rem Scans every map: modes and whether the bots can build a route map for it.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u mapscan.py
echo DONE> mapscan_done.txt
