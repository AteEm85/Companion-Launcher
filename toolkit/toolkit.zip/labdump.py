"""List what is inside the game's .lab archives (names and sizes) into botctl\\labdump.txt, reading only the headers.
  python labdump.py [lab names...]     (default: olremaster1.lab olremaster1_de.lab oltaunthd.lab olsfxhd.lab)"""
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
GAME = HERE.parent
args = sys.argv[1:]
outname = "labdump.txt"
if "--out" in args:
    i = args.index("--out"); outname = args[i + 1]; del args[i:i + 2]
names = args or ["olremaster1.lab", "olremaster2.lab", "oltaunthd.lab", "olsfxhd.lab"]
out = []
for n in names:
    p = GAME / n
    if not p.exists():
        out.append(f"## {n}: missing")
        continue
    with p.open("rb") as f:
        head = f.read(16)
        if head[:4] != b"LABN":
            out.append(f"## {n}: not a LAB ({head[:4]!r})")
            continue
        cnt, = struct.unpack_from("<I", head, 8)
        ent = f.read(16 * cnt)
        names_blob = f.read(struct.unpack_from("<I", head, 12)[0])
    out.append(f"## {n}: {cnt} entries")
    for i in range(cnt):
        no, off, size, _t = struct.unpack_from("<IIII", ent, 16 * i)
        nm = names_blob[no:names_blob.index(b"\0", no)].decode("latin1")
        out.append(f"{nm}\t{size}\t{off}")
(HERE / outname).write_text("\n".join(out), encoding="utf-8")
print("wrote", HERE / outname, len(out), "lines")
