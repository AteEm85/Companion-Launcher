"""Set the player limit of YOUR hosted lobby (the Ghosts tab's own game): the game's -maxplayers start-up option only takes 2-8,
so the launcher runs this right after starting your game. It attaches the bot agent to your game, asks for the size the way the
console's 'kexmultiplayer maxplayers <n>' does (the host bot does the same for its own lobbies), waits until the lobby exists and
reports the size, then lets go of the game.

  python lobbysize.py <players> --pid N [--wait 90]

Log: botctl\\lobbysize_log.txt"""
import argparse
import sys
import time
from pathlib import Path

import frida

HERE = Path(__file__).resolve().parent
LOG = HERE / "lobbysize_log.txt"


def log(msg):
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    try:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("players", type=int)
    ap.add_argument("--pid", type=int, required=True)
    ap.add_argument("--wait", type=float, default=90.0, help="seconds to wait for the lobby (the game loads first)")
    a = ap.parse_args()
    want = max(2, min(32, a.players))
    done = {"ok": None}

    def on_message(m, _data):
        p = m.get("payload") if m.get("type") == "send" else None
        if isinstance(p, dict) and "lobby size" in str(p.get("message", "")):
            log(f"pid {a.pid}: {p['message']}")
            done["ok"] = p.get("kind") == "info"

    t0 = time.time()
    session = None
    while session is None and time.time() - t0 < a.wait:      # the game may still be starting
        try:
            session = frida.get_local_device().attach(a.pid)
        except Exception:
            time.sleep(1.0)
    if session is None:
        log(f"pid {a.pid}: could not attach to the game; the lobby stays at its start-up size")
        return 1
    script = session.create_script((HERE / "input_agent.js").read_text())
    script.on("message", on_message)
    script.load()
    api = script.exports_sync
    try:
        if not api.set_max_players(want):
            log(f"pid {a.pid}: this game build has no known lobby-size function; the lobby stays at its start-up size")
            return 1
        while done["ok"] is None and time.time() - t0 < a.wait:
            time.sleep(0.5)
        if done["ok"] is None:
            log(f"pid {a.pid}: no lobby within {a.wait:.0f} s; the size was not changed")
        return 0 if done["ok"] else 1
    finally:
        try:
            api.shutdown()
            time.sleep(0.5)
        except Exception:
            pass
        try:
            session.detach()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
