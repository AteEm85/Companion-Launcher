@echo off
rem Gold Gatling in the Juggernaut's hand: copies the first-person Gatling sprite (IGATGUN.SPX, about 22 MB) out of olremaster1.lab into botctl\extract\. The archive itself is not changed.
cd /d "%~dp0"
.venv\Scripts\python.exe labextract.py olremaster1.lab IGATGUN.SPX
pause
