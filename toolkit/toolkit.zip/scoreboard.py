"""The live scoreboard over the game: python scoreboard.py <run id> <horde.py pid> [your name]
Hold the ` key (left of 1; another key: state/scoreboard_settings.json {"key": "0x09"} for Tab) while in the game:
kills, deaths, streaks, accuracy, the longest hit, the Horde tier and everyone's rank title (livestats.py, state/live_<run>.json).
When the match ends, the MATCH OVER card (MVP, most kills, longest streak, best shot) shows by itself for 15 seconds.
The window is made once at the start and only made see-through or drawn into after that, never opened mid-match (that makes
the game let go of the keys you are holding: see tierhud.py). No focus, click-through."""
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
CARD_SECS = 15.0


def settings_key():
    try:
        v = json.loads((HERE / "state" / "scoreboard_settings.json").read_text()).get("key")
        return int(str(v), 0)
    except (OSError, ValueError, TypeError, AttributeError):
        return 0xC0


def main():
    run = sys.argv[1] if len(sys.argv) > 1 else ""
    parent = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    vk = settings_key()
    import ambient
    import sbview
    st = HERE / "state"
    stop, human, live = st / f"stop_{run}", st / f"human_{run}.flag", st / f"live_{run}.json"
    while not human.exists():
        if stop.exists() or (parent and not ambient.alive(parent)):
            return
        time.sleep(0.5)
    import ctypes
    u = ctypes.windll.user32
    fg0 = u.GetForegroundWindow()
    import tkinter as tk
    root = tk.Tk()
    root.withdraw()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    KEY = "#010101"
    root.configure(bg=KEY)
    try:
        root.attributes("-transparentcolor", KEY)
    except tk.TclError:
        pass
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    W = min(int(sw * 0.62), 1100)
    H = int(sh * 0.8)
    cv = tk.Canvas(root, width=W, height=H, bg=KEY, highlightthickness=0)
    cv.pack()
    root.geometry(f"{W}x{H}+{(sw - W) // 2}+{int(sh * 0.1)}")
    try:
        root.attributes("-alpha", 0.0)
    except tk.TclError:
        pass
    try:
        root.update()
        hwnd = u.GetParent(root.winfo_id()) or root.winfo_id()
        u.SetWindowLongW(hwnd, -20, u.GetWindowLongW(hwnd, -20) | 0x08000000 | 0x80 | 0x20 | 0x80000)
        u.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)
        u.ShowWindow(hwnd, 4)
        if fg0 and u.GetForegroundWindow() != fg0:
            u.SetForegroundWindow(fg0)
    except Exception:
        root.deiconify()
    me = sys.argv[3] if len(sys.argv) > 3 else ""
    if not me:
        try:
            me = json.loads((HERE / "launcher_settings.json").read_text()).get("stats_player", "")
        except (OSError, ValueError, AttributeError):
            pass
    state = {"shown": False, "board_t": None, "card_until": None, "last_draw": 0.0}

    def read():
        try:
            return json.loads(live.read_text())
        except (OSError, ValueError):
            return None

    def show(on):
        if on != state["shown"]:
            state["shown"] = on
            try:
                root.attributes("-alpha", 0.92 if on else 0.0)
            except tk.TclError:
                pass
            if not on:
                cv.delete("all")

    def tick():
        now = time.time()
        if stop.exists() or (parent and not ambient.alive(parent)):
            if not (state["card_until"] and now < state["card_until"]):
                root.destroy()
                return
        b = None
        held = bool(u.GetAsyncKeyState(vk) & 0x8000)
        if state["card_until"] is None:
            b = read()
            if b and b.get("final"):                    # (17 Nov: no MATCH OVER card at the end any more - the board just closes)
                root.destroy()
                return
        if state["card_until"] is not None:
            if now >= state["card_until"]:
                show(False)
                root.destroy()
                return
        elif held:
            if now - state["last_draw"] > 1.0 or not state["shown"]:
                b = b or read()
                if b:
                    sbview.draw(cv, b, W, me=me)
                    state["last_draw"] = now
                    show(True)
        else:
            show(False)
        root.after(50, tick)
    tick()
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
