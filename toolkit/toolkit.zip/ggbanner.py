"""Gun-game round banner: python ggbanner.py <launcher pid>
Big text across the middle of the screen when a round ends: ROUND 1 COMPLETE with the winner's name under it, then
ROUND 2 BEGIN. The winning bot writes state/gg_banner.json (gungame.announce_round) and state/gg_freeze.json; every
bot stands still until the freeze is over. For you: while the banner is up this takes the keyboard from the game (a
tiny invisible window gets the focus) so you stand still too, and hands it back when ROUND n BEGIN is gone.
Drawn into a see-through click-through window made at the start (a new window mid-match makes the game let go of
your keys). Closes when the launcher is gone."""
import ctypes
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
STATE = HERE / "state"
KEY = "#010101"
u = ctypes.windll.user32
k = ctypes.windll.kernel32


def alive(pid):
    h = k.OpenProcess(0x1000, False, pid)
    if not h:
        return False
    code = ctypes.c_ulong()
    k.GetExitCodeProcess(h, ctypes.byref(code))
    k.CloseHandle(h)
    return code.value == 259


def exe_of(hwnd):
    pid = ctypes.c_ulong()
    u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    h = k.OpenProcess(0x1000, False, pid.value)
    if not h:
        return ""
    buf = ctypes.create_unicode_buffer(520)
    n = ctypes.c_ulong(520)
    k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n))
    k.CloseHandle(h)
    return buf.value.lower()


def focus(hwnd):
    """Bring hwnd to the front even though we aren't the foreground process (the Alt tap lets it through)."""
    try:
        u.keybd_event(0x12, 0, 0, 0)
        u.keybd_event(0x12, 0, 2, 0)
        u.SetForegroundWindow(hwnd)
    except Exception:
        pass


SOUNDS = HERE / "sounds"
WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven"]


def gunshot(rate=22050):
    """A synthesized gunshot (noise crack + low thump + a little echo) as 16-bit samples."""
    import array
    import math
    import random
    rnd = random.Random(7)
    n = int(rate * 0.9)
    out = array.array("h", [0] * n)
    lp = 0.0
    for i in range(n):
        t = i / rate
        lp += 0.35 * ((rnd.random() * 2 - 1) - lp)                      # softened noise
        v = lp * math.exp(-t * 11) * 1.4 + math.sin(2 * math.pi * 62 * t) * math.exp(-t * 7) * 0.9
        if i > int(rate * 0.12):                                         # a short echo
            v += out[i - int(rate * 0.12)] / 32768.0 * 0.28
        out[i] = max(-32767, min(32767, int(v * 24000)))
    return out, rate


def mix(shot, voice):
    """The shot first, the voice starting 0.25 s in, one array of samples."""
    import array
    off = int(shot[1] * 0.25)
    a, b = shot[0], voice
    out = array.array("h", [0] * max(len(a), off + len(b)))
    for i, x in enumerate(a):
        out[i] = x
    for i, x in enumerate(b):
        out[off + i] = max(-32767, min(32767, out[off + i] + x))
    return out


def prepare_sounds(rounds=6):
    """sounds\\gg_a<n>.wav (a gunshot, then a deep 'Round n complete') and gg_b<n>.wav ('Round n begin'), made once.
    The voice is Windows' own speech, played back slowed down: lower and slower. Quietly gives up if that fails."""
    import array
    import subprocess
    import wave
    try:
        SOUNDS.mkdir(exist_ok=True)
        todo = [(f"gg_a{n}", f"Round {WORDS[n]} complete") for n in range(1, rounds + 1)] \
            + [(f"gg_b{n}", f"Round {WORDS[n]} begin") for n in range(2, rounds + 1)]
        todo = [(name, text) for name, text in todo if not (SOUNDS / f"{name}.wav").exists()]
        if not todo:
            return
        ps = ["Add-Type -AssemblyName System.Speech",
              "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer",
              "try { $s.SelectVoice('Microsoft David Desktop') } catch {}",
              "$s.Rate = -2",
              "$f = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(22050, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono)"]
        for name, text in todo:
            ps += [f"$s.SetOutputToWaveFile('{SOUNDS / (name + '_v.wav')}', $f)", f"$s.Speak('{text}')", "$s.SetOutputToNull()"]
        script = SOUNDS / "gg_voices.ps1"
        script.write_text("\n".join(ps))
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)], timeout=120,
                       creationflags=0x08000000)
        shot = gunshot()
        for name, _ in todo:
            vp = SOUNDS / f"{name}_v.wav"
            voice = array.array("h")
            if vp.exists():
                with wave.open(str(vp), "rb") as w:
                    if w.getsampwidth() == 2 and w.getnchannels() == 1:
                        voice.frombytes(w.readframes(w.getnframes()))
                vp.unlink()
            data = mix(shot, voice)
            with wave.open(str(SOUNDS / f"{name}.wav"), "wb") as w:   # the voice part plays slowed to 0.8x: deeper
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(int(shot[1] * 0.8))
                w.writeframes(data.tobytes())
    except Exception:
        pass


def play(name):
    try:
        import winsound
        p = SOUNDS / f"{name}.wav"
        if p.exists():
            winsound.PlaySound(str(p), winsound.SND_FILENAME | winsound.SND_ASYNC)
    except Exception:
        pass


def main():
    import threading
    threading.Thread(target=prepare_sounds, daemon=True).start()
    parent = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    born = time.time()
    import tkinter as tk
    from tkinter import font as tkfont
    root = tk.Tk()
    root.withdraw()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.configure(bg=KEY)
    try:
        root.attributes("-transparentcolor", KEY)
    except tk.TclError:
        pass
    SW, SH, BH = root.winfo_screenwidth(), root.winfo_screenheight(), 360
    cv = tk.Canvas(root, width=SW, height=BH, bg=KEY, highlightthickness=0)
    cv.pack()
    root.geometry(f"{SW}x{BH}+0+{(SH - BH) // 2}")
    big = tkfont.Font(family="Impact", size=72, weight="bold")
    mid = tkfont.Font(family="Impact", size=48, weight="bold")

    def shadowed(y, text, font, color):
        for dx, dy in ((-3, 3), (3, 3), (0, 5), (-3, -3), (3, -3), (-4, 0), (4, 0)):
            cv.create_text(SW // 2 + dx, y + dy, text=text, font=font, fill="black")
        cv.create_text(SW // 2, y, text=text, font=font, fill=color)

    # a tiny, almost invisible window that can take the focus (so the game gets no keys while we hold it)
    fz = tk.Toplevel(root)
    fz.overrideredirect(True)
    fz.attributes("-topmost", True)
    try:
        fz.attributes("-alpha", 0.01)
    except tk.TclError:
        pass
    fz.geometry("2x2+0+0")
    fz.withdraw()

    def make_click_through(win):
        try:
            win.update()
            h = u.GetParent(win.winfo_id()) or win.winfo_id()
            u.SetWindowLongW(h, -20, u.GetWindowLongW(h, -20) | 0x08000000 | 0x80 | 0x20 | 0x80000)
            u.SetWindowPos(h, -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)
            u.ShowWindow(h, 4)
        except Exception:
            win.deiconify()
    fg0 = u.GetForegroundWindow()
    make_click_through(root)
    if fg0 and u.GetForegroundWindow() != fg0:
        focus(fg0)
    seen = [None]
    held = [None]          # the game window we took the keyboard from, while the banner is up
    shown = [None]

    def release():
        if held[0]:
            focus(held[0])
            held[0] = None
        try:
            fz.withdraw()
        except tk.TclError:
            pass

    def tick():
        if parent and not alive(parent):
            root.destroy()
            return
        try:
            d = json.loads((STATE / "gg_banner.json").read_text())
        except (OSError, ValueError):
            d = None
        now = time.time()
        if d and d.get("seq") != seen[0] and d.get("t0", 0) >= born - 1 and now - d["t0"] < 60:
            seen[0] = d["seq"]
            fg = u.GetForegroundWindow()
            if fg and "outlawsahom" in exe_of(fg):          # you are playing: hold still too
                held[0] = fg
                fz.deiconify()
                focus(int(fz.winfo_id()) if not u.GetParent(fz.winfo_id()) else u.GetParent(fz.winfo_id()))
            cur = d
            d = None
        else:
            cur = None
        if cur is not None:
            tick.cur = cur
        c = getattr(tick, "cur", None)
        if c:
            t = now - c["t0"]
            hold, begin = float(c.get("hold", 5)), (float(c.get("begin_secs", 2.5)) if c.get("begin") else 0.0)
            want = ("a" if t < hold else "b" if t < hold + begin else None)
            if want != shown[0]:
                shown[0] = want
                cv.delete("all")
                try:
                    num = int((c["title"] if want == "a" else c["begin"]).split()[1]) if want else 0
                except (ValueError, IndexError, KeyError, TypeError):
                    num = 0
                if want and num:
                    play(f"gg_{want}{min(num, 6)}")
                if want == "a":
                    shadowed(110, c["title"], big, "#f2e6c4")
                    shadowed(235, c.get("name", ""), mid, "#ffd24a")
                elif want == "b":
                    shadowed(180, c["begin"], big, "#7be37b")
                else:
                    release()
                    tick.cur = None
        root.after(100, tick)
    root.after(100, tick)
    root.mainloop()


if __name__ == "__main__":
    main()
