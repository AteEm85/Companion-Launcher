"""Round 4 (hostnext4.cmd), no playing needed: with the game in its main menu, after 8 seconds it hosts by itself the
way the menu's Start does - MoveToNewLobby(the multiplayer manager, "lan", 0, 0, an empty settings list) with
mp_levelName set - and notes what happens. Round 3 had found those arguments (and that its own replay failed only because
the lobby kind text was read with junk after it).

Round 3 (hostnext3.cmd): mapprobe4 found what the menu's Start does: kexMultiplayerManager::MoveToNewLobby (Steam
exe+0x135cf0: manager, lobby kind text, move flags, a kind number, a list of settings) opens the new session, and that
session sends the host request itself. This round notes the arguments YOUR first host passes, and after that match
replays the same call (with the next map in mp_levelName). If the settings list is not empty it only reports it.

Round 2 (hostnext2.cmd): round 1's host request reached the game but the session check (exe+0xc1660) said no and it
stayed in the menu. This round notes that check's answer and the multiplayer manager's state, for its own try AND for
yours: after its try, host the next map yourself from the menu, so the two can be compared.

Host-the-next-map test (hostnext.cmd): can the game host its next map by itself, without closing?

What the next-map probes (mapprobe*.py) found on the Steam build: when you press Host, the menu sends the game's state
machine (exe+0x92a80) the request (object, 2, 0); the map it hosts is the cvar mp_levelName ("Multiplayer: Level Name").
After a match everyone is back in the main menu in the same running game.

This test DOES change your game, once: you host a match yourself as usual and play it to the end. Back in the main menu,
after 5 seconds it sets mp_levelName to the next map of its list and sends the same host request the menu would. If it
works, the game hosts that map by itself (the lobby, then the match) without you touching the menu. Writes
state\\hostnext.txt.

  python hostnext.py [MAP]      (default: the next of HARGROVE, TOWN_2P, DRYGULCH after the one you played)
"""
import subprocess
import sys
import time
from pathlib import Path

import frida

HERE = Path(__file__).resolve().parent
OUT = HERE / "state" / "hostnext4.txt"
WANT = sys.argv[1].upper() if len(sys.argv) > 1 else ""

JS = r"""
const exe = Process.mainModule;
const stamp = exe.base.add(exe.base.add(0x3c).readU32() + 8).readU32();
if (stamp !== 0x6a39ed68) send({ kind: 'error', message: 'this test knows the Steam build only (0x' + stamp.toString(16) + ')' });
const STATE = exe.base.add(0xf0d714);
const REQUEST = exe.base.add(0x92a80);
const request = new NativeFunction(REQUEST, 'void', ['pointer', 'int', 'pointer']);
const WANT = __WANT__;
const LIST = ['TOWN_2P', 'DRYGULCH'];
let lobbySince = 0, entered = false, hosts = 0, ctx = null, armed = false, done = false, menuSince = 0, lastState = STATE.readS32(), sawMatch = false;

const MPM = exe.base.add(0x1355420);
function mpState() {
  const o = {};
  try { const m = MPM.readPointer(); o.mgr = m.isNull() ? null : m.toString();
        if (!m.isNull()) { o.mgr4c = m.add(0x4c).readS32(); o.mgr110 = m.add(0x110).readPointer().toString(); } } catch (e) { o.err = String(e); }
  try { o.g1354eb0 = exe.base.add(0x1354eb0).readS32(); o.g1357ff8 = exe.base.add(0x1357ff8).readS32(); o.g1354f7c = exe.base.add(0x1354f7c).readS32(); o.gf0d718 = exe.base.add(0xf0d718).readS32(); o.gf0d710 = exe.base.add(0xf0d710).readS32(); } catch (e) {}
  return JSON.stringify(o);
}
let lobbyArgs = null;
function hexd(p, n) { try { return Array.from(new Uint8Array(p.readByteArray(n))).map(x => ('0' + x.toString(16)).slice(-2)).join(' '); } catch (e) { return '?'; } }
function strAt(p) { try { const s = p.readPointer().readCString(40); return /^[\x20-\x7e]{1,40}$/.test(s) ? s : null; } catch (e) { return null; } }
Interceptor.attach(exe.base.add(0x135cf0), { onEnter(args) {
  let name = null; try { name = args[1].isNull() ? null : args[1].readCString(60); } catch (e) {}
  const a = { mgr: args[0], name: name, flags: args[2].toInt32(), kind: args[3].toInt32(), list: null, count: 0 };
  let listInfo = 'none';
  try {
    const L = this.context.sp.add(0x28).readPointer(); a.list = L;
    if (!L.isNull()) {
      const data = L.readPointer(); a.count = L.add(0xc).readU32();
      listInfo = 'list ' + L + ' head ' + hexd(L, 0x10) + ', ' + a.count + ' entries';
      for (let i = 0; i < Math.min(a.count, 12); i++) {
        const e = data.add(0x50 * i);
        const ss = []; for (let o = 0; o < 0x50; o += 8) { const t = strAt(e.add(o)); if (t) ss.push('+' + o.toString(16) + ' "' + t + '"'); }
        listInfo += '\n        entry ' + i + ': ' + hexd(e, 0x50) + (ss.length ? '  texts: ' + ss.join(', ') : '');
      }
    }
  } catch (e) { listInfo = 'list unreadable: ' + e; }
  send({ kind: 'info', message: 'MoveToNewLobby(' + a.mgr + ', ' + JSON.stringify(name) + ', flags ' + a.flags + ', kind ' + a.kind + ') state ' + STATE.readS32() + '; ' + listInfo });
  if (name) a.name = name.split(/[^\x20-\x7e]/)[0];        // (round 3: the text was read past its end: "lan" + junk)
  if (lobbyArgs === null && a.name) lobbyArgs = a;
} });
let checks = 0;
Interceptor.attach(exe.base.add(0xc1660), {
  onEnter() { this.before = mpState(); },
  onLeave(ret) { if (checks++ < 40) send({ kind: 'info', message: 'session check (0xc1660) answered ' + ret.toInt32() + '; before ' + this.before + ' after ' + mpState() }); }
});
let reqs = 0;
Interceptor.attach(exe.base.add(0x93420), { onEnter() { send({ kind: 'info', message: 'END GAME (0x93420) called from ' + bt(this.context, 12) }); } });
Interceptor.attach(REQUEST, { onEnter(args) {
  if (reqs++ < 60) { let t = ''; if (args[1].toInt32() === 3) { try { t = ' ' + args[2].readCString(20); } catch (e) {} }
    send({ kind: 'info', message: 'request ' + args[1].toInt32() + ' ' + args[2] + t + ' (state ' + STATE.readS32() + ') ' + mpState() + ' calls ' + bt(this.context, 12) }); }
  if (ctx === null || !args[0].equals(ctx)) { ctx = args[0]; send({ kind: 'info', message: 'the state machine object: ' + ctx + ' (request ' + args[1].toInt32() + ')' }); }
} });

const CVAR_SET_PROLOGUE = '48 89 5c 24 18 48 89 74 24 20 55 41 56 41 57 48 8b ec 48 81 ec 80 00 00 00';
let cvarSetFn = null;
function cvarSetter() {
  if (cvarSetFn) return cvarSetFn;
  for (const r of exe.enumerateRanges('r-x')) {
    let hits = [];
    try { hits = Memory.scanSync(r.base, r.size, CVAR_SET_PROLOGUE); } catch (e) { continue; }
    if (hits.length === 1) { cvarSetFn = new NativeFunction(hits[0].address, 'void', ['pointer', 'pointer', 'uint32', 'uint32']); return cvarSetFn; }
  }
  throw new Error('the cvar setter was not found');
}
function findCvar(name) {
  const pat = Array.from(name, c => c.charCodeAt(0).toString(16).padStart(2, '0')).join(' ') + ' 00';
  const strs = [];
  for (const r of exe.enumerateRanges('r--')) { try { for (const m of Memory.scanSync(r.base, r.size, pat)) strs.push(m.address); } catch (e) {} }
  for (const sAddr of strs) {
    const le = sAddr.toString().replace('0x', '').padStart(16, '0').match(/../g).reverse().join(' ');
    for (const r of exe.enumerateRanges('rw-')) {
      let hits = [];
      try { hits = Memory.scanSync(r.base, r.size, le); } catch (e) {}
      for (const h of hits) { try { if (h.address.readPointer().readCString() === name) return h.address; } catch (e) {} }
    }
  }
  return null;
}
function cvarValue(cv) { try { return cv.add(0x60).readPointer().readPointer().readCString(); } catch (e) { return null; } }
const LEVEL = findCvar('mp_levelName');
send({ kind: 'info', message: 'mp_levelName ' + (LEVEL ? 'found, now ' + cvarValue(LEVEL) : 'NOT found') });
const keep = [];

// every write of the scenario state, with the code that wrote it (hardware watchpoint, as mapprobe.py)
function rva(p) { try { return '0x' + p.sub(exe.base).toString(16); } catch (e) { return String(p); } }
function inExe(p) { return p.compare(exe.base) >= 0 && p.compare(exe.base.add(exe.size)) < 0; }
function bt(c, n) { try { return Thread.backtrace(c, Backtracer.FUZZY).filter(inExe).slice(0, n || 10).map(rva).join(' < '); } catch (e) { return '?'; } }
const armedThreads = new Set();
function armWatch() { for (const t of Process.enumerateThreads()) { if (armedThreads.has(t.id)) continue; try { t.setHardwareWatchpoint(0, STATE, 4, 'w'); t.setHardwareWatchpoint(1, GSTATE, 4, 'w'); armedThreads.add(t.id); } catch (e) {} } }
const GSTATE = exe.base.add(0xf0d718);
let wpLast = STATE.readS32(), gsLast = GSTATE.readS32();
Process.setExceptionHandler(function (d) {
  if (d.type !== 'single-step') return false;
  try { const v = STATE.readS32(); if (v !== wpLast) { send({ kind: 'info', message: 'STATE ' + wpLast + ' -> ' + v + ' at ' + rva(d.context.pc) + ' gs ' + exe.base.add(0xf0d718).readS32() + ' pick ' + exe.base.add(0x1357934).readS32() + ' lvl ' + exe.base.add(0xf0d940).readPointer() + ' calls ' + bt(d.context, 8) }); wpLast = v; }
        const g = GSTATE.readS32(); if (g !== gsLast) { send({ kind: 'info', message: 'GAMESTATE ' + gsLast + ' -> ' + g + ' at ' + rva(d.context.pc) + ' scen ' + STATE.readS32() + ' calls ' + bt(d.context, 10) }); gsLast = g; } } catch (e) {}
  return true;
});
armWatch();
setInterval(armWatch, 1000);

// the game's own developer messages (Main_..., printed through the pointer at exe+0xf0d650)
try {
  const devPrint = exe.base.add(0xf0d650).readPointer();
  let dp = 0;
  if (!devPrint.isNull()) Interceptor.attach(devPrint, { onEnter(args) {
    if (dp++ > 300) return;
    let f = ''; try { f = args[0].readCString(120); } catch (e) { return; }
    const fmt = f.split('\n')[0];
    const vals = [1, 2, 3].map(function (i) { try { const t = args[i].readCString(80); if (/^[\x20-\x7e]{1,80}$/.test(t)) return JSON.stringify(t); } catch (e) {} return String(args[i].toInt32()); });
    send({ kind: 'info', message: 'GAME SAYS: ' + fmt + '  [' + vals.join(', ') + ']' });
  } });
  send({ kind: 'info', message: 'developer messages: ' + (devPrint.isNull() ? 'none' : rva(devPrint)) });
} catch (e) { send({ kind: 'info', message: 'developer messages hook failed: ' + e }); }
const CV = {};
for (const n of ['mp_gamemode', 'mp_killsToEnd', 'mp_timeToEnd', 'mp_friendlyFire']) CV[n] = findCvar(n);
function cvars() { const o = {}; for (const n in CV) o[n] = CV[n] ? cvarValue(CV[n]) : 'NOT found'; return JSON.stringify(o); }

const sdl = Process.getModuleByName('SDL3.dll');
Interceptor.attach(sdl.getExportByName('SDL_PollEvent'), { onEnter() {
  const s0 = STATE.readS32();
  if (hosts > 0 && s0 === 8) {                      // our lobby: start the match the way "Enter Game" does
    if (!lobbySince) lobbySince = Date.now();
    else if (!entered && Date.now() - lobbySince > 1500) {
      entered = true;
      const PICK = exe.base.add(0x1357934);
      send({ kind: 'info', message: 'lobby: entering the match (pick ' + PICK.readS32() + ' -> 2, closing the menu)' });
      PICK.writeS32(2);
      try { new NativeFunction(exe.base.add(0x129c10), 'void', [], { exceptions: 'propagate' })(); } catch (e) { send({ kind: 'error', message: 'menu close failed: ' + e }); }
    }
  } else if (s0 !== 8) { lobbySince = 0; entered = false; }
  if (done || !armed) return;
  const s = STATE.readS32();
  if (s !== 0) { menuSince = 0; return; }
  const now = Date.now();
  if (!menuSince) { menuSince = now; send({ kind: 'info', message: 'back in the main menu: hosting the next map in 5 seconds' }); return; }
  if (now - menuSince < 15000) return;
  hosts++; if (hosts >= 3) done = true; menuSince = 0;
  send({ kind: 'info', message: 'host try ' + hosts + ': before ' + mpState() + ' ' + cvars() });
  try {
    const cur = (cvarValue(LEVEL) || '').toUpperCase();
    const next = WANT || (cur ? LIST[(LIST.indexOf(cur) + 1) % LIST.length] : 'DRYGULCH');
    const mem = Memory.allocUtf8String(next); keep.push(mem);
    cvarSetter()(LEVEL, mem, 0, 0);
    if (!lobbyArgs) lobbyArgs = { mgr: exe.base.add(0x1355420).readPointer(), name: 'lan', flags: 0, kind: 0, list: ptr(1), count: 0 };
    if (lobbyArgs.count > 0) { send({ kind: 'error', message: 'your host passed ' + lobbyArgs.count + ' settings: not replaying (see above)' }); return; }
    send({ kind: 'info', message: 'mp_levelName ' + cur + ' -> ' + cvarValue(LEVEL) + '; replaying MoveToNewLobby' });
    const MODEP = exe.base.add(0xf0d724), want = parseInt(CV.mp_gamemode ? cvarValue(CV.mp_gamemode) : '', 10);
    send({ kind: 'info', message: 'game mode (exe+0xf0d724) ' + MODEP.readS32() + (isNaN(want) ? '' : ' -> ' + want) });
    if (!isNaN(want)) MODEP.writeS32(want);
    send({ kind: 'info', message: 'lobby kind ' + JSON.stringify(lobbyArgs.name) });
    const nm = Memory.allocUtf8String(lobbyArgs.name); keep.push(nm);
    const empty = Memory.alloc(0x20); keep.push(empty);
    const move = new NativeFunction(exe.base.add(0x135cf0), 'void', ['pointer', 'pointer', 'int', 'int', 'pointer'], { exceptions: 'propagate' });
    move(lobbyArgs.mgr, nm, lobbyArgs.flags, lobbyArgs.kind, lobbyArgs.list === null || lobbyArgs.list.isNull() ? ptr(0) : empty);
    send({ kind: 'info', message: 'MoveToNewLobby replayed; the game state is now ' + STATE.readS32() + ' ' + mpState() });
  } catch (e) { send({ kind: 'error', message: 'hosting failed: ' + (e.stack || e) }); }
} });

setInterval(function () {
  const s = STATE.readS32();
  if (s !== lastState) { send({ kind: 'state', from: lastState, to: s, level: LEVEL ? cvarValue(LEVEL) : null }); send({ kind: 'info', message: '  ' + mpState() + ' ' + cvars() }); lastState = s; }
  if (s === 2) sawMatch = true;
  if (!armed && LEVEL && s === 0) { armed = true; send({ kind: 'info', message: 'ready: when this match ends and you are back in the main menu, it hosts the next map by itself' }); }
}, 250);
send({ kind: 'ready' });
"""

NAMES = {0: "main menu", 1: "loading", 2: "playing", 3: "starting", 8: "lobby", 10: "joining"}


def own_game_pid():
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='OutlawsAHOM.exe'\" | "
          "ForEach-Object { '{0}|{1}' -f $_.ProcessId, $_.CommandLine }")
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True, timeout=30)
    mine = [int(l.split("|", 1)[0]) for l in r.stdout.splitlines() if l.strip() and "-userpath" not in l]
    return mine[0] if mine else None


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    print("waiting for your own game (start Outlaws; stay in the main menu)...")
    pid = None
    fresh = False
    for _ in range(300):
        pid = own_game_pid()
        if pid:
            break
        fresh = True
        time.sleep(2)
    if not pid:
        print("your game was not found")
        return
    if fresh:
        print("your game just started: waiting 45 seconds so you can get past the title screen to the main menu...")
        time.sleep(45)
    print("found it. Leave the game in its main menu: in about 15 seconds this test hosts a LAN game by itself.")
    log = open(OUT, "w", encoding="utf-8")
    t0 = time.time()

    def w(line):
        print(line)
        log.write(f"{time.strftime('%H:%M:%S')} +{time.time() - t0:6.1f}s  {line}\n")
        log.flush()

    def on_msg(msg, data):
        if msg.get("type") == "error":
            w("script error: %s" % msg.get("description"))
            return
        pl = msg.get("payload") or {}
        k = pl.get("kind")
        if k == "state":
            w(f"game: {NAMES.get(pl['from'], pl['from'])} -> {NAMES.get(pl['to'], pl['to'])}   (mp_levelName {pl.get('level')})")
        else:
            w(f"{k}: {pl.get('message', '')}")

    s = frida.get_local_device().attach(pid)
    sc = s.create_script(JS.replace("__WANT__", repr(WANT)))
    sc.on("message", on_msg)
    sc.load()
    t_end = time.time() + 420
    try:
        while time.time() < t_end:
            time.sleep(1)
            if int(time.time() - t0) % 15 == 0 and own_game_pid() != pid:
                w("your game closed")
                break
    except KeyboardInterrupt:
        pass
    try:
        sc.unload()
        s.detach()
    except Exception:
        pass
    log.close()
    print(f"done: {OUT}")


if __name__ == "__main__":
    main()
