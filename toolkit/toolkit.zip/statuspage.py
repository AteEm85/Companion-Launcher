"""The server status page: a small web page friends can open on a phone to see which games this PC is running, who is in
them and the live scores.

    http://<this PC's ZeroTier or home-network address>:8791/

The launcher (launchertools.py) and companionhost.py start it; only addresses on the home network or ZeroTier (private
addresses) get an answer, and all it can show is what is in state/live_*.json (livestats.py) and state/match_summaries.json:
names, scores, the map. Standard library only.

    GET /                the page (it refreshes itself every 3 seconds)
    GET /games.json      the games running now: [{mode, map, tier, target, team_kills, final, age, rows, summary}]
    GET /live.json       the newest game's board (the companion app's scoreboard and director camera read this)
    GET /history.json    the last 20 finished matches' summaries
    GET /director        the director camera: an overhead live view that follows the most exciting fight on its own
    GET /director.json   where everyone is and which fight the camera is on (director())
    GET /map/<key>.json  the map's walls, for drawing it"""
import ipaddress
import json
import os
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = 8791
LIVE_FOR = 25.0          # a board not written for this long is a game that has stopped (a final one stays up 3 minutes)
FINAL_FOR = 180.0
_srv = [None]
HERE = [Path(__file__).resolve().parent]


def games():
    st = HERE[0] / "state"
    out, now = [], time.time()
    try:
        files = [p for p in st.glob("live_*.json")]
    except OSError:
        files = []
    for p in files:
        try:
            age = now - p.stat().st_mtime
            if age > FINAL_FOR:
                continue
            b = json.loads(p.read_text())
        except (OSError, ValueError):
            continue
        if not b.get("final") and age > LIVE_FOR:
            continue
        b["age"] = round(age, 1)
        b["id"] = p.stem[5:]
        out.append(b)
    out.sort(key=lambda b: (bool(b.get("final")), b["age"]))
    return out


def newest():
    g = games()
    return g[0] if g else {}


def history(n=20):
    try:
        h = json.loads((HERE[0] / "state" / "match_summaries.json").read_text())
        return h[-n:][::-1] if isinstance(h, list) else []
    except (OSError, ValueError):
        return []


import math
import re
BOSS_RE = re.compile(r"^(Santa|Bob Graham|Dr\. Death|Headless Demon|Healer|Krampus|Nutcracker|Jack Frost|Frost Clone \d+|Gingerbread Man)$")
BOT_RE = re.compile(r"^((Zombie|Skeleton|Bot|Host Bot|Elf|Santa|Gingerbread|Snowman|Nutcracker|Present)( \d+| #\d{3}| No\. \d{3})?|GhostBot_\d+|Bob Graham|Dr\. Death|Headless Demon|Healer|Krampus|Nutcracker|Jack Frost|Frost Clone \d+|Gingerbread Man|Mrs\. Claus)$")
_maps = {}
CAMS = {}                                                   # each game's camera: which fight it is on


def map_walls(key):
    """[[x1, z1, x2, z2], ...] of the map's solid walls (the outer sky boxes left out), cached"""
    key = re.sub(r"[^A-Za-z0-9_]", "", key or "")
    if not key:
        return None
    if key in _maps:
        return _maps[key]
    try:
        import sys as _s
        if str(HERE[0]) not in _s.path:
            _s.path.insert(0, str(HERE[0]))
        import lvt
        secs = lvt.load(key)
    except Exception:
        _maps[key] = None
        return None
    segs = []
    for sc in secs:
        v = sc.vertices
        if not v:
            continue
        area = abs(sum(v[i][0] * v[(i + 1) % len(v)][1] - v[(i + 1) % len(v)][0] * v[i][1] for i in range(len(v)))) / 2
        if area > 60000:
            continue
        for w in sc.walls:
            if w.adjoin < 0:
                a_, b_ = v[w.v1], v[w.v2]
                segs.append([round(a_[0], 1), round(a_[1], 1), round(b_[0], 1), round(b_[1], 1)])
    _maps[key] = segs
    return segs


def pos_file(gid):
    """a game's position file: live_<run>.json goes with pos_<run>.txt (the Map Rotation's live_rotation.json with pos_live.txt)"""
    gid = re.sub(r"[^A-Za-z0-9_\-]", "", gid or "")
    return HERE[0] / "state" / ("pos_live.txt" if gid == "rotation" else f"pos_{gid}.txt")


def positions(gid=None):
    """the position list of game gid, or the newest one (a ghost game's feed ghost writes state/pos_<run>.txt four times a second)"""
    best = None
    try:
        for p in ([pos_file(gid)] if gid else (HERE[0] / "state").glob("pos_*.txt")):
            if not p.exists():
                continue
            mt = p.stat().st_mtime
            if best is None or mt > best[0]:
                best = (mt, p)
    except OSError:
        return []
    if best is None or time.time() - best[0] > 5.0:
        return []
    out = []
    try:
        lines = best[1].read_text().splitlines()[1:]
    except OSError:
        return []
    for ln in lines:
        q = ln.split("|")
        if len(q) >= 4:
            try:
                out.append({"name": q[0], "x": float(q[1]), "y": float(q[2]), "z": float(q[3]),
                            "bot": bool(BOT_RE.match(q[0])), "boss": bool(BOSS_RE.match(q[0]))})
            except ValueError:
                pass
    return out


def director(gid=None):
    """Which fight the camera is on: every player against every enemy near them, scored by how close they are (a duel up
    close), a boss in it (Santa, Bob Graham ...: far more), streaks on the line and how many are in it. The camera keeps its
    fight until another one is clearly better for 3 seconds, so it doesn't jump about."""
    # (18 Nov, the user: the camera opened straight onto an old test game. /director now lists the games first and each one
    #  is watched by its id: its own board and its own positions.)
    ps = positions(gid)
    b = (next((g for g in games() if g.get("id") == gid), None) if gid else newest()) or {}
    CAM = CAMS.setdefault(gid or "", {"key": None, "since": 0.0, "best": None})
    rows = {r["name"]: r for r in b.get("rows") or []}
    humans = [p for p in ps if not p["bot"]] or [p for p in ps]
    cands = []
    for h in humans:
        for e in ps:
            if e is h or (not e["bot"] and not h["bot"] and len(humans) < 2):
                continue
            d = math.hypot(h["x"] - e["x"], h["z"] - e["z"])
            if d > 140 or abs(h["y"] - e["y"]) > 40:
                continue
            crowd = sum(1 for o in ps if math.hypot(o["x"] - h["x"], o["z"] - h["z"]) < 50)
            sc = 100.0 / (8.0 + d) + (3.0 if e["boss"] else 0) + 0.3 * crowd
            sc += 0.15 * ((rows.get(h["name"]) or {}).get("streak", 0) + (rows.get(e["name"]) or {}).get("streak", 0))
            if not e["bot"] and not h["bot"]:
                sc += 1.0                                          # two players: a real duel
            key = tuple(sorted((h["name"], e["name"])))
            why = "BOSS FIGHT" if e["boss"] else ("CLOSE DUEL" if d < 30 else "FIREFIGHT")
            cands.append((sc, key, h, e, d, why))
    now = time.time()
    focus = None
    if cands:
        cands.sort(key=lambda c: -c[0])
        top = cands[0]
        cur = next((c for c in cands if c[1] == CAM["key"]), None)
        if cur is None or (top[1] != CAM["key"] and top[0] > cur[0] * 1.3 and now - CAM["since"] > 3.0):
            CAM.update(key=top[1], since=now)
            cur = top
        sc, key, h, e, d, why = cur
        focus = {"x": (h["x"] + e["x"]) / 2, "z": (h["z"] + e["z"]) / 2, "r": max(40.0, d * 0.9 + 30.0),
                 "title": f"{why}: {h['name']} vs {e['name']}", "a": h["name"], "b": e["name"], "dist": round(d)}
    elif humans:
        h = humans[0]
        focus = {"x": h["x"], "z": h["z"], "r": 70.0, "title": f"Following {h['name']}", "a": h["name"], "b": ""}
    return {"t": now, "map": b.get("map"), "map_key": b.get("map_key"), "mode": b.get("mode"), "tier": b.get("tier"),
            "objective": b.get("objective", ""), "feed": b.get("feed") or [], "players": ps, "focus": focus,
            "rows": (b.get("rows") or [])[:16], "final": b.get("final", False), "gone": bool(gid) and not b}


DIRECTOR = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Director cam</title><style>
html,body{margin:0;height:100%;background:#0d0b09;color:#efe6d2;font:14px system-ui,Segoe UI,Roboto,sans-serif;overflow:hidden}
canvas{display:block;width:100vw;height:100vh}
#top{position:fixed;left:0;right:0;top:0;padding:10px 14px;background:linear-gradient(#000c,#0000);pointer-events:none}
#title{font-weight:800;font-size:20px;letter-spacing:.5px;color:#ffd166;text-shadow:0 2px 4px #000}
#sub{color:#b9ad92;font-size:13px}#feed{position:fixed;right:12px;top:64px;text-align:right;font-size:13px;line-height:1.5;text-shadow:0 1px 3px #000}
#board{position:fixed;left:12px;bottom:12px;font-size:12px;background:#000a;border-radius:8px;padding:6px 10px;font-variant-numeric:tabular-nums}
#board td{padding:1px 6px}
#board{min-width:220px}#board th{color:#ffd166;font-size:11px;font-weight:700;text-align:right;padding:1px 6px}#board th:first-child,#board td:first-child{text-align:left}
#board td{text-align:right}#board tr.g td{color:#9a8f78}#board .cap{font-weight:800;color:#ffd166;letter-spacing:.5px;margin-bottom:3px}
#view{position:fixed;right:12px;bottom:12px;background:#000c;border-radius:8px;padding:6px 8px;font-size:13px;color:#cbbfa5;display:flex;gap:6px;align-items:center}
#view select,#view button{background:#1d1912;color:#efe6d2;border:1px solid #5a4a33;border-radius:6px;font:inherit;padding:3px 6px;cursor:pointer}
#live{position:fixed;right:12px;top:12px;background:#c0211f;color:#fff;font-weight:800;font-size:11px;padding:3px 7px;border-radius:4px}
</style></head><body><canvas id="c"></canvas><div id="top"><div id="title">Director cam</div><div id="sub">waiting for a game...</div></div>
<div id="live">LIVE</div><div id="feed"></div><div id="board"></div>
<div id="view"><a href="director" style="color:#ffd166;text-decoration:none;margin-right:6px">&larr; All games</a>View<select id="mode"><option value="map">Whole map</option><option value="auto">Follow the action</option></select><button id="zo" title="Zoom out (-)">&minus;</button><button id="zi" title="Zoom in (+)">+</button><button id="zf" title="Fit (0)">Fit</button><button id="sb">Scoreboard</button></div><script>
const cv=document.getElementById('c'),g=cv.getContext('2d');let walls=null,mapKey=null,cam={x:0,z:0,r:120},want=null,D=null,trails={};
function fit(){cv.width=innerWidth*devicePixelRatio;cv.height=innerHeight*devicePixelRatio}addEventListener('resize',fit);fit();
const E=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
// (18 Nov, the user: the camera following the fights and moving the map about can cause a headache. The default is now the whole
//  map, standing still; "Follow the action" is the old camera, and any player can be followed on their own. The choice is kept.
//  The scoreboard: everyone in the game (ghosts and bots dimmer), shown or hidden with its button or the S key.)
const sel=document.getElementById('mode');let mode='map',showSB=true;try{mode=localStorage.getItem('dirview')||'map';showSB=localStorage.getItem('dirsb')!=='0'}catch(e){}
sel.onchange=()=>{mode=sel.value;try{localStorage.setItem('dirview',mode)}catch(e){}};
function toggleSB(){showSB=!showSB;try{localStorage.setItem('dirsb',showSB?'1':'0')}catch(e){};board()}
document.getElementById('sb').onclick=toggleSB;addEventListener('keydown',e=>{if(e.key==='s'||e.key==='S')toggleSB()});
// (18 Nov, the user: a zoom. The wheel, the + / - buttons or keys zoom; on the whole map the wheel zooms where the pointer is and
//  the map can be dragged about; Fit (or 0) puts it back. Following someone, the zoom sets how close the camera is.)
let Z=1,pan={x:0,z:0},S=1,drag=null;const zclamp=v=>Math.max(0.5,Math.min(12,v));
function zoomAt(f,px,py){const W=cv.width,H=cv.height;if(mode==='map'&&box&&px!==undefined){const wx=cam.x+(px-W/2)/S,wz=cam.z-(py-H/2)/S;
  const nz=zclamp(Z*f),k=nz/Z;Z=nz;const ns=S*k;pan.x=wx-(px-W/2)/ns-box.x;pan.z=wz+(py-H/2)/ns-box.z}else Z=zclamp(Z*f)}
function fitView(){Z=1;pan={x:0,z:0}}
document.getElementById('zi').onclick=()=>zoomAt(1.25);document.getElementById('zo').onclick=()=>zoomAt(1/1.25);document.getElementById('zf').onclick=fitView;
// (the wheel is caught on the whole page, not just the map: over the scoreboard or the kill feed it did nothing)
addEventListener('wheel',e=>{if(e.target&&e.target.closest&&e.target.closest('#view'))return;const d=e.deltaY||e.deltaX;if(!d)return;e.preventDefault();
 zoomAt(d<0?1.15:1/1.15,e.clientX*devicePixelRatio,e.clientY*devicePixelRatio)},{passive:false});
cv.addEventListener('mousedown',e=>{if(mode==='map')drag={x:e.clientX,y:e.clientY,p:{...pan}}});
addEventListener('mousemove',e=>{if(drag){pan.x=drag.p.x-(e.clientX-drag.x)*devicePixelRatio/S;pan.z=drag.p.z+(e.clientY-drag.y)*devicePixelRatio/S}});
addEventListener('mouseup',()=>{drag=null});
addEventListener('keydown',e=>{if(e.key==='+'||e.key==='=')zoomAt(1.25);else if(e.key==='-'||e.key==='_')zoomAt(1/1.25);else if(e.key==='0')fitView()});
let box=null;function bounds(){if(!walls||!walls.length){box=null;return}let a=1e9,b=-1e9,c=1e9,d=-1e9;for(const w of walls){a=Math.min(a,w[0],w[2]);b=Math.max(b,w[0],w[2]);c=Math.min(c,w[1],w[3]);d=Math.max(d,w[1],w[3])}box={x:(a+b)/2,z:(c+d)/2,w:Math.max(20,b-a),h:Math.max(20,d-c)}}
function options(){const names=[...new Set((D&&D.players||[]).map(p=>p.name))].sort();const want_=['map','auto'].concat(names.map(n=>'p:'+n));
 if(mode.startsWith('p:')&&!want_.includes(mode))want_.push(mode);
 const have=[...sel.options].map(o=>o.value);if(have.join('|')!==want_.join('|')){sel.innerHTML='';for(const v of want_){const o=document.createElement('option');o.value=v;o.textContent=v==='map'?'Whole map':v==='auto'?'Follow the action':'Follow '+v.slice(2);sel.appendChild(o)}}
 sel.value=mode}
function board(){const el=document.getElementById('board');el.hidden=!showSB;if(!showSB||!D)return;
 const rows=(D.rows||[]).slice().sort((a,b)=>(b.kills-a.kills)||(a.deaths-b.deaths));
 el.innerHTML='<div class="cap">SCOREBOARD</div><table><tr><th></th><th>Kills</th><th>Deaths</th><th>Streak</th></tr>'+(rows.length?rows.map(r=>`<tr class="${r.ghost?'g':''}"><td>${E(r.name)}</td><td>${r.kills}</td><td>${r.deaths}</td><td>${r.streak||''}</td></tr>`).join(''):'<tr><td colspan="4">no scores yet</td></tr>')+'</table>'}
const GID=new URLSearchParams(location.search).get('g')||'';
async function poll(){try{D=await (await fetch('director.json?g='+encodeURIComponent(GID),{cache:'no-store'})).json();
 if(D.gone){document.getElementById('title').textContent='This game has ended';document.getElementById('sub').innerHTML='<a href="director" style="color:#ffd166">Back to all games</a>';return}
 if(D.map_key&&D.map_key!==mapKey){mapKey=D.map_key;walls=await (await fetch('map/'+encodeURIComponent(mapKey)+'.json')).json();bounds()}
 options();
 if(D.focus)want=D.focus;
 document.getElementById('title').textContent=mode==='auto'?(D.focus?D.focus.title:'Waiting for a fight...'):mode==='map'?(D.map||'Whole map'):('Following '+mode.slice(2));
 document.getElementById('sub').textContent=[D.map,D.mode,D.tier?('tier: '+D.tier):'',D.objective?D.objective.split('\\n').pop():''].filter(Boolean).join(' \\u00b7 ');
 document.getElementById('feed').innerHTML=(D.feed||[]).slice(-6).map(E).join('<br>');
 board();
 for(const p of D.players||[]){(trails[p.name]=trails[p.name]||[]).push([p.x,p.z]);if(trails[p.name].length>16)trails[p.name].shift()}
}catch(e){document.getElementById('sub').textContent='no connection ('+e+')'}}
setInterval(poll,250);poll();
function draw(){requestAnimationFrame(draw);const W=cv.width,H=cv.height;let s;
 if(mode==='map'&&box){cam.x=box.x+pan.x;cam.z=box.z+pan.z;s=Math.min(W/(box.w*1.06),(H*0.86)/(box.h*1.06))*Z}       // the whole map, still
 else{let t=null;
  if(mode==='auto')t=want;
  else if(mode.startsWith('p:')){const p=(D&&D.players||[]).find(q=>q.name===mode.slice(2));if(p)t={x:p.x,z:p.z,r:70}}
  if(t){cam.x+=(t.x-cam.x)*0.08;cam.z+=(t.z-cam.z)*0.08;cam.r+=(t.r-cam.r)*0.05}
  s=Math.min(W,H)/(2*cam.r)*Z}
 S=s;
 const X=x=>W/2+(x-cam.x)*s,Y=z=>H/2-(z-cam.z)*s;
 g.fillStyle='#0d0b09';g.fillRect(0,0,W,H);
 const grad=g.createRadialGradient(W/2,H/2,0,W/2,H/2,Math.max(W,H)*0.7);grad.addColorStop(0,'#1d1912');grad.addColorStop(1,'#060504');g.fillStyle=grad;g.fillRect(0,0,W,H);
 if(walls){g.strokeStyle='#8c7a5c';g.lineWidth=Math.max(1,2*devicePixelRatio);g.beginPath();for(const w of walls){g.moveTo(X(w[0]),Y(w[1]));g.lineTo(X(w[2]),Y(w[3]))}g.stroke()}
 if(!D)return;const f=D.focus||{};
 for(const p of D.players||[]){const t=trails[p.name]||[];g.strokeStyle=p.bot?'#7a3a2a55':'#ffd16655';g.lineWidth=2*devicePixelRatio;g.beginPath();t.forEach((q,i)=>i?g.lineTo(X(q[0]),Y(q[1])):g.moveTo(X(q[0]),Y(q[1])));g.stroke()}
 for(const p of D.players||[]){const x=X(p.x),y=Y(p.z),inF=p.name===f.a||p.name===f.b,rad=(p.boss?11:7)*devicePixelRatio;
  if(inF){g.strokeStyle='#ffd166';g.lineWidth=2*devicePixelRatio;g.beginPath();g.arc(x,y,rad+6*devicePixelRatio+2*Math.sin(Date.now()/150),0,7);g.stroke()}
  g.fillStyle=p.boss?'#ff5a1f':p.bot?'#b8412c':'#56b4ff';g.beginPath();g.arc(x,y,rad,0,7);g.fill();
  g.font=`${(inF?14:11)*devicePixelRatio}px system-ui`;g.fillStyle=inF?'#fff':'#cbbfa5';g.textAlign='center';g.fillText(p.name,x,y-rad-5*devicePixelRatio)}
 if(f.a&&f.b){const A=(D.players||[]).find(p=>p.name===f.a),B=(D.players||[]).find(p=>p.name===f.b);if(A&&B){g.setLineDash([6*devicePixelRatio,6*devicePixelRatio]);g.strokeStyle='#ffd16699';g.beginPath();g.moveTo(X(A.x),Y(A.z));g.lineTo(X(B.x),Y(B.z));g.stroke();g.setLineDash([])}}
}draw();</script></body></html>"""


DIRECTOR_LIST = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Director cam</title><style>
body{margin:0;background:#0d0b09;color:#efe6d2;font:15px system-ui,Segoe UI,Roboto,sans-serif;padding:24px max(16px,4vw)}
h1{margin:0 0 4px;color:#ffd166;font-size:24px;letter-spacing:.5px}.sub{color:#b9ad92;margin-bottom:20px}
#list{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px}
a.g{display:block;text-decoration:none;color:inherit;background:#1d1912;border:1px solid #3d3123;border-radius:12px;padding:14px 16px}
a.g:hover{border-color:#ffd166}.map{font-weight:800;font-size:18px}.mode{color:#b9ad92;font-size:13px;margin:2px 0 8px}
.tag{float:right;font-size:11px;font-weight:800;padding:3px 8px;border-radius:99px;background:#c0211f;color:#fff}.tag.end{background:#3a2a17;color:#ffd166}
.who{font-size:13px;color:#cbbfa5}#links{display:flex;flex-wrap:wrap;gap:10px;margin:-8px 0 18px}
#links a{color:#ffd166;text-decoration:none;border:1px solid #5a4a33;border-radius:99px;padding:6px 14px;font-size:14px}#links a:hover{border-color:#ffd166}.empty{color:#b9ad92;padding:30px 0}
</style></head><body><h1>Director cam</h1><div class="sub">Pick a game to watch</div><div id="links"></div><div id="list"><div class="empty">Looking for games...</div></div><script>
const E=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
async function poll(){try{const d=await (await fetch('games.json',{cache:'no-store'})).json();const gs=d.games||[];
 document.getElementById('list').innerHTML=gs.length?gs.map(g=>{const rows=g.rows||[];const ppl=rows.filter(r=>!r.ghost).map(r=>r.name);
  const lead=rows.slice().sort((a,b)=>b.kills-a.kills)[0];
  return `<a class="g" href="director?g=${encodeURIComponent(g.id)}"><span class="tag ${g.final?'end':''}">${g.final?'FINISHED':'LIVE'}</span>
  <div class="map">${E(g.map||'Unknown map')}</div><div class="mode">${E([g.id==='rotation'?'Map Rotation':'',g.mode,g.tier?('tier '+g.tier):''].filter(Boolean).join(' \u00b7 '))}</div>
  <div class="who">${ppl.length?('Players: '+E(ppl.join(', '))):'No players yet'}${lead&&lead.kills?('<br>Leading: '+E(lead.name)+' ('+lead.kills+' kills)'):''}</div></a>`}).join(''):'<div class="empty">No games running right now. This page checks again every few seconds.</div>'}
 catch(e){document.getElementById('list').innerHTML='<div class="empty">No connection ('+E(e)+')</div>'}}
// (18 Nov, the user: a link from this camera to the 24/7 server's. Other cameras come from director_links.json next to the
//  launcher: [{"name": "...", "url": "http://.../director"}].)
fetch('links.json',{cache:'no-store'}).then(r=>r.json()).then(L=>{document.getElementById('links').innerHTML=(L||[]).map(l=>`<a href="${E(l.url)}">${E(l.name||l.url)} &rarr;</a>`).join('')}).catch(()=>{});
setInterval(poll,3000);poll();</script></body></html>"""


PAGE = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Outlaws servers</title><style>
:root{--bg:#15110c;--card:#221b13;--line:#3d3123;--text:#efe6d2;--dim:#a39679;--gold:#f2c443;--red:#d9602b}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:15px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;padding:16px}
h1{font-size:20px;margin:0 0 2px;letter-spacing:.5px}.sub{color:var(--dim);font-size:13px;margin-bottom:14px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px;margin-bottom:12px}
.top{display:flex;justify-content:space-between;align-items:baseline;gap:8px;flex-wrap:wrap}
.map{font-weight:700;font-size:17px}.tag{font-size:12px;font-weight:700;padding:2px 7px;border-radius:99px;background:#3a2a17;color:var(--gold)}
.tag.over{background:#3a1a14;color:#ff8a6a}.meta{color:var(--dim);font-size:13px;margin:4px 0 8px}
table{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums}th{color:var(--dim);font-size:11px;font-weight:600;text-align:right;padding:4px 3px;border-bottom:1px solid var(--line)}
th:first-child,td:first-child{text-align:left}td{padding:6px 3px;text-align:right;border-bottom:1px solid #2b2218}
td .t{display:block;color:var(--dim);font-size:11px}.bot td{color:var(--dim)}.mvp{color:var(--gold);font-weight:700}
.empty{color:var(--dim);text-align:center;padding:28px 8px}.awards{display:flex;gap:10px;flex-wrap:wrap;margin-top:8px;font-size:13px}
.awards div{background:#2b2218;border-radius:8px;padding:6px 9px}.awards b{display:block;color:var(--dim);font-size:10px;letter-spacing:.5px}
h2{font-size:14px;color:var(--dim);margin:20px 0 8px;text-transform:uppercase;letter-spacing:1px}
.hist{font-size:13px;padding:8px 10px}.hist .when{color:var(--dim);float:right}
</style></head><body><h1 id="pc">Outlaws servers</h1><div class="sub" id="sub">loading...</div><div id="games"></div>
<p><a href="director" style="color:#ffd166;font-weight:700">Watch live: the director cam &rarr;</a></p><h2>Recent matches</h2><div id="hist"></div><script>
const E=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const ago=t=>{const s=Math.max(0,Date.now()/1000-t);return s<90?Math.round(s)+"s ago":s<5400?Math.round(s/60)+"m ago":Math.round(s/3600)+"h ago"};
function rows(b){let r=b.rows||[],p=r.filter(x=>!x.ghost),g=r.filter(x=>x.ghost);
 if(g.length>4){const k=a=>g.reduce((s,x)=>s+(x[a]||0),0);g=[{name:(b.mode||"").includes("Christmas")?"The Elves":"The Horde",title:g.length+" on the field",kills:k("kills"),deaths:k("deaths"),streak:0,best_streak:Math.max(...g.map(x=>x.best_streak)),hits:k("hits"),shots:k("shots"),best_shot:Math.max(...g.map(x=>x.best_shot)),ghost:true}];g[0].acc=g[0].shots?Math.round(100*g[0].hits/g[0].shots):null}
 return p.concat(g)}
function card(b){const mv=(b.summary||{}).mvp;let h=`<div class="card"><div class="top"><span class="map">${E(b.map||"?")}</span>`+
 (b.final?`<span class="tag over">MATCH OVER</span>`:(b.tier?`<span class="tag">${E((b.mode||"")+": "+b.tier.toUpperCase())}</span>`:`<span class="tag">${E(b.mode||"LIVE")}</span>`))+`</div>`+
 `<div class="meta">${E(b.mode||"")}${b.target&&b.tier!=="santa"?` &middot; ${b.team_kills}/${b.target} kills`:""}${b.tier==="santa"?" &middot; Santa is out!":""}</div>`;
 const rs=rows(b);if(!rs.length)return h+`<div class="empty">Waiting for players...</div></div>`;
 h+=`<table><tr><th>Player</th><th>K</th><th>D</th><th>Streak</th><th>Acc</th></tr>`;
 for(const r of rs)h+=`<tr class="${r.ghost?"bot":""}"><td><span class="${r.name===mv&&b.final?"mvp":""}">${E(r.name)}</span><span class="t">${E(r.title||"")}</span></td><td>${r.kills}</td><td>${r.deaths}</td><td>${r.streak}${r.best_streak>r.streak?` (${r.best_streak})`:""}</td><td>${r.acc==null?"-":r.acc+"%"}</td></tr>`;
 h+=`</table>`;const s=b.summary||{};if(b.final&&s.mvp){h+=`<div class="awards"><div><b>MVP</b>${E(s.mvp)}</div>`+(s.most_kills?`<div><b>MOST KILLS</b>${E(s.most_kills[0])} (${s.most_kills[1]})</div>`:"")+(s.longest_streak?`<div><b>STREAK</b>${E(s.longest_streak[0])} (${s.longest_streak[1]})</div>`:"")+(s.best_shot?`<div><b>BEST SHOT</b>${E(s.best_shot[0])} (${s.best_shot[1]} ft)</div>`:"")+`</div>`}
 return h+`</div>`}
async function tick(){try{const g=await (await fetch("games.json",{cache:"no-store"})).json();
 document.getElementById("pc").textContent=(g.pc||"Outlaws")+" servers";
 document.getElementById("sub").textContent=(g.games.length?g.games.filter(x=>!x.final).length+" game(s) running":"No games running right now")+" \\u00b7 updated "+new Date().toLocaleTimeString();
 document.getElementById("games").innerHTML=g.games.map(card).join("")||`<div class="card empty">Nothing running. Check back soon.</div>`;
 const h=await (await fetch("history.json",{cache:"no-store"})).json();
 document.getElementById("hist").innerHTML=h.map(m=>{const s=m.summary||{};return `<div class="card hist"><span class="when">${ago(m.t)}</span><b>${E(m.map||"?")}</b> ${E(m.mode||"")}<br>${s.mvp?"MVP "+E(s.mvp)+" &middot; "+E(s.mvp_line||""):"no kills"}</div>`}).join("")||`<div class="sub">None yet.</div>`;
}catch(e){document.getElementById("sub").textContent="can't reach the server ("+e+")"}}
tick();setInterval(tick,3000);</script></body></html>"""


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, data, ctype):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(data)
        except OSError:
            pass

    def do_GET(self):
        try:
            ip = ipaddress.ip_address(self.client_address[0])
            if not (ip.is_private or ip.is_loopback):
                return self.send_error(403)                     # home network / ZeroTier only
            p = self.path.split("?")[0]
            if p in ("/", "/index.html", "/status"):
                return self._send(PAGE.encode("utf-8"), "text/html; charset=utf-8")
            if p == "/games.json":
                return self._send(json.dumps({"pc": socket.gethostname(), "games": games()}).encode(), "application/json")
            if p == "/live.json":
                return self._send(json.dumps(newest()).encode(), "application/json")
            if p == "/history.json":
                return self._send(json.dumps(history()).encode(), "application/json")
            from urllib.parse import parse_qs
            q = parse_qs(self.path.split("?", 1)[1]) if "?" in self.path else {}
            gid = (q.get("g") or [""])[0]
            if p == "/director":
                return self._send((DIRECTOR if gid else DIRECTOR_LIST).encode("utf-8"), "text/html; charset=utf-8")
            if p == "/links.json":                 # director_links.json: other cameras to link to (kept on this PC only)
                try:
                    links = json.loads((HERE[0] / "director_links.json").read_text())
                except (OSError, ValueError):
                    links = []
                return self._send(json.dumps(links if isinstance(links, list) else []).encode(), "application/json")
            if p == "/director.json":
                return self._send(json.dumps(director(gid or None)).encode(), "application/json")
            if p.startswith("/map/") and p.endswith(".json"):
                from urllib.parse import unquote
                return self._send(json.dumps(map_walls(unquote(p[5:-5])) or []).encode(), "application/json")
            self.send_error(404)
        except Exception:
            try:
                self.send_error(500)
            except OSError:
                pass


def start(here=None):
    """Serve the page (once per process; a busy port means another program here already does, from the same files)."""
    if here:
        HERE[0] = Path(here)
    if _srv[0]:
        return True
    try:
        _srv[0] = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    except OSError:
        return False
    threading.Thread(target=_srv[0].serve_forever, daemon=True).start()
    return True


def addresses():
    """the addresses friends can use: http://<ip>:8791/"""
    out = []
    try:
        for a in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = a[4][0]
            if ip not in out and not ip.startswith("127."):
                out.append(ip)
    except OSError:
        pass
    return [f"http://{ip}:{PORT}/" for ip in out]


if __name__ == "__main__":
    start()
    print("status page:", ", ".join(addresses()) or f"http://localhost:{PORT}/")
    while True:
        time.sleep(3600)
