"""Puts your own game on the Survivors (red) team as soon as its lobby shows: python autojoin.py <game pid> [red|blue] [log file]
Attaches to your game the way the bots do, presses 'Join Red' once the lobby is up, waits until you are in the match and lets go
again. Used by the launcher for Survival Horde so nobody joins the Horde by accident. If anything goes wrong it just stops:
you can still pick your team by hand."""
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOBBY_STATE = 8
PICK = {"red": 3, "blue": 4}


def log(msg, path=None):
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    try:
        if path:
            with open(path, "a") as f:
                f.write(line + "\n")
    except OSError:
        pass


def main():
    pid = int(sys.argv[1])
    team = (sys.argv[2] if len(sys.argv) > 2 else "red").lower()
    logf = sys.argv[3] if len(sys.argv) > 3 else None
    import frida
    dev = frida.get_local_device()
    session = None
    end = time.time() + 150
    while time.time() < end:                      # the game may still be starting
        try:
            session = dev.attach(pid)
            break
        except Exception:
            time.sleep(1.0)
    if session is None:
        log("autojoin: could not attach to your game; pick your team by hand", logf)
        return 1
    script = session.create_script((HERE / "input_agent.js").read_text())
    script.on("message", lambda m, d: None)
    script.load()
    api = script.exports_sync
    pressed_at, presses, seen_lobby_at = 0.0, 0, None
    deadline = time.time() + 20 * 60
    try:
        while time.time() < deadline:
            time.sleep(0.5)
            try:
                lob = api.lobby()
            except Exception:
                continue                           # not ready yet (or the game is closing)
            if lob and lob.get("state") == LOBBY_STATE and lob.get("pick") == 0:
                if seen_lobby_at is None:
                    seen_lobby_at = time.time()
                    log("autojoin: your lobby is up", logf)
                if time.time() - seen_lobby_at >= 2.0 and time.time() - pressed_at >= 3.0 and presses < 20:
                    api.lobby_join(PICK[team])
                    pressed_at, presses = time.time(), presses + 1
                    log(f"autojoin: joined the {team} team (Survivors)", logf)
            elif presses and lob and lob.get("state") != LOBBY_STATE and time.time() - pressed_at > 3.0:
                log("autojoin: you are in the match", logf)
                return 0
    finally:
        try:
            script.unload()
            session.detach()
        except Exception:
            pass
    log("autojoin: gave up waiting for the lobby; pick your team by hand", logf)
    return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print("autojoin:", e)
        sys.exit(1)
