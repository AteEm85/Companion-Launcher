@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" labextract.py olremaster2.lab ijpistol.SPX
".venv\Scripts\python.exe" labextract.py olremaster1.lab ijfist.SPX ijknife.SPX
echo.
echo Done. Tell Claude it finished.
pause
