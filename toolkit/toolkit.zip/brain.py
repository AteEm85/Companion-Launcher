"""Bot brain: hunt the nearest living player, aim, shoot only with a clear line of sight, reload fully,
pick the best weapon that has ammo, collect items, and respawn with E after dying.

Behaviours (BEHAVIOURS, picked per bot) change what it fights with: the sapper throws TNT (tnt.py), the sniper
and the pistolero favour the rifle and the pistol, the brawler fights with the knife or its fists only.

Movement uses the level's sector graph (nav.py) when the level has been identified: routes to items, to
where a target was last seen, and to random spots when wandering. Without a level it falls back to walking
straight at things. Keys are chosen relative to where we're looking, so the bot can follow a route while
aiming at an enemy.

The brain runs at about 20 ticks a second. Each tick it reads the world through the agent (positions, dead
flags, line of sight computed on the game thread, inventory, ground items), then presses or releases keys
and replaces any pending turn with a speed-limited step toward where it wants to look.
"""
import json
import math
import os
import random
import time
import gungame
from dataclasses import dataclass, field

import items as itemlib
import nav
import tnt

FULL_TURN = 16384                  # 14-bit angles: 16384 = 360 degrees
EYE = 0.85                         # our eye height as a fraction of player height (estimate)
AIM = 0.6                          # aim point on the target, fraction of height from the feet.
                                   # Above 0.5 is the head zone (x1.5) when also near the centre line.
TNT_SLOT = 7                       # never chosen by best_weapon: only the sapper throws it (Brain.tnt_fight)
FIST_SLOT = 1
SAWED_SLOT = 6                     # the sawed-off: only without Marshall Law, and only point blank
SAWED_RANGE = 12.0                 # use it inside this distance (the game's own effective range, if lower); keep it to 1.5x
PATHCHECK_NO_GATLING = bool(os.environ.get("BOT_NO_GATLING"))   # set by pathcheck.py: no Gatling camping or carrying out
GATLING_SLOT = 9                   # can't move while it's out: used only standing still in a fight
KNIFE_SLOT = 8                     # the only weapon that works in the water (secondary fire = jab, reach 8)
BADGE_AVOID = 14.0                 # keep at least this far from a badge on the ground (pickup is ~3.5)
DOOR_PRESS = 4.0                   # ... but E only when this close: it nudges what is right in front of us
DOOR_REACH = 6.0                   # press E for a door on the route within this distance
FLEE_HEALTH = 4.0             # at or below this health (of 10) in a gunfight with cover and a health or armor item both close, bots duck behind the cover and run for the item
FLEE_CAP = 10.0               # a flee that keeps re-arming this long is not working: fight on ...
FLEE_COOLDOWN = 30.0          # ... and don't flee again for this long
COVER_REACH = 25.0             # cover (out of the enemy's line of sight) must be this near by route
FLEE_STAY = 8.0               # seconds they keep under after that
FLEE_ITEM_MAX = 83.0          # fleeing: a health item (canteen, elixir, medbag) this near is gone for before the water
FLEE_MAX = 50.0               # ... if the water is no further than this
WATER_LINGER = 12.0           # seconds in the water (not diving for an item, not fleeing) before we give up fighting/fetching there and head for land
WET_WORTH = ("CANTEEN", "ELIXIR", "DOCBAG", "BPLATE")      # Orleans: the only items worth going into the water for
ORLEANS_LINGER = 3.0          # Orleans: seconds in the water (not diving for one of those) before heading for land
POOL_COST = 45.0              # Orleans: route cost allowed for the dive under the west building and up into its pool
POOL_TRIP_MAX = 60.0          # seconds a trip into the pool may take before we give up on it
POOL_IDLE = 4.0               # seconds on the stairs/roof/in the pool with nothing to fetch before jumping off the roof
WATER_AWAY = 40.0             # ... and how long that lasts
WELL_DEPTH = 15.0            # water at least this deep (a well) is dived to the bottom without surfacing for air
WELL_AIR = 45.0              # seconds we let ourselves stay under in one
WELL_LOOK = 2.0              # seconds spent looking round the bottom when nothing is left there
DOOR_PASS_TIME = 10.0       # seconds a bot has to get through a double door after opening one half of it
SALOON_BACKOFF = 1.0        # seconds of walking backwards after nudging a saloon door from inside
DOOR_RETRY = 1.6                   # seconds to let a door swing before nudging again (85 deg at 60/s)
WINDOW_REACH = 12.0                # shoot out a window on the route within this distance
# Handover step 7: how much each character likes each gun (slot 2 revolver, 3 rifle, 4 shotgun, 5 double barrel,
# 6 sawed-off) and its aggression (1 to 8).
CHAR_NAMES = {1: "sanchez", 2: "james", 3: "twofeathers", 4: "doc", 5: "bob", 6: "mary"}
LIKING = {
    "mary":        {2: 25, 3: 5,  4: 60, 5: 10, 6: 0},
    "james":       {2: 25, 3: 75, 4: 0,  5: 0,  6: 0},
    "doc":         {2: 25, 3: 75, 4: 0,  5: 0,  6: 0},
    "sanchez":     {2: 55, 3: 0,  4: 10, 5: 10, 6: 25},
    "twofeathers": {2: 35, 3: 50, 4: 15, 5: 0,  6: 0},
    "bob":         {2: 15, 3: 0,  4: 25, 5: 60, 6: 0},
}
CHAR_AGGRESSION = {"mary": 5, "james": 4, "doc": 4, "sanchez": 6, "twofeathers": 3, "bob": 5}
SHOT_TIME = {2: 1.4, 3: 1.6, 4: 1.8, 5: 2.0, 6: 2.0}      # seconds between shots (bursts), before skill
TNT_BLAST = 50.0                  # dynamite blast radius
LEAN_BONUS = 70                   # added to a leaned-toward gun's weight in the rolls
CLOSE_BAND, FAR_BAND, BAND_HYST = 20.0, 40.0, 2.5
MOVE_KEYS = ("w", "a", "s", "d", "space", "lctrl", "lshift")
# Fire buttons on the default binds the bot copies use: mouse_left = KEY_ORD_SMALL_FIRE (primary),
# mouse_right = KEY_ORD_BIG_FIRE (secondary).
PRIMARY_FIRE = "mouse_left"
SECONDARY_FIRE = "mouse_right"
RELOAD_KEY = "r"
USE_KEY = "f"                      # KEY_ORD_USE: uses the medbag
# Shotgun and double-barrel: one press per shot. Every other weapon repeats while the button is held.
# Why (weapon logic 0xdd340/0xdd150, chor timings from the weapons' .NWX files, 100 ms per step): a fire
# or reload animation can't be interrupted on these two, a press made during one only counts if the
# button is still down when it ends, and holding fire past the end of the shot animation repeats it,
# which on an empty gun plays a ~0.5 s click. See Bots.md, "Weapon timing".
PUMP_SLOTS = {4, 5, 6}
# Teams (actor +0xB0 low nibble): 1 red, 2 blue, 3 green, 4 black, 0 none. Game modes: 1 capture the flag,
# 2 tag, 3 kill the fool with the chicken, 4 secret document, 5 team play, 6 death match. In 1, 4 and 5 players
# keep the team they picked. In 2 and 3 everyone is team 2 except the one "holder" (team 1), and the game drops
# damage between same-team players unless teamDamage is on. See Bots.md, "Teams and CTF".
TEAM_MODES = {1, 4, 5}
CTF_MODE = 1
RED, BLUE = 1, 2
TEAM_NAMES = {0: "none", 1: "red", 2: "blue", 3: "green", 4: "black"}
FLAG_HOME = 3.0                    # a flag this close (flat) to its base counts as home
# Lobby (input_agent.js lobby()): game state 8 = waiting for this player's pick. Picks: 2 join, 3 red, 4 blue.
LOBBY_STATE = 8
LOBBY_JOIN, LOBBY_RED, LOBBY_BLUE = 2, 3, 4
RELOAD_ACTION = 3                  # weapon logic action number for a reload (0-2 are the fire modes)
TNT_WOUND_ACTION = 5               # TNT: the throw is wound up and waits for primary fire to be let go (0xda1be)
DEFAULT_KEEP = 30.0                # Skill.keep_distance of the default bot


def wrap(delta):
    return (delta + FULL_TURN // 2) % FULL_TURN - FULL_TURN // 2


def to_units(degrees):
    return degrees / 360 * FULL_TURN


def to_deg(units):
    return units * 360 / FULL_TURN


def bearing(src, dst):
    """Heading that points from src to dst (0 faces +z, increasing toward +x)."""
    return to_units(math.degrees(math.atan2(dst["x"] - src["x"], dst["z"] - src["z"]))) % FULL_TURN


def clamp(v, m):
    return max(-m, min(m, v))


def flat_dist(a, b):
    return math.hypot(b["x"] - a["x"], b["z"] - a["z"])


def keys_toward(yaw, heading):
    """W/A/S/D combination that moves toward `heading` while facing `yaw` (8 directions)."""
    rel = to_deg(wrap(round(heading - yaw)))          # positive = to our right
    keys = set()
    if abs(rel) < 67.5:
        keys.add("w")
    elif abs(rel) > 112.5:
        keys.add("s")
    if 22.5 < rel < 157.5:
        keys.add("d")
    elif -157.5 < rel < -22.5:
        keys.add("a")
    return keys


@dataclass
class Skill:
    turn_speed: float = 240.0      # max turn rate, degrees per second (heading and pitch)
    aim_error: float = 4.0         # aim wobble amplitude, degrees
    reaction: float = 0.25         # seconds a target must be visible before we shoot
    sight_memory: float = 1.0      # a target out of sight for less than this keeps the reaction already made
    max_engage: float = 120.0      # never shoot beyond this distance, whatever the weapon's range
    keep_distance: float = DEFAULT_KEEP   # stop advancing inside this distance and strafe instead
    respawn_delay: float = 1.5     # seconds after dying before pressing E
    lobby_delay: float = 2.0       # seconds in the lobby before pressing Join (lets the menu settle)
    # Weapon slots by preference, best first. Close range favours the shotguns, long range the rifle.
    # Pistol, knife and fists are last resorts. TNT (7) is never picked; the sawed-off (6) only without Marshall Law (best_weapon). In the water
    # it's the knife, or fists (Brain.melee_slot).
    prefer_close: list = field(default_factory=lambda: [5, 4, 3, 9, 2, 8, 1])
    prefer_far: list = field(default_factory=lambda: [3, 9, 5, 4, 2, 8, 1])
    far: float = 90.0              # beyond this distance use prefer_far
    far_long: float = None         # beyond this distance (if set) use prefer_long instead
    prefer_long: list = None
    sprint: bool = True            # hold sprint (lshift) while moving (not while crouched) ...
    sprint_frac: float = 1.0       # ... for this fraction of the time (re-rolled every few seconds)
    strafe_frac: float = 1.0       # fraction of fight strafes actually made (the rest: stand and shoot)
    min_item_value: float = 5.0    # ignore items worth less than this (see items.value). Plain ammo
                                   # top-ups are worth 8, so idle bots collect them; pistol-only ammo 4.
    item_patience: float = 4.0     # give up on an item after this long without getting closer
    armor_detour: float = 60.0     # mid-fight or on the CTF objective, still go for a boiler plate this far along
                                   # the route, scaled by what it gives (/100: heavy plate 90, smallest 30)
    # Secondary fire for everything (pistol fanning, the knife's jab) except these slots. The double-barrel's
    # primary fires both barrels; the fists' primary punch does 1.0 damage, the secondary 0.3 (ifist.itm).
    primary_slots: set = field(default_factory=lambda: {5, 6, 1})
    reload_stall: float = 1.2      # holding R this long with no new round: let go and press again
    close_range: float = 40.0      # an enemy this close (in sight, or seen within fight_memory) is a close fight
    fight_memory: float = 3.0      # seconds an enemy out of sight still counts as close
    close_reload_below: int = 5    # in a close fight only reload with fewer rounds than this loaded (not the
                                   # shotguns, which pump() reloads shell by shell between shots)
    hold_slack: float = 6.0        # extra degrees of aim error tolerated while holding fire down
    aggression: float = 3.0        # extra degrees of aim error accepted on every shot
    lead_turn: float = 0.25        # shotguns: share of the turn made before the shot leaves (0.1 s) counted
                                   # as aimed (6 deg at 240 deg/s)
    queue_cone: float = 30.0       # during a shotgun reload, queue the next shot when aimed within this
    medbag_health: float = 4.0     # use a medbag at or below this health (of 10) in a fight
    medbag_health_idle: float = 6.0   # ... and at or below this with nobody in sight
    crouch_hold: float = 1.5       # keep crouching this long after a crouch-jump (through a window)
    # Movement: climbing crates and ledges, jumping gaps (the difficulty sets these, see DIFFICULTY).
    climb_face: float = 10.0       # degrees off square to a ledge at which we still jump at it (wider: quicker, sloppier)
    climb_jump_at: float = 3.5     # start jumping this close (flat) to the foot of a ledge (earlier = a fluid run-up)
    climb_jump_on: float = 0.35    # jump key held this long ...
    climb_jump_off: float = 0.10   # ... then let go this long, so each landing gets a fresh press (shorter: re-jumps at once)
    climb_pause: float = 0.0       # seconds the bot stands at the foot of a climb before the first jump (hesitation)
    gap_jump_at: float = 1.5       # jump a gap when this close to the take-off spot
    ctf_chase: float = 40.0        # CTF: chase a visible enemy within this distance; farther ones are only
                                   # shot at while we keep to the objective
    air_time: float = 15.0         # seconds with our head under water before we swim up for air (players drown
                                   # after about 30)
    breathe: float = 1.5           # seconds with our head out of the water that count as a fresh breath
    knife_value: float = 80.0      # item value of a knife while we have none, on Orleans (the river map) ...
    knife_value_wet: float = 130.0 # ... and while we're in the water. Elsewhere knives are worth nothing.
    knife_keep: float = 15.0       # on land, keep stabbing with the knife already out at an enemy this close
                                   # (switching to a gun takes time)
    knife_hold: float = 5.0        # and keep it out this long after climbing out of the water, whatever the range
    shore_chase: float = 30.0      # in the water with the knife out, go for an enemy on land this close: out of
                                   # the water and stab
    # Behaviour (BEHAVIOURS below).
    behaviour: str = "default"
    favorite: int = None           # weapon slot it fights with first: its pickups and ammo are worth more, and
                                   # keep_distance and back_off only apply while it's usable
    melee_only: bool = False       # never picks up or fights with guns (the brawler)
    fist_share: float = 0.0        # melee: how often it fights with its fists although it has a knife (the boxer), rolled
                                   # every 6-10 s; in the water it always uses the knife
    berserk: bool = False          # Melee zombies: no hesitation. Reacts at once, sprints straight at the enemy without
                                   # strafing, never flees, ignores pickups, and fights with fists rather than run off for a knife
                                   # (BERSERK below, applied after the difficulty)
    knife_first: bool = False      # on every map, getting a knife lying about comes first, with no fighting on the
                                   # way (on Orleans every bot does it, fighting as it goes)
    back_off: float = 0.0          # with the favourite usable, back away from an enemy closer than this
    tnt: bool = False              # throws TNT (the sapper; see Brain.tnt_fight): with sticks left it never
                                   # takes out a gun (user)
    tnt_min: float = 45.0          # never land a stick closer than this to us (blast radius 50; ~0.2 damage at 45),
                                   # or than a standing throw's reach less 2 if that's shorter (Brain.tnt_min);
                                   # an enemy closer than this still gets one (see tnt_self_max), and we back off
                                   # while it cooks
    tnt_max: float = 85.0          # light one for an enemy up to this far (standing reach ~65, running adds more);
                                   # farther ones we walk toward with the TNT out
    tnt_self_max: float = 4.0      # an enemy closer than tnt_min gets the stick thrown so it goes off right at them
                                   # (user), if the blast would do us at most this much (before armour; a full hit
                                   # is 12), allowing for us backing off until it goes
    dodge_tnt: bool = True         # run from a lit stick within dodge_radius: anyone's, ours once thrown
    dodge_radius: float = 45.0
    spawn_armor: int = 0           # boiler plate armor given at every spawn (Hell: 50), through the agent
    hop_frac: float = 0.0          # share of fight strafes made while hopping (Hell)
    # Narrow raised walkways (Brain.ledge_guard): the higher the difficulty, the tighter the steering and the better the jumps.
    ledge_turn: float = 2.0        # turning this many times faster on a ledge
    ledge_err: float = 22.0        # degrees off the waypoint at which we stand still and turn before walking on
    ledge_stop: float = 1.3        # stop this far short of an edge we are walking at
    ledge_gap: float = 6.0         # widest gap jumped
    ledge_push: float = 10.0       # degrees steered away from a drop at our side
    ledge_sprint: float = 8.0      # sprint on a ledge while within this many degrees of the waypoint (0: never)
    speed_mult: float = 1.0        # walking speed multiplier (Hell: 1.2), applied through the agent's setSpeed
    weapon_aim: dict = None        # slot -> multiplier on aim_error while that weapon is out (apply_levels)
    # Handover step 9 (None = off, as before): aim error multiplier, shot-time multiplier, sight re-check (s per 25 u),
    # confidence, and the step in the character's aggression.
    aim_mult: float = None
    shot_mult: float = None
    recheck: float = 0.0
    confidence: float = 0.75
    aggr_step: int = 0
    lean: int = None               # weapon slot this bot leans toward in this game (the launcher's per-bot option)


# Behaviours: picked per bot with a tag (sanchez:sapper) or --behaviour, as Skill overrides.
BEHAVIOURS = {
    "default": {},
    # TNT whenever it has sticks (tnt.py, user): never a gun until they're gone. It lights one for any enemy within
    # 85 (farther, it walks toward them with the TNT out) and winds up at once. It cooks the stick so it goes off
    # just after it lands where the enemy is heading, landing it at least 45 (or a standing throw less 2) from
    # itself. An enemy closer than that gets it aimed low and let go at the last moment, to go off right at them.
    # Out of sticks it fights with guns like the default bot, from 60 away.
    "sapper": dict(favorite=TNT_SLOT, tnt=True, keep_distance=60.0, back_off=40.0),
    # TNT only: the sapper's TNT, and nothing else. Guns and ammo are worthless to it, so out of sticks it fights
    # with fists (and goes looking for dynamite and ammo boxes of TNT, which it values most).
    "dynamiter": dict(favorite=TNT_SLOT, tnt=True, keep_distance=60.0, back_off=40.0, melee_only=True,
                      prefer_close=[FIST_SLOT], prefer_far=[FIST_SLOT]),
    # Nightmare mode (launcher): every bot sharp, with every weapon strong (the launcher adds the wp_ levels).
    "nightmare": dict(max_engage=220.0, far=50.0, aim_error=0.35, reaction=0.10, turn_speed=420.0),
    # Dark Mode (Survival Horde): a close encounter. Shotguns up close (the double-barrel first), the knife or fists otherwise;
    # no rifle, pistol or gatling (items.py skips them and their ammo when BOT_DARK is set).
    "closeq": dict(favorite=4, prefer_close=[5, 4, 6, 8, 1], prefer_far=[5, 4, 6, 8, 1], prefer_long=[5, 4, 6, 8, 1],
                   keep_distance=3.0, back_off=0.0, knife_value=90.0, knife_value_wet=130.0,
                   aim_error=2.0, reaction=0.18, turn_speed=300.0),
    # TNT-only game: TNT first, always; out of sticks, the knife if it has one, else fists. It picks up no guns.
    "tnt_only": dict(favorite=TNT_SLOT, tnt=True, keep_distance=60.0, back_off=40.0, melee_only=True,
                     prefer_close=[KNIFE_SLOT, FIST_SLOT], prefer_far=[KNIFE_SLOT, FIST_SLOT],
                     knife_value=100.0, knife_value_wet=130.0, aim_error=2.0, reaction=0.18, turn_speed=300.0),
    # --- The named bots (botctl.py PERSONAS). Sharper aim than the default bot: less wobble, quicker to react
    # and to turn. `far` is where the weapon order switches from prefer_close to prefer_far.
    # Dotard: the rifle from range, the double-barrel up close, the pistol in between.
    "dotard": dict(favorite=3, far=35.0, prefer_close=[5, 2, 3, 4, 9, 8, 1], prefer_far=[3, 2, 5, 4, 9, 8, 1],
                   keep_distance=50.0, back_off=20.0, aim_error=2.0, reaction=0.18, turn_speed=300.0),
    # DTG_Legend and creature9: TNT first, always, until the sticks run out; then the pistol.
    "legend": dict(favorite=TNT_SLOT, tnt=True, keep_distance=60.0, back_off=40.0, far=50.0,
                   prefer_close=[2, 5, 4, 3, 9, 8, 1], prefer_far=[2, 3, 9, 5, 4, 8, 1],
                   aim_error=2.0, reaction=0.18, turn_speed=300.0),
    # T4H_Dingle: all-round, strongest with the pistol and the shotguns.
    "allrounder": dict(far=50.0, prefer_close=[4, 5, 2, 3, 9, 8, 1], prefer_far=[2, 3, 4, 5, 9, 8, 1],
                       aim_error=2.5, reaction=0.2, turn_speed=280.0),
    # T4H_LadyOutlaw: the rifle at every range.
    "rifleman": dict(favorite=3, prefer_close=[3, 5, 4, 9, 2, 8, 1], prefer_far=[3, 9, 5, 4, 2, 8, 1],
                     keep_distance=70.0, back_off=35.0, aim_error=1.8, reaction=0.16, turn_speed=320.0),
    # WAC_Dirtyolero: the shotguns, up close.
    "shotgunner": dict(favorite=4, prefer_close=[5, 4, 3, 9, 2, 8, 1], prefer_far=[4, 5, 3, 9, 2, 8, 1],
                       keep_distance=12.0, back_off=0.0, aim_error=2.0, reaction=0.18, turn_speed=300.0),
    # WAC_Dirtyolero as Dr. Death: the shotguns up close, the pistol from mid-range, the rifle at long range.
    "shotgunner_doc": dict(favorite=4, far=30.0, prefer_close=[5, 4, 2, 3, 9, 8, 1], prefer_far=[2, 4, 5, 3, 9, 8, 1],
                           far_long=75.0, prefer_long=[3, 2, 9, 4, 5, 8, 1],
                           keep_distance=20.0, back_off=0.0, aim_error=2.0, reaction=0.18, turn_speed=300.0),
    # Noobke: the knife, charging in; any weapon only when there is no knife in his hands to use.
    "knifer": dict(favorite=KNIFE_SLOT, prefer_close=[8, 5, 4, 3, 9, 2, 1], prefer_far=[8, 5, 4, 3, 9, 2, 1],
                   keep_distance=2.0, knife_value=150.0, knife_value_wet=150.0, aim_error=2.5, reaction=0.18),
    # The rifle at every range, from far off.
    "sniper": dict(favorite=3, prefer_close=[3, 5, 4, 9, 2, 8, 1], prefer_far=[3, 9, 5, 4, 2, 8, 1],
                   keep_distance=70.0, back_off=35.0),
    # The knife's jab, or fists without one. No guns, so it charges. Finding a knife comes first, on any map.
    "brawler": dict(melee_only=True, knife_first=True, prefer_close=[KNIFE_SLOT, FIST_SLOT],
                    prefer_far=[KNIFE_SLOT, FIST_SLOT], keep_distance=2.0, knife_value=150.0, knife_value_wet=150.0),
    # Mostly fists (7 times in 10), sometimes the knife when it has one; no guns. It doesn't go looking for a knife.
    "boxer": dict(melee_only=True, fist_share=0.7, prefer_close=[FIST_SLOT, KNIFE_SLOT],
                  prefer_far=[FIST_SLOT, KNIFE_SLOT], keep_distance=2.0),
    # Melee zombies (Survival Horde): Mary is a berserk boxer, Two Feathers a berserk brawler (the knife while he has one).
    "zombie_boxer": dict(melee_only=True, berserk=True, fist_share=0.7, prefer_close=[FIST_SLOT, KNIFE_SLOT],
                         prefer_far=[FIST_SLOT, KNIFE_SLOT], keep_distance=1.0),
    "zombie_knifer": dict(melee_only=True, berserk=True, knife_first=True, prefer_close=[KNIFE_SLOT, FIST_SLOT],
                          prefer_far=[KNIFE_SLOT, FIST_SLOT], keep_distance=1.0, knife_value=150.0, knife_value_wet=150.0),
    # The pistol (fanned) first.
    "pistolero": dict(favorite=2, prefer_close=[2, 5, 4, 3, 9, 8, 1], prefer_far=[2, 3, 9, 5, 4, 8, 1]),
}


def load_taunts():
    """Every sound in oltaunt.lab (taunts.txt next to this file lists them); empty if the file is missing."""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "taunts.txt")) as f:
            return [line.strip() for line in f if line.strip()]
    except OSError:
        return []


# Per-weapon strength from the launcher: a level for each slot, 's'(trong), 'a'(verage) or 'w'(eak).
LEVEL_RANK = {"s": 0, "a": 1, "w": 2}
LEVEL_AIM = {"s": 0.6, "a": 1.0, "w": 1.8}        # multiplier on aim_error with that weapon out


def apply_levels(skill, levels):
    """Reshape a Skill by weapon strength. The weapon lists put strong weapons first and weak ones last (a weak
    weapon is still used when nothing better is in the inventory); the aim wobble with a weapon out is 0.6x for
    strong, 1x for average and 1.8x for weak. TNT: strong and average throw it whenever there are sticks left
    (strong from 85 away, average from 65), weak never throws it."""
    def lvl(slot):
        return levels.get(slot, "a")

    def order(slots):
        return None if slots is None else sorted(slots, key=lambda sl: LEVEL_RANK[lvl(sl)])
    skill.prefer_close, skill.prefer_far, skill.prefer_long = (order(skill.prefer_close), order(skill.prefer_far),
                                                               order(skill.prefer_long))
    if lvl(TNT_SLOT) in "sa" and not (skill.melee_only and not skill.tnt):   # melee bots (brawler, boxer): never TNT
        if not skill.tnt:
            skill.tnt, skill.keep_distance, skill.back_off = True, 60.0, 40.0
        skill.favorite = TNT_SLOT
        skill.tnt_max = 85.0 if lvl(TNT_SLOT) == "s" else 65.0
    else:
        skill.tnt = False
        if skill.favorite == TNT_SLOT:
            skill.favorite = None
    if skill.favorite is not None and lvl(skill.favorite) == "w":
        skill.favorite = None
    skill.weapon_aim = {slot: LEVEL_AIM[lvl(slot)] for slot in range(1, 10)}
    return skill


# Difficulty. The aim wobble is how far (degrees) the aim drifts either side of the target; a shot lands while the
# drift is smaller than the target's width, so the hit rate falls roughly as 1 / wobble once the wobble is wider
# than the target. These are set for hit rates of about 100% (nightmare), 80% (hard), 70% (normal), 60% (easy) and
# 35% (easiest) of nightmare's, against a body about 2 degrees wide; hell never misses its aim. The weapon strengths
# from the launcher still scale the wobble (strong x0.6, weak x1.8). To tune a tier, change its aim_error.
DIFFICULTY = {
    #            aim wobble, reaction (s), turn deg/s, sprint share, strafe share
    # Easiest / Easy / Normal / Hard follow the handover's step 9 table: aim error 3 degrees x 2 / 1.5 / 1.35 / 1.2,
    # shot time x 1.4 / 1.15 / 1.07 / 1.0, sight re-check 0.6 / 0.45 / 0.4 / 0.35 s per 25 u, confidence
    # 0.6 / 0.75 / 0.82 / 0.9, aggression -1 / 0 / 0 / +1. Normal sits halfway between Easy and Hard.
    "easiest":   dict(ledge_turn=1.2, ledge_err=40.0, ledge_stop=0.8, ledge_gap=3.5, ledge_push=0.0, ledge_sprint=0.0,
                      aim_error=6.0, aim_mult=2.0, shot_mult=1.4, recheck=0.60, confidence=0.60, aggr_step=-1,
                      reaction=0.25, sight_memory=1.5, turn_speed=160.0, sprint=False, sprint_frac=0.0, strafe_frac=0.15,
                      climb_face=6.0, climb_jump_at=2.5, climb_jump_on=0.25, climb_jump_off=0.35, climb_pause=0.6, gap_jump_at=0.8),
    "easy":      dict(ledge_turn=1.6, ledge_err=30.0, ledge_stop=1.0, ledge_gap=4.5, ledge_push=6.0, ledge_sprint=0.0,
                      aim_error=4.5, aim_mult=1.5, shot_mult=1.15, recheck=0.45, confidence=0.75, aggr_step=0,
                      reaction=0.25, sight_memory=1.5, turn_speed=240.0, sprint=True, sprint_frac=0.45, strafe_frac=0.20,
                      climb_face=12.0, climb_jump_at=3.8, climb_jump_on=0.38, climb_jump_off=0.10, climb_pause=0.15, gap_jump_at=1.3),
    "normal":    dict(ledge_turn=2.0, ledge_err=22.0, ledge_stop=1.3, ledge_gap=6.0, ledge_push=10.0, ledge_sprint=8.0,
                      aim_error=4.0, aim_mult=1.35, shot_mult=1.07, recheck=0.40, confidence=0.82, aggr_step=0,
                      reaction=0.25, sight_memory=1.5, turn_speed=285.0, sprint=True, sprint_frac=0.68, strafe_frac=0.52,
                      climb_face=13.5, climb_jump_at=4.0, climb_jump_on=0.40, climb_jump_off=0.08, climb_pause=0.07, gap_jump_at=1.5),
    "hard":      dict(ledge_turn=2.5, ledge_err=16.0, ledge_stop=1.6, ledge_gap=7.0, ledge_push=14.0, ledge_sprint=22.0,
                      max_engage=170.0, aim_error=3.6, aim_mult=1.2, shot_mult=1.0, recheck=0.35, confidence=0.90, aggr_step=1,
                      reaction=0.25, sight_memory=1.5, turn_speed=330.0, sprint=True, sprint_frac=0.90, strafe_frac=0.85,
                      climb_face=15.0, climb_jump_at=4.2, climb_jump_on=0.42, climb_jump_off=0.06, climb_pause=0.0, gap_jump_at=1.7),
    "nightmare": dict(ledge_turn=3.2, ledge_err=12.0, ledge_stop=1.9, ledge_gap=8.5, ledge_push=18.0, ledge_sprint=30.0,
                      max_engage=220.0, aim_error=0.35, reaction=0.10, turn_speed=420.0, sprint=True, sprint_frac=1.0, strafe_frac=1.0,
                      climb_face=18.0, climb_jump_at=4.8, climb_jump_on=0.45, climb_jump_off=0.04, climb_pause=0.0, gap_jump_at=2.0),
    # Hell: nightmare with no aim wobble, no reaction time and 600 deg/s turning.
    # Hell also: goes straight for the fight (ignores small pickups, gives up on items quickly, closes in), hops while
    # strafing, reloads sooner, is back in the fight at once after dying, and spawns with a light boiler plate (50 armor).
    "hell":      dict(ledge_turn=4.0, ledge_err=8.0, ledge_stop=2.2, ledge_gap=10.0, ledge_push=22.0, ledge_sprint=38.0,
                      max_engage=300.0, aim_error=0.0, reaction=0.0, turn_speed=600.0, sprint=True, sprint_frac=1.0, strafe_frac=1.0,
                      climb_face=18.0, climb_jump_at=4.8, climb_jump_on=0.45, climb_jump_off=0.04, climb_pause=0.0, gap_jump_at=2.0,
                      min_item_value=25.0, item_patience=2.5, keep_distance=18.0, hop_frac=0.5, reload_stall=0.7,
                      close_reload_below=8, respawn_delay=0.3, spawn_armor=50),
}
DIFFICULTY_ALIASES = {"average": "easy"}       # the old name of Easy (lv_average)


def apply_difficulty(skill, difficulty):
    """Set the bot's aim, reactions, turning, sprinting and strafing for the launcher's difficulty (see DIFFICULTY).
    None leaves the behaviour as designed."""
    difficulty = DIFFICULTY_ALIASES.get(difficulty, difficulty)
    for key, value in DIFFICULTY.get(difficulty or "", {}).items():
        setattr(skill, key, value)
    if skill.berserk:
        for key, value in BERSERK.items():
            setattr(skill, key, value)
    return skill


# Melee zombies: whatever the tier, no hesitation: no reaction time, 900 deg/s turning (Hell: 600), quick weapon swaps.
# The tier still sets the aim.
BERSERK = dict(reaction=0.0, turn_speed=900.0, sight_memory=4.0, sprint=True, sprint_frac=1.0, strafe_frac=0.0, climb_pause=0.0,
               keep_distance=1.0, back_off=0.0, min_item_value=25.0, item_patience=2.0, respawn_delay=0.3,
               fight_memory=5.0, max_engage=300.0, recheck=0.0, shot_mult=0.0, confidence=1.0)


def behaviour_skill(name, levels=None, difficulty=None):
    skill = Skill(behaviour=name, **BEHAVIOURS[name])
    if levels:
        skill = apply_levels(skill, levels)
    return apply_difficulty(skill, difficulty)


class Brain:
    TICK = 0.05
    W_TAP = True                   # tap W while sprinting (set_keys)
    W_TAP_PERIOD = 500.0           # ms per tap ...
    W_TAP_GAP = 120.0              # ... of which W is up for this long
    REPLAN = 2.0                   # seconds between route refreshes (handover step 4: every 2 s)
    GOAL_MOVED = 7.0               # ... or sooner when the goal has moved this far (handover step 4)
    WAYPOINT_REACHED = 3.3         # flat distance at which a portal waypoint counts as passed (handover: 3.3 across)
    WAYPOINT_VERT = 5.0            # ... and only if we're within this height of it (handover: 5 vertically)
    SWEEP_ANGLES = (30, 60, 90, 125)   # blocked-ahead sweep: turn this far either way to find a clear heading
    SWEEP_LOOK = 5.0               # how far ahead the sweep looks
    CORNER_REACHED = 1.5           # the same for a point to walk round a corner
    DROP_AT = 2.0                  # a waypoint this far below us is a ledge to drop off
    # Narrow raised walkways (Thud Tower's arms and the spiral round the tower): near a drop the bot walks, never strafes
    # or hops, turns fast and squares up to its waypoint before it moves, stops at the edge, and jumps a gap on its way.
    LEDGE_MAPS = ("thudtowr",)
    LEDGE_DROP = 5.0               # ground this far below us (or none at all) is an edge
    LEDGE_NEAR = 4.0               # an edge this close in any direction: we are on a ledge
    ITEM_COSTS_EVERY = 1.0         # seconds between recomputing route lengths to items
    UNSTICK_CROUCH = 0.3           # seconds of crouch before the unstick jump and strafe
    CROUCH_LEAD = 0.35             # crouch held this long counts as taken hold (if the height doesn't show it)
    CROUCH_JUMP_AT = 3.0           # jump this close (flat) to a crouch-jump opening, once crouched
    JUMP_PULSE = 0.3               # jump key: down this long, then up as long, so a short jump retries
    PUMP_PRESS_MAX = 0.7           # let go of a shotgun trigger after this long even if no shot went out
    GIVE_UP_STUCKS = 3             # unsticks in a row on the way to one portal before routing round it
    STUCK_MEMORY = 12.0            # ... counted as in a row if no more than this many seconds apart
    AVOID_FOR = 30.0               # seconds a portal we gave up on costs extra to route through (nav.AVOID_COST)
    ITEM_DROP_FOR = 30.0           # 2nd stuck in a row on the way to an item: leave that item alone this long (handover step 1)
    ESCAPE_FOR = 6.0               # 3rd stuck in a row / no route for NO_ROUTE_FOR: head for a far spot this long
    ESCAPE_MIN_DIST = 20.0         # ... at least this far away
    NO_ROUTE_FOR = 8.0             # seconds with no route at all before heading for another spot
    DOOR_TRIES = 3                 # E presses at one door before giving up on it
    WINDOW_PATIENCE = 10.0          # seconds shooting at one window before giving up on it
    TNT_LAND_MARGIN = 0.25         # let a stick go so it goes off this long after landing (it bounces and rolls)
    TNT_LAST_CALL = 0.45           # fuse left at which a lit stick goes, aimed or not
    TNT_LIGHT_WAIT = 1.5           # seconds pressing secondary fire for a stick to light before giving up
    TNT_LIT_UNSEEN = 1.0           # seconds into the lighting animation without seeing the lit stick: take it as lit
    TNT_LIT_GRACE = 0.6            # seconds into the lighting action (0) with no lit stick seen before winding up
                                   # anyway (only if the agent has never shown us a lit stick)
    TNT_SWITCH_WAIT = 1.0          # seconds with the TNT selected before lighting: the switch animation (user: a
                                   # press during it went to the old weapon, and the stick went out unlit)
    TNT_REPRESS = 0.3              # seconds the weapon may sit idle with primary held before we press it again
    TNT_WIND_WAIT = 2.5            # seconds after lighting to see the wind-up state before throwing regardless
    TNT_MIN_VIEW = -45.0           # lowest view pitch (degrees) a close throw aims at
    TNT_BACK_OFF = 7.0             # with a stick out, back off from an enemy this much inside tnt_min
    TNT_SETTLE = 0.35              # close throw: stand still this long before choosing where it goes...
    TNT_SETTLE_NEAR = 15.0         # ... unless the enemy is closer than this
    TNT_LEAD = 0.8                 # share of a target's measured velocity to lead it by
    MEGA_CHANCE = float(os.environ.get("BOT_MEGA", "0.10"))   # chance per throw of the mega-blast (user: 10%)
    MEGA_MIN_STICKS = 4            # "several" sticks: this many (the lit one included) for a mega-blast
    MEGA_SPREAD = 3.5              # unlit sticks land this far around the lit one
    MEGA_LAST = 1.6                # no new unlit throw with less fuse than this left on the lit stick
    TNT_LEAD_MAX = 1.5             # seconds ahead at most

    JOIN_GRACE = 5.0               # seconds after the last awaited player shows up before we start (lets them
                                   # press Join and spawn)

    def __init__(self, bot, skill=None, log=print, wait_for=None, wait_max=120.0, bench=None, taunts=True):
        self.bot = bot             # botctl.Bot: press(), held, api, units_per_mouse, items, badges, level_key
        self.skill = skill or Skill()
        self.log = log
        # Team balance (bench.Bench, or None): on the bigger team, stay dead instead of respawning.
        self.bench = bench
        self.bench_decided = False # this death's sit-out decision has been made
        self.my_team = None        # our team while alive, remembered for while we're dead
        # A hosting bot stands still at the start until this many other players are in the match, or for
        # wait_max seconds at most, so it doesn't score before anyone has joined.
        self.wait_for = wait_for
        self.wait_max = wait_max
        self.wait_started = None
        self.wait_full = None      # when the awaited player count was first reached
        self.rng = random.Random()
        self.allies_now = []
        self.char_num = None       # set by botctl: 1 sanchez 2 james 3 twofeathers 4 doc 5 bob 6 mary
        self.liked_slot = None     # handover step 7: the gun rolled out of a fight
        self.owned_seen = None
        self.liked_next = 0.0
        self.last_any_seen = 0.0
        self.band = None           # "close" / "mid" / "far", with hysteresis
        self.fight_slot = None
        self.next_roll_swap = 0.0
        self.burst_shots = 0       # handover step 9: shots in the current burst, its length, when the next may start
        self.burst_len = 1
        self.burst_wait_until = 0.0
        self.gate_loaded = None
        self.gate_slot = None
        self.last_aim_yaw = None
        self.target_addr = None
        self.visible_since = None  # when the current target became visible
        self.last_visible = 0.0    # when we last saw a target
        self.last_seen = None      # {x, y, z} where we last saw a target
        self.aim_offset = 0.0      # current heading wobble, degrees
        self.pitch_offset = 0.0    # current pitch wobble, degrees
        self.strafe_key = "a"
        self.strafe_until = 0.0
        self.strafe_skip = False   # this strafe segment is skipped (skill.strafe_frac)
        self.sprint_on = True      # sprinting this stretch (skill.sprint_frac)
        self.sprint_until = 0.0
        self.stuck_check = None    # (time, x, z) when we last checked progress
        self.unstick_until = 0.0
        self.climb_t0 = None       # when the current ledge climb began
        self.ledge_now = False     # on a narrow raised walkway (see LEDGE_MAPS)
        self.ledge_at = 0.0        # when ledge_now was last worked out
        self.ledge_jump_until = 0.0   # a gap jump is under way: sprint and jump are allowed
        self.ledge_sprint_ok = False  # on a ledge but the way is clear and straight: sprinting is fine
        self.climb_active = False  # climbing this tick: no strafing
        self.climb_centers = {}    # sector -> middle point (or None), for climb_target
        self.hop_until = 0.0       # first unstick: a plain jump forward (plants, crates, low clutter)
        self.camp_avoid = None
        self.camp_wait_since = None   # when the camping Gatling bot began waiting with nobody in sight
        self.cheat_keys = []       # letters of a cheat code still to type (see cellar_escape)
        self.gg = False            # gun game: gg_rung is the rung on the weapon ladder (gungame.py)
        self.gg_rung, self.gg_base, self.gg_cheat_at, self.gg_applied = 0, None, -1e9, None
        self.gg_tries = 0
        self.gg_check_at = 0.0
        self.gg_spawn_at = -1e9
        self.gg_stin = False        # the stinnett cheat (move with the gatling) typed this life
        self.cheat_start = 0.0
        self.cellar_since = None   # when we were first seen in a cellar we can't route out of
        self.cheat_done_at = -1e9
        self.cheat_tries = 0
        self.door_pass = None      # after opening one half of a double door: walk through the middle of that half
        self.backoff_until = 0.0   # saloon door: back away from the swinging door until then
        self.backoff_look = None   # ... while facing this bearing
        self.turn_until = 0.0      # turn-around escape: end time ...
        self.turn_heading = 0      # ... and the heading to walk away on (see check_stuck)
        self.stuck_log = []        # (time, x, z) of recent stuck moments
        self.unstick_crouch_until = 0.0
        self.crouch_since = 0.0    # when crouch last went down
        self.crouch_until = 0.0    # keep crouching until then (after a crouch-jump)
        self.crouch_logged = False
        self.jump_at = 0.0         # start of the current jump-key pulse
        self.progress = (0.0, 0.0, 0.0)  # (time, x, z) for stalled()
        self.is_stalled = False
        self.next_nudge = 0.0      # earliest time to press E at a door again
        self.hop_t0 = None          # when the crouch before a jump up through a roof hole began
        self.pool = None            # Orleans' west building: see nav.POOLS
        self.pool_mode = None       # "enter": diving in for an item on the stairs/roof; "leave": back out over the roof
        self.pool_addr = None       # the item we're diving in for
        self.pool_since = 0.0
        self.zone_idle = None       # since when we've been in the pool/stairs/roof with nothing to fetch
        self.pool_items = set()     # items only reachable through the pool (from the last refresh_costs)
        self.wet_since = None       # when we got into the water (for WATER_LINGER)
        self.no_water_until = 0.0   # until then: no water fights, no items in the water
        self.water_ok = False       # routes may enter open water (fleeing); otherwise only for an item in the water
        self.allow_water_now = False  # set around the walk to an item in the water
        self.flee_until, self.flee_goal, self.flee_goal_at = 0.0, None, 0.0
        self.bottom_since = None    # when we found nothing (left) at the bottom of a well; None = not looking
        self.well_exit = False      # done at the bottom: swimming up and out
        self.dive_seen = -1e9       # last time we were diving for an item
        self.dive_best = 1e9        # least height between us and the item we're diving for
        self.door_face_since = None  # when we started turning to face a door before nudging it
        self.next_window_shot = 0.0
        self.next_medbag = 0.0     # earliest time to press USE for a medbag again
        self.medbag_try = None     # (time, medbags carried, health) when we last pressed USE
        self.inv_names = None      # names in the inventory array last tick (None = take a fresh baseline)
        self.had_badge = False
        self.tapped = set()        # keys pressed by tap() last tick, released this tick
        self.leave_t0 = None       # horde: when the pause-menu leave sequence started
        self.leave_i = 0
        self.died_at = None
        self.next_respawn_press = 0.0
        self.lms = int(os.environ.get("BOT_LMS") or 0)     # last man standing: lives per bot (0 = off)
        self.lms_deaths, self.lms_out = 0, False
        self.stats_on = bool(os.environ.get("BOT_STATS_PLAYER"))   # launcher games: save the human's stats (see stats_tick)
        self.passive = bool(os.environ.get("BOT_PASSIVE"))          # horde host: stays in the game but never fights
        self.stats_obs = False                                     # set by botctl for the hosting bot: the one that watches
        self.st_pos_at, self.st_bots, self.st_human, self.st_alive = 0.0, set(), None, None
        self.st_last, self.st_dead, self.st_kills, self.st_deaths, self.st_suic = None, {}, 0, 0, 0
        self.st_sid, self.st_t0, self.st_saved = None, time.time(), 0.0
        self.my_display = os.environ.get("BOT_DISPLAY") or str(os.getpid())
        self.st_name, self.st_joined = None, []                    # the human's in-game name (from the kill feed) and who joined
        self.st_ex = {"kills": 0, "deaths": 0, "suicides": 0, "causes": {}}   # exact counts read from the game's messages
        self.st_last_msg = ("", 0.0)
        self.ranked = bool(os.environ.get("BOT_RANKED"))      # ranked horde: log when the human (red team) dies
        self.rank_present, self.rank_gone_at, self.rank_seen_at = None, None, 0.0
        self.lobby_since = None    # when we noticed we're waiting in the lobby
        self.lobby_pressed = 0.0
        self.reloading = False
        self.reload_progress = (None, 0.0)   # (rounds loaded, when it last changed)
        self.reload_held = False   # R is held down while reloading (one tap loads only one round)
        self.fire_held = None      # fire button currently held down, if any
        self.fire_since = 0.0      # when it went down
        self.was_dead = {}         # addr -> dead, last tick (check_kills)
        self.taunt_at = 0.0        # earliest time for the next taunt
        self.taunt_queue = 0       # kills waiting for a taunt
        self.taunt_rng = random.Random()
        self.taunt_sounds = load_taunts() if taunts else []
        self.taunts_on = taunts
        self.boom_at, self.boom_pos = -1e9, None
        self.fire_loaded = None    # rounds loaded when it went down (a drop means the shot is out)
        self.reload_since = 0.0    # when R last went down or up
        self.last_action = None    # the weapon's action on the previous tick (inventory["action"])
        self.last_shot_at = 0.0    # when the last shotgun shot animation started
        self.next_switch = 0.0
        self.item_goal = None      # address of the ground item we're walking to
        self.item_mode = None      # which search chose it (any / knife / health / armor): only that one may drop it
        self.ignore_count = {}     # address -> times given up on (each wait is longer)
        self.flee_began, self.flee_last, self.flee_block_until = None, -1e9, 0.0
        self.flee_threat = None    # the enemy we are backing away from (set around the retreat)
        self.left_well = False     # just came up out of a well
        self.item_since = 0.0      # when we last got closer to it
        self.item_best = 0.0       # closest we've been to it (route length)
        self.ignored_items = {}    # address -> time until which we leave it alone
        self.cellar_walk_log = -1e9
        self.camp_set = False       # Gatling camp: in place with the gun out (gatling_camp)
        self.camp_spot = None       # where we are going to camp, and since when / failed tries
        self.camp_since = None
        self.camp_fails = 0
        self.sawed_logged = False
        self.item_called = -1e9     # when seek_item last ran (patience only counts uninterrupted trips)
        self.item_costs = {}       # address -> route length (None = unreachable)
        self.item_costs_at = 0.0
        # Navigation
        self.level = None          # nav.Level for the loaded map
        self.level_name = None
        self.level_key = None      # the game's level pointer when we identified it
        self.route = None
        self.route_goal = None
        self.route_at = 0.0
        self.wander_goal = None
        self.wander_until = 0.0
        self.giveups = {}          # portal key -> how many times we've given up on it
        self.avoid = {}            # portal key (nav.Edge.key) -> time until which routes go round it
        self.escape_until = 0.0    # heading for a far spot until then (3rd stuck in a row, or no route): no item trips meanwhile
        self.no_route_since = None # when routes to the current goal started failing
        self.stuck_key = None      # portal we were heading for at the last unstick
        self.last_key, self.last_key_t = None, -1e9   # last portal the route was heading for (the route is cleared while unsticking)
        self.camp_bad = []         # (x, z) camp spots we could not get to
        self.camp_quiet = []       # (x, z, time) spots where nobody came for 20 s: not again for a while
        self.camp_off_until = 0.0  # no spot with a worthwhile view nearby: keep the Gatling for fights until then
        self.camp_best_seen = 0.0
        self.camp_stucks = 0       # stuck moments on the way to the current camp spot
        self.stuck_count = 0       # unsticks in a row on the way to it
        self.stuck_at = 0.0        # when the last unstick started
        self.obstacle = None       # (portal key, since, E presses) for the door or window we're working on
        # Water (see note_water)
        self.high_route_log = 0.0
        self.gap_logged = 0.0
        self.high_reached = 0      # how many HIGH_MARKS heights we're above (the ledge log)
        self.wet = False           # feet in the water: guns don't fire here
        self.under_since = None    # when our head last went under (not reset by a short trip up)
        self.above_since = None    # when our head last came out
        self.surfacing = False     # swimming up for air
        self.surface_wait = None   # (since, highest eye height) while surfacing, to notice we can't get higher
        self.shore_target = None   # enemy on land swim() wants us to climb out at with the knife
        self.left_water_at = -1e9  # when we last came out of the water (Skill.knife_hold)
        self.water_route = None    # route through the water sectors when under a roof (water_waypoint)
        self.water_route_at = 0.0
        self.water_route_goal = None
        self.swim_low_until = 0.0  # swim lower (crouch) until then: stuck under a roof
        # Teams and CTF
        self.team_seen = None      # (team, mode) last logged
        self.objective = None      # (label, {x, y, z}) for CTF, or None
        # TNT (see tnt_fight) and dodging lit sticks
        self.tracks = {}           # player addr -> (time, x, z, vx, vz): smoothed velocity, for leading throws
        self.tnt_phase = None      # None, "light", "wind", "hold", "thrown"
        self.tnt_since = 0.0       # when the phase started
        self.tnt_lit_at = 0.0      # when our stick lit (its fuse runs from then)
        self.tnt_light_seen = None # when we first saw the lighting action (0) for this stick
        self.tnt_lit_seen = False  # the agent showed us the lit stick (else tnt_lit_at is the lighting's start;
                                   # None: not seen, and logged)
        self.tnt_pressed_at = 0.0  # when secondary went down for this stick (for the timing log)
        self.tnt_times = {}        # "lit" / "wound" -> seconds after that press, for the log
        self.tnt_idle_since = None # primary held but the weapon idle since then (the press got lost: press again)
        self.tnt_repress = False   # primary let go to be pressed again next tick
        self.tnt_close = False     # the target is close: the stick goes off at them in the air (tnt_close_hold)
        self.tnt_commit = False    # ... and we've passed the moment to throw it away instead
        self.tnt_last_close = None # (solution, point) of the last close throw found
        self.tnt_wound_at = 0.0    # when the wind-up ended (power grows from then)
        self.tnt_target = None     # the player we throw at (last seen)
        self.tnt_jumped = False    # jumped for reach during this throw
        self.tnt_lob = False       # this throw goes as a lob (the flat arc hits the level)
        self.tnt_arc_ok = True     # some throw at the target has a clear arc (check_arcs)
        self.tnt_arc_at = 0.0      # next arc check
        self.tnt_fb_turn = 0.0     # degrees off the target's direction for a last-moment throw (check_arcs)
        self.tnt_arc_cache = {}    # enemy addr -> (time, arc clear) for tnt_unseen_target
        self._neighbours = None    # (level, [set of sector indices] per sector) for arc_clear
        self.tnt_blocked = None    # the target we last found no clear throw at (logged once)
        self.tnt_retries = 0       # extra presses when a let-go didn't throw
        self.tnt_actions = []      # weapon actions seen during this throw, for the log
        self.tnt_plan = None       # (power, flight, goal) of the throw as let go
        self.tnt_next = 0.0        # earliest time to light another
        self.tnt_now = 0.0         # this tick's time, for tnt_solution
        self.tnt_watch = None      # our thrown stick in flight (watch_stick)
        self.mega_on, self.mega = False, None     # TNT mega-blast under way (tnt_fight / mega_step)
        self.gravity = tnt.load_gravity()
        self._tnt_min = None       # (gravity, tnt_min()) cached
        self.top_speed = 20.0      # fastest we've been seen moving on the ground (burst_risk)
        self.slot_seen = None      # weapon slot selected, and since when (TNT_SWITCH_WAIT)
        self.slot_since = 0.0
        self.lit_works = False     # the agent has shown us a lit stick in our hand at least once
        self.dodging = False

    # -- input helpers --------------------------------------------------------------------------------
    def set_keys(self, wanted):
        """Hold exactly the movement keys in `wanted`, plus sprint while moving upright."""
        if ((self.skill.sprint and self.sprint_now() and (not self.ledge_now or self.ledge_sprint_ok or time.time() < self.ledge_jump_until))
                or self.climb_active) \
                and wanted & {"w", "a", "s", "d"} and "lctrl" not in wanted:
            wanted = wanted | {"lshift"}          # climbing always sprints: the run-up carries the jump (user)
        if "lctrl" in wanted and "lctrl" not in self.bot.held:
            self.crouch_since = time.time()
        if self.W_TAP and "w" in wanted and "lshift" in wanted and not self.climb_active:
            # A player's trick to make stamina last: tap forward instead of holding it down while sprinting.
            if (time.time() * 1000) % self.W_TAP_PERIOD > self.W_TAP_PERIOD - self.W_TAP_GAP:
                wanted = wanted - {"w"}
        for k in MOVE_KEYS:
            if k in wanted and k not in self.bot.held:
                self.bot.press(k, True)
            elif k not in wanted and k in self.bot.held:
                self.bot.press(k, False)

    def sprint_now(self):
        """Whether this stretch is a sprinting one: skill.sprint_frac of the time, re-rolled every 2-5 seconds."""
        frac = self.skill.sprint_frac
        if frac >= 1.0:
            return True
        now = time.time()
        if now > self.sprint_until:
            self.sprint_on = self.rng.random() < frac
            self.sprint_until = now + self.rng.uniform(2.0, 5.0)
        return self.sprint_on

    LEAVE_STEPS = ((0.0, "escape"), (1.2, "up"), (2.2, "return"), (3.4, "return"))

    def end_match(self, now):
        """Horde host: when state/end_<BOT_RUN>.flag appears, make the game end the match itself (time limit to 1 minute,
        kill limit to 1) so everyone gets the real end-of-match screen."""
        if os.environ.get("BOT_TAG") != "hd1" or getattr(self, "end_done", False):
            return
        lim = os.environ.get("BOT_LIMITS")             # "kills,minutes": the game's own limits, so it ends exactly on time
        if lim and now >= getattr(self, "lim_next", 0):
            self.lim_next = now + 15.0                  # (re)apply now and then in case the match start reset them
            try:
                k, m = lim.split(",")
                ok = [bool(self.bot.api.set_cvar("mp_killsToEnd", k)), bool(self.bot.api.set_cvar("mp_timeToEnd", m))]
                if not getattr(self, "lim_logged", False):
                    self.lim_logged = True
                    self.log(f"match limits set: {k} kills, {m} minutes: {ok}")
            except Exception as e:
                self.log(f"match limits failed: {e}")
        if now < getattr(self, "end_next", 0):
            return
        from pathlib import Path
        if not (Path(__file__).resolve().parent / "state" / f"end_{os.environ.get('BOT_RUN', '')}.flag").exists():
            return
        self.end_next = now + 1.0
        ok = []
        for name, val in (("mp_timeToEnd", 1), ("mp_killsToEnd", 1)):
            try:
                ok.append(bool(self.bot.api.set_cvar(name, str(val))))
            except Exception as e:
                self.log(f"end match: {name} failed: {e}")
                ok.append(False)
        self.log(f"ending the match through the game's limits: {ok}")
        if all(ok):
            self.end_done = True

    def watch_match_end(self, now):
        """Horde observers (hd2, hd3): log each new game state the game reports (STATE: ...), and when one shows up that was
        never seen during the first 90 s of play and holds for 3 s (the scoreboard after the game's own kill limit), write
        state/matchend_<BOT_RUN>.flag so horde.py can end the match: the last kills often never reach the feed."""
        if not os.environ.get("BOT_STATS_OBS"):
            return
        lob = getattr(self.bot, "lobby", None)
        if not lob:
            return
        st = lob.get("state")
        t0 = getattr(self, "_wme_t0", None)
        if t0 is None:
            self._wme_t0 = t0 = now
            self._wme_seen, self._wme_cand = {}, None
        if st not in self._wme_seen:
            self._wme_seen[st] = now
            self.log(f"STATE: game state {st} (pick {lob.get('pick')}) after {now - t0:.0f}s")
        if now - t0 < 90.0 or self._wme_seen.get(st, 0) - t0 < 90.0:
            self._wme_cand = None
            return
        if self._wme_cand is None or self._wme_cand[0] != st:
            self._wme_cand = (st, now)
        elif now - self._wme_cand[1] >= 3.0 and not getattr(self, "_wme_done", False):
            self._wme_done = True
            self.log(f"STATE: the match is over (state {st})")
            try:
                from pathlib import Path
                (Path(__file__).resolve().parent / "state" / f"matchend_{os.environ.get('BOT_RUN', '')}.flag").write_text(str(st))
            except OSError:
                pass

    def spawn_armor(self, now):
        """Hell: a light boiler plate (50 armor) each life, and when a bot is raised to Hell. The game's pickup makes the plate
        (IBPLATE), a moment later its count is set to the armor wanted; only with a live player actor, or the game asserts."""
        want = int(getattr(self.skill, "spawn_armor", 0) or 0)
        if want <= 0 or getattr(self, "_armor_given", False) or now - getattr(self, "_armor_t", 0.0) < 0.5:
            return
        self._armor_t = now
        api = self.bot.api
        try:
            w = api.world()
            if not w.get("ok"):
                return
            cur = int((((w.get("self") or {}).get("inventory") or {}).get("armor")) or 0)
            if cur >= want:
                self._armor_given = True
                self.log(f"already has {cur} armor")
                return
            if getattr(self, "_armor_stage", 0) == 0:
                api.give(["IBPLATE"])
                self._armor_stage = 1
            else:
                api.set_count("IBPLATE", want)
                self._armor_given, self._armor_stage = True, 0
                self.log(f"spawned with {want} armor")
        except Exception as e:
            self.log(f"could not give armor: {e}")

    def apply_speed(self, now):
        """Hell: 20% faster on foot. The agent adds that share of every physics step; checked every few seconds."""
        want = getattr(self.skill, "speed_mult", 1.0) or 1.0
        if want == getattr(self, "_speed_set", 1.0) or now - getattr(self, "_speed_t", 0.0) < 3.0:
            return
        self._speed_t = now
        try:
            if self.bot.api.set_speed(want):
                self._speed_set = want
                self.log(f"walking speed x{want:g}")
        except Exception as e:
            self.log(f"could not set the walking speed: {e}")

    def check_upgrade(self, now):
        """Horde: when state/level_<BOT_RUN>_<BOT_TAG>.flag appears, take on that difficulty on the spot (aim, reactions, turning,
        sprinting, strafing), so a tier change doesn't need the bot to leave and a new one to join."""
        tag = os.environ.get("BOT_TAG")
        if not tag or now - getattr(self, "_upg_t", 0.0) < 1.0:
            return
        self._upg_t = now
        from pathlib import Path
        f = Path(__file__).resolve().parent / "state" / f"level_{os.environ.get('BOT_RUN', '')}_{tag}.flag"
        try:
            level = f.read_text().strip()
            f.unlink()
        except OSError:
            return
        level, _, extra = level.partition("+")
        if level not in DIFFICULTY:
            return
        apply_difficulty(self.skill, level)
        self._armor_given, self._armor_stage = False, 0         # Hell: the light boiler plate comes now
        if level in ("nightmare", "hell"):
            for k, v in BEHAVIOURS["nightmare"].items():
                setattr(self.skill, k, v)
            apply_difficulty(self.skill, level)              # the tier's own numbers win over the nightmare behaviour's (Hell is sharper)
        if extra == "strong":                             # strong with every weapon from here on
            apply_levels(self.skill, {slot: "s" for slot in range(1, 10)})
        self.log(f"difficulty raised to {level}" + (" (strong with every weapon)" if extra == "strong" else ""))

    def session(self, now):
        """Next match without restarting the copy (rotation.py). Once a second we write state/status_<BOT_PROFILE>.json
        ({t, pid, host, state, lobby, map}: game state, whether a LAN lobby exists) and look for
        state/session_<BOT_PROFILE>.json, which holds one step, which we do and then delete: {"action": "continue"}
        presses Enter on the score screen (to the main menu), {"action": "host", "map", "mode" (number), "timelimit",
        "fraglimit"} hosts the next lobby, {"action": "join", "address", "map"} joins it. A step older than 30 s (its
        "t") is left over from an earlier run and is dropped."""
        if now < getattr(self, "session_next", 0):
            return
        self.session_next = now + 1.0
        profile = os.environ.get("BOT_PROFILE")
        if not profile:
            return
        from pathlib import Path
        folder = Path(__file__).resolve().parent / "state"
        try:
            mp = self.bot.api.max_players() or {}
            status = {"t": time.time(), "pid": os.getpid(), "host": bool(getattr(self.bot, "hosting", False)),
                      "state": (self.bot.lobby or {}).get("state"), "lobby": bool(mp.get("lobby")),
                      "map": self.level_name}
            folder.mkdir(exist_ok=True)
            tmp = folder / f"status_{profile}.tmp"
            tmp.write_text(json.dumps(status))
            os.replace(tmp, folder / f"status_{profile}.json")       # whole, so the reader never sees half a file
        except Exception:
            pass
        path = folder / f"session_{profile}.json"
        try:
            step = json.loads(path.read_text())
            path.unlink()
        except (OSError, ValueError):
            return
        action = step.get("action")
        if time.time() - float(step.get("t") or 0) > 30:
            self.log(f"session: dropped a stale {action} step")
            return
        try:
            if action == "continue":
                self.set_keys(set())
                self.tap("return")
                ok = True
            elif action == "host":
                ok = self.bot.host_next(step.get("map"), step.get("mode"), step.get("timelimit"), step.get("fraglimit"))
            elif action == "join":
                ok = self.bot.join_next(step.get("address") or "127.0.0.1")
            else:
                ok = False
            if ok and action in ("host", "join") and step.get("map"):
                os.environ["BOT_MAP"] = step["map"]      # the next map identification tries it first
        except Exception as e:
            ok = f"failed: {e}"
        self.log(f"session: {action} -> {ok}")

    def leave_game(self, now):
        """Horde: when state/leave_<BOT_TAG>.flag exists, leave the match the way a player does (pause menu, Leave Game,
        confirm) so the others see us go instead of a frozen body. Returns True while that is going on."""
        tag = os.environ.get("BOT_TAG")
        if not tag:
            return False
        if self.leave_t0 is None:
            from pathlib import Path
            if not (Path(__file__).resolve().parent / "state" / f"leave_{os.environ.get('BOT_RUN', '')}_{tag}.flag").exists():
                return False
            self.leave_t0 = now
            self.leave_i = 0
            self.set_keys(set())
            self.log("leaving the game through the pause menu")
        el = now - self.leave_t0
        while self.leave_i < len(self.LEAVE_STEPS) and el >= self.LEAVE_STEPS[self.leave_i][0]:
            self.tap(self.LEAVE_STEPS[self.leave_i][1])
            self.leave_i += 1
        return True

    def tap(self, key):
        """Press `key` now; tick() releases it at the start of the next tick."""
        if key not in self.tapped:
            self.bot.press(key, True)
            self.tapped.add(key)

    def hold_reload(self, down):
        if down != self.reload_held:
            self.bot.press(RELOAD_KEY, down)
            self.reload_held = down
            self.reload_since = time.time()

    def stop_reload(self):
        self.reloading = False
        self.hold_reload(False)

    def recheck_delay(self, dist):
        """Sight re-check (handover step 9): the further the enemy, the longer before we notice it's in view again.
        On average half the re-check interval (s per 25 u), at most 1.5 s."""
        r = self.skill.recheck
        return 0.0 if not r or dist is None else min(1.5, 0.5 * r * dist / 25.0)

    def shot_gate(self, weapon, now):
        """Bursts and shot time (handover step 9): 1 to 4 shots to a burst (a shotgun one), then SHOT_TIME x the
        skill's multiplier before the next. Off when the skill has no shot_mult."""
        if self.skill.shot_mult is None or weapon is None or weapon["slot"] not in SHOT_TIME:
            return True
        slot, loaded = weapon["slot"], weapon["loaded"]
        if slot != self.gate_slot:
            self.gate_slot, self.gate_loaded, self.burst_shots = slot, loaded, 0
            self.burst_len = 1 if slot in PUMP_SLOTS else self.rng.randint(1, 4)
        if self.gate_loaded is not None and loaded < self.gate_loaded:
            self.burst_shots += self.gate_loaded - loaded
            if self.burst_shots >= self.burst_len:
                self.burst_wait_until = now + SHOT_TIME[slot] * self.skill.shot_mult
                self.burst_shots = 0
                self.burst_len = 1 if slot in PUMP_SLOTS else self.rng.randint(1, 4)
        self.gate_loaded = loaded
        if now < self.burst_wait_until:
            self.release_fire()
            return False
        return True

    def fire_button(self, weapon):
        if weapon is not None and weapon["slot"] in self.skill.primary_slots:
            return PRIMARY_FIRE
        return SECONDARY_FIRE

    def press_fire(self, button, weapon, now):
        if self.fire_held != button:
            self.release_fire()
            self.bot.press(button, True)
            self.fire_held, self.fire_since, self.fire_loaded = button, now, weapon["loaded"]

    def release_fire(self):
        if self.fire_held:
            self.bot.press(self.fire_held, False)
            self.fire_held = None

    def trigger(self, weapon, want, now, inv=None, queue=False):
        """Drive the fire button. Shotgun and double-barrel: see pump(); `queue` is a looser wish to shoot,
        for a shot that only goes out when the current reload ends. Everything else: hold while we want to
        shoot, and the game keeps firing until the gun is empty."""
        action = inv.get("action") if inv else None
        if weapon is None:
            self.release_fire()
        elif weapon["slot"] in PUMP_SLOTS and action is not None:
            self.pump(weapon, action, want, now, queue)
        elif weapon["slot"] in PUMP_SLOTS:
            # Without the weapon state: press, and let go once the shot is out.
            if self.fire_held:
                if weapon["loaded"] < self.fire_loaded or now - self.fire_since > self.PUMP_PRESS_MAX:
                    self.release_fire()
            elif want and weapon["loaded"] > 0:
                self.press_fire(self.fire_button(weapon), weapon, now)
        elif want and (weapon["ammo"] is None or weapon["loaded"] > 0 or weapon["slot"] == KNIFE_SLOT):
            # (The knife's jab doesn't use up the knife, whatever its loaded count says.)
            self.press_fire(self.fire_button(weapon), weapon, now)
        else:
            self.release_fire()

    def pump(self, w, action, want, now, queue=False):
        """Shotgun / double-barrel in a fight: keep the next action queued behind the current one.

        The game holds one queued action and starts it the frame the current animation ends, provided
        its button is still down. So: once the shot animation has started, let go of fire (holding it
        would repeat the shot) and press R so the reload follows on at once. Once the reload has
        started, keep R down (letting go stops it after one round) and, if we want to shoot, press
        fire so the shot follows the moment the gun is full. A queued press needs a fresh key-down,
        hence the release on the tick an action starts. The queued shot only leaves when the reload ends
        (100 ms after, in fact), and we keep aiming meanwhile, so it only needs `queue`: roughly facing the
        target."""
        loaded, reserve = w["loaded"], w["reserve"] or 0
        can_reload = loaded < w["capacity"] and reserve > 0
        started = action != self.last_action
        self.last_action = action
        if action in (0, 1, 2):                         # shot animation running
            if started:
                gap = now - self.last_shot_at
                if gap < 5.0:                           # back-to-back shots: report the cycle time
                    self.log(f"{w['name']} shot, {gap:.2f}s after the last")
                self.last_shot_at = now
            self.release_fire()
            if started or reserve <= 0:
                self.hold_reload(False)                 # fresh key-down next tick
            else:
                self.hold_reload(True)
        elif action == RELOAD_ACTION:
            self.hold_reload(True)
            if want or queue:
                if started:
                    self.release_fire()
                else:
                    self.press_fire(self.fire_button(w), w, now)
            else:
                self.release_fire()
        else:                                           # idle
            if want and loaded > 0:
                self.hold_reload(False)
                if self.fire_held and now - self.fire_since > self.PUMP_PRESS_MAX:
                    self.release_fire()                 # nothing started (weapon still coming up?): retry
                else:
                    self.press_fire(self.fire_button(w), w, now)
            elif can_reload:
                self.release_fire()
                if self.reload_held and now - self.reload_since > self.PUMP_PRESS_MAX:
                    self.hold_reload(False)             # held but no reload started: press again
                else:
                    self.hold_reload(True)
            else:
                self.release_fire()
                self.hold_reload(False)

    def note_inventory(self, inv):
        """Log items entering or leaving the inventory array (names as they are in memory) and badge
        pickups, so a pickup the brain didn't act on shows up in the console."""
        if not inv:
            return
        names = {s["name"] for s in inv.get("slots") or [] if s["name"]}
        if self.inv_names is not None and names != self.inv_names:
            counts = {s["name"]: s["count"] for s in inv.get("slots") or []}
            change = [f"+{n} ({counts.get(n)})" for n in sorted(names - self.inv_names)]
            change += [f"-{n}" for n in sorted(self.inv_names - names)]
            self.log("inventory: " + " ".join(change))
        self.inv_names = names
        has = bool(inv.get("hasBadge"))
        if has != self.had_badge:
            self.log("picked up the badge" if has else "no longer holding the badge")
            self.had_badge = has

    def use_medbag(self, health, inv, now, engaged):
        """Press USE when hurt and carrying a medbag (IDOCBAG). The remaster has no select-item action, so
        USE applies the medbag directly. If the count doesn't drop after a press, say so and back off."""
        if not inv or health is None:
            return
        bags = inv.get("carried", {}).get("IDOCBAG") or 0
        if self.medbag_try:
            t, before, hp = self.medbag_try
            if now - t >= 1.0:
                if bags >= before and health <= hp:
                    self.log(f"pressed {USE_KEY.upper()} with {before} medbag(s) at health {hp:.1f}, but nothing "
                             f"happened (is USE bound to {USE_KEY!r} in this copy?)")
                    self.next_medbag = now + 10.0
                self.medbag_try = None
            return
        limit = self.skill.medbag_health if engaged else self.skill.medbag_health_idle
        if bags > 0 and 0 < health <= limit and now >= self.next_medbag:
            self.tap(USE_KEY)
            self.log(f"health {health:.1f}: using a medbag ({bags} left)")
            self.medbag_try = (now, bags, health)
            self.next_medbag = now + 1.5

    def fire_range(self, weapon):
        """The weapon's effective range for the fire mode we use, capped by max_engage."""
        if weapon is None:
            return self.skill.max_engage
        eff = weapon["effRange"] if self.fire_button(weapon) == PRIMARY_FIRE else weapon.get("effRange2", 0)
        eff = eff or weapon["effRange"]
        return min(self.skill.max_engage, eff) if eff > 0 else self.skill.max_engage

    def look_toward(self, me, heading, pitch):
        """Speed-limited turn toward a heading and pitch (14-bit units)."""
        max_step = to_units(self.skill.turn_speed * self.TICK * (self.skill.ledge_turn if self.ledge_now else 1.0))
        yaw_err = wrap(round(heading - me["yaw"]))
        pitch_err = pitch - me["pitch"]
        # Mouse x turns right (heading up); mouse y down lowers the pitch, so pitch takes the opposite sign.
        self.bot.api.set_look(clamp(yaw_err, max_step) / self.bot.units_per_mouse,
                              -clamp(pitch_err, max_step) / self.bot.units_per_mouse)

    def aim(self, me, target, dist):
        """Aim at the target with wobble. Returns (heading error, pitch error) in degrees, without wobble."""
        s = self.skill
        err = s.aim_error
        if s.aim_mult:
            # Handover step 9: 3 degrees x the multiplier, plus 15 x the multiplier scaled by how fast we're turning
            # while moving, plus 7 in a panic (hurt below 40%).
            yaw = to_deg(me["yaw"])
            rate = 0.0
            if self.last_aim_yaw is not None:
                rate = abs(to_deg(wrap(round(me["yaw"] - self.last_aim_yaw[0])))) / max(0.02, time.time() - self.last_aim_yaw[1])
            self.last_aim_yaw = (me["yaw"], time.time())
            err = 3.0 * s.aim_mult
            if math.hypot(me.get("vx") or 0.0, me.get("vz") or 0.0) > 3.0:
                err += 15.0 * s.aim_mult * min(1.0, rate / max(1.0, s.turn_speed))
            if (me.get("health") or 10.0) < 4.0:
                err += 7.0
        if s.weapon_aim:
            err *= s.weapon_aim.get((me.get("inventory") or {}).get("slot"), 1.0)
        self.aim_offset = clamp(self.aim_offset + random.uniform(-1, 1) * err * 0.3, err)
        self.pitch_offset = clamp(self.pitch_offset + random.uniform(-1, 1) * err * 0.15, err / 2)
        eye_y = me["y"] + EYE * me["height"]
        aim_y = target["y"] + AIM * target["height"]
        want_yaw = bearing(me, target)
        want_pitch = to_units(math.degrees(math.atan2(aim_y - eye_y, max(dist, 1.0))))
        self.look_toward(me, want_yaw + to_units(self.aim_offset), want_pitch + to_units(self.pitch_offset))
        return to_deg(wrap(round(want_yaw - me["yaw"]))), to_deg(want_pitch - me["pitch"])

    # -- level and routes -----------------------------------------------------------------------------
    def ensure_level(self, me, others):
        """Identify the loaded map from live positions when the game's level changes."""
        key = self.bot.level_key
        rc = getattr(self, "level_recheck", None)
        if rc and key is not None and key == self.level_key and time.time() >= rc[0] and rc[1] > 0:
            self.level_recheck = (time.time() + 2.0, rc[1] - 1)
            self.level_key = None                # identify again now that more items are in the world
        elif key is None or key == self.level_key:
            return
        key = self.bot.level_key
        if key is None:
            return
        self.level_key = key
        points = [dict(p, kind="player") for p in [me] + others if not p.get("dead")]
        points += [dict(i, kind="item") for i in self.bot.items + self.bot.badges]
        started = time.time()
        name, sectors, score = nav.identify(points, prefer=os.environ.get("BOT_MAP"))
        weak = len(points) < 12 or nav.identify.ties > 1
        self.level_recheck = (time.time() + 2.0, 15) if weak else None   # items load late: look again
        if name and score >= 0.8 * len(points):
            ch = (self.bot.self_state or {}).get("crouchHeight")
            ch = ch if ch and 1.0 < ch < 6.0 else nav.CROUCH_HEIGHT
            self.level, self.level_name = nav.Level(sectors, nav.lvt.load_inf(name), crouch_height=ch, name=name), name
            self.log(f"map: {name} ({score}/{len(points)} positions match, {time.time() - started:.1f}s), "
                     f"crouched height {ch:.2f}")
            self.pool = self.level.pool
        else:
            self.level, self.level_name, self.pool = None, None, None
            self.log(f"map not recognised (best {name}: {score}/{len(points)}); walking straight")
        self.route, self.item_costs, self.avoid, self.giveups = None, {}, {}, {}

    def nav_point(self, me):
        """Where we are for routes. The sector graph has no way up out of the water, so in it routes start
        from the surface: straight above us in open water, or the nearest open water when under a roof."""
        if not self.wet or self.level is None:
            return me
        air = self.level.air_point(me["x"], me["y"] + 0.3, me["z"])
        if air is None:
            return me
        return dict(me, x=air[0], y=air[2] + 0.1, z=air[1])

    def avoiding(self, now):
        """Keys of the portals we gave up on that routes should still go round."""
        if self.avoid:
            self.avoid = {k: t for k, t in self.avoid.items() if t > now}
        return self.avoid

    def start_escape(self, me, now, why):
        """Handover step 1: after a 3rd stuck in a row, or 8 s without any route, walk to a random spot at least
        ESCAPE_MIN_DIST away for ESCAPE_FOR seconds (item trips wait), then choose again."""
        spot = None
        if self.level is not None:
            for _ in range(8):
                cand = self.level.random_spot(self.rng, self.nav_point(me))
                if cand is not None and flat_dist(me, cand) > self.ESCAPE_MIN_DIST:
                    spot = cand
                    break
        if spot is None:
            return
        self.wander_goal, self.wander_until = spot, now + self.ESCAPE_FOR
        self.escape_until = now + self.ESCAPE_FOR
        self.route = None
        self.item_goal = None
        self.log(f"{why}: heading for another spot for {self.ESCAPE_FOR:.0f}s")

    def give_up(self, key, now, why):
        """Route round a portal we can't get through for AVOID_FOR seconds: a jump that falls short, a door
        that won't open, a window that won't break, a gap the map data says we fit through but we don't. If
        it's the only way, routes still use it."""
        n = self.giveups.get(key, 0) + 1          # each repeat at the same portal doubles the wait (up to 20x)
        self.giveups[key] = n
        span = self.AVOID_FOR * min(2 ** (n - 1), 20)
        self.avoid[key] = now + span
        self.note_stuck("giveup:" + why.replace(",", " "), key[2], 0.0, key[3])
        self.route = None
        self.stuck_key, self.stuck_count, self.obstacle = None, 0, None
        self.log(f"can't get through at ({key[2]:.0f}, {key[3]:.0f}), {why}: going round for {span:.0f}s")

    def next_edge(self):
        """Key of the portal we're heading for: the next waypoint's, or the one after a corner or line-up
        point."""
        for wp in (self.route or [])[:2]:
            if wp.get("edge"):
                return wp["edge"]
        return None

    def waypoint(self, me, goal, now):
        """Next point to walk to on the way to `goal`, or None if there's no route."""
        if self.level is None:
            return dict(goal, jump=False, crouch=False)
        me = self.nav_point(me)
        stale = self.route is None or now - self.route_at > self.REPLAN
        moved = self.route_goal is not None and flat_dist(self.route_goal, goal) > self.GOAL_MOVED
        if stale or moved:
            hp = me.get("health")
            water_ok = self.water_ok or self.allow_water_now or self.wet
            hurt = nav.LOW_HP_DROP if hp is not None and 0 < hp <= nav.LOW_HP else None
            self.route = self.level.route(me, goal, self.avoiding(now), water=water_ok, drop_limit=hurt)
            if self.route and self.level_name and self.level_name.lower() in nav.MAP_JUMP_UP:
                top = max(w.get("y", 0.0) for w in self.route)
                if top >= 8.0 and now - self.high_route_log > 5.0:
                    self.high_route_log = now
                    self.log(f"HIGH: route climbs to height {top:.1f}")
            if self.route is None and hurt is not None:
                # Low on health, but the only way is a long drop: better that than standing there.
                self.route = self.level.route(me, goal, self.avoiding(now), water=water_ok)
            self.route_goal, self.route_at = dict(goal), now
            if self.route is None:
                if self.no_route_since is None:
                    self.no_route_since = now
                elif now - self.no_route_since > self.NO_ROUTE_FOR and now >= self.escape_until:
                    self.no_route_since = None
                    self.start_escape(me, now, "no route")
                return None
            self.no_route_since = None
        # Drop waypoints we've passed: close enough, or we're already in the sector beyond them.
        here = self.level.locate(me["x"], me["y"], me["z"])
        # A line-up point in front of a narrow opening lies in our own sector: it's passed when we're close
        # to it or already through the opening.
        while len(self.route) > 1:
            wp = self.route[0]
            if wp.get("approach"):
                passed = flat_dist(me, wp) < 1.2 or self.route[1]["sector"] == here
            elif wp.get("corner"):
                # A point to walk round something jutting into our sector (a building corner): passed when
                # we're close, once we can walk straight on to the next waypoint, or if we're past it already.
                # In a room with posts (extra berth) the shortcut is off: cutting the corner is what hugs the post.
                roomy = self.level._outline(wp["sector"]).get("berth", 1.5) > 1.6 if wp.get("sector") is not None else False
                passed = (flat_dist(me, wp) < self.CORNER_REACHED
                          or not roomy and here is not None and self.level.clear_line(here, me, self.route[1])
                          or here is not None and here != wp["sector"]
                          and any(w["sector"] == here for w in self.route[1:]))
            elif wp.get("jump"):
                # A ledge or window sill: passed once we're up on it, not when we're close to its foot.
                # Also passed once we're beyond it (over a thin sill and down the other side).
                passed = (wp["sector"] == here
                          or flat_dist(me, wp) < self.WAYPOINT_REACHED and me["y"] > wp["y"] - 0.5
                          or any(w["sector"] == here for w in self.route[1:]))
            elif wp["y"] < me["y"] - self.DROP_AT:
                # A ledge to drop off (a porch roof): passed once we're down there or beyond, not when we're
                # near the edge, or we'd turn back for the next waypoint underneath us.
                passed = wp["sector"] == here or any(w["sector"] == here for w in self.route[1:])
            else:
                # A portal: passed once we're through it (in its sector, or already in the next one when it
                # leads into a thin one). Close to it but still on this side we head on through it (below)
                # rather than cutting across to the next waypoint: `blocked` only sees our sector's solid
                # walls, and the next waypoint can lie past a window, a ledge or the porch sectors in front of
                # a building that only this portal gets us through. Without a point past it, cut across if
                # that doesn't run into the door frame or a post.
                passed = (here is not None and here in (wp["sector"], self.route[1]["sector"])
                          or not wp.get("beyond") and flat_dist(me, wp) < self.WAYPOINT_REACHED
                          and abs(me["y"] - wp["y"]) < self.WAYPOINT_VERT
                          and (here is None or not self.level.blocked(here, me, self.route[1])))
            if not passed:
                break
            popped = self.route.pop(0)
            if popped.get("edge") is not None and not popped.get("approach"):
                # Got through after all.
                if popped["edge"] == self.stuck_key:
                    self.stuck_key, self.stuck_count = None, 0
                if self.obstacle and popped["edge"] == self.obstacle[0]:
                    self.obstacle = None
        wp = self.route[0]
        if (wp.get("beyond") and not wp.get("approach") and not wp.get("corner")
                and flat_dist(me, wp) < (1.0 if wp["y"] < me["y"] - self.DROP_AT else self.WAYPOINT_REACHED)):
            # At the opening: head on through it, to a point just past it. On the edge of a drop, head on over
            # it, not for the edge under our feet.
            return dict(wp, x=wp["beyond"]["x"], z=wp["beyond"]["z"])
        return wp

    # -- weapons --------------------------------------------------------------------------------------
    @staticmethod
    def usable(w):
        """A weapon we can fight with: fists, or a gun with rounds loaded or in reserve."""
        return w["ammo"] is None or w["loaded"] > 0 or (w["reserve"] or 0) > 0

    def best_weapon(self, inv, dist, exclude=()):
        if self.gg:                          # gun game: the rung's weapon, nothing else
            w = next((w for w in inv["weapons"] if w["slot"] == gungame.slot_for(self.gg_rung)), None)
            return w if w and self.usable(w) else next((w for w in inv["weapons"] if w["slot"] == FIST_SLOT), None)
        order = self.skill.prefer_far if dist is not None and dist > self.skill.far else self.skill.prefer_close
        if self.skill.lean in order and not self.liking_on():
            order = [self.skill.lean] + [sl for sl in order if sl != self.skill.lean]
        if dist is not None and self.skill.far_long is not None and dist > self.skill.far_long:
            order = self.skill.prefer_long
        by_slot = {w["slot"]: w for w in inv["weapons"]}
        if self.skill.fist_share > 0:                       # the boxer: fists most of the time, now and then the knife
            k, f = by_slot.get(KNIFE_SLOT), by_slot.get(FIST_SLOT)
            if k and f and self.usable(k) and KNIFE_SLOT not in exclude and FIST_SLOT not in exclude:
                if self.wet:
                    return k                                # in the water the knife reaches further
                now = time.time()
                if now >= getattr(self, "_fist_next", 0.0):
                    self._fist_pick = self.rng.random() < self.skill.fist_share
                    self._fist_next = now + self.rng.uniform(6.0, 10.0)
                return f if self._fist_pick else k
        # Camping with the Gatling (gatling_camp): it stays out until we die or it runs dry.
        g = by_slot.get(GATLING_SLOT)
        gat_far = bool(g) and dist is not None and dist > min(self.skill.max_engage, g.get("effRange") or self.skill.max_engage)
        if g and self.usable(g) and not gat_far and not self.wet and not PATHCHECK_NO_GATLING and (GATLING_SLOT not in exclude or self.camp_set):   # in a fight, or camping, it stays out until it runs dry (user); on the move it roots us, so manage_weapon excludes it
            return g
        # Marshall Law off: the sawed-off at point blank range, and kept until the enemy is well clear.
        w6 = by_slot.get(SAWED_SLOT)
        if (w6 and not self.bot.marshall_law and dist is not None and self.usable(w6)
                and SAWED_SLOT not in exclude):
            reach = min(SAWED_RANGE, w6.get("effRange") or SAWED_RANGE)
            if dist < reach * (1.5 if inv.get("slot") == SAWED_SLOT else 1.0):
                return w6
        rolled = self.rolled_weapon(by_slot, dist, exclude)
        if rolled is not None:
            return rolled
        for slot in order:
            w = by_slot.get(slot)
            if w and slot != TNT_SLOT and slot not in exclude and self.usable(w):
                return w
        return None

    def liking_on(self):
        s = self.skill
        return (CHAR_NAMES.get(self.char_num) in LIKING and s.behaviour == "default" and s.favorite is None
                and not s.melee_only and not s.tnt)

    def rolled_weapon(self, by_slot, dist, exclude):
        """Handover step 7. Out of a fight: the gun rolled by the character's liking (rolled at spawn and on each
        pickup, then again every 12-20 s once 4 s have passed since we last saw anyone). In a fight: the gun for the
        range band (under 20 any shotgun, over 40 the rifle, else the revolver; the revolver also when the band's
        gun isn't carried), rolled with weight liking + 5, one time in seven by liking alone. 2.5 of hysteresis at
        the band edges. Returns None to leave the choice to the old order."""
        if not self.liking_on():
            return None
        like = LIKING[CHAR_NAMES[self.char_num]]
        now = time.time()
        guns = {sl: w for sl, w in by_slot.items() if sl in like and sl not in exclude and self.usable(w)
                and not (sl == SAWED_SLOT and self.bot.marshall_law)}
        if not guns:
            return None
        owned = frozenset(guns)

        def roll(slots, plus):
            ws = [like[sl] + plus + (LEAN_BONUS if sl == self.skill.lean else 0) for sl in slots]
            if sum(ws) <= 0:
                return self.rng.choice(slots)
            return self.rng.choices(slots, weights=ws)[0]

        if dist is None:
            if owned != self.owned_seen or self.liked_slot not in guns or (
                    now >= self.liked_next and now - self.last_any_seen > 4.0):
                self.owned_seen = owned
                self.liked_slot = roll(sorted(guns), 0)
                self.liked_next = now + self.rng.uniform(12.0, 20.0)
                self.log(f"liked gun rolled: slot {self.liked_slot}")
            return guns[self.liked_slot]
        self.last_any_seen = now
        # Band with hysteresis.
        band = self.band
        edge = BAND_HYST
        if band == "close" and dist < CLOSE_BAND + edge:
            pass
        elif band == "far" and dist > FAR_BAND - edge:
            pass
        elif band == "mid" and CLOSE_BAND - edge <= dist <= FAR_BAND + edge:
            pass
        else:
            band = "close" if dist < CLOSE_BAND else "far" if dist > FAR_BAND else "mid"
        if band != self.band:
            self.band, self.fight_slot = band, None
        cand = [sl for sl in ((4, 5, 6) if band == "close" else (3,) if band == "far" else (2,)) if sl in guns]
        if not cand:
            cand = [2] if 2 in guns else sorted(guns)
        lean = self.skill.lean
        if lean in guns and lean not in cand:
            cand = cand + [lean]            # a leaned-toward gun competes at any range (its weight carries the bonus)
        cur = guns.get(self.fight_slot)
        if self.fight_slot not in cand or cur is None:
            plus = 5
            if self.rng.random() < 1.0 / 7.0:
                plus = 0
            self.fight_slot = roll(cand, plus)
        return guns[self.fight_slot]

    @staticmethod
    def melee_slot(inv):
        """The weapon for the water: the knife if we have one, otherwise fists (None if neither shows up)."""
        slots = {w["slot"] for w in inv["weapons"]}
        return KNIFE_SLOT if KNIFE_SLOT in slots else FIST_SLOT if FIST_SLOT in slots else None

    def close_fight(self, me, now, dist, engaged):
        """An enemy within Skill.close_range: in sight, or seen there moments ago (ducked behind a corner)."""
        s = self.skill
        if engaged:
            return dist is not None and dist < s.close_range
        return (self.last_seen is not None and now - self.last_visible < s.fight_memory
                and flat_dist(me, self.last_seen) < s.close_range)

    def manage_weapon(self, me, now, dist, engaged):
        """Switch to the best usable weapon, and reload fully. Returns (weapon, may_fire)."""
        inv = me.get("inventory")
        if not inv:
            return None, True
        current = next((w for w in inv["weapons"] if w["slot"] == inv["slot"]), None)
        if not self.sawed_logged and any(w["slot"] == SAWED_SLOT for w in inv["weapons"]):
            self.sawed_logged = True
            w6 = next(w for w in inv["weapons"] if w["slot"] == SAWED_SLOT)
            self.log(f"sawed-off in hand: {w6.get('name')} range {w6.get('range')} effRange {w6.get('effRange')} "
                     f"spread {w6.get('spread')} capacity {w6.get('capacity')} "
                     f"({'unused: Marshall Law' if self.bot.marshall_law else 'used point blank'})")

        # Holding the badge: fists only.
        if inv.get("hasBadge"):
            self.stop_reload()
            if inv["slot"] != FIST_SLOT:
                self.release_fire()
                if now >= self.next_switch:
                    self.log("holding the badge: switching to fists")
                    self.tap(str(FIST_SLOT))
                    self.next_switch = now + 1.0
                return current, False
            return current, True

        # In the water or on top of it, no guns (they don't fire under water, and on top it counts as cheating):
        # the knife, or fists without one.
        if self.wet:
            self.stop_reload()
            melee = self.melee_slot(inv)
            if melee is None:
                self.release_fire()
                return current, False
            if inv["slot"] != melee:
                self.release_fire()
                if now >= self.next_switch:
                    self.log(f"in the water: switching to {'the knife' if melee == KNIFE_SLOT else 'fists'}")
                    self.tap(str(melee))
                    self.next_switch = now + 1.0
                return current, False
            return current, True

        # A sapper with sticks keeps the TNT out, fighting or not, and never fires a gun (user). tnt_fight throws.
        if self.tnt_ready(inv):
            self.stop_reload()
            self.release_fire()
            if inv["slot"] != TNT_SLOT and now >= self.next_switch:
                self.log(f"switch {current['name'] if current else 'weapon'} -> TNT ({itemlib.tnt_count(inv)} sticks)")
                self.tap(str(TNT_SLOT))
                self.next_switch = now + 1.5
            return current, False

        # The knife already out and an enemy at arm's length, or just out of the water (we climbed out at
        # someone): stab rather than spend the switch time on a gun.
        if current is not None and current["slot"] == KNIFE_SLOT and (
                now - self.left_water_at < self.skill.knife_hold
                or engaged and dist is not None and dist < self.skill.knife_keep):
            self.stop_reload()
            return current, True

        # Melee bots (brawler, boxer) never fire a gun: holding one (the pistol they spawn with), they put it away first.
        if (self.skill.melee_only and current is not None and current["slot"] not in (FIST_SLOT, KNIFE_SLOT)
                and not (self.skill.tnt and current["slot"] == TNT_SLOT)):
            self.release_fire()
            self.stop_reload()
            if now >= self.next_switch:
                to = self.best_weapon(inv, dist) or {"slot": FIST_SLOT, "name": "fists"}
                self.log(f"melee only: putting the {current.get('name')} away -> {to.get('name')}")
                self.tap(str(to["slot"]))
                self.next_switch = now + 0.5
            return current, False

        # Out of a fight we need to move, and the Gatling roots us: carry something else if we can.
        best = None
        if not engaged:
            best = self.best_weapon(inv, dist, exclude=(GATLING_SLOT,))
        best = best or self.best_weapon(inv, dist)

        # Switch when something better is usable or the current weapon is dry. Not mid-reload unless dry.
        dry = current is None or not self.usable(current)
        if (best and current and best["slot"] != current["slot"] and now >= self.next_switch
                and (dry or not (self.reloading or inv.get("action") == RELOAD_ACTION))
                and (dry or not self.liking_on() or self.burst_shots == 0)):      # step 7: never mid-burst unless empty
            self.log(f"switch {current['name']} -> {best['name']}")
            self.release_fire()
            self.tap(str(best["slot"]))
            self.stop_reload()
            self.next_switch = now + (3.0 if self.liking_on() else 0.4 if self.skill.berserk else 1.5)   # step 7: swap at most every 3 s
            return best, False
        if current is None or current["ammo"] is None or current["slot"] == TNT_SLOT:
            self.stop_reload()                      # fists/knife/TNT: nothing to reload
            return current, True

        if engaged and current["slot"] in PUMP_SLOTS and inv.get("action") is not None:
            self.reloading = False                  # in a fight pump() runs fire and reload together
            return current, True

        loaded, cap, reserve = current["loaded"], current["capacity"], current["reserve"] or 0
        full = loaded >= cap or reserve <= 0
        # Up close a part-loaded gun beats standing there reloading: with enough rounds in, don't start a
        # reload (even with the enemy just out of sight), and cut one short once the enemy shows up.
        enough = loaded >= min(self.skill.close_reload_below, cap)
        hold_off = current["slot"] not in PUMP_SLOTS and enough and self.close_fight(me, now, dist, engaged)
        if self.reloading and hold_off and engaged:
            self.stop_reload()
            self.log(f"reload cut short: {current['name']} {loaded}/{cap}, enemy at {dist:.0f}")
        if not self.reloading and not full and not hold_off and (loaded == 0 or not engaged):
            self.reloading = True
            self.reload_progress = (loaded, now)
            self.log(f"reloading {current['name']} {loaded}/{cap} (+{reserve})")
        if self.reloading:
            last, since = self.reload_progress
            if full:
                self.stop_reload()
                self.log(f"reloaded {current['name']} {loaded}/{cap}")
            elif loaded != last:
                self.reload_progress = (loaded, now)
            elif now - since > self.skill.reload_stall and self.reload_held:
                self.hold_reload(False)                     # stalled: let go, hold again next tick
                self.reload_progress = (loaded, now)
                return current, False
            if self.reloading:
                # Keep R down until the weapon is full (or out of spare rounds). Pressing it while a
                # shotgun shot is still animating is fine: the game starts the reload when that ends,
                # as long as R is still down then.
                self.release_fire()
                self.hold_reload(True)
        # Firing cancels a reload, so hold fire until it's done.
        return current, not self.reloading and loaded > 0

    # -- movement -------------------------------------------------------------------------------------
    def sweep_heading(self, me, wp, heading):
        """Blocked-ahead sweep (handover step 4): if a solid wall of our sector lies straight ahead on the way to
        an ordinary waypoint, try 30, 60, 90 and 125 degrees either way (the side nearer the target first) and
        take the first heading with a clear short run. Ledges, jumps, crouches, line-ups and doors keep their
        own handling."""
        if (self.level is None or wp.get("jump") or wp.get("crouch") or wp.get("approach") or wp.get("gap")
                or wp.get("leap") or wp.get("crouch_jump") or wp.get("edge") is not None and flat_dist(me, wp) < 4.0):
            return heading
        here = self.level.locate(me["x"], me["y"], me["z"])
        if here is None:
            return heading
        d = flat_dist(me, wp)
        look = min(d, self.SWEEP_LOOK)

        def ahead(h):                         # h in degrees, 0 = +z, turning toward +x
            r = math.radians(h)
            return {"x": me["x"] + math.sin(r) * look, "z": me["z"] + math.cos(r) * look}

        deg = to_deg(heading)

        if not self.level.blocked(here, me, ahead(deg)):
            return heading
        # Only when the waypoint itself is in our sector (else the wall may be the portal's own frame).
        if wp.get("sector") != here:
            return heading
        for ang in self.SWEEP_ANGLES:
            for sign in (1, -1):
                h = deg + sign * ang
                if not self.level.blocked(here, me, ahead(h)):
                    return to_units(h) % FULL_TURN
        return heading

    def go(self, me, now, goal, aiming=False, keep=0.0, strafe=False):
        """Move toward `goal` along a route. When `aiming`, the view belongs to the aim code and we pick
        W/A/S/D relative to it; otherwise we face the next waypoint. Returns False if unreachable."""
        keys = set()
        reachable = True
        self.climb_active = False
        tight = False                         # about to go through a narrow opening: no sidestepping
        busy = False                          # waiting on a door or shooting out a window
        roofed = None
        if now < self.backoff_until:
            # Just nudged a saloon door from inside: step back so the swinging door doesn't hit us.
            if self.backoff_look is not None:
                self.look_toward(me, self.backoff_look, 0)
            keys = {"s"}
            busy = True
        elif self.door_pass is not None and now < self.door_pass["until"] and now >= self.backoff_until:
            keys = self.door_pass_keys(me, now)
            if keys is None:
                self.door_pass = None
                return self.go(me, now, goal, aiming=aiming, keep=keep, strafe=strafe)
            busy = True
        elif now < self.turn_until:
            # Stuck in the same spot again and again: turn round and walk (jumping) the other way.
            self.look_toward(me, self.turn_heading, 0)
            if abs(to_deg(wrap(round(self.turn_heading - me["yaw"])))) < 25:
                keys = {"w"} | ({"space"} if int(now / 0.3) % 2 == 0 else set())
            else:
                keys = set()
        elif now < self.hop_until:
            # First try at a stuck spot: jump straight on, as over a potted plant or a crate (user).
            keys = {"w"} | self.jump_keys(now)
        elif now < self.unstick_until:
            # Crouch-jump while strafing: a crouched player fits through window openings and low gaps.
            # Crouch first; jump and strafe once the crouch has taken hold.
            if now < self.unstick_crouch_until:
                keys = {"lctrl", "w"}
            else:
                keys = {self.strafe_key, "space", "w", "lctrl"}
        else:
            roofed = self.roofed_exit(me, now)
            if roofed is not None:
                wp = roofed                   # under the docks: out into open water first, where routes start
            else:
                wp = self.waypoint(me, goal, now) if flat_dist(me, goal) > keep else None
            if wp is None and flat_dist(me, goal) > keep:
                reachable = False
            if wp is not None:
                heading = bearing(me, wp)
                heading = self.sweep_heading(me, wp, heading)
                if aiming:
                    keys |= keys_toward(me["yaw"], heading)
                else:
                    self.look_toward(me, heading, 0)
                    if abs(to_deg(wrap(round(heading - me["yaw"])))) < 60:   # turn first on sharp corners
                        keys.add("w")
                d = flat_dist(me, wp)
                near = d < 6.0
                if wp.get("leap"):
                    # A hole in a roof right above us (Orleans' north building): stand under it crouched for a
                    # moment, then jump, still crouched, and move on to the roof (user).
                    hx, hz = wp["leap"]
                    if me["y"] > wp["y"] - 3.0 or flat_dist(me, {"x": hx, "z": hz}) > 3.0:
                        self.hop_t0 = None
                    else:
                        if self.hop_t0 is None or now - self.hop_t0 > 6.0:
                            self.hop_t0 = now
                        if now - self.hop_t0 < 0.5:
                            keys = {"lctrl"}
                        else:
                            keys |= {"lctrl", "space"}
                elif wp.get("gap"):
                    # A window above a ledge across a gap (Dry Gulch): run at it and jump from the sill (user).
                    gx, gz = wp["gap"]
                    keys.add("w")
                    up_here = me["y"] > (wp["gap_y"] - 1.0 if wp.get("gap_y") is not None else wp["y"] + 2.0)
                    if up_here and flat_dist(me, {"x": gx, "z": gz}) < self.skill.gap_jump_at:
                        if now - self.gap_logged > 3.0:
                            self.gap_logged = now
                            self.log(f"HIGH: jumping the gap at ({gx:.0f}, {gz:.0f}) height {me['y']:.1f} toward ({wp['x']:.0f}, {wp['z']:.0f}) height {wp['y']:.1f}")
                        keys |= self.jump_keys(now)
                        if self.level_name not in ("billhmre", "thudtowr"):
                            keys.add("lctrl")                # low ceiling over the sill (8 units): tuck the head in for the jump
                            self.crouch_until = now + 0.6
                elif wp.get("crouch_jump"):
                    # A low opening above a ledge (a window): crouch first, jump once the crouch has
                    # taken hold, and stay crouched through the jump and a little after.
                    if near and self.crouched(me, now) and d < self.CROUCH_JUMP_AT:
                        keys |= self.jump_keys(now)
                        self.crouch_until = now + self.skill.crouch_hold
                elif wp.get("jump") and near:
                    keys |= self.jump_keys(now)
                tight = (wp.get("width", 99.0) < self.TIGHT_PASS and not wp.get("corner")
                         and not wp.get("approach") and d < 8.0)
                climbing = self.climb_step(me, now, wp, heading, d)
                if climbing is not None:
                    keys = climbing                  # face the ledge, jump, keep forward held: the whole job
                if wp.get("crouch") and near or self.in_crouch_space(me):
                    keys.add("lctrl")
                if climbing is not None:
                    busy = self.climb_t0 is not None and now - self.climb_t0 < self.CLIMB_PATIENCE
                elif roofed is None:
                    busy = self.handle_obstacles(me, now, wp, aiming)
            if now < self.crouch_until:
                keys.add("lctrl")
            if self.level_name in self.LEDGE_MAPS and self.level is not None and not self.wet and not self.climb_active:
                keys, strafe = self.ledge_guard(me, now, wp, keys, strafe, aiming)
            else:
                self.ledge_now = False
            if strafe:
                if now > self.strafe_until:
                    self.strafe_key = self.rng.choice("ad")
                    self.strafe_until = now + self.rng.uniform(0.6, 1.8)
                    self.strafe_skip = self.rng.random() >= self.skill.strafe_frac
                    self.strafe_hop = self.rng.random() < self.skill.hop_frac
                if getattr(self, "strafe_hop", False) and not self.climb_active and not tight and now % 0.9 < 0.25:
                    keys.add("space")                              # Hell: hop while strafing, so it is harder to hit
                if not self.strafe_skip and not keys & {"a", "d"} and not self.climb_active and not tight:
                    keys.add(self.strafe_key)
            # Avoid badges before the stuck check, so holding back from a badge doesn't count as stuck.
            keys = self.avoid_badges(me, keys)
            self.check_stuck(now, me, bool(keys & {"w", "a", "s", "d"}) and not strafe and not busy)
        if self.wet and self.roof_over(me) is not None:
            keys = self.roof_keys(me, now, keys)
        elif self.wet:
            # Swim up (jump) to stay at the surface, where routes run and the banks can be climbed. No crouching.
            keys = (keys - {"lctrl"}) | {"space"}
        self.set_keys(keys)
        return reachable

    # -- narrow raised walkways (Thud Tower) -------------------------------------------------------------
    def ground_at(self, me, x, z):
        """The floor height under (x, z) at about our own height, or None where there is no floor there."""
        # The highest floor under (x, z) that is no more than a step (3.5) above us: a ramp rising ahead still counts as
        # ground, and a sector stacked high over our head does not.
        best = None
        lvl = self.level
        boxes = getattr(self, "_ledge_boxes", None)
        if boxes is None or boxes[0] is not lvl:
            boxes = (lvl, [(min(v[0] for v in sec.vertices), max(v[0] for v in sec.vertices),
                            min(v[1] for v in sec.vertices), max(v[1] for v in sec.vertices), sec)
                           for sec in lvl.sectors if sec.walls and sec.vertices])
            self._ledge_boxes = boxes
        for x0, x1, z0, z1, sec in boxes[1]:
            if x < x0 or x > x1 or z < z0 or z > z1 or not sec.contains(x, z):
                continue
            f = lvl.floor_at(sec.index, x, z)
            if f <= me["y"] + 3.5 and lvl.ceiling_at(sec.index, x, z) > f + 1.0 and (best is None or f > best):
                best = f
        return best

    def is_drop(self, me, x, z):
        """Ground more than LEDGE_DROP below us at (x, z). A point in no sector is a solid wall, not a drop."""
        g = self.ground_at(me, x, z)
        return g is not None and g < me["y"] - self.LEDGE_DROP

    def edge_dist(self, me, rad, far):
        """How far along a heading (radians) the first drop is, or None within `far`."""
        d = 0.5
        while d <= far:
            if self.is_drop(me, me["x"] + math.sin(rad) * d, me["z"] + math.cos(rad) * d):
                return d
            d += 0.5
        return None

    def ledge_near(self, me, now):
        """An edge (ground more than LEDGE_DROP below us) within LEDGE_NEAR of us in any of 8 directions, or
        ahead of us within 8 (so a bot running at a walkway slows down before it is on it). Worked out about 12 times a second."""
        if now - self.ledge_at < 0.08:
            return self.ledge_now
        self.ledge_at = now
        if me.get("y") is None or (me.get("vy") or 0.0) < -3.0:
            return self.ledge_now                         # falling already
        for k in range(8):
            r = math.radians(k * 45.0)
            if self.is_drop(me, me["x"] + math.sin(r) * self.LEDGE_NEAR, me["z"] + math.cos(r) * self.LEDGE_NEAR):
                return True
        vx, vz = me.get("vx") or 0.0, me.get("vz") or 0.0
        head = math.atan2(vx, vz) if math.hypot(vx, vz) > 2.0 else math.radians(to_deg(me["yaw"]))
        for off in (-0.45, 0.0, 0.45):
            for d in (6.0, 8.0):
                if self.is_drop(me, me["x"] + math.sin(head + off) * d, me["z"] + math.cos(head + off) * d):
                    return True
        return False

    def ledge_guard(self, me, now, wp, keys, strafe, aiming):
        """On a narrow raised walkway: no strafing, no hopping, no sprinting, a fast turn, steering that keeps to the
        middle, a stop short of an edge we are heading for (judged from our speed, and a push the other way), and a jump
        over a gap in the way. The bot keeps moving and shooting otherwise. Returns (keys, strafe)."""
        last = getattr(self, "ledge_last", None)
        if last is not None and now - last[0] < 2.0 and me["y"] < last[1] - 8.0:
            self.log(f"LEDGE: fell from height {last[1]:.1f} to {me['y']:.1f} at ({last[2]:.0f}, {last[3]:.0f}) "
                     f"going {last[4]:.1f} units/s, difficulty {getattr(self.skill, 'ledge_err', '?')}")
            self.ledge_last = None
        self.ledge_now = self.ledge_near(me, now)
        self.ledge_sprint_ok = False
        if not self.ledge_now:
            return keys, strafe
        vx, vz = me.get("vx") or 0.0, me.get("vz") or 0.0
        speed = math.hypot(vx, vz)
        self.ledge_last = (now, me["y"], me["x"], me["z"], speed)
        strafe = False
        want_down = wp is not None and wp["y"] < me["y"] - 3.0            # the route wants to drop off here
        if wp is not None and not aiming and self.skill.ledge_push > 0 and not want_down:
            # Keep to the middle: the distances to the drop at the left and right of the way we go decide a push.
            h = math.radians(to_deg(bearing(me, wp)))
            dl = self.edge_dist(me, h - 1.5708, 3.5)
            dr = self.edge_dist(me, h + 1.5708, 3.5)
            if dl is not None or dr is not None:
                off = (3.5 if dl is None else dl) - (3.5 if dr is None else dr)      # > 0: nearer the right edge
                shift = max(-2.0, min(2.0, off / 1.75)) * self.skill.ledge_push * -1.0
                if abs(shift) > 0.5:
                    self.look_toward(me, (bearing(me, wp) + to_units(shift)) % FULL_TURN, 0)
        if wp is not None and not want_down and self.skill.ledge_sprint > 0:
            # Sprinting is fine while we face the waypoint, the walkway is wide enough at both sides and no edge or
            # corner is coming up: that is what makes the bot a moving target rather than a slow walker.
            err = abs(to_deg(wrap(round(bearing(me, wp) - me["yaw"]))))
            if err < self.skill.ledge_sprint and flat_dist(me, wp) > 6.0:
                h = bearing(me, wp)
                hr = math.radians(to_deg(h))
                dl = self.edge_dist(me, hr - 1.5708, 1.0)
                dr = self.edge_dist(me, hr + 1.5708, 1.0)
                ahead = self.edge_dist(me, hr, 7.0 + 0.4 * speed)
                self.ledge_sprint_ok = dl is None and dr is None and ahead is None
        jumping = wp is not None and (wp.get("jump") or wp.get("gap") or wp.get("crouch_jump") or wp.get("leap"))
        if not jumping and now >= self.ledge_jump_until:
            keys = keys - {"space"}
        yaw = to_deg(me["yaw"])
        goal_deg = to_deg(bearing(me, wp)) if wp is not None else yaw
        # A gap on the way: run at it and jump it (the far side level with us, within reach).
        if wp is not None and not want_down and "w" in keys and now >= self.ledge_jump_until:
            r = math.radians(goal_deg)
            sx, cz = math.sin(r), math.cos(r)
            edge = next((d for d in (1.0, 1.75, 2.5) if self.is_drop(me, me["x"] + sx * d, me["z"] + cz * d)), None)
            if edge is not None and flat_dist(me, wp) > edge + 2.5:
                land = None
                d = edge + 1.0
                while d <= self.skill.ledge_gap:
                    g = self.ground_at(me, me["x"] + sx * d, me["z"] + cz * d)
                    if g is not None and me["y"] - 2.5 <= g <= me["y"] + 4.0:
                        land = d
                        break
                    d += 0.75
                if land is not None and abs(to_deg(wrap(round(bearing(me, wp) - me["yaw"])))) < 12.0:
                    self.ledge_jump_until = now + 0.9
                    self.log(f"LEDGE: jumping a {land - edge:.1f}-unit gap at ({me['x']:.0f}, {me['z']:.0f}) height {me['y']:.1f}")
        if now < self.ledge_jump_until:
            return keys | {"w", "space"}, strafe
        if wp is not None and (wp.get("gap") or wp.get("jump") or wp.get("leap") or wp.get("crouch_jump")):
            return keys, strafe                              # the route's own jump: its code runs the approach
        if want_down:
            return keys, strafe
        # Stop at the edge. The distance counts our speed (we keep sliding a moment after the keys go up), and what we
        # do is judged along the way we are really going as well as along the way the keys point.
        stop = self.skill.ledge_stop + 0.3 * speed
        if wp is not None and not aiming:
            err = abs(to_deg(wrap(round(bearing(me, wp) - me["yaw"]))))
            if err > self.skill.ledge_err:
                stop *= 1.5                                   # still turning round
        move = {"w": 0.0, "d": 90.0, "s": 180.0, "a": 270.0}
        over = False
        for k in [k for k in keys if k in move]:
            r = math.radians(yaw + move[k])
            if self.is_drop(me, me["x"] + math.sin(r) * stop, me["z"] + math.cos(r) * stop):
                keys = keys - {k}
                over = True
        if speed > 3.0:
            vr = math.atan2(vx, vz)
            if self.is_drop(me, me["x"] + math.sin(vr) * stop * 1.3, me["z"] + math.cos(vr) * stop * 1.3):
                keys = keys - set(move)
                if speed > 6.0:                               # sliding toward the edge: push back against it
                    keys = keys | keys_toward(me["yaw"], to_units(math.degrees(vr + math.pi)) % FULL_TURN)
        return keys, strafe

    # -- Orleans' west building pool ----------------------------------------------------------------------
    def pool_state(self, me):
        """Where we are relative to the pool: "pool" (in its water), "dock" (under the dock roof), "zone" (on the
        stairs, the roof or at the pool's surface) or "out"."""
        lvl, p = self.level, self.pool
        if self.wet:
            if lvl.water_at(me["x"], me["y"] + 0.3, me["z"]) in p["water"]:
                return "pool"
            if self.roof_over(me) is not None:
                return "dock"
        if lvl.locate(me["x"], me["y"] + 0.1, me["z"]) in p["zone"]:
            return "zone"
        return "out"

    def pool_tick(self, me, now, target):
        """Runs the trips into and out of the pool before the normal logic. True when it handled the tick."""
        st = self.pool_state(me)
        if st in ("zone", "pool"):
            if self.pool_mode == "enter":
                self.pool_mode = None                 # arrived: the item routes take it from here
            if target is None and self.item_goal is None and self.pool_mode != "leave":
                if self.zone_idle is None:
                    self.zone_idle = now
                elif now - self.zone_idle > POOL_IDLE:
                    self.pool_mode = "leave"
                    self.log("nothing left up here: jumping off the roof into the river")
            elif self.item_goal is not None or target is not None:
                self.zone_idle = None
            if self.pool_mode == "leave":
                return self.pool_leave(me, now)
            return False
        self.zone_idle = None
        if self.pool_mode == "leave":
            self.pool_mode = None                     # out again
            return False
        if self.pool_mode == "enter":
            there = any(it["addr"] == self.pool_addr for it in self.bot.items)
            if (not there or now - self.pool_since > POOL_TRIP_MAX or self.surfacing or now < self.flee_until
                    or self.ignored_items.get(self.pool_addr, 0) > now):
                self.pool_mode = None
                return False
            if target is not None and not self.wet:
                return False                          # a fight on the way: the normal logic
            return self.pool_enter(me, now, st)
        return False

    def pool_enter(self, me, now, st):
        """On the way into the pool: to the river by the dock's south entrance, down under its roof (feet below the
        roof's edge before moving on) and in along the dock water to the pool. False if there's no way."""
        p = self.pool
        if st == "dock":
            goal = {"x": p["inside"][0], "y": me["y"], "z": p["inside"][1]}
        else:
            mx, mz = p["mouth"]
            if self.wet and flat_dist(me, {"x": mx, "z": mz}) < 12.0:
                heading = bearing(me, {"x": p["south"][0], "z": p["south"][1]})
                self.look_toward(me, heading, 0)
                keys = {"lctrl"}                      # swim down first: the dock's roof is 3 below the surface
                if me["y"] < -12.0:
                    keys.add("w")
                self.set_keys(keys)
                return True
            goal = {"x": mx, "y": -5.0, "z": mz}
        self.allow_water_now = True
        try:
            return self.go(me, now, goal)
        finally:
            self.allow_water_now = False

    def pool_leave(self, me, now):
        """Off the roof: to its south edge, then run and jump out over the quay into the river (a fall into water
        doesn't hurt; onto the quay it would)."""
        edge_z = 110.0
        if not self.wet and me["z"] >= edge_z - 1.0 and me["y"] > 15.0:
            self.look_toward(me, bearing(me, {"x": me["x"], "z": me["z"] + 40.0}), 0)
            self.set_keys({"w"} | (self.jump_keys(now) if me["z"] >= edge_z + 1.5 else set()))
            return True
        self.go(me, now, {"x": -99.0, "y": 22.0, "z": edge_z})
        return True

    def roofed_exit(self, me, now):
        """In the water under a roof (below the docks): the next point on the way out into open water, else None."""
        if self.roof_over(me) is None:
            return None
        if self.pool is not None and self.pool_mode == "enter":
            return self.water_waypoint(me, {"x": self.pool["inside"][0], "z": self.pool["inside"][1]}, now)
        air = self.level.air_point(me["x"], me["y"] + 0.3, me["z"])
        if air is None:
            return None
        return self.water_waypoint(me, {"x": air[0], "z": air[1]}, now)

    def roof_over(self, me):
        """The roof's height when we're in water with no air above it (under the docks and the riverside
        buildings), else None."""
        if not self.wet or self.level is None:
            return None
        i = self.level.water_at(me["x"], me["y"] + 0.3, me["z"])
        if i is None or self.level.sectors[i].vadjoin >= 0:
            return None
        return self.level.sectors[i].ceiling

    def roof_keys(self, me, now, keys):
        """Keys under a roof in the water. Never swim up: that pins us to the roof. Swim lower (crouch) when our
        head nears it, and for a second whenever we stop getting anywhere: the beams and the tops of the
        pilings' walls catch us up there, and going lower gets us loose (user)."""
        roof = self.roof_over(me)
        keys = keys - {"space"}
        if keys & {"w", "a", "s", "d"} and self.stalled(now, me):
            if now >= self.swim_low_until:
                self.log("stuck under a roof in the water: swimming lower")
            self.swim_low_until = now + 1.0
        if now < self.swim_low_until or roof is not None and me["y"] + me["height"] > roof - 1.0:
            keys.add("lctrl")
        return keys

    def water_waypoint(self, me, goal, now):
        """Next point on the way to `goal` (x, z) under water: a route through the water sectors at our depth,
        round the pilings under the docks (a straight line runs into them). Straight at it without a route."""
        g = {"x": goal["x"], "y": me["y"], "z": goal["z"]}
        if (self.water_route is None or now - self.water_route_at > 1.0
                or flat_dist(self.water_route_goal, g) > 3.0):
            self.water_route = self.level.route(me, g) or []
            self.water_route_at, self.water_route_goal = now, g
        while len(self.water_route) > 1 and flat_dist(me, self.water_route[0]) < 2.0:
            self.water_route.pop(0)
        wp = self.water_route[0] if self.water_route else g
        return {"x": wp["x"], "y": wp["y"], "z": wp["z"]}

    def crouched(self, me, now):
        """Crouch has taken hold: we're down at our crouched height, or it has been held CROUCH_LEAD."""
        if "lctrl" not in self.bot.held:
            return False
        ch = (self.bot.self_state or {}).get("crouchHeight")
        if ch and me["height"] <= ch + 0.25:
            if not self.crouch_logged:
                self.crouch_logged = True
                self.log(f"crouched: height {me['height']:.2f} after {now - self.crouch_since:.2f}s")
            return True
        return now - self.crouch_since >= self.CROUCH_LEAD

    TIGHT_PASS = 15.0              # a doorway narrower than this: walk straight through it, no strafing into the posts at its sides
    CLIMB_FACE = 10.0              # degrees: square up to a ledge before jumping at it
    CLIMB_JUMP_ON = 0.35           # climbing: jump key down this long, then up for CLIMB_JUMP_OFF
    CLIMB_JUMP_OFF = 0.10
    CLIMB_JUMP_AT = 3.5            # jump this close (flat) to the foot of a ledge
    CLIMB_PATIENCE = 6.0           # seconds of trying one climb before the stuck handling may step in
    CLIMB_MIN_RISE = 2.0           # a step up bigger than this is jumped (crates, ledges), not walked

    def climb_target(self, wp):
        """Where to run when climbing onto a crate or ledge: its middle, so the bot lands well inside it and
        carries on to the next jump, not just up to its lip."""
        idx = wp.get("sector")
        if idx in self.climb_centers:
            c = self.climb_centers[idx]
        else:
            c = None
            if self.level is not None and idx is not None and 0 <= idx < len(self.level.sectors):
                sec = self.level.sectors[idx]
                xs = [v[0] for v in sec.vertices]
                zs = [v[1] for v in sec.vertices]
                if xs and max(xs) - min(xs) < 30 and max(zs) - min(zs) < 30:
                    cx, cz = (min(xs) + max(xs)) / 2, (min(zs) + max(zs)) / 2
                    if sec.contains(cx, cz):
                        c = (cx, cz)
            self.climb_centers[idx] = c
        if c is None:
            b = wp.get("beyond")
            return (b["x"], b["z"]) if b else (wp["x"], wp["z"])
        return c

    def climb_step(self, me, now, wp, heading, d):
        """A ledge or crate to jump up onto (not a window or roof hole): sprint at it facing the middle of the top,
        jump at its foot and hold forward right through the jump, and again from the top of each crate in turn
        (user). Returns the keys to hold, or None when this waypoint isn't a climb."""
        self.climb_active = False
        if (not wp.get("jump") or wp.get("leap") or wp.get("gap") or wp.get("crouch_jump") or wp.get("window")
                or wp.get("approach") or wp.get("corner") or wp["y"] - me["y"] <= self.CLIMB_MIN_RISE or d > 14.0):
            self.climb_t0 = None
            return None
        self.climb_active = True
        tx, tz = self.climb_target(wp)
        face = bearing(me, {"x": tx, "z": tz})
        self.look_toward(me, face, 0)             # eyes on the crate, even in the middle of a fight
        err = abs(to_deg(wrap(round(face - me["yaw"]))))
        sk = self.skill
        if d > sk.climb_jump_at + 2.0:
            return {"w"}                          # sprint up to it
        if self.climb_t0 is None:
            self.climb_t0 = now
        if err > sk.climb_face and me["y"] < wp["y"] - 1.0 and d > 2.0:
            return set()                          # not square on: turn first, no running about sideways
        if now - self.climb_t0 < sk.climb_pause and me["y"] < wp["y"] - 1.0:
            return set()                          # an easy bot sizes the ledge up before it jumps
        keys = {"w"}                              # forward stays down through the jump
        if d < sk.climb_jump_at:
            # jump held nearly all the time, let go briefly so each landing gets a fresh press
            if now - self.jump_at >= sk.climb_jump_on + sk.climb_jump_off:
                self.jump_at = now
            if now - self.jump_at < sk.climb_jump_on:
                keys.add("space")
        return keys

    def jump_keys(self, now):
        """The jump key in pulses, so a jump that fell short gets a fresh press."""
        if now - self.jump_at >= 2 * self.JUMP_PULSE:
            self.jump_at = now
        return {"space"} if now - self.jump_at < self.JUMP_PULSE else set()

    def stalled(self, now, me):
        """True when we've barely moved over the last ~0.4 s. Call every tick."""
        t, x, z = self.progress
        if now - t >= 0.4:
            self.is_stalled = math.hypot(me["x"] - x, me["z"] - z) < 0.8
            self.progress = (now, me["x"], me["z"])
        return self.is_stalled

    def door_pass_keys(self, me, now):
        """Keys for getting through a double door whose one half we've just opened: line up in front of the middle
        of that half, then walk straight through it, not along the seam between the halves (where the half still
        shut is in the way). Stuck in the doorway: open the other half as well. None when through (or given up)."""
        dp = self.door_pass
        cx, cz, side = dp["cx"], dp["cz"], dp["side"]
        near, far = (cx, cz - side * 4.0), (cx, cz + side * 5.0)
        if dp["phase"] == 0 and ((me["z"] - near[1]) * side >= 0 or flat_dist(me, {"x": near[0], "z": near[1]}) < 1.5):
            dp["phase"] = 1
        if dp["phase"] == 1 and (me["z"] - far[1]) * side >= -1.0:
            return None                           # through
        tx, tz = near if dp["phase"] == 0 else far
        if dp["phase"] == 1 and abs(me["z"] - cz) < 4.0 and self.stalled(now, me):
            if dp["stuck_since"] is None:
                dp["stuck_since"] = now
            if now - dp["stuck_since"] > 0.8 and dp["sib_tries"] < 2 and now >= self.next_nudge:
                sib = dp["sib"]
                target = {"x": sib["x"], "z": sib["z"]}
                self.look_toward(me, bearing(me, target), 0)
                off = abs(to_deg(wrap(round(bearing(me, target) - me["yaw"]))))
                if dp["face_since"] is None:
                    dp["face_since"] = now
                if off > 10 and now - dp["face_since"] < 1.0:
                    return set()                  # turn to face it first
                self.tap("e")
                self.next_nudge = now + DOOR_RETRY
                dp.update(sib_tries=dp["sib_tries"] + 1, stuck_since=None, face_since=None)
                self.log("still stuck on the other half of the double door: opening it too")
                return set()
        elif dp["phase"] == 1:
            dp["stuck_since"] = None
        goal = {"x": tx, "z": tz}
        heading = bearing(me, goal)
        self.look_toward(me, heading, 0)
        return {"w"} if abs(to_deg(wrap(round(heading - me["yaw"])))) < 30 else set()

    def saloon_inside(self, me, door):
        """True for a door on the north wall of Sanctuary's south-east saloon, nudged from the inside."""
        return (self.level_name == "town_2p" and 240.0 <= door["x"] <= 256.0 and abs(door["z"] - 269.0) < 4.0
                and me["z"] < door["z"])

    def handle_obstacles(self, me, now, wp, aiming):
        """Doors and windows on the route (nav marks them on waypoints). We only act when stalled in front
        of one: E toggles a door, so pressing it on an open door would close it. Returns True while we're
        waiting on one, which keeps the stuck handling from strafing away. After DOOR_TRIES presses or
        WINDOW_PATIENCE seconds of shooting we give up on it (give_up) and stop waiting."""
        stalled = self.stalled(now, me)
        door, window = wp.get("door"), wp.get("window")
        nxt = (self.route[1] if self.route and len(self.route) > 1
               and (self.route[0] is wp or wp.get("edge") is not None and self.route[0].get("edge") == wp["edge"])
               else None)                     # (waypoint() hands out a copy when steering past a portal)
        if nxt and not door and not window:      # the obstacle may sit just past the next waypoint
            door, window = nxt.get("door"), nxt.get("window")
            wp = nxt
        if door and ((door["x"] - me["x"]) * (wp["x"] - me["x"]) + (door["z"] - me["z"]) * (wp["z"] - me["z"]) < 0
                     and flat_dist(me, wp) > 1.0):
            door = None                       # already behind us
        key = wp.get("edge")
        if self.obstacle and now - self.obstacle[1] > 20.0:
            self.obstacle = None              # an old one: start counting afresh
        if door and flat_dist(me, door) < DOOR_REACH:
            if stalled and now >= self.next_nudge and flat_dist(me, door) < DOOR_PRESS:
                tries = self.obstacle[2] + 1 if self.obstacle and self.obstacle[0] == key else 1
                if tries > self.DOOR_TRIES:
                    # With no portal to route round (a door inside one sector), stop waiting on it and let
                    # the stuck handling take over.
                    if key is not None:
                        self.give_up(key, now, "the door won't open")
                    return False
                if not aiming:
                    # Face the door before pressing: the nudge acts on what's in front of us, and a bot that
                    # arrives side-on would press at the wall beside it. Wait up to 1 s for the turn.
                    aim_at = (self.level.nudge_aim(door["x"], door["z"], me["x"], me["z"], tries - 1)
                              if self.level is not None else None) or door      # a grate: aim at a bar
                    self.look_toward(me, bearing(me, aim_at), 0)
                    off = abs(to_deg(wrap(round(bearing(me, aim_at) - me["yaw"]))))
                    if self.door_face_since is None:
                        self.door_face_since = now
                    if off > 10 and now - self.door_face_since < 1.0:
                        return True
                self.door_face_since = None
                self.obstacle = (key, now, tries)
                self.tap("e")
                self.next_nudge = now + DOOR_RETRY
                self.log(f"door at ({door['x']:.0f}, {door['z']:.0f}), bot at ({me['x']:.0f}, {me['z']:.0f}), try {tries}")
                panel, sib = self.level.double_door(door["x"], door["z"]) if self.level is not None else (None, None)
                if panel is not None and sib is not None:
                    side = 1 if panel["z"] > me["z"] else -1          # which way we're going through
                    self.door_pass = dict(cx=panel["x"], cz=panel["z"], side=side, sib=sib, phase=0, sib_tries=0,
                                          stuck_since=None, face_since=None, until=now + DOOR_PASS_TIME)
                if self.saloon_inside(me, door):
                    self.backoff_until = now + SALOON_BACKOFF
                    self.backoff_look = bearing(me, dict(me, z=me["z"] + 10.0))   # face the wall: backing up goes straight into the room
                    self.log("saloon door: backing away")
                self.log("door in the way: pressing E")
            return now < self.next_nudge
        slow = math.hypot(me.get("vx") or 0.0, me.get("vz") or 0.0) < 1.5
        if (window and not aiming and not self.wet and flat_dist(me, window) < WINDOW_REACH
                and (stalled or (slow and flat_dist(me, window) < 4.0))
                and (me.get("inventory") or {}).get("slot") != TNT_SLOT):   # firing would light a stick
            if not (self.obstacle and self.obstacle[0] == key):
                self.obstacle = (key, now, 0)
            elif now - self.obstacle[1] > self.WINDOW_PATIENCE:
                if key is not None:
                    self.give_up(key, now, "the window won't break")
                return False
            elapsed = now - self.obstacle[1]
            dist = max(flat_dist(me, window), 1.0)
            want_yaw = bearing(me, window)
            want_pitch = to_units(math.degrees(math.atan2(window["y"] - (me["y"] + EYE * me["height"]), dist)))
            self.look_toward(me, want_yaw, want_pitch)
            lined_up = abs(to_deg(wrap(round(want_yaw - me["yaw"])))) < 4 and abs(to_deg(want_pitch - me["pitch"])) < 4
            inv = me.get("inventory") or {}
            owned = {w["slot"] for w in inv.get("weapons", [])}
            weapon = next((w for w in inv.get("weapons", []) if w["slot"] == inv.get("slot")), None)
            # Escalate: a gun for the first 4 s, then the knife (7 s), then fists; after WINDOW_PATIENCE go round.
            phase = "gun" if elapsed < 4.0 else "knife" if elapsed < 7.0 and KNIFE_SLOT in owned else "fists" if elapsed >= 4.0 else "gun"
            if phase != "gun" and not self.gg:
                self.set_keys({"w"} if dist > 2.5 else set())            # walk up to the glass to hit it
                want = KNIFE_SLOT if phase == "knife" else FIST_SLOT
                if (weapon is None or weapon["slot"] != want) and now >= self.next_window_shot:
                    self.tap(str(want))
                    self.next_window_shot = now + 0.8
                    return True
                if lined_up and now >= self.next_window_shot:
                    self.tap(self.fire_button(weapon))
                    self.next_window_shot = now + 0.4
                    self.log(f"window in the way: hitting it ({phase})")
                return True
            if lined_up and now >= self.next_window_shot:
                if not self.gg and (weapon is None or weapon["slot"] in (FIST_SLOT, KNIFE_SLOT)):
                    gun = self.best_weapon(inv, None) if inv.get("weapons") else None     # glass needs a gun
                    if gun is not None and gun["slot"] not in (FIST_SLOT, KNIFE_SLOT):
                        self.tap(str(gun["slot"]))
                        self.next_window_shot = now + 1.0
                        return True
                self.tap(self.fire_button(weapon))
                self.next_window_shot = now + 0.5
                self.log("window in the way: shooting it")
            return True
        return False

    def in_crouch_space(self, me):
        if self.level is None:
            return False
        sec = self.level.locate(me["x"], me["y"], me["z"])
        return sec is not None and self.level._crouch_only(sec, me["x"], me["z"])

    def avoid_badges(self, me, keys):
        """Never walk onto a badge: stop advancing toward one and strafe away from it."""
        for b in self.bot.badges:
            d = flat_dist(me, b)
            if d > BADGE_AVOID:
                continue
            rel = to_deg(wrap(round(bearing(me, b) - me["yaw"])))     # positive = badge on our right
            if abs(rel) < 100:                                       # it's ahead of us
                keys.discard("w")
                if d < BADGE_AVOID / 2:
                    keys.add("s")
            keys.discard("a")
            keys.discard("d")
            keys.add("a" if rel > 0 else "d")
        return keys

    def note_stuck(self, kind, x, y, z):
        """Pathing check (pathcheck.py): append where a bot got stuck to the file named by BOT_STUCK_LOG."""
        path = os.environ.get("BOT_STUCK_LOG")
        if not path:
            return
        try:
            with open(path, "a") as f:
                f.write(f"{os.environ.get('BOT_MAP', '?')},{os.environ.get('BOT_TAG', '?')},{time.time():.1f},"
                        f"{kind},{x:.1f},{y:.1f},{z:.1f}\n")
        except OSError:
            pass

    def check_stuck(self, now, me, moving):
        if self.stuck_check is None or not moving:
            self.stuck_check = (now, me["x"], me["z"])
            return
        t, x, z = self.stuck_check
        if now - t < 0.8:
            return
        if math.hypot(me["x"] - x, me["z"] - z) < 2.0:
            self.note_stuck("stuck", me["x"], me["y"], me["z"])
            if os.environ.get("BOT_STUCK_LOG"):      # pathing tests: say what the bot was doing, to find out why
                try:
                    wp = self.route[0] if self.route else None
                    sec = self.level.locate(me["x"], me["y"], me["z"]) if self.level is not None else None
                    self.log(f"STUCK at ({me['x']:.1f}, {me['z']:.1f}) sector {sec} yaw {me['yaw']} "
                             f"next wp {None if wp is None else (wp.get('sector'), round(wp['x'], 1), round(wp['z'], 1), wp.get('corner'), wp.get('jump'))} "
                             f"item {self.item_goal} keys {sorted(getattr(self.bot, 'held', []) or [])} "
                             f"enemy-in-view {bool(getattr(self, 'target', None))}")
                except Exception as e:
                    self.log(f"STUCK at ({me['x']:.1f}, {me['z']:.1f}) (detail failed: {e})")
            # Three stuck moments within 8 units in 20 seconds: whatever is in the way, turn round and walk off
            # the other way (a corner, a crate, the back of a cell), then plan again.
            self.stuck_log = [e for e in self.stuck_log if now - e[0] < 20.0] + [(now, me["x"], me["z"])]
            near_n = sum(1 for e in self.stuck_log if math.hypot(e[1] - me["x"], e[2] - me["z"]) < 8.0)
            if near_n <= 1:
                self.hop_until = now + 0.7        # stage 1: jump over whatever it is
            if near_n >= 3:
                self.turn_heading = wrap(round(me["yaw"] + to_units(180)))
                self.turn_until = now + 2.5
                self.stuck_log = []
                self.route = None
                self.wander_goal = None
                self.log("stuck here again and again: turning round")
            # The same portal again: after GIVE_UP_STUCKS in a row, route round it for a while.
            key = self.next_edge()
            if key is not None:
                self.last_key, self.last_key_t = key, now
            elif now - self.last_key_t < 6.0:
                key = self.last_key          # the route is cleared while we unstick: still the same portal
            if self.camp_spot is not None and not self.camp_set:
                self.camp_stucks += 1
            if key is not None and key == self.stuck_key and now - self.stuck_at < self.STUCK_MEMORY:
                self.stuck_count += 1
            else:
                self.stuck_key, self.stuck_count = key, 1
            self.stuck_at = now
            if self.stuck_count >= 2 and self.item_goal is not None and now >= self.escape_until:
                # 2nd stuck in a row on the way to an item: leave that item alone for a while.
                self.ignored_items[self.item_goal] = now + self.ITEM_DROP_FOR
                self.log("stuck twice on the way to an item: leaving it for "
                         f"{self.ITEM_DROP_FOR:.0f}s")
                self.item_goal = None
            if self.stuck_count >= 3 and now >= self.escape_until:
                self.start_escape(me, now, "stuck three times in a row")
            if key is not None and self.stuck_count >= self.GIVE_UP_STUCKS:
                self.give_up(key, now, "stuck")
            self.strafe_key = self.rng.choice("ad")
            if near_n >= 2:                       # stage 2: crouch-jump with a sidestep (stage 3 turns round, above)
                self.unstick_crouch_until = now + self.UNSTICK_CROUCH
                self.unstick_until = self.unstick_crouch_until + 0.6
                self.crouch_until = self.unstick_until + 1.0
            self.route = None                 # replan from wherever we end up
            self.wander_goal = None
        self.stuck_check = (now, me["x"], me["z"])

    CAMP_MIN_VIEW = 8.0            # a camp spot must see at least this many of the sampled points, or it isn't worth rooting for
    CAMP_OFF_FOR = 60.0            # seconds to carry the Gatling without camping when there's no such spot
    QUIET_MEMORY = 120.0           # seconds a quiet camp spot (and its surroundings) is not picked again
    CAMP_RADIUS = 100.0            # a camp spot must be this close: long walks across the map get the bot killed
    CAMP_TRAVEL = 25.0             # seconds to get to the camp spot before camping wherever we got to

    def gatling_camp(self, me, now, enemies):
        """A usable Gatling and nobody in sight: slip away to a corner far from everybody, stand there with the gun
        out and keep it until we die or it runs dry (user). Returns True while it has the tick."""
        inv = me.get("inventory")
        g = next((w for w in inv["weapons"] if w["slot"] == GATLING_SLOT), None) if inv else None
        if PATHCHECK_NO_GATLING or self.gg:       # pathing tests, and the gun game: the Gatling rule is for real games only
            return False
        if now < self.camp_off_until and not self.camp_set:
            return False                          # nowhere good to set up just now: the gun is for fights
        if not g or not self.usable(g) or self.wet or inv.get("hasBadge") or me.get("carries"):
            if self.camp_spot is not None or self.camp_set:
                self.log("Gatling camp over" + (" (out of ammo)" if g is not None and not self.usable(g) else ""))
            self.camp_set, self.camp_spot, self.camp_since, self.camp_fails = False, None, None, 0
            return False
        if self.camp_spot is None and not self.camp_set:
            self.camp_since = now
            self.camp_stucks = 0
            self.camp_spot = self.pick_camp(me, enemies)
            if self.camp_spot is not None and self.camp_best_seen < self.CAMP_MIN_VIEW:
                self.camp_spot = None
            if self.camp_spot is None:
                self.camp_off_until = now + self.CAMP_OFF_FOR
                self.camp_since = None
                self.log("Gatling: no spot nearby with a good view, keeping it for fights")
                return False
            else:
                self.log(f"Gatling: heading for a spot with a wide view ({flat_dist(me, self.camp_spot):.0f} away)")
        if not self.camp_set:
            spot = self.camp_spot
            if self.camp_stucks >= 6:
                self.camp_bad = (self.camp_bad + [(spot["x"], spot["z"])])[-6:]
                self.camp_stucks = 0
                self.camp_fails += 1
                self.camp_spot = self.pick_camp(me, enemies) if self.camp_fails < 3 else None
                self.camp_since = now
                if self.camp_spot is None:
                    self.camp_set = True
                    self.log("Gatling: can't get to the corner, setting up here")
                else:
                    self.log("Gatling: can't get to that spot, trying another")
                return True
            if flat_dist(me, spot) < 5.0 or now - self.camp_since > self.CAMP_TRAVEL:
                self.camp_set = True
                self.log("Gatling: setting up")
            elif not self.go(me, now, spot):
                self.camp_fails += 1
                if self.camp_fails >= 3:
                    self.camp_set = True
                    self.log("Gatling: can't get to the corner, setting up here")
                else:
                    self.camp_spot = self.pick_camp(me, enemies)
                    if self.camp_spot is None:
                        self.camp_set = True
                return True
            else:
                return True
        # In place: the Gatling out, standing still. Nobody coming for 20 s: move to another spot.
        if self.camp_wait_since is None:
            self.camp_wait_since = now
        elif now - self.camp_wait_since > 20.0:
            self.camp_wait_since = None
            self.camp_set, self.camp_since, self.camp_fails = False, None, 0
            self.camp_avoid = (me["x"], me["z"])
            self.camp_quiet = [q for q in self.camp_quiet if now - q[2] < self.QUIET_MEMORY] + [(me["x"], me["z"], now)]
            self.camp_spot = self.pick_camp(me, enemies)
            self.camp_avoid = None
            self.camp_stucks = 0
            if self.camp_spot is not None and self.camp_best_seen < self.CAMP_MIN_VIEW:
                self.camp_spot = None
            if self.camp_spot is None:
                self.camp_set, self.camp_since = False, None
                self.camp_off_until = now + self.CAMP_OFF_FOR
                self.log("Gatling: quiet here and no better spot nearby, keeping it for fights")
                return False
            self.log("Gatling: quiet here, moving to a more active spot")
            self.camp_since = now
            return True
        self.set_keys(set())
        if inv["slot"] != GATLING_SLOT and now >= self.next_switch:
            self.release_fire()
            self.tap(str(GATLING_SLOT))
            self.next_switch = now + 1.5
        return True

    def pick_camp(self, me, enemies):
        """Where to set up with the Gatling: a spot that looks over a lot of the map, with weight on the busy parts
        (items on the ground, where enemies are), not in a closet and not out in the open middle either (many
        ways in count against it), and not a long walk. None if there's no map."""
        if self.level is None:
            return None
        spots = self.level.spots(self.nav_point(me))
        if not spots:
            return None
        # What it should be able to see: every reachable sector centre, double where something is going on.
        busy = [(i["x"], i["z"]) for i in self.bot.items] + [(e["x"], e["z"]) for e in enemies]
        if self.last_seen is not None:
            busy += [(self.last_seen["x"], self.last_seen["z"])] * 3     # where the last fight was: the action
        quiet = [(q[0], q[1]) for q in self.camp_quiet if time.time() - q[2] < self.QUIET_MEMORY]
        step = max(1, len(spots) // 70)
        sample = spots[::step]
        cands = [sp for sp in spots if flat_dist(me, sp) <= self.CAMP_RADIUS
                 and (self.camp_avoid is None or math.hypot(sp["x"] - self.camp_avoid[0], sp["z"] - self.camp_avoid[1]) > 30.0)
                 and min((flat_dist(sp, e) for e in enemies), default=999.0) > 35.0
                 and all(math.hypot(sp["x"] - bx, sp["z"] - bz) > 25.0 for bx, bz in self.camp_bad)
                 and all(math.hypot(sp["x"] - qx, sp["z"] - qz) > 40.0 for qx, qz in quiet)]
        cands.sort(key=lambda sp: flat_dist(me, sp))
        cands = cands[::max(1, len(cands) // 45)]       # at most ~45 candidates: the line checks cost time
        best, best_score, best_seen = None, -1e9, 0
        for sp in cands:
            seen = 0.0
            for t in sample:
                if t is sp or not self.level.sees(sp, t):
                    continue
                d = flat_dist(sp, t)
                if d < 12.0:
                    continue                            # right next to us: not a view
                near_busy = any(math.hypot(t["x"] - bx, t["z"] - bz) < 30.0 for bx, bz in busy)
                seen += 2.0 if near_busy else 1.0
            score = seen - 2.0 * max(0, sp["exits"] - 4) - 0.05 * flat_dist(me, sp)
            if self.level.high_min is not None and sp["y"] >= self.level.high_min:
                score += 25.0                           # high ground (Thud Tower's walkways): the view is better
            if score > best_score:
                best, best_score, best_seen = sp, score, seen
        if best is not None:
            self.camp_best_seen = best_seen
            self.log(f"Gatling: spot sees {best_seen:.0f} points of {len(sample)} sampled")
        return best

    def wander(self, me, now):
        if self.wander_goal is None or now > self.wander_until or flat_dist(me, self.wander_goal) < 4:
            spot = self.level.random_spot(self.rng, self.nav_point(me)) if self.level else None
            if spot is None:                  # no map (or a miss): pick a point ahead of us
                heading = math.radians(to_deg(me["yaw"]) + self.rng.uniform(-90, 90))
                spot = {"x": me["x"] + 40 * math.sin(heading), "y": me["y"], "z": me["z"] + 40 * math.cos(heading)}
            self.wander_goal, self.wander_until = spot, now + 15.0
        if not self.go(me, now, self.wander_goal):
            self.wander_goal = None

    # -- items ----------------------------------------------------------------------------------------
    def refresh_costs(self, me, now):
        """Route lengths to every item on the ground, at most every ITEM_COSTS_EVERY seconds."""
        if now - self.item_costs_at > self.ITEM_COSTS_EVERY:
            items = self.bot.items
            costs = (self.item_routes(me, items, now) if self.level is not None
                     else [flat_dist(me, it) for it in items])
            self.item_costs = {it["addr"]: c for it, c in zip(items, costs)}
            self.item_costs_at = now

    def seek_item(self, me, now, aiming=False, knife_only=False, armor_only=False, health_only=False,
                  badge_only=False):
        """Walk to the most worthwhile reachable item, or with `knife_only` the nearest reachable knife however
        far, or with `armor_only` a boiler plate within Skill.armor_detour. Returns False when there's nothing
        worth getting."""
        inv = me.get("inventory")
        if not inv:
            return False
        if now < self.escape_until:           # walking off from a stuck spot: no item trips for a moment
            return False
        self.refresh_costs(me, now)
        mode = ("knife" if knife_only else "health" if health_only else "armor" if armor_only
                else "badge" if badge_only else "any")
        if badge_only:
            it = self.nearest_badge(me, now)
        elif knife_only:
            it = self.nearest_knife(me, now)
        elif health_only:
            it = self.health_nearby(me, inv, now)
        elif armor_only:
            it = self.armor_nearby(me, inv, now)
        else:
            it = itemlib.pick(self.bot.items, me, inv, self.bot.badges, self.ignored_items, now,
                              cost=self.item_costs.get if self.level else None, knife=self.knife_value(),
                              favorite=self.skill.favorite, melee_only=self.skill.melee_only,
                              sawed=not self.bot.marshall_law,
                              weapon_limit=self.PISTOL_WEAPON_TRIP if self.pistol_only(inv) else None,
                              supply_limit=self.SUPPLY_TRIP)
        if mode == "any" and it is not None and self.item_goal is not None and it["addr"] != self.item_goal:
            # Handover step 5: keep a choice for CHOICE_HOLD seconds rather than flipping between two items.
            cur = next((i for i in self.bot.items if i["addr"] == self.item_goal), None)
            if (cur is not None and now - self.item_chosen_at < self.CHOICE_HOLD and self.item_mode == "any"
                    and self.ignored_items.get(cur["addr"], 0) <= now):
                d = self.item_costs.get(cur["addr"]) if self.level is not None else flat_dist(me, cur)
                v = itemlib.value(cur, inv, me.get("health"), self.knife_value(), self.skill.favorite,
                                  self.skill.melee_only, not self.bot.marshall_law)
                if d is not None and v >= self.skill.min_item_value:
                    it = dict(cur, value=v, dist=d)
        if it is None or not (knife_only or health_only or badge_only) and it["value"] < self.skill.min_item_value:
            if self.item_mode == mode:        # (another search finding nothing mustn't reset this one's patience)
                self.item_goal = None
            return False
        if it["addr"] == self.item_goal and now - self.item_called > 1.5:
            self.item_since, self.item_best = now, it["dist"]     # a fight or other job came between: start the clock over
        self.item_called = now
        if it["addr"] != self.item_goal:
            self.item_goal, self.item_since, self.item_best = it["addr"], now, it["dist"]
            self.item_mode = mode
            self.item_chosen_at = now
            self.dive_best = 1e9
            self.log(f"going for {it['name']} (worth {it['value']:.0f}) {it['dist']:.0f} away")
        if self.pool is not None and it["addr"] in self.pool_items and self.pool_state(me) in ("out", "dock"):
            if self.pool_mode != "enter" or self.pool_addr != it["addr"]:
                self.pool_mode, self.pool_addr, self.pool_since = "enter", it["addr"], now
                self.log(f"going into the pool under the building for {it['name']}")
            self.item_since = now                 # the trip is under way: not stuck
            if self.pool_enter(me, now, self.pool_state(me)):
                return True
            self.pool_mode = None
            self.ignore_item(it["addr"], now)
            self.item_goal = None
            return False
        dive_dy = abs(me["y"] - it["y"]) if self.wet else None
        if it["dist"] < self.item_best - 1.0:
            self.item_best, self.item_since = it["dist"], now
        elif dive_dy is not None and dive_dy < self.dive_best - 0.5:
            self.dive_best, self.item_since = dive_dy, now      # swimming down a well counts as progress
        elif now - self.item_since > self.skill.item_patience * (2.5 if mode == "badge" else 1.0):
            # Not getting closer (blocked), or standing on it without it being taken (we're full).
            if mode == "badge":
                self.ignored_items[it["addr"]] = now + 10.0      # the badge is worth another try soon
            else:
                self.ignore_item(it["addr"], now)
            self.log(f"giving up on {it['name']}")
            self.item_goal = None
            return False
        under = self.level.air_point(it["x"], it["y"] + 0.5, it["z"]) if self.level is not None else None
        if under is not None and now < self.no_water_until:
            self.ignored_items[it["addr"]] = now + WATER_AWAY      # no more time in the water for now
            self.item_goal = None
            return False
        if under is not None and self.wet:
            self.dive_seen = now
            self.dive(me, now, it, aiming)    # in the water with it: swim straight there
            return True
        if under is None and not aiming and flat_dist(me, it) < 2.0:
            self.set_keys({"w"} | ({"lctrl"} if self.in_crouch_space(me) else set()))
            return True                       # right on top of it: the bearing swings wildly, just step
        # An item in the water is first walked to as the surface above it; once in, we dive.
        goal = it if under is None else {"x": under[0], "y": under[2], "z": under[1]}
        self.allow_water_now = under is not None        # swimming is fine when the item is in the water
        try:
            ok = self.go(me, now, goal, aiming=aiming)
        finally:
            self.allow_water_now = False
        if not ok:
            if mode == "badge":
                self.ignored_items[it["addr"]] = now + 10.0
            else:
                self.ignore_item(it["addr"], now)
            self.item_goal = None
            return False
        return True

    CHOICE_HOLD = 6.0              # seconds an item choice is kept (handover step 5)
    item_chosen_at = 0.0
    SUPPLY_TRIP = 167.0            # armor plates and medbags farther than this by route aren't worth the walk
    PISTOL_WEAPON_TRIP = 167.0     # a bot with only its pistol doesn't walk farther than this for a weapon

    def pistol_only(self, inv):
        """No good weapon with rounds (items.GOOD_SLOTS): the pistol, knife and fists are all it has."""
        return not any(w["slot"] in itemlib.GOOD_SLOTS and self.usable(w) for w in inv["weapons"])

    def want_badge(self, me):
        """Marshall Law off: the badge (big damage boost, less damage taken) is worth going out of the way for.
        Not while we hold it, carry a flag, or are in the water on Orleans."""
        inv = me.get("inventory")
        return (not self.bot.marshall_law and bool(inv) and not inv.get("hasBadge") and not me.get("carries")
                and any("BADGE" in (i.get("name") or "") for i in self.bot.items))

    def nearest_badge(self, me, now):
        """The badge item with the shortest route from here, however far, or None when none can be reached."""
        best = None
        for it in self.bot.items:
            if "BADGE" not in (it.get("name") or "") or self.ignored_items.get(it["addr"], 0) > now:
                continue
            d = self.item_costs.get(it["addr"]) if self.level is not None else flat_dist(me, it)
            if d is None:
                continue
            if best is None or d < best["dist"]:
                best = dict(it, value=itemlib.value(it, me.get("inventory"), me.get("health"), sawed=not self.bot.marshall_law), dist=d)
        return best

    def ignore_item(self, addr, now, base=20.0):
        """Leave an item alone for a while; every repeat doubles the wait (up to 8x), so an item we keep failing
        to reach stops eating the game."""
        n = self.ignore_count.get(addr, 0)
        self.ignore_count[addr] = n + 1
        self.ignored_items[addr] = now + base * min(2 ** n, 8)

    def want_knife(self, me):
        """On Orleans a bot without a knife makes getting one its first job (user): before other items, the CTF
        objective and hunting, and while fighting it heads for one instead of closing in. A brawler
        (Skill.knife_first) does it on every map. Not while holding the badge (fists only) or carrying a flag
        home."""
        inv = me.get("inventory")
        return ((self.level_name == "orleans" or self.skill.knife_first) and bool(inv) and not inv.get("hasBadge")
                and not me.get("carries")
                and not any(w["slot"] == KNIFE_SLOT for w in inv["weapons"]))

    def nearest_knife(self, me, now, badge_margin=8.0):
        """The knife on the ground with the shortest way there (Brain.item_costs), or None."""
        best = None
        for it in self.bot.items:
            if it.get("name") != itemlib.KNIFE or self.ignored_items.get(it["addr"], 0) > now:
                continue
            d = self.item_costs.get(it["addr"]) if self.level is not None else flat_dist(me, it)
            if d is None:
                continue
            if any(math.hypot(it["x"] - b["x"], it["z"] - b["z"]) < badge_margin for b in self.bot.badges):
                continue
            if best is None or d < best["dist"]:
                best = dict(it, value=self.knife_value(), dist=d)
        return best

    def health_nearby(self, me, inv, now):
        """The nearest recovery item we'd still take (canteen, elixir, medbag, or a boiler plate) within FLEE_ITEM_MAX
        by route, or None."""
        best, best_d = None, FLEE_ITEM_MAX
        for it in self.bot.items:
            name = it.get("name")
            if name not in itemlib.HEALTH and name != itemlib.MEDBAG and name not in itemlib.ARMOR:
                continue
            if self.ignored_items.get(it["addr"], 0) > now:
                continue
            d = self.item_costs.get(it["addr"]) if self.level is not None else flat_dist(me, it)
            if d is None or d > best_d:
                continue
            if self.flee_threat is not None and flat_dist(it, self.flee_threat) < flat_dist(it, me):
                continue                      # nearer the enemy than to us: not a way out
            v = itemlib.armor_value(name, inv) if name in itemlib.ARMOR else itemlib.value(it, inv, me.get("health"), sawed=not self.bot.marshall_law)
            if v > 0:
                best, best_d = dict(it, value=max(v, self.skill.min_item_value + 1.0), dist=d), d
        return best

    def armor_nearby(self, me, inv, now, badge_margin=8.0):
        """The best boiler plate we'd still take (items.armor_value) within its detour (Skill.armor_detour scaled
        by what it gives), or None."""
        best, best_score = None, 0.0
        for it in self.bot.items:
            name = it.get("name")
            if name not in itemlib.ARMOR or self.ignored_items.get(it["addr"], 0) > now:
                continue
            d = self.item_costs.get(it["addr"]) if self.level is not None else flat_dist(me, it)
            if d is None or d > self.skill.armor_detour * itemlib.ARMOR[name] / 100.0:
                continue
            if any(math.hypot(it["x"] - b["x"], it["z"] - b["z"]) < badge_margin for b in self.bot.badges):
                continue
            v = itemlib.armor_value(name, inv)
            if v > 0 and v / (d + 15.0) > best_score:
                best, best_score = dict(it, value=v, dist=d), v / (d + 15.0)
        return best

    def item_routes(self, me, items, now):
        """Route length to each item (None = unreachable). Items in the water (Orleans' knives lie on the river
        bed) count from in the water as the straight swim there, from dry land as the route to the surface above
        them plus the dive."""
        goals, wet = [], {}
        for k, it in enumerate(items):
            air = self.level.air_point(it["x"], it["y"] + 0.5, it["z"]) if self.level.water else None
            if air is None:
                goals.append(it)
            else:
                wet[k] = air
                goals.append({"x": air[0], "y": air[2] + 0.1, "z": air[1]})
        # Dry items never route through open water; items in the water are reached by swimming to them.
        dry_ix = [k for k in range(len(goals)) if k not in wet]
        costs = [None] * len(goals)
        if dry_ix:
            for k, c in zip(dry_ix, self.level.route_lengths(self.nav_point(me), [goals[k] for k in dry_ix],
                                                             self.avoiding(now), water=self.wet)):
                costs[k] = c
        if wet:
            for k, c in zip(wet, self.level.route_lengths(self.nav_point(me), [goals[k] for k in wet],
                                                          self.avoiding(now), water=True)):
                costs[k] = c
        self.pool_items = set()
        if self.pool is not None and self.pool_state(me) in ("out", "dock"):
            # Orleans' west building: the stairs and roof are only reachable from the pool inside it, which we dive
            # into from the river. The cost is the way to the dive, a flat allowance for it, and the way on from the pool.
            zone = self.pool["zone"]
            lost = [k for k in range(len(items)) if costs[k] is None and not wet.get(k)
                    and self.level.locate(items[k]["x"], items[k]["y"] + 0.5, items[k]["z"]) in zone]
            if lost:
                mx, mz = self.pool["mouth"]
                ex, ez = self.pool["exit"]
                to_mouth = self.level.route_lengths(self.nav_point(me), [{"x": mx, "y": -5.0, "z": mz}],
                                                    self.avoiding(now), water=True)[0]
                inside = self.level.route_lengths({"x": ex, "y": 2.5, "z": ez}, [items[k] for k in lost], (), water=False)
                for k, c in zip(lost, inside):
                    if to_mouth is not None and c is not None:
                        costs[k] = to_mouth + POOL_COST + c
                        self.pool_items.add(items[k]["addr"])
        for k in wet:
            # Orleans: the river bed is no place to hang about. Knives, ammo and the like down there aren't worth the
            # swim (bots drowned or got stuck in fist fights); only health and armor are fetched from the water.
            if self.level_name == "orleans" and not any(t in str(items[k].get("name", "")) for t in WET_WORTH):
                costs[k] = None
        for k, (ax, az, top, _) in wet.items():
            it = items[k]
            if costs[k] is None:
                continue
            if self.wet:
                costs[k] = math.dist((me["x"], me["y"], me["z"]), (it["x"], it["y"], it["z"]))
            elif costs[k] is not None:
                costs[k] += top - it["y"] + math.hypot(ax - it["x"], az - it["z"])
        return costs

    def knife_value(self):
        """What a knife is worth while we have none (items.value: nothing once we have one): only on Orleans or to
        a brawler, and most while we're in the water."""
        if self.level_name != "orleans" and not self.skill.knife_first:
            return 0.0
        return self.skill.knife_value_wet if self.wet else self.skill.knife_value

    # -- water ----------------------------------------------------------------------------------------
    HIGH_MARKS = (8.0, 16.0, 24.0, 32.0)

    def note_height(self, me, now):
        """Log how high we get (the cliff ledges and roofs): HIGH lines in the log, once per level of height per life."""
        y = me["y"]
        reached = sum(1 for m in self.HIGH_MARKS if y >= m)
        if reached > self.high_reached:
            self.high_reached = reached
            self.log(f"HIGH: up at height {y:.1f} (x {me['x']:.0f}, z {me['z']:.0f})")
        elif reached == 0 and self.high_reached:
            self.log("HIGH: back down on the ground")
            self.high_reached = 0

    def note_water(self, me, now):
        """Track whether we're in the water (feet below the surface, or on top of it) and how long our head has
        been under, from the map's water sectors. Past Skill.air_time under, `surfacing` is set until we've had our head out
        for Skill.breathe seconds. A short trip up doesn't reset the clock: we don't know how fast air comes
        back."""
        lvl = self.level
        if lvl is None or not lvl.water:
            self.wet, self.under_since, self.above_since, self.surfacing = False, None, None, False
            return
        x, z = me["x"], me["z"]
        wet = lvl.in_water(x, me["y"], z)
        if wet != self.wet:
            self.log("in the water" if wet else "out of the water")
            self.wet = wet
            if not wet:
                self.left_water_at = now
                if self.left_well:            # out of the well: not straight back in
                    self.left_well = False
                    self.no_water_until = now + WATER_AWAY
        if not wet or now < self.flee_until or now - self.dive_seen < 1.0:
            self.wet_since = now if wet else None       # fleeing or diving for an item: not lingering
        elif self.wet_since is None:
            self.wet_since = now
        elif (now - self.wet_since > (ORLEANS_LINGER if self.level_name == "orleans" else WATER_LINGER)
              and now >= self.no_water_until):
            self.no_water_until = now + WATER_AWAY
            self.log(f"in the water for {now - self.wet_since:.0f}s: heading for land")
        eye = me["y"] + EYE * me["height"]
        # A well (deep water): dive to the bottom for what's there without coming up for air; with nothing
        # (left) to get, look round the bottom for WELL_LOOK seconds, then swim up and out.
        deep, wi = False, lvl.water_at(x, me["y"] + 0.3, z)
        if wet and wi is not None:
            air = lvl.air_point(x, me["y"] + 0.3, z)
            deep = bool(air and air[3] and air[2] - me["y"] > WELL_DEPTH)
        if not deep:
            self.bottom_since, self.well_exit = None, False
        elif (me["y"] < lvl.sectors[wi].floor + 3.0 and now - self.dive_seen > 0.5 and not self.well_exit
              and not self.surfacing):
            if self.bottom_since is None:
                self.bottom_since = now
                self.log(f"at the bottom of the well with nothing to get: looking round for {WELL_LOOK:.0f}s")
            elif now - self.bottom_since >= WELL_LOOK:
                self.bottom_since, self.well_exit, self.surfacing = None, True, True
                self.left_well = True
                self.surface_wait = (now, eye)
                self.log("swimming up out of the well")
        else:
            self.bottom_since = None
        if lvl.water_at(x, eye, z) is not None:
            self.above_since = None
            if self.under_since is None:
                self.under_since = now
            under_for = now - self.under_since
            if not self.surfacing and under_for > (WELL_AIR if deep else self.skill.air_time):
                self.surfacing, self.surface_wait = True, (now, eye)
                self.log(f"under water for {under_for:.0f}s: swimming up for air")
            elif self.surfacing:
                # Not getting any higher with the surface right above: our eye may stay just under it while we
                # float there. Count that as air rather than hang at the top for good.
                since, best = self.surface_wait
                if eye > best + 0.3:
                    self.surface_wait = (now, eye)
                else:
                    air = lvl.air_point(x, me["y"] + 0.3, z)
                    if air and air[3] and now - since > 3.0 and eye > air[2] - 1.5:
                        self.log(f"at the surface but the eye stays under ({eye:.1f} < {air[2]:.1f}): "
                                 "counting it as air")
                        self.under_since, self.surfacing = None, False
        elif self.under_since is not None:
            if self.above_since is None:
                self.above_since = now
            if now - self.above_since >= self.skill.breathe:
                self.log(f"breathed after {self.above_since - self.under_since:.0f}s under water")
                self.under_since, self.above_since, self.surfacing = None, None, False

    def update_flee(self, health, now, target, me=None):
        """Open water is for fetching items and for escaping: at or below FLEE_HEALTH with an enemy on us the bot
        runs for the water and stays under FLEE_STAY seconds. Routes only enter open water while that lasts."""
        lvl = self.level
        if lvl is None or me is None:
            self.water_ok = False
            return
        if (not self.skill.berserk and health is not None and 0 < health <= FLEE_HEALTH and target is not None and now >= self.flee_until
                and now >= self.flee_block_until and self.flee_plan(me, now, target) is not None):
            if self.flee_began is None or now - self.flee_last > 5.0:
                self.flee_began = now                     # a new flee, not the old one re-arming
            if now - self.flee_began > FLEE_CAP:
                self.flee_block_until, self.flee_began = now + FLEE_COOLDOWN, None
                self.log(f"health {health:.1f}: fleeing is not working, fighting on")
            else:
                self.flee_until, self.flee_goal = now + FLEE_STAY, None
                self.flee_last = self.flee_until
                self.log(f"health {health:.1f}: ducking behind cover, then running for health or armor")
        if now < self.flee_until and health is not None and health >= FLEE_HEALTH:
            self.flee_until, self.flee_began = 0.0, None
            self.log(f"health back to {health:.1f}: done fleeing")
        self.water_ok = now < self.flee_until

    def find_cover(self, me, threat, now):
        """A spot within COVER_REACH by route that the enemy can't see (a wall or building between), not nearer to
        them than we are, or None when we're out in the open. Looked up at most twice a second."""
        lvl = self.level
        if lvl is None or threat is None:
            return None
        cache = getattr(self, "cover_cache", None)
        if cache and now - cache[0] < 0.5 and cache[1] == threat["addr"]:
            return cache[2]
        found, here = None, flat_dist(me, threat)
        pts = []
        for r in (5.0, 8.0, 12.0, 16.0, 20.0, 25.0):      # handover step 8: cover 5 to 25 away
            for k in range(16):
                a = k * math.pi / 8
                x, z = me["x"] + r * math.cos(a), me["z"] + r * math.sin(a)
                if math.hypot(x - threat["x"], z - threat["z"]) < here - 1.0:
                    continue
                sec = lvl.locate(x, me["y"] + 0.5, z)
                if sec is None or lvl._march(sec, (x, z), (threat["x"], threat["z"])) is not None:
                    continue                  # no floor there, or still in their sight
                pts.append({"x": x, "y": me["y"], "z": z})
        if pts:
            costs = lvl.route_lengths(self.nav_point(me), pts, self.avoiding(now), water=False)
            ok = [(c, p) for c, p in zip(costs, pts) if c is not None and c <= COVER_REACH]
            found = min(ok, key=lambda cp: cp[0])[1] if ok else None
        self.cover_cache = (now, threat["addr"], found)
        return found

    def flee_plan(self, me, now, target):
        """(recovery item, cover) when a health or armor item and cover from the enemy are both close; else None
        and the bot stays in the fight."""
        inv = me.get("inventory")
        if not inv:
            return None
        self.refresh_costs(me, now)
        self.flee_threat = target
        try:
            item = self.health_nearby(me, inv, now)
        finally:
            self.flee_threat = None
        cover = self.find_cover(me, target, now) if item else None
        return (item, cover) if item and cover else None

    def flee_to_water(self, me, now, aiming=True):
        """Head for the nearest open water (within FLEE_MAX), turned toward the enemy. False if there is none."""
        lvl = self.level
        if self.flee_goal is None or now - self.flee_goal_at > 3.0:
            pts = []
            for i in lvl.water_surfaces:
                s = lvl.sectors[i]
                vs = [s.vertices[w.v1] for w in s.walls]
                if vs:
                    pt = {"x": sum(v[0] for v in vs) / len(vs), "y": s.floor + 0.1,
                          "z": sum(v[1] for v in vs) / len(vs)}
                    wi = lvl.water_at(pt["x"], s.floor - 0.3, pt["z"])
                    if wi is not None and s.floor - lvl.sectors[wi].floor > WELL_DEPTH:
                        continue              # a well is a dead end, not an escape
                    if self.flee_threat is not None and flat_dist(pt, self.flee_threat) < flat_dist(pt, me):
                        continue              # nearer the enemy than to us
                    pts.append(pt)
            costs = lvl.route_lengths(self.nav_point(me), pts, self.avoiding(now), water=True) if pts else []
            near = [(c, p) for c, p in zip(costs, pts) if c is not None and c <= FLEE_MAX]
            self.flee_goal = min(near, key=lambda cp: cp[0])[1] if near else False
            self.flee_goal_at = now
        if not self.flee_goal:
            return False
        return self.go(me, now, self.flee_goal, aiming=aiming)

    def retreat(self, me, now, target):
        """Nearly dead with the enemy in sight: keep aiming and firing (the caller already did) and back off, by
        the key that takes us along the route given the view, toward the nearest health item or open water. False
        when there's nowhere to go: the bot fights on."""
        cover = self.find_cover(me, target, now)
        if cover is not None:
            return bool(self.go(me, now, cover, aiming=True, keep=1.0))      # duck behind it, still shooting
        self.flee_threat = target
        try:
            return bool(self.seek_item(me, now, aiming=True, health_only=True))
        finally:
            self.flee_threat = None

    def swim(self, me, now, target):
        """In the water or on top of it. Returns True when it handled the tick: swimming up for air (fighting on
        the way if we can), or a melee fight (knife, or fists without one) with an enemy who is in the water too or
        within reach. Otherwise the land logic runs, with go() keeping us at the surface and routing out, and
        without a target: no guns in the water."""
        inv = me.get("inventory")
        armed = bool(inv) and inv["slot"] == self.melee_slot(inv)
        self.shore_target = None
        if now < self.no_water_until or (self.level_name == "orleans" and now - self.dive_seen > 1.0
                                         and now >= self.flee_until):
            target = None                     # lingered too long (Orleans: always): no water fights, just get out
        if now < self.flee_until and not self.surfacing:
            self.release_fire()
            if self.seek_item(me, now, health_only=True):
                return True                   # a health item within reach (in or out of the water): go and get it
            self.set_keys({"lctrl"})          # fled into the water nearly dead: stay down, out of the line of fire
            return True
        if target is not None:
            weapon = next((w for w in inv["weapons"] if w["slot"] == inv["slot"]), None) if armed else None
            reach = math.dist((me["x"], me["y"], me["z"]), (target["x"], target["y"], target["z"]))
            if not armed or not (self.level.in_water(target["x"], target["y"], target["z"])
                                 or reach < self.fire_range(weapon)):
                if armed and inv["slot"] == KNIFE_SLOT and flat_dist(me, target) < self.skill.shore_chase:
                    # On land but close: climb out at them with the knife up (the land fight logic does it, and
                    # manage_weapon keeps the knife once we're out, see Skill.knife_keep).
                    self.shore_target = target
                target = None                 # melee only, at someone in the water or in reach
        if self.bottom_since is not None and not self.surfacing and target is None:
            # Looking round the bottom of the well: slow turn, walking and strafing, kept down with crouch.
            self.look_toward(me, me["yaw"] + to_units(70), 0)
            self.set_keys({"w", "lctrl"} | ({"a"} if int(now / 0.5) % 2 == 0 else {"d"}))
            return True
        if not self.surfacing and target is None:
            return False
        keys = set()
        dist = flat_dist(me, target) if target else None
        weapon, may_fire = self.manage_weapon(me, now, dist, engaged=target is not None)
        if target is not None:
            if self.visible_since is None:
                self.visible_since = now
            self.last_visible = now
            self.last_seen = {"x": target["x"], "y": target["y"], "z": target["z"]}
            yaw_err, pitch_err = self.aim(me, target, dist)
            reach = math.dist((me["x"], me["y"] + me["height"] / 2, me["z"]),
                              (target["x"], target["y"] + target["height"] / 2, target["z"]))
            want = (may_fire and now - self.visible_since > self.skill.reaction
                    and reach < self.fire_range(weapon) * 0.8 and abs(yaw_err) < 25 and abs(pitch_err) < 30)
            self.trigger(weapon, want, now, inv)
        else:
            self.release_fire()
        roofed = self.roof_over(me) is not None
        if self.surfacing:
            air = self.level.air_point(me["x"], me["y"] + 0.3, me["z"])
            if air is not None and math.hypot(air[0] - me["x"], air[1] - me["z"]) > 1.0:
                # Under a roof: out to open water first, round the pilings.
                wp = (self.water_waypoint(me, {"x": air[0], "z": air[1]}, now) if roofed
                      else {"x": air[0], "z": air[1]})
                heading = bearing(me, wp)
                if target is not None:
                    keys |= keys_toward(me["yaw"], heading)
                else:
                    self.look_toward(me, heading, 0)
                    if abs(to_deg(wrap(round(heading - me["yaw"])))) < 60:
                        keys.add("w")
            if not roofed:
                keys.add("space")
        else:
            # Close in, rising to the target when it's above us (we sink on our own).
            if dist > 2.0:
                keys |= keys_toward(me["yaw"], bearing(me, target))
            if target["y"] + target["height"] / 2 > me["y"] + me["height"] / 2 + 1.0:
                keys.add("space")
        if roofed:
            keys = self.roof_keys(me, now, keys)
        self.set_keys(keys)
        return True

    def dive(self, me, now, goal, aiming):
        """Swim straight to a point in the water (an item on the river bed): face it, pitch and all, and go.
        Jump rises when it's above us; otherwise we sink onto it."""
        heading = bearing(me, goal)
        d = flat_dist(me, goal)
        keys = set()
        if aiming:
            if d > 1.0:
                keys |= keys_toward(me["yaw"], heading)
        else:
            eye = me["y"] + EYE * me["height"]
            self.look_toward(me, heading, to_units(math.degrees(math.atan2(goal["y"] + 0.5 - eye, max(d, 1.0)))))
            if d > 1.0 and abs(to_deg(wrap(round(heading - me["yaw"])))) < 60:
                keys.add("w")
        if goal["y"] > me["y"] + 0.5:
            keys.add("space")                 # swim up
        elif goal["y"] < me["y"] - 0.5:
            keys.add("lctrl")                 # swim down: the crouch key (without it we only sink slowly)
        self.set_keys(keys)

    # -- behaviours -----------------------------------------------------------------------------------
    def desperate(self, inv):
        """Nothing to fight with (items.desperate), where a sapper's sticks count and a brawler never is."""
        if self.skill.tnt and itemlib.tnt_count(inv) > 0:
            return False
        return itemlib.desperate(inv, self.skill.melee_only)

    def favorite_ready(self, inv):
        """Whether the behaviour's favourite weapon is to hand (owned and loaded or with spare ammo; TNT: sticks
        left), so its keep_distance and back_off apply."""
        fav = self.skill.favorite
        if fav is None or not inv:
            return fav is None
        if fav == TNT_SLOT:
            return itemlib.tnt_count(inv) > 0 and not self.wet
        w = next((w for w in inv["weapons"] if w["slot"] == fav), None)
        return w is not None and self.usable(w)

    def back_away(self, me, now, target, step=20.0):
        """Walk away from `target` while aiming at it, strafing. False if there's no way back there."""
        d = max(flat_dist(me, target), 0.1)
        goal = {"x": me["x"] + (me["x"] - target["x"]) / d * step, "y": me["y"],
                "z": me["z"] + (me["z"] - target["z"]) / d * step}
        return self.go(me, now, goal, aiming=True, strafe=True)

    def track(self, players, now):
        """Smoothed velocity of every living player, from its position tick to tick (for leading TNT throws)."""
        seen = set()
        for p in players:
            seen.add(p["addr"])
            old = self.tracks.get(p["addr"])
            vx = vz = 0.0
            if old and 0 < now - old[0] < 0.5:
                dt = now - old[0]
                mx, mz = (p["x"] - old[1]) / dt, (p["z"] - old[2]) / dt
                if math.hypot(mx, mz) < 60.0:         # faster is a respawn or a teleport, not running
                    vx, vz = old[3] + 0.35 * (mx - old[3]), old[4] + 0.35 * (mz - old[4])
            self.tracks[p["addr"]] = (now, p["x"], p["z"], vx, vz)
        for addr in [a for a in self.tracks if a not in seen]:
            del self.tracks[addr]

    def predict(self, p, ahead, now):
        """Where player p (tnt_fight stores its position, seen_at, vx and vz each tick, in sight or not: the user
        allows that for TNT) will be `ahead` seconds from now, leading by part of its velocity."""
        t = min(ahead + now - p.get("seen_at", now), self.TNT_LEAD_MAX) * self.TNT_LEAD
        return {"x": p["x"] + p.get("vx", 0.0) * t, "y": p["y"], "z": p["z"] + p.get("vz", 0.0) * t}

    def ceiling_over(self, a, b):
        """The lower ceiling of the sectors at a and b (a throw's arc has to fit under it), or None without a map."""
        if self.level is None:
            return None
        tops = []
        for p in (a, b):
            i = self.level.locate(p["x"], p["y"] + 0.5, p["z"])
            if i is not None:
                tops.append(self.level.ceiling_at(i, p["x"], p["z"]))
        return min(tops) if tops else None

    def dodge(self, me, now, aiming=False):
        """Run from lit sticks within Skill.dodge_radius (not the one in our own hand), straight away from them.
        When `aiming` the view stays on the target. Returns True while running."""
        if not self.skill.dodge_tnt:
            return False
        held = (self.bot.lit or {}).get("addr")
        ax = az = 0.0
        nearest = None
        for st in self.bot.explosives:
            if st["addr"] == held:
                continue
            st = self.stick_rest(st, me["y"])
            d = math.dist((me["x"], me["y"], me["z"]), (st["x"], st["y"], st["z"]))
            radius = self.skill.dodge_radius + (3.0 if self.dodging else 0.0)   # a little farther once running
            if d >= radius:
                continue
            w = (radius - d) / max(flat_dist(me, st), 0.5)
            ax, az = ax + (me["x"] - st["x"]) * w, az + (me["z"] - st["z"]) * w
            nearest = d if nearest is None else min(nearest, d)
        if nearest is None:
            self.dodging = False
            return False
        if not self.dodging:
            self.log(f"lit TNT {nearest:.0f} away: running")
            self.dodging = True
        heading = bearing({"x": 0.0, "z": 0.0}, {"x": ax, "z": az}) if ax or az else me["yaw"] + FULL_TURN // 2
        keys = keys_toward(me["yaw"], heading)
        if self.stalled(now, me):
            keys.add(self.strafe_key)              # backed into a wall: slide along it
        self.set_keys(keys)
        return True

    def stick_rest(self, st, floor_y):
        """Where a stick will come down: itself when it's slow (lying or rolling), else where its flight meets
        `floor_y`. So a stick flying past, our own on its way out included, isn't run from."""
        if math.dist((st["vx"], st["vy"], st["vz"]), (0, 0, 0)) < 10.0:
            return st
        disc = st["vy"] ** 2 + 2 * self.gravity * max(st["y"] - floor_y, 0.0)
        t = (st["vy"] + math.sqrt(disc)) / self.gravity
        return dict(st, x=st["x"] + st["vx"] * t, y=floor_y, z=st["z"] + st["vz"] * t)

    # -- TNT (the sapper) -------------------------------------------------------------------------------
    # Secondary fire lights a stick, primary winds up, and letting go throws (tnt.py has the mechanics). The fuse
    # runs from lighting, so the throw is held ("cooked") until the stick will go off TNT_LAND_MARGIN after it
    # lands, and aimed at where the target will be by then; a close target gets it going off right at them
    # (tnt_close_hold). Phases: light (secondary held until the lighting starts), wind (primary held from then
    # on, so the wind-up follows the lighting at once, until the weapon is wound up), hold (aim, wait, let go)
    # and thrown (until the stick has left our hand).
    def tnt_ready(self, inv):
        """A sapper with sticks, able to use them: on dry land (no lighting in the water) and without the badge."""
        return (self.skill.tnt and bool(inv) and not self.wet and not inv.get("hasBadge")
                and itemlib.tnt_count(inv) > 0 and any(w["slot"] == TNT_SLOT for w in inv["weapons"]))

    def tnt_wanted(self, me, now):
        """Go after the enemy in sight with TNT (tnt_fight)? Whenever we can, once we've reacted to them."""
        if self.last_seen is not None and any(flat_dist(a, self.last_seen) < 0.6 * TNT_BLAST for a in self.allies_now):
            if now - getattr(self, "tnt_ally_logged", 0.0) > 5.0 and self.tnt_ready(me.get("inventory")):
                self.tnt_ally_logged = now
                self.log("TNT: a teammate is too close to the target; holding the throw")
            return False                  # handover step 10: no throw with a teammate this near the target
        return (self.tnt_ready(me.get("inventory")) and now >= self.tnt_next and self.visible_since is not None
                and now - self.visible_since >= self.skill.reaction)

    def tnt_min(self):
        """How far from us a stick has to land: Skill.tnt_min, or less when a standing throw doesn't carry that far
        (the gravity measured live, ~97, gives ~42). Closer targets get the close throw (tnt_close_hold)."""
        if self._tnt_min is None or self._tnt_min[0] != self.gravity:
            still = {"x": 0.0, "y": 0.0, "z": 0.0, "height": 6.0}
            reach = tnt.reach(still, (0.0, 0.0, 0.0), 0.0, 1.0, 0.0, self.gravity)[0]
            self._tnt_min = (self.gravity, min(self.skill.tnt_min, reach - 2.0))
        return self._tnt_min[1]

    def tnt_reset(self):
        self.tnt_phase, self.tnt_target, self.tnt_plan = None, None, None
        self.mega_on, self.mega = False, None

    def tnt_set(self, phase, now):
        self.tnt_phase, self.tnt_since = phase, now

    def tnt_solution(self, me, pw, flattest=None, check_arc=False):
        """The throw with power `pw` that lands the stick where the target will be when it goes off (we let go
        flight + TNT_LAND_MARGIN before the fuse ends). Flattest throw unless this throw switched to a lob
        (tnt_lob), or as `flattest` says. With `check_arc`, a throw whose arc runs into the level (a wall, a roof)
        counts as none. Returns (solution or None, goal point)."""
        flattest = not self.tnt_lob if flattest is None else flattest
        vel = (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0)
        flight, sol, goal = 0.9, None, None
        for _ in range(3):
            goal = self.predict(self.tnt_target, flight + self.TNT_LAND_MARGIN, self.tnt_now)
            sol = tnt.solve(me, vel, goal, pw, self.gravity, self.ceiling_over(me, goal), flattest=flattest)
            if sol is None:
                break
            flight = sol["flight"]
        if sol is not None and check_arc and not self.arc_clear(me, vel, sol, pw):
            sol = None
        return sol, goal

    def arc_clear(self, me, vel, sol, pw):
        """Whether a throw's arc stays in open space (a stick that hits a wall or a roof on the way can come back
        at us). Walls have no thickness in this engine, so a point beyond one is simply in the next sector: the
        arc is followed sector by sector, every ~3 units. Each step stays in its sector, under the ceiling, or
        passes into a neighbouring one through an opening it fits at that height (sector_step). Without a map we
        can't tell: clear."""
        lvl = self.level
        if lvl is None:
            return True
        start = (me["x"], me["y"] + tnt.LAUNCH_HEIGHT * me.get("height", 6.0), me["z"])
        here = lvl.locate(*start)
        if here is None:
            return True                                     # we're nowhere on the map: can't tell
        length = sol["flight"] * math.hypot(tnt.SPEED * pw, math.hypot(vel[0], vel[2]))
        prev = start
        for p in tnt.arc(me, vel, sol, pw, n=max(12, int(length / 3.0)), g=self.gravity):
            here = self.sector_step(here, prev, p)
            if here is None:
                return False
            prev = p
        return True

    def sector_neighbours(self, i):
        """Sectors a thrown stick can pass into from sector i: through a wall's adjoins, or the one stacked above
        or below (vadjoin)."""
        if self._neighbours is None or self._neighbours[0] is not self.level:
            secs = self.level.sectors
            near = [set() for _ in secs]
            for s in secs:
                for w in s.walls:
                    near[s.index].update(k for k in (w.adjoin, w.dadjoin) if 0 <= k < len(secs))
                if 0 <= s.vadjoin < len(secs):
                    near[s.index].add(s.vadjoin)
                    near[s.vadjoin].add(s.index)
            self._neighbours = (self.level, near)
        return self._neighbours[1][i]

    def sector_step(self, i, a, b, depth=0):
        """The sector point b is in, coming from point a in sector i, or None when the step is blocked: above the
        ceiling, into the floor, or into a sector that isn't a neighbour reached through an opening tall enough
        at that height. A step that skips a sector is halved (3 times at most)."""
        lvl = self.level
        x, y, z = b
        j = None
        for k in [i, *self.sector_neighbours(i)]:
            s = lvl.sectors[k]
            if s.walls and s.contains(x, z) and lvl.floor_at(k, x, z) - 0.5 <= y <= lvl.ceiling_at(k, x, z) + 0.5:
                j = k
                break
        if j is None:
            j = lvl.locate(x, y, z)
            if j is None:
                return None
        if y > lvl.ceiling_at(j, x, z) - 0.2 or y < lvl.floor_at(j, x, z) - 0.2:
            return None
        if j == i:
            return j
        if j in self.sector_neighbours(i):
            si, sj = lvl.sectors[i], lvl.sectors[j]
            if si.vadjoin == j or sj.vadjoin == i:
                return j                                    # up or down into a stacked sector
            mx, mz = (a[0] + x) / 2, (a[2] + z) / 2
            low = max(lvl.floor_at(i, mx, mz), lvl.floor_at(j, mx, mz))
            high = min(lvl.ceiling_at(i, mx, mz), lvl.ceiling_at(j, mx, mz))
            if low + 0.1 < (a[1] + y) / 2 < high - 0.2:
                return j
            return None
        if depth >= 3:
            return None
        mid = tuple((u + v) / 2 for u, v in zip(a, b))
        k = self.sector_step(i, a, mid, depth + 1)
        return None if k is None else self.sector_step(k, mid, b, depth + 1)

    def check_arcs(self, me, now, pw):
        """While holding a lit stick, every 0.3 s: does the flat throw's arc stay clear of the level, else does the
        lob's? Sets tnt_lob (aim the lob from now on) and tnt_arc_ok (some throw gets there). Decided ahead of the
        release because a lob flies longer, so it has to go sooner."""
        if now < self.tnt_arc_at:
            return
        self.tnt_arc_at = now + 0.3
        vel = (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0)
        flat, goal = self.tnt_solution(me, pw, flattest=True)
        safe = flat is not None and flat_dist(me, goal) >= self.tnt_min() - 3.0
        if safe:
            if self.arc_clear(me, vel, flat, pw):
                lob, ok = False, True
            else:
                ok = self.tnt_solution(me, pw, flattest=False, check_arc=True)[0] is not None
                lob = ok
            if (lob, ok) != (self.tnt_lob, self.tnt_arc_ok):
                self.log("TNT: the flat throw hits the level; lobbing it" if lob
                         else "TNT: every throw at them hits the level; waiting" if not ok else "TNT: flat throw clear")
            self.tnt_lob, self.tnt_arc_ok = lob, ok
            if ok:
                return
        if pw < 1.0:
            return                                          # power still building: the last moment is far off
        # No good throw: the one for the last moment (tnt_fallback) goes the nearest way off the target's that's
        # clear. Only searched then, as it costs a few arc checks.
        for turn in (0.0, 30.0, -30.0, 60.0, -60.0, 90.0, -90.0, 135.0, -135.0, 180.0):
            self.tnt_fb_turn = turn
            fb = self.tnt_fallback(me, pw)
            if fb is not None and self.arc_clear(me, vel, fb, pw):
                break
        else:
            self.tnt_fb_turn = 0.0

    def tnt_unseen_target(self, me, now, enemies):
        """Sapper: an enemy out of sight but within a standing throw, to lob a stick at (user: TNT may go by where
        everyone is; you'd hear them anyway). The nearest one whose throw arc is clear of the level (checked at most
        every 0.5 s per enemy). None if there's none, or we can't throw now."""
        if not self.tnt_ready(me.get("inventory")) or now < self.tnt_next:
            return None
        reach = tnt.reach(me, (0.0, 0.0, 0.0), 0.0, 1.0, me["y"], self.gravity)[0]
        near = [p for p in enemies if flat_dist(me, p) <= reach]
        if not near:
            return None
        best = min(near, key=lambda p: flat_dist(me, p))
        fresh = best["addr"] not in self.tnt_arc_cache or now - self.tnt_arc_cache[best["addr"]][0] >= 0.5
        if not self.tnt_arc_possible(me, now, best):
            return None
        if fresh:
            self.log(f"TNT: an enemy out of sight {flat_dist(me, best):.0f} away")
        return best

    def tnt_arc_possible(self, me, now, p):
        """Is there a full-power throw from where we stand at player p (flat or lob) whose arc is clear of the level?
        Targets beyond a standing throw count as possible (running adds reach; the hold re-checks). Cached for 0.5 s
        per player."""
        cached = self.tnt_arc_cache.get(p["addr"])
        if cached and now - cached[0] < 0.5:
            return cached[1]
        # At where they are now: this is about walls in the way, and where they're heading changes by the throw.
        saved, self.tnt_now = self.tnt_target, now
        self.tnt_target = dict(p, seen_at=now, vx=0.0, vz=0.0)
        still = dict(me, vx=0.0, vy=0.0, vz=0.0)
        standing = tnt.reach(still, (0.0, 0.0, 0.0), to_deg(bearing(me, p)), 1.0, p["y"], self.gravity)[0]
        if flat_dist(me, p) > standing:
            ok = True
        elif flat_dist(me, p) < self.tnt_min():
            sol = self.tnt_burst(still, 1.0)[0]             # close: the throw that goes off at them
            ok = sol is None or self.arc_clear(still, (0.0, 0.0, 0.0), sol, 1.0)
        else:
            ok = any(self.tnt_solution(still, 1.0, flattest=f, check_arc=True)[0] for f in (True, False))
        self.tnt_target = saved
        self.tnt_arc_cache = {a: c for a, c in self.tnt_arc_cache.items() if now - c[0] < 5.0}
        self.tnt_arc_cache[p["addr"]] = (now, ok)
        return ok

    def tnt_fallback(self, me, pw):
        """Somewhere to throw a stick that must go now, when the target can't be reached safely: in the target's
        direction, at least tnt_min + 8 from us (past them when they're close), at most as far as it carries."""
        t = self.tnt_target
        d = max(flat_dist(me, t), 0.1)
        vel = (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0)
        # Turned off the target's direction by tnt_fb_turn when check_arcs found that way blocked.
        heading = math.radians(to_deg(bearing(me, t)) + self.tnt_fb_turn)
        carry = tnt.reach(me, vel, math.degrees(heading), pw, t["y"], self.gravity, self.ceiling_over(me, t))[0]
        far = min(max(self.tnt_min() + 8.0, d), carry - 1.0)
        for share in (1.0, 0.85, 0.7, 0.5):             # (reach() leaves out our sideways drift: a bit shorter)
            goal = {"x": me["x"] + math.sin(heading) * far * share, "y": t["y"],
                    "z": me["z"] + math.cos(heading) * far * share}
            sol = tnt.solve(me, vel, goal, pw, self.gravity, self.ceiling_over(me, goal))
            if sol is not None:
                return sol
        return None

    def tnt_look(self, me, sol):
        """Turn toward a throw solution (or, without one, the target at the farthest-carrying pitch). Returns the
        (heading, pitch) error in degrees."""
        if sol is not None:
            want_yaw, want_pitch = to_units(sol["yaw"]), to_units(sol["view_pitch"])
        else:
            want_yaw, want_pitch = bearing(me, self.tnt_target), to_units(45.0 - tnt.THROW_PITCH)
        self.look_toward(me, want_yaw, want_pitch)
        return to_deg(wrap(round(want_yaw - me["yaw"]))), to_deg(want_pitch - me["pitch"])

    def tnt_fight(self, me, now, target):
        """Run the TNT throw (see the section comment). `target` is the enemy in sight, or None (the throw goes on
        at where they were heading)."""
        s = self.skill
        inv = me.get("inventory") or {}
        self.tnt_now = now
        # Follow the target where it really is, in sight or not (user: fine for TNT).
        addr = (target or self.tnt_target or {}).get("addr")
        live = target or next((p for p in self.bot.all_players if addr and p["addr"] == addr and not p["dead"]), None)
        if live is not None:
            tr = self.tracks.get(live["addr"])
            self.tnt_target = dict(live, seen_at=now, vx=tr[3] if tr else 0.0, vz=tr[4] if tr else 0.0)
        if self.tnt_target is None:
            self.tnt_target = dict(me, addr=None)          # nothing to aim at (shouldn't happen): straight ahead
        weapon = next((w for w in inv.get("weapons", []) if w["slot"] == TNT_SLOT), None)
        action, lit = inv.get("action"), self.bot.lit
        if self.tnt_actions[-1:] != [action]:
            self.tnt_actions.append(action)
        self.stop_reload()
        dist = flat_dist(me, self.tnt_target)

        if self.tnt_phase is None:
            self.tnt_actions = [action]
            if lit:                                         # a stick already lit (we re-attached mid-throw)
                self.log("TNT: a stick is already lit; throwing it")
                self.tnt_lit_at = now - 2.0                 # its age is unknown: assume it's old
                self.tnt_lit_seen, self.tnt_pressed_at, self.tnt_times = True, now, {}
                self.tnt_idle_since, self.tnt_repress = None, False
                self.tnt_close, self.tnt_commit = dist < self.tnt_min(), False
                self.release_fire()
                self.press_fire(PRIMARY_FIRE, weapon or {"loaded": 0}, now)
                self.tnt_set("wind", now)
                return
            self.tnt_look(me, self.tnt_solution(me, 1.0)[0])
            far = dist > s.tnt_max
            if far:
                # Out of range even with a run-up: walk toward them with the TNT out, and light it once in range.
                self.go(me, now, self.tnt_target, aiming=True, keep=s.tnt_max - 10.0)
            else:
                self.tnt_move(me, now, None)
            if inv.get("slot") != TNT_SLOT:
                if now >= self.next_switch:
                    self.release_fire()
                    self.log(f"TNT: switching to TNT for an enemy {dist:.0f} away ({itemlib.tnt_count(inv)} sticks)")
                    self.tap(str(TNT_SLOT))
                    self.next_switch = now + 1.5
                return
            if far or action not in (None, -1) or weapon is None or now - self.slot_since < self.TNT_SWITCH_WAIT:
                return                                      # too far, or still bringing it up
            if not self.tnt_arc_possible(me, now, self.tnt_target):
                # Every throw at them from here runs into the level: get closer rather than waste a stick.
                if self.tnt_blocked != self.tnt_target.get("addr"):
                    self.tnt_blocked = self.tnt_target.get("addr")
                    self.log(f"TNT: no clear throw at them from here ({dist:.0f} away); moving in")
                self.go(me, now, self.tnt_target, aiming=True, keep=10.0)
                return
            self.tnt_blocked = None
            self.release_fire()
            self.press_fire(SECONDARY_FIRE, weapon, now)
            self.tnt_jumped, self.tnt_retries, self.tnt_plan = False, 0, None
            self.tnt_lob, self.tnt_arc_ok, self.tnt_arc_at, self.tnt_fb_turn = False, True, 0.0, 0.0
            self.tnt_pressed_at, self.tnt_times, self.tnt_lit_seen = now, {}, False
            self.tnt_idle_since, self.tnt_repress, self.tnt_light_seen = None, False, None
            self.tnt_close, self.tnt_commit, self.tnt_last_close = dist < self.tnt_min(), False, None
            self.tnt_set("light", now)
            self.log(f"TNT: lighting a stick for an enemy {dist:.0f} away")
            sticks = itemlib.tnt_count(inv)
            self.mega_on = (sticks >= self.MEGA_MIN_STICKS and self.tnt_min() + 3.0 <= dist <= s.tnt_max - 5.0
                            and random.random() < self.MEGA_CHANCE)
            if self.mega_on:
                self.log(f"TNT: MEGA-BLAST: the lit stick goes down early, then the other {sticks - 1} unlit around it")
            return

        if lit and not self.tnt_lit_seen and self.tnt_phase in ("light", "wind"):
            # The fuse runs from the moment it lit (until now we may have been timing it from the lighting's start).
            self.tnt_lit_seen = True
            self.tnt_lit_at = now - self.TICK / 2
            self.tnt_times["lit"] = now - self.tnt_pressed_at
        fuse_left = self.tnt_lit_at + tnt.FUSE - now
        if self.tnt_phase == "light":
            self.tnt_look(me, self.tnt_solution(me, 1.0)[0])
            self.tnt_move(me, now, None)
            if action == 0 and self.tnt_light_seen is None:
                self.tnt_light_seen = now
            if lit or (not self.lit_works and self.tnt_light_seen is not None
                       and now - self.tnt_light_seen >= self.TNT_LIT_GRACE):
                # Lit: wind up straight away, the throw gets its power while the fuse burns (user). Primary pressed
                # now is queued behind the lighting animation (tnt.py); letting go of secondary doesn't stop the
                # lighting. Only if the agent has never shown us a lit stick, and none shows up a while into the
                # lighting action (0), do we go by that action instead, timing the fuse from its start (it can only
                # be later, so we err toward throwing early). Action 0 alone isn't enough: during a weapon switch it
                # can be the old weapon's, and then the stick would go out unlit.
                if not self.tnt_lit_seen:
                    self.tnt_lit_at = self.tnt_light_seen - self.TICK / 2
                self.tnt_times["wind-up pressed"] = now - self.tnt_pressed_at
                self.release_fire()
                self.press_fire(PRIMARY_FIRE, weapon or {"loaded": 0}, now)
                self.tnt_set("wind", now)
            elif now - self.tnt_since > self.TNT_LIGHT_WAIT:
                self.release_fire()
                self.log(f"TNT: no stick lit after {self.TNT_LIGHT_WAIT:.1f}s (weapon actions {self.tnt_actions}); "
                         "giving up for now")
                self.tnt_next = now + 5.0
                self.tnt_reset()
            return

        if self.tnt_phase == "wind":
            self.tnt_look(me, self.tnt_solution(me, 1.0)[0])
            self.tnt_move(me, now, None)
            if self.tnt_repress:
                self.tnt_repress = False
                self.press_fire(PRIMARY_FIRE, weapon or {"loaded": 0}, now)
            elif action == TNT_WOUND_ACTION:
                self.tnt_wound_at = now - self.TICK / 2
                self.tnt_times["wound"] = now - self.tnt_pressed_at
                self.tnt_set("hold", now)
                return
            elif action in (-1, None) and (self.tnt_lit_seen or now - self.tnt_since > self.TNT_REPRESS):
                # Lit, primary held, yet the weapon sits idle: the queued press got lost. Let go and press again
                # next tick, rather than hold a lit stick that isn't wound up.
                if self.tnt_idle_since is None:
                    self.tnt_idle_since = now
                elif now - self.tnt_idle_since >= self.TNT_REPRESS and action == -1:
                    self.log(f"TNT: lit but not winding up (weapon actions {self.tnt_actions}); pressing again")
                    self.release_fire()
                    self.tnt_repress, self.tnt_idle_since = True, None
            else:
                self.tnt_idle_since = None
            if self.tnt_lit_seen is False and now - self.tnt_since > self.TNT_LIT_UNSEEN:
                self.tnt_lit_seen = None                    # (logged once)
                self.log("TNT: lighting done but the lit stick never showed up; timing the fuse from the lighting")
            if now - self.tnt_lit_at > self.TNT_WIND_WAIT:
                self.log(f"TNT: no wind-up state ({TNT_WOUND_ACTION}) after "
                         f"{self.TNT_WIND_WAIT:.1f}s (weapon actions {self.tnt_actions}); holding anyway")
                self.press_fire(PRIMARY_FIRE, weapon or {"loaded": 0}, now)
                self.tnt_wound_at = now
                self.tnt_set("hold", now)
            elif fuse_left <= self.TNT_LAST_CALL:
                self.tnt_release(me, now, "the fuse is nearly out (still winding up)", None, None, 0.5)
            return

        if self.tnt_phase == "hold":
            pw = tnt.power(now - self.tnt_wound_at)
            t = self.tnt_target
            near = flat_dist(me, t) < self.tnt_min() + (4.0 if self.tnt_close else 0.0)
            if near != self.tnt_close and not self.tnt_commit:
                self.tnt_close = near
                self.log(f"TNT: target {dist:.0f} away: " + ("close, it goes off right at them" if near
                                                               else "back to landing it at them"))
            if self.tnt_close and self.mega_on:
                self.mega_on = False
                self.log("TNT: mega-blast dropped, the target is too close")
            if self.tnt_close:
                self.tnt_close_hold(me, now, pw, fuse_left)
                return
            self.check_arcs(me, now, pw)
            sol, goal = self.tnt_solution(me, pw)
            safe = sol is not None and flat_dist(me, goal) >= self.tnt_min() - 3.0
            aim_sol = sol if safe and self.tnt_arc_ok else self.tnt_fallback(me, pw)
            yaw_err, pitch_err = self.tnt_look(me, aim_sol)
            lined = aim_sol is not None and abs(yaw_err) < 2.5 and abs(pitch_err) < 2.5
            self.tnt_move(me, now, goal, fuse_left)
            cooked = safe and fuse_left <= sol["flight"] + self.TNT_LAND_MARGIN + self.TICK
            # Coming at us: soon there's no safe throw left, so let go now, cooked or not. Unless they'll still be
            # far enough off when it goes for the close throw (tnt_close_hold) to get them.
            toward = ((me["x"] - t["x"]) * t.get("vx", 0.0) + (me["z"] - t["z"]) * t.get("vz", 0.0)) / max(dist, 0.1)
            closing = (safe and toward > 3.0 and flat_dist(me, goal) < self.tnt_min() + 10.0
                       and self.burst_risk(me, self.predict(t, fuse_left, now), fuse_left) > s.tnt_self_max)
            # The last moment it can still get far enough from us before it goes off.
            last_call = max(self.TNT_LAST_CALL, aim_sol["flight"] + self.TICK if aim_sol else 1.0)
            if self.mega_on and lined and safe and self.tnt_arc_ok:
                self.tnt_release(me, now, "mega-blast: down early", sol, goal, pw)
                return
            if lined and (cooked or closing) and self.tnt_arc_ok:
                self.tnt_release(me, now, None if cooked else "they're closing in", sol, goal, pw)
            elif fuse_left <= last_call:
                why = ("the way there is blocked" if safe and lined else "not lined up" if safe
                       else "the target is too close" if sol is not None or dist < self.tnt_min() + 5
                       else "the target is out of reach")
                self.tnt_release(me, now, f"the fuse is nearly out, {why}", aim_sol, goal, pw)
            return

        if self.tnt_phase == "mega":
            self.mega_step(me, now, inv, weapon, action)
            return

        # thrown: the stick should have left our hand. If it hasn't (the let-go came before the wind-up ended,
        # say), press and let go again. Keep backing off from where it goes off if that's near.
        self.tnt_look(me, self.tnt_plan[1] if self.tnt_plan else None)
        goal = self.tnt_plan[2] if self.tnt_plan else None
        if not (goal and flat_dist(me, goal) < s.dodge_radius and self.back_away(me, now, goal)):
            self.set_keys(set())
        if not lit or lit.get("addr") != (self.tnt_watch or {}).get("addr"):
            if (self.mega_on and (self.tnt_watch or {}).get("addr") and itemlib.tnt_count(inv) > 0
                    and fuse_left > self.MEGA_LAST):
                self.mega = {"addr": self.tnt_watch["addr"], "sub": "gap", "since": now, "n": 0, "fails": 0,
                             "goal": None, "wound_at": now}
                self.tnt_set("mega", now)
                self.log(f"TNT mega-blast: lit stick down, {itemlib.tnt_count(inv)} unlit to throw around it, "
                         f"{fuse_left:.1f}s of fuse left")
                return
            self.mega_on = False
            self.tnt_next = now + 0.5
            self.tnt_reset()
        elif now - self.tnt_since > 0.3:
            if self.tnt_retries < 4:
                self.tnt_retries += 1
                self.log(f"TNT: still in hand after letting go (weapon action {action}); pressing again")
                self.tap(PRIMARY_FIRE)
                self.tnt_since = now
            elif fuse_left < -0.5:
                self.tnt_reset()                            # it went off in our hand, or the agent lost it

    KNIFE_THROW_MIN, KNIFE_THROW_MAX, KNIFE_THROW_GAP = 7.0, 28.0, 3.0

    def knife_throw(self, me, now, weapon, dist, lined_up):
        """Chasing with the knife out and more than one knife: throw one (primary fire; the jab is the secondary) to
        spin the enemy around, then close in and stab (user). Returns True on the tick it throws."""
        if (weapon is None or weapon["slot"] != KNIFE_SLOT or self.wet or not lined_up
                or not (self.KNIFE_THROW_MIN <= dist <= self.KNIFE_THROW_MAX)
                or now < getattr(self, "knife_throw_next", 0.0)):
            return False
        knives = (weapon.get("loaded") or 0) + (weapon.get("reserve") or 0)
        if knives < 2:
            return False
        self.knife_throw_next = now + self.KNIFE_THROW_GAP
        self.release_fire()
        self.tap(PRIMARY_FIRE)
        self.log(f"knife: throwing one at an enemy {dist:.0f} away to spin them round "
                 f"({knives} knives; loaded {weapon.get('loaded')}, reserve {weapon.get('reserve')})")
        return True

    def mega_step(self, me, now, inv, weapon, action):
        """Mega-blast, after the lit stick is down: throw the unlit sticks (primary fire only, no lighting) around it
        while its fuse burns, then back away. The hope (user) is that the lit stick sets the rest off together."""
        m = self.mega
        st = next((e for e in self.bot.explosives if e["addr"] == m["addr"]), None)
        fuse_left = self.tnt_lit_at + tnt.FUSE - now
        sticks = itemlib.tnt_count(inv)
        if st is None or fuse_left < -0.3:
            self.release_fire()
            self.log(f"TNT mega-blast: over; {m['n']} unlit stick(s) thrown, {sticks} left")
            self.tnt_next = now + 1.0
            self.tnt_reset()
            return
        spot = self.stick_rest(st, me["y"])
        if m["goal"] is None or m["sub"] == "idle":
            a = 2.4 * m["n"] + 0.7
            m["goal"] = {"x": spot["x"] + self.MEGA_SPREAD * math.cos(a), "y": spot["y"],
                         "z": spot["z"] + self.MEGA_SPREAD * math.sin(a), "addr": None, "vx": 0.0, "vz": 0.0,
                         "height": 0.0}
        self.tnt_target = dict(m["goal"], seen_at=now)
        sub = m["sub"]
        if sub in ("idle", "gap") and (sticks <= 0 or fuse_left < self.MEGA_LAST):
            m["sub"] = sub = "done"
        if sub == "done":
            self.release_fire()
            if not self.back_away(me, now, spot):
                self.set_keys(set())
            return
        if sub == "gap":
            self.tnt_move(me, now, None)
            if now - m["since"] >= 0.6:
                m["sub"] = "idle"
            return
        if sub == "idle":
            self.tnt_move(me, now, None)
            if inv.get("slot") != TNT_SLOT:
                if now >= self.next_switch:
                    self.tap(str(TNT_SLOT))
                    self.next_switch = now + 1.0
                return
            if action not in (None, -1):
                return                                      # still bringing it up / finishing the last throw
            self.release_fire()
            self.press_fire(PRIMARY_FIRE, weapon or {"loaded": 0}, now)
            m["sub"], m["since"] = "wind", now
            return
        if sub == "wind":
            self.tnt_look(me, self.tnt_solution(me, 1.0)[0])
            self.tnt_move(me, now, None)
            if action == TNT_WOUND_ACTION:
                m["wound_at"], m["sub"], m["since"] = now - self.TICK / 2, "hold", now
            elif now - m["since"] > 1.5:
                m["fails"] += 1
                self.release_fire()
                self.log(f"TNT mega-blast: primary on an unlit stick didn't wind up (weapon action {action}); "
                         f"try {m['fails']}")
                m["sub"], m["since"] = ("done" if m["fails"] >= 2 else "gap"), now
            return
        if sub == "hold":
            pw = tnt.power(now - m["wound_at"])
            sol, _ = self.tnt_solution(me, pw, flattest=True)
            yaw_err, pitch_err = self.tnt_look(me, sol)
            lined = sol is not None and abs(yaw_err) < 2.5 and abs(pitch_err) < 2.5
            self.tnt_move(me, now, None)
            if lined or fuse_left < 1.0 or now - m["wound_at"] > 1.6:
                self.release_fire()
                m["n"] += 1
                self.log(f"TNT mega-blast: unlit stick {m['n']} thrown at {flat_dist(me, m['goal']):.0f} away, "
                         f"power {pw:.2f}, lit one has {fuse_left:.1f}s left, {sticks - 1} to go")
                m["sub"], m["since"] = "gap", now
            return

    def tnt_close_hold(self, me, now, pw, fuse_left):
        """The hold with the target closer than tnt_min (user): aim low and let go at the last moment, so the stick
        goes off right at them (in the air, or as it lands), backing off if they're very close. At the last moment a
        throw away
        (tnt_fallback) could still get clear, we choose: at them if the blast would do us at most tnt_self_max
        and the way there is clear, else away. After that we're committed."""
        s = self.skill
        t = self.tnt_target
        fb = self.tnt_fallback(me, pw)
        # From a little before the moment to choose until we let go, hold still: backing off takes reach off the
        # throw. Unless they're right on us, or coming at us (standing still would let them close in).
        d = max(flat_dist(me, t), 0.1)
        toward = ((me["x"] - t["x"]) * t.get("vx", 0.0) + (me["z"] - t["z"]) * t.get("vz", 0.0)) / d
        if ((self.tnt_commit or fuse_left <= self.TNT_SETTLE + (fb["flight"] + self.TICK if fb else 1.0))
                and d >= self.TNT_SETTLE_NEAR and toward < 5.0):
            self.set_keys(set())
        else:
            self.tnt_move(me, now, None, fuse_left)
        sol, point = self.tnt_burst(me, pw)
        if sol is None:
            # At the edge of our reach a throw can't get to their body: land it at their feet instead.
            sol, point = self.tnt_solution(me, pw, flattest=True)
        if sol is not None:
            self.tnt_last_close = (sol, point)
        elif self.tnt_commit and self.tnt_last_close:
            sol, point = self.tnt_last_close                # lost it for a tick: keep to the last one
        yaw_err, pitch_err = self.tnt_look(me, sol)
        lined = sol is not None and abs(yaw_err) < 4.0 and abs(pitch_err) < 4.0
        risk = None
        if sol is not None:
            at = dict(self.predict(t, fuse_left, now), y=point["y"])      # where they'll be when it goes off
            risk = self.burst_risk(me, at, sol["flight"])                  # (we back off once it's thrown)
        if not self.tnt_commit or risk is None or risk > 2 * s.tnt_self_max:
            decide = max(self.TNT_LAST_CALL, fb["flight"] + self.TICK if fb else 1.0,
                         sol["flight"] + self.TICK if sol else 0.0)
            if self.tnt_commit and fuse_left <= self.TNT_LAST_CALL:
                pass                                        # too late to throw it anywhere else
            elif not self.tnt_commit and fuse_left > decide:
                return
            elif (sol is not None and risk <= s.tnt_self_max
                  and self.arc_clear(me, (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0), sol, pw)):
                if not self.tnt_commit:
                    self.tnt_commit = True
                    self.log(f"TNT: it goes off at them ({flat_dist(me, t):.0f} away, ~{risk:.1f} damage to us)")
            else:
                why = ("no throw gets to them" if sol is None else f"it would do us ~{risk:.1f}"
                       if risk > s.tnt_self_max else "the way there is blocked")
                goal = {"x": fb["x"], "y": t["y"], "z": fb["z"]} if fb else None
                self.tnt_release(me, now, f"too close, {why}; throwing it away", fb, goal, pw)
                return
        # Let go when the stick will get to them just as the fuse ends (a tick late is still a few units past them).
        if sol is not None and fuse_left <= sol["flight"] + self.TICK and (lined or fuse_left <= sol["flight"]):
            self.tnt_release(me, now, f"close, going off at them; ~{risk:.1f} damage to us", sol, point, pw)
        elif sol is None and fuse_left <= 2 * self.TICK:
            self.tnt_release(me, now, "close, the fuse is out", None, None, pw)

    def tnt_burst(self, me, pw):
        """Close throw: the flattest one that gets the stick to the target's body (half its height up, else 0.8),
        where it will be when it gets there, rising or falling, aimed no lower than TNT_MIN_VIEW. Returns
        (solution or None, that point)."""
        vel = (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0)
        t = self.tnt_target
        point = None
        for share in (0.5, 0.8):
            flight, sol = 0.3, None
            for _ in range(3):
                point = self.predict(t, flight, self.tnt_now)
                point["y"] += share * t.get("height", 6.0)
                sol = tnt.solve(me, vel, point, pw, self.gravity, self.ceiling_over(me, point), flattest=True,
                                descending=False, min_launch=self.TNT_MIN_VIEW + tnt.THROW_PITCH)
                if sol is None:
                    break
                flight = sol["flight"]
            if sol is not None:
                return sol, point
        return None, point

    def burst_risk(self, me, point, after):
        """Blast damage to us (before armour) from a stick going off at `point` `after` seconds from now, with us
        backing away from it until then (thrown phase) at half our top speed (we strafe, a wall may stop us), or
        faster if we're already moving away faster."""
        d = max(flat_dist(me, point), 0.1)
        ux, uz = (me["x"] - point["x"]) / d, (me["z"] - point["z"]) / d
        away = max(0.7 * ((me.get("vx") or 0.0) * ux + (me.get("vz") or 0.0) * uz), 0.5 * self.top_speed)
        gap = d + away * max(after, 0.0)
        rise = me["y"] + me.get("height", 6.0) / 2 - point["y"]
        return tnt.damage(math.hypot(gap, rise))

    def tnt_move(self, me, now, goal=None, fuse_left=None):
        """Feet during a throw. Too close: back off. Where the stick should land (`goal`, else the target) is out
        of reach standing still: run at it (our speed carries the stick on), and near the moment to let go jump
        as well. In reach: stand still, so the throw goes where it was aimed. Decided on the standing reach, not
        on the throw with our speed added, or stopping would put it back out of reach. "Too close" is
        TNT_BACK_OFF inside tnt_min: anyone within a standing throw gets one that goes off at them anyway."""
        t = self.tnt_target
        goal = goal or t
        if flat_dist(me, t) < self.tnt_min() - self.TNT_BACK_OFF:
            if not self.back_away(me, now, t):
                self.set_keys(set())
            return
        dist = flat_dist(me, goal)
        standing = tnt.reach(me, (0.0, 0.0, 0.0), to_deg(bearing(me, goal)), 1.0, goal["y"], self.gravity,
                             self.ceiling_over(me, goal))[0]
        if t.get("addr") is None or dist <= standing - 1.0:
            self.set_keys(set())
            self.stuck_check = None
            return
        keys = keys_toward(me["yaw"], bearing(me, goal))
        if (self.tnt_phase == "hold" and fuse_left is not None and not self.tnt_jumped
                and fuse_left < 1.4 + self.TNT_LAND_MARGIN + 0.3):
            keys.add("space")
            self.tnt_jumped = True
            self.log(f"TNT: jumping for reach ({dist:.0f} away, {standing:.0f} standing)")
        self.set_keys(keys)

    def tnt_release(self, me, now, why, sol, goal, pw):
        """Let go of primary fire: the stick flies."""
        self.release_fire()
        fuse_left = self.tnt_lit_at + tnt.FUSE - now
        lit = self.bot.lit or {}
        self.tnt_watch = {"addr": lit.get("addr"), "at": now, "lit_at": self.tnt_lit_at, "power": pw,
                          "target": self.tnt_target.get("addr"), "samples": [], "last": None, "logged": False,
                          "self_vel": (me.get("vx") or 0.0, me.get("vy") or 0.0, me.get("vz") or 0.0)}
        self.tnt_plan = (pw, sol, goal)
        target = (f"{flat_dist(me, goal):.0f} away" if goal else "nowhere in particular")
        if sol:
            target += f", flight {sol['flight']:.2f}s, launch {sol['launch']:.0f} deg"
        times = ", ".join(f"{k} +{v:.2f}s" for k, v in self.tnt_times.items())
        self.log(f"TNT: thrown{' (' + why + ')' if why else ''}: power {pw:.2f}, to {target}, fuse left "
                 f"{fuse_left:.2f}s, weapon actions {self.tnt_actions}"
                 + (f" (after the lighting press: {times})" if times else ""))
        self.tnt_set("thrown", now)

    def watch_stick(self, me, now):
        """Follow our thrown stick: log how it left our hand (speed against tnt.py's model) and the gravity its
        flight shows, which then replaces the default, and where it went off, against the target and us."""
        w = self.tnt_watch
        if w is None or w["addr"] is None:
            self.tnt_watch = None
            return
        st = next((e for e in self.bot.explosives if e["addr"] == w["addr"]), None)
        held = (self.bot.lit or {}).get("addr") == w["addr"]
        if st is None:
            if w["last"] is not None or now - w["at"] > 2.0:
                self.stick_done(me, now)
            return
        if held:
            return
        w["last"] = st
        samples = w["samples"]
        if not w.get("flying_done"):
            if samples and (st["vy"] > samples[-1][1] + 0.5
                            or math.hypot(st["vx"], st["vz"]) < 0.7 * math.hypot(samples[0][2], samples[0][3])):
                w["flying_done"] = True                     # it bounced
            else:
                samples.append((now, st["vy"], st["vx"], st["vz"]))
        if not w["logged"] and samples:
            w["logged"] = True
            _, vy, vx, vz = samples[0]
            sx, sy, sz = w["self_vel"]
            speed = math.dist((vx, vy, vz), (sx, sy, sz))
            self.log(f"TNT flight: left at {speed:.1f} (model: {max(tnt.MIN_SPEED, tnt.SPEED * w['power']):.1f}) "
                     f"on top of our {math.hypot(sx, sz):.1f}")
        if w.get("flying_done") and not w.get("gravity_done"):
            w["gravity_done"] = True
            if len(samples) >= 4 and samples[-1][0] - samples[0][0] >= 0.25:
                n = len(samples)
                mt = sum(t for t, *_ in samples) / n
                mv = sum(v for _, v, *_ in samples) / n
                var = sum((t - mt) ** 2 for t, *_ in samples)
                g = -sum((t - mt) * (v - mv) for t, v, *_ in samples) / var if var else 0.0
                if 15.0 < g < 250.0:
                    self.gravity = g if self.gravity == tnt.GRAVITY else 0.5 * (self.gravity + g)
                    tnt.save_gravity(self.gravity)
                    self.log(f"TNT flight: gravity {g:.1f} over {n} samples; using {self.gravity:.1f}")
                else:
                    self.log(f"TNT flight: gravity {g:.1f} looks wrong ({n} samples); keeping {self.gravity:.1f}")

    TAUNT_KEYS = tuple(f"f{n}" for n in range(1, 11))     # the quick taunts (botctl.py binds F1-F10 to them)

    # -- gun game (gungame.py) ----------------------------------------------------------------------------
    def gg_move(self, step, why):
        old = self.gg_rung
        self.gg_rung = max(0, old + step)
        if self.gg_rung >= len(gungame.LADDER):
            self.log(f"GUNGAME: WIN with the knife ({why})")
            self.gg_end = True           # end the game: the host's kill limit drops to 1 (see gg_tick)
            self.gg_rung = 0
            self.gg_wins = getattr(self, "gg_wins", 0) + 1
        elif self.gg_rung != old:
            self.log(f"GUNGAME: rung {old} -> {self.gg_rung} ({gungame.NAMES[gungame.slot_for(self.gg_rung)]}) {why}")

    def gg_tick(self, me, now):
        """Apply the rung's skill, and type the all-weapons cheat when the rung's weapon isn't in hand."""
        if self.gg_base is None:
            self.gg_base = self.skill
        if self.gg_applied != self.gg_rung:
            self.gg_applied = self.gg_rung
            self.skill = gungame.rung_skill(self.gg_base, self.gg_rung)
            self.next_switch = 0.0
            self.tnt_reset()
        inv = me.get("inventory")
        if inv and not self.cheat_keys and self.gg_check_at and now >= self.gg_check_at:
            self.gg_check_at = 0.0
            self.log("GUNGAME: after typing: " + ", ".join(f"{x['slot']}:{x.get('loaded')}/{x.get('reserve')}" for x in inv["weapons"])
                     + f" (slot {inv.get('slot')})")
        if not inv or self.cheat_keys or now - self.gg_cheat_at < 8.0:
            return False
        if getattr(self, "gg_end", False):
            self.gg_end = False
            self.gg_cheat_at = now
            self.cheat_keys = self.cheat_script(True, "mp_killsToEnd 1")
            self.cheat_start = now
            self.set_keys(set())
            self.release_fire()
            self.log("GUNGAME: ending the game (mp_killsToEnd 1)")
            return True
        if gungame.STINNETT and not self.gg_stin:     # the gatling is on the ladder: let everyone move with it
            self.gg_stin = True
            self.gg_cheat_at = now
            self.cheat_keys = self.cheat_script(True, "olstinnett")
            self.cheat_start = now
            self.set_keys(set())
            self.release_fire()
            self.log("GUNGAME: typing stinnett (move with the gatling)")
            return True
        w = next((w for w in inv["weapons"] if w["slot"] == gungame.slot_for(self.gg_rung)), None)
        slot_now = gungame.slot_for(self.gg_rung)
        low = (w is not None and slot_now in gungame.AMMO_ITEM and w.get("capacity")
               and (w.get("loaded") or 0) + (w.get("reserve") or 0) < 2 * w["capacity"])      # top the ammo up
        knives = ((w.get("loaded") or 0) + (w.get("reserve") or 0)) if w else 0          # as knife_throw counts them
        if slot_now == KNIFE_SLOT and w is not None and knives < 2:
            low = True                                  # out of knives to throw: more
        if (w is None or not self.usable(w) or low or (w["slot"] == TNT_SLOT and itemlib.tnt_count(inv) <= 0)) \
                and now - self.gg_spawn_at > 1.0:
            self.gg_cheat_at = now - 4.0                # a retry after 4 s
            self.gg_check_at = now + 1.5
            slot = gungame.slot_for(self.gg_rung)
            try:
                res = self.bot.api.give(gungame.GIVE.get(slot, []))
            except Exception as e:
                res = f"error {e}"
            self.log("GUNGAME: inventory " + ", ".join(f"{x['slot']}:{x.get('loaded')}/{x.get('reserve')}" for x in inv["weapons"]))
            self.log(f"GUNGAME: gave {gungame.NAMES[slot]}: {res}")
            return True
        return False

    def check_kills(self, me, others, now):
        """A random taunt for each enemy that dies on our account: it was our target a moment ago, we had the fire
        button down at it, or one of our sticks went off where it died."""
        prev, self.was_dead = self.was_dead, {p["addr"]: p["dead"] for p in others}
        if self.taunts_on and self.taunt_queue and now >= self.taunt_at:
            self.taunt_queue -= 1
            self.taunt_at = now + 2.5          # leave the last one time to play
            sound = self.taunt_rng.choice(self.taunt_sounds) if self.taunt_sounds else None
            ok = False
            if sound:
                try:
                    ok = bool(self.bot.api.set_taunt(1, sound))       # g_taunt1 = this sound
                except Exception:
                    ok = False
            self.log(f"g_taunt1 = {sound}" if ok else "g_taunt1 not set; playing whatever F1 has")
            self.f1_at = now + 0.15                                 # let the game see the new value first
        if self.taunts_on and getattr(self, "f1_at", None) is not None and now >= self.f1_at:
            self.f1_at = None
            self.log("taunt: F1")
            self.tap("f1")
        for p in others:
            if not p["dead"] or prev.get(p["addr"]) is not False or self.is_ally(me, p):
                continue
            ours = (self.target_addr == p["addr"] and now - self.last_visible < 1.5 and bool(self.fire_held)) \
                or (self.target_addr == p["addr"] and now - self.last_visible < 0.6) \
                or (now - self.boom_at < 1.5 and self.boom_pos is not None
                    and math.dist(self.boom_pos, (p["x"], p["y"], p["z"])) < 40.0)
            if ours and self.gg:
                self.gg_move(+1, f"killed {p['addr']}")
            if ours and self.taunts_on:
                if not self.taunt_queue:
                    self.taunt_at = max(self.taunt_at, now + self.taunt_rng.uniform(0.3, 0.8))
                self.taunt_queue = min(self.taunt_queue + 1, 4)
                self.log(f"killed {p['addr']}")

    def stick_done(self, me, now):
        """Our stick is gone (went off): log where, against the target and us."""
        w, self.tnt_watch = self.tnt_watch, None
        last = w["last"]
        if last is None:
            self.log("TNT: lost track of the stick")
            return
        self.boom_at, self.boom_pos = now, (last["x"], last["y"], last["z"])
        msg = f"TNT: went off {now - w['lit_at']:.1f}s after lighting, {flat_dist(me, last):.0f} from us"
        t = next((p for p in self.bot.all_players if p["addr"] == w["target"]), None)
        if t is not None:
            d = math.dist((last["x"], last["y"], last["z"]), (t["x"], t["y"] + t["height"] / 2, t["z"]))
            msg += f", {d:.0f} from the target (~{tnt.damage(d):.1f} damage before armour)"
        self.log(msg)

    # -- one tick -------------------------------------------------------------------------------------
    def tick(self, now):
        for key in list(self.tapped):           # every tap lasts exactly one tick
            self.bot.press(key, False)
            self.tapped.discard(key)

        try:
            me, others = self.bot.players()
        except RuntimeError:
            me, others = None, []
        own = self.bot.self_state or {}
        health = me["health"] if me else own.get("health")
        self.end_match(now)                # horde host: end the match when asked (it sits in the "lobby" the whole game)
        self.watch_match_end(now)
        self.session(now)                  # map rotation: continue / host / join the next match when asked
        if self.join_lobby(now):           # in the lobby our player may exist, parked below the map
            return
        self.check_upgrade(now)
        self.apply_speed(now)
        if me is not None and not me.get("dead") and self.died_at is None:
            self.spawn_armor(now)
        if self.leave_game(now):           # horde: asked to leave through the pause menu before the window closes
            return
        if self.bench:
            self.bench.note(now, self.bot.all_players, self.bot.game, self.bot.level_key)

        # Our own death: wait a moment, then press E until we're back. While dead there may be no live
        # player actor at all (ours turned into a corpse), so this goes by PlayerData health.
        if health is not None and health <= 0:
            if self.died_at is None:
                self.died_at = now
                self.log("died")
                if self.lms:
                    self.lms_deaths += 1
                    if self.lms_deaths >= self.lms and not self.lms_out:
                        self.lms_out = True
                        self.log(f"LMS: eliminated after {self.lms_deaths} death(s)")
                if self.gg:
                    self.gg_move(-1, "died")
                    self.gg_stin = False
                if self.tnt_phase is not None:
                    self.log(f"TNT: died during the throw ({self.tnt_phase})")
                self.tnt_reset()
                self.set_keys(set())
                self.bot.api.set_look(0, 0)
                self.stop_reload()
                self.release_fire()
            if self.cheat_keys:                   # finish the script (close the console) before pressing E
                self.run_cheat(now)
                self.next_respawn_press = max(self.next_respawn_press, now + 0.5)
                return
            if now - self.died_at > self.skill.respawn_delay and not self.lms_out and not self.sitting_out(now) \
                    and now >= self.next_respawn_press:
                self.tap("e")
                self.next_respawn_press = now + 1.0
            return
        if me is None:
            self.set_keys(set())                # not in a match, or between levels
            self.release_fire()
            return
        if self.died_at is not None:
            self.log("respawned")
            self._armor_given, self._armor_stage = False, 0
            self.gg_spawn_at = now
            self.high_reached = 0
            self.died_at, self.last_seen, self.target_addr, self.route = None, None, None, None
            self.visible_since = None
            self.bench_decided = False
            self.inv_names, self.had_badge = None, False     # a respawn resets the inventory: not news
            self.item_goal = None                            # the old trip's progress means nothing now
            self.camp_set, self.camp_spot, self.camp_since, self.camp_fails = False, None, None, 0
            for a in [a for a, t in self.ignored_items.items() if t > now]:
                if any(i["addr"] == a and "BADGE" in (i.get("name") or "") for i in self.bot.items):
                    del self.ignored_items[a]
            self.slot_seen = None                            # and brings the weapon up again
            self.wet, self.under_since, self.above_since, self.surfacing = False, None, None, False
            self.left_water_at, self.water_route = -1e9, None
            if self.bench and self.bench.out:   # alive without pressing E: a new level started
                self.bench.leave()
                self.log("back in: new level")
        self.my_team = me.get("team")
        if self.waiting_for_players(now, others):
            self.set_keys(set())
            self.release_fire()
            return

        self.ensure_level(me, others)
        if self.gg and not self.cheat_keys and self.gg_tick(me, now):
            return
        if self.cellar_escape(me, now):
            return
        self.note_team(me)
        self.note_water(me, now)
        self.note_height(me, now)
        living = [p for p in others if not p["dead"]]
        enemies = [] if self.passive else [p for p in living if not self.is_ally(me, p)]
        self.check_kills(me, others, now)
        if self.ranked:
            self.rank_watch(me, others, now)
        if self.stats_on:
            self.stats_tick(me, others, now)
        if os.environ.get("BOT_TRACKLOG") and now - getattr(self, "track_at", 0.0) > 1.0:
            self.track_at = now                    # movement sampling for pathing tests: tag,time,x,z,alive
            try:
                with open(os.environ["BOT_TRACKLOG"], "a") as f:
                    f.write(f"{os.environ.get('BOT_TAG', '?')},{time.time():.1f},{me['x']:.1f},{me['z']:.1f},{int(not me.get('dead'))}\n")
            except OSError:
                pass
        if os.environ.get("BOT_TRACEFMT") or (self.stats_on and self.stats_obs):
            self.fmt_pump(now)
        if os.environ.get("BOT_DUMPITEMS") and not getattr(self, "dumped", False):
            self.dump_t0 = getattr(self, "dump_t0", now)
            if now - self.dump_t0 > 20.0:
                self.dumped = True
                try:
                    import json
                    res = self.bot.api.dump_items()
                    with open(f"itemdump_{self.level_name or 'unknown'}.json", "w") as f:
                        json.dump(res, f)
                    self.log(f"ITEMDUMP: {len((res or {}).get('items') or [])} ground items")
                except Exception as e:
                    self.log(f"ITEMDUMP failed: {e}")
        self.allies_now = [p for p in living if self.is_ally(me, p)]
        visible = [p for p in enemies if p.get("visible")]
        def tscore(p):                        # handover step 6: distance plus twice the height difference
            return flat_dist(me, p) + 2.0 * abs(p["y"] - me["y"])

        target = min(visible, key=tscore) if visible else None
        if target is not None and self.target_addr is not None and target["addr"] != self.target_addr:
            # Stick with the current target unless another is a third nearer (no flip-flopping between two enemies).
            cur = next((p for p in visible if p["addr"] == self.target_addr), None)
            if cur is not None and tscore(target) > tscore(cur) * (2.0 / 3.0):
                target = cur
        if self.pool is not None and self.pool_tick(me, now, target):
            return
        self.note_inventory(me.get("inventory"))
        self.use_medbag(health, me.get("inventory"), now, engaged=target is not None)
        self.update_flee(health, now, target, me)
        objective = self.ctf_objective(me, living)
        self.track(living, now)
        if not self.wet:
            self.top_speed = max(self.top_speed, min(40.0, math.hypot(me.get("vx") or 0.0, me.get("vz") or 0.0)))
        slot = (me.get("inventory") or {}).get("slot")
        if slot != self.slot_seen:
            self.slot_seen, self.slot_since = slot, now
        if self.bot.lit:
            self.lit_works = True
        self.watch_stick(me, now)
        if self.tnt_phase is not None:
            # A throw under way goes on, target in sight or not: a lit stick has to leave our hand.
            self.tnt_fight(me, now, target)
            return
        if self.wet:
            if self.swim(me, now, target):
                return
            target = self.shore_target        # in the water we only fight hand to hand (swim())

        if target is None:
            if now - self.last_visible > self.skill.sight_memory:
                self.visible_since = None
            self.release_fire()
            self.manage_weapon(me, now, None, engaged=False)    # reload / pick weapons while hunting
            if self.gatling_camp(me, now, enemies):
                return
            if not self.wet and now < self.flee_until:
                # Out of the enemy's sight (behind cover): turn and run for the health or armor item.
                if self.seek_item(me, now, health_only=True):
                    return
            if self.dodge(me, now):
                return
            # Sapper: nobody in sight, but someone within a throw behind cover gets a stick lobbed at them.
            unseen = self.tnt_unseen_target(me, now, enemies) if not objective or not me.get("carries") else None
            if unseen is not None:
                self.tnt_fight(me, now, unseen)
                return
            if self.want_knife(me) and self.seek_item(me, now, knife_only=True):
                return
            if self.want_badge(me) and not self.wet and self.seek_item(me, now, badge_only=True):
                return
            if objective:
                # Fetch ammo or a weapon first only when we have nothing to fight with (and no flag).
                inv = me.get("inventory")
                if not me.get("carries") and inv and self.desperate(inv) and self.seek_item(me, now):
                    return
                # A boiler plate close by is worth the detour (user).
                if not me.get("carries") and self.seek_item(me, now, armor_only=True):
                    return
                self.go(me, now, objective, keep=self.objective_keep())
                return
            if self.seek_item(me, now):
                return
            if self.last_seen and flat_dist(me, self.last_seen) > 6:
                if self.go(me, now, self.last_seen):
                    return
            self.last_seen = None
            self.wander(me, now)
            return

        # Nothing good to fight with: go and get ammo or a weapon first, keeping an eye on the target.
        if not self.wet and me.get("inventory") and self.desperate(me["inventory"]):
            self.aim(me, target, flat_dist(me, target))
            if self.seek_item(me, now, aiming=True, knife_only=self.want_knife(me)):
                self.release_fire()
                return

        # A brawler without a knife goes for one lying about before anything else, and doesn't fight on the way
        # (user). With none on the map it fights with its fists.
        if (self.skill.knife_first and not self.wet and self.want_knife(me)
                and not (self.skill.berserk and flat_dist(me, target) < 40.0)
                and self.seek_item(me, now, knife_only=True)):
            self.release_fire()
            return

        # Marshall Law off: a far-off enemy isn't worth chasing while the badge is on the map.
        if (self.want_badge(me) and not self.wet and not self.camp_set and flat_dist(me, target) > 30.0
                and self.seek_item(me, now, aiming=True, badge_only=True)):
            return

        dist = flat_dist(me, target)
        self.camp_wait_since = None
        if target["addr"] != self.target_addr:
            self.target_addr = target["addr"]
            self.log(f"target -> {target['addr']} at {dist:.0f}")
        if self.visible_since is None:
            self.visible_since = now
        self.last_visible = now
        self.last_seen = {"x": target["x"], "y": target["y"], "z": target["z"]}

        if self.tnt_wanted(me, now):
            self.tnt_fight(me, now, target)
            return

        yaw_err, pitch_err = self.aim(me, target, dist)
        weapon, may_fire = self.manage_weapon(me, now, dist, engaged=True)
        fire_range = self.fire_range(weapon)
        if self.camp_set and dist >= fire_range and (weapon is None or weapon["slot"] != GATLING_SLOT):
            self.camp_set, self.camp_spot, self.camp_since = False, None, None      # shot at from beyond the Gatling's reach: leave the camp
            self.camp_off_until = now + 20.0
            self.log("Gatling camp over (an enemy out of its reach)")

        # Lined up: the aim error fits in the target's silhouette plus a degree, the weapon's spread
        # (pellets and fanned shots fan out, so the crosshair needn't be dead on) and Skill.aggression.
        # A shotgun shot leaves 0.1 s after the press while we keep turning toward the target, so part of
        # that turn counts as aimed too. Weapons that fire while held (pistol fanning and the like) keep
        # the button down through aim wobble instead: every release cuts the burst short.
        s = self.skill
        half_w = math.degrees(math.atan2(1.5, max(dist, 1.0)))                       # radius 1.5
        half_h = math.degrees(math.atan2(target["height"] / 2, max(dist, 1.0)))
        slack, turn = 1.0 + s.aggression, 0.0
        if weapon:
            slack += weapon.get("spread" if self.fire_button(weapon) == PRIMARY_FIRE else "spread2") or 0
            if weapon["slot"] in PUMP_SLOTS:
                turn = s.lead_turn * s.turn_speed * 0.1
            else:
                slack += s.hold_slack
        lined_up = abs(yaw_err) - turn < half_w + slack and abs(pitch_err) - turn < half_h + slack
        facing = abs(yaw_err) < s.queue_cone and abs(pitch_err) < s.queue_cone
        ready = (may_fire and now - self.visible_since > s.reaction + self.recheck_delay(dist) and dist < fire_range
                 and self.shot_gate(weapon, now))
        if not self.knife_throw(me, now, weapon, dist, lined_up):
            self.trigger(weapon, ready and lined_up, now, me.get("inventory"), queue=ready and facing)

        if not self.wet and not self.camp_set and now < self.flee_until and self.retreat(me, now, target):
            return                            # backing away, still firing

        if self.dodge(me, now, aiming=True):
            return

        # With the Gatling out we can't move: stand still and shoot.
        if me.get("inventory") and me["inventory"]["slot"] == GATLING_SLOT:
            self.set_keys(set())
            self.stuck_check = None
            return

        # Orleans without a knife: shoot back, but head for a knife rather than closing in.
        if self.want_knife(me) and self.seek_item(me, now, aiming=True, knife_only=True):
            return

        # A boiler plate close by: grab it, shooting on the way (user). Not with a flag to bring home.
        if not me.get("carries") and self.seek_item(me, now, aiming=True, armor_only=True):
            return

        # CTF: a flag carrier keeps heading for home, and nobody chases a far-off enemy away from the
        # objective; we shoot at them on the way.
        if objective and (me.get("carries") or dist > self.skill.ctf_chase):
            self.go(me, now, objective, aiming=True, keep=self.objective_keep())
            return

        # With the favourite weapon (or TNT) to hand, keep the behaviour's distance, backing off if they come close.
        fav = self.favorite_ready(me.get("inventory"))
        if fav and s.back_off and dist < s.back_off and self.back_away(me, now, target):
            return

        # Close in along a route (shotguns get closer), strafing while we aim.
        keep = min(s.keep_distance if fav else DEFAULT_KEEP,
                   fire_range * 0.6 if weapon is None or weapon["slot"] != TNT_SLOT else s.keep_distance)
        inv_now = me.get("inventory") or {}
        w6 = next((w for w in inv_now.get("weapons", []) if w["slot"] == SAWED_SLOT), None)
        if w6 and not self.bot.marshall_law and self.usable(w6) and not self.camp_set and dist < 40.0:
            keep = 3.0                      # the sawed-off wants them point blank
        self.go(me, now, target, aiming=True, keep=keep, strafe=dist < keep * 2 or (dist >= fire_range and s.hop_frac > 0))

    # -- teams and CTF --------------------------------------------------------------------------------
    def is_ally(self, me, p):
        """A player we must not shoot: same team in a team mode. In the holder modes (everyone but the
        holder shares team 2) same-team players only count as allies while the game blocks the damage."""
        team = me.get("team") or 0
        if team == 0 or p.get("team") != team:
            return False
        game = self.bot.game or {}
        return game.get("mode") in TEAM_MODES or not game.get("teamDamage")

    def sitting_out(self, now):
        """While dead: whether to stay dead to keep the teams even (see bench.py). Decided once per death,
        then rechecked while sitting out."""
        if not self.bench:
            return False
        if not self.bench_decided:
            self.bench_decided = True
            return self.bench.at_death(now, self.my_team)
        return self.bench.still_out(now, self.my_team)

    CELLAR_WALK = 20.0             # seconds spent trying to walk out of the cellar before the tombstone
    CELLAR_PATIENCE = 4.0          # seconds down in the cellar before giving up on it
    CHEAT_KILL = "oltombstone"     # the cheat typed during play; in the console it is "tombstone"

    @staticmethod
    def console_chord(t):
        """ctrl+alt+backquote, which toggles the game console, starting at offset t."""
        return [(t, "d", "lctrl"), (t + 0.05, "d", "lalt"), (t + 0.12, "d", "backquote"), (t + 0.2, "u", "backquote"),
                (t + 0.25, "u", "lalt"), (t + 0.3, "u", "lctrl")]

    @staticmethod
    def plain_console(t):
        """The backquote key by itself toggles the game console (the chord also works, but is flaky after a respawn)."""
        return [(t, "d", "backquote"), (t + 0.1, "u", "backquote")]

    def cheat_script(self, use_console, code=None):
        """(offset s, op, arg) steps. Console: open it, type tombstone, Enter, close it. Otherwise: type the cheat
        as key presses during play (the game takes ol<cheat> typed at any time)."""
        if use_console:
            word = code[2:] if code and code.startswith("ol") else (code or "tombstone")
            chord = self.plain_console if code else self.console_chord      # gun game (code given): the plain key
            return (chord(0.0) + [(0.9, "t", word), (1.2, "d", "return"), (1.3, "u", "return")]
                    + chord(2.0))
        return [(0.12 * i, "k", c) for i, c in enumerate(code or self.CHEAT_KILL)]

    def run_cheat(self, now):
        """Carry on with the cheat script (see cheat_script). Also runs while we are dead: the cheat kills us before
        the console has been closed again, and a console left open eats the E presses that respawn us."""
        t = now - self.cheat_start
        while self.cheat_keys and self.cheat_keys[0][0] <= t:
            _, op, arg = self.cheat_keys.pop(0)
            if op == "d":
                self.bot.press(arg, True)
            elif op == "u":
                self.bot.press(arg, False)
            elif op == "t":
                self.bot.type_text(arg)
            elif op == "k":
                self.set_keys(set())      # first: it would let go of an 's' typed this tick
                self.tap(arg)

    def cellar_escape(self, me, now):
        """On a map with a cellar the bots can't climb out of (nav.CELLAR; its sectors are off limits in routing), a
        bot that spawned or fell down there kills itself with the tombstone cheat (no score lost) and respawns. The
        first try uses the console, the second types the cheat as key presses, the third the console again.
        Returns True while it is busy (the rest of the tick is skipped)."""
        if self.cheat_keys:                   # a script is running: (offset, op, arg) steps
            self.run_cheat(now)
            return True
        level = self.level
        if level is None or not getattr(level, "cellar", None):
            self.cellar_since = None
            return False
        sector = level.locate(me["x"], me["y"], me["z"])
        if sector not in level.cellar:
            self.cellar_since, self.cheat_tries = None, 0
            return False
        if self.cellar_since is None:
            self.cellar_since = now
        # First try to simply walk (and jump) out: the tombstone is for a bot that really can't get out.
        out = level.walk_out(sector, me) if now - self.cellar_since < self.CELLAR_WALK else None
        if out is not None:
            if now - self.cellar_walk_log > 10.0:
                self.cellar_walk_log = now
                self.log(f"in the cellar: walking out toward ({out[0]:.0f}, {out[1]:.0f})")
            goal = {"x": out[0], "z": out[1]}
            self.look_toward(me, bearing(me, goal), 0)
            keys = {"w", "lshift"}
            if level.sectors[sector].ceiling - me["y"] < 8.0:
                keys = {"w", "lctrl"}                    # low ceiling down there: crouch along it
            elif flat_dist(me, goal) < 6.0 or self.stalled(now, me):
                keys |= self.jump_keys(now)
            self.set_keys(keys)
            return True
        if (now - self.cellar_since > self.CELLAR_PATIENCE and now - self.cheat_done_at > 15.0
                and self.cheat_tries < 3):
            self.cheat_tries += 1
            use_console = self.cheat_tries != 2
            self.set_keys(set())
            self.release_fire()
            self.cheat_keys = self.cheat_script(use_console)
            self.cheat_start = now
            self.cheat_done_at = now
            self.log("stuck in the cellar: " + ("typing tombstone in the console" if use_console
                                                 else f"typing {self.CHEAT_KILL}"))
            return True
        return False

    def waiting_for_players(self, now, others):
        """Whether we're still holding off at the start for the others to join (see wait_for). Counts living
        players only: corpses would inflate it once the early joiners fight each other. Once the count is
        reached the grace countdown runs to the end: the early joiners keep killing each other, so the living
        count dips all the time and restarting the countdown on every dip held us back for minutes."""
        if not self.wait_for:
            return False
        joined = sum(1 for p in others if not p["dead"])
        if self.wait_started is None:
            self.wait_started = now
            self.log(f"waiting for {self.wait_for} player(s) to join (at most {self.wait_max:.0f}s)")
        if self.wait_full is None and joined >= self.wait_for:
            self.wait_full = now
            self.log(f"{joined} player(s) in; starting in {self.JOIN_GRACE:.0f}s")
        if self.wait_full is not None:
            if now - self.wait_full < self.JOIN_GRACE:
                return True
            self.log("go")
        else:
            if now - self.wait_started < self.wait_max:
                return True
            self.log(f"only {joined} of {self.wait_for} player(s) joined after {self.wait_max:.0f}s; starting anyway")
        self.wait_for = None
        return False

    def join_lobby(self, now):
        """In the lobby, waiting for our pick: press Join, or Join Red / Join Blue in a team game
        (bot.team_pref, default red). Returns whether we're in the lobby."""
        lobby = getattr(self.bot, "lobby", None)
        if not lobby or lobby["state"] != LOBBY_STATE or lobby["pick"] != 0:
            self.lobby_since = None
            return False
        if self.passive:                       # the horde host stays in the lobby: no team pick, just reads the kill feed
            self.set_keys(set())
            if not getattr(self, "_human_seen", False) and os.environ.get("BOT_RUN") and \
                    any(p.get("team") == RED and not p.get("dead") for p in (self.bot.all_players or [])):
                self._human_seen = True                # somebody is on the Survivors (red) team: horde.py starts the music
                try:
                    from pathlib import Path
                    (Path(__file__).resolve().parent / "state" / f"human_{os.environ['BOT_RUN']}.flag").write_text("in")
                except OSError:
                    pass
                self.log("a player is on the Survivors team")
            if self.stats_on and self.stats_obs:
                self.fmt_pump(now)
            return True
        if self.lobby_since is None:
            self.lobby_since = now
            self.set_keys(set())
            self.release_fire()
        if os.environ.get("BOT_HOLD_JOIN"):    # horde: stay in the lobby (not spawned) until horde.py says we're attached and it's our turn
            from pathlib import Path
            if not (Path(__file__).resolve().parent / "state" / f"go_{os.environ.get('BOT_RUN', '')}_{os.environ.get('BOT_TAG', '')}.flag").exists():
                if not getattr(self, "_hold_logged", False):
                    self._hold_logged = True
                    self.log("lobby: holding until released")
                return True
        if now - self.lobby_since >= self.skill.lobby_delay and now - self.lobby_pressed >= 3.0:
            team = getattr(self.bot, "team_pref", None) or "red"
            pick = (LOBBY_BLUE if team == "blue" else LOBBY_RED) if lobby["mode"] in TEAM_MODES else LOBBY_JOIN
            self.bot.api.lobby_join(pick)
            self.lobby_pressed = now
            self.log({LOBBY_JOIN: "lobby: join", LOBBY_RED: "lobby: join red", LOBBY_BLUE: "lobby: join blue"}[pick]
                     + f" (game mode {lobby['mode']})")
        return True

    def note_team(self, me):
        game = self.bot.game or {}
        seen = (me.get("team"), game.get("mode"))
        if seen != self.team_seen:
            self.team_seen = seen
            self.log(f"team {TEAM_NAMES.get(seen[0], seen[0])}, game mode {seen[1]}"
                     f"{' (capture the flag)' if seen[1] == CTF_MODE else ''}"
                     f"{', team damage on' if game.get('teamDamage') else ''}")

    def ctf_objective(self, me, living):
        """Where to go in capture the flag, or None outside CTF. In order: bring the enemy flag home if we
        carry it; return our own flag if it lies dropped somewhere; take the enemy flag if nobody on our
        side has it; otherwise go after whoever carries our flag (a capture needs our flag at our base),
        or escort our carrier."""
        game = self.bot.game or {}
        ctf, team = game.get("ctf"), me.get("team")
        if os.environ.get("BOT_NO_FLAGS"):            # survival on a map with no team mode: CTF teams, the flags ignored
            return self.set_objective(None)
        if game.get("mode") != CTF_MODE or not ctf or team not in (RED, BLUE):
            return self.set_objective(None)
        own, enemy = (ctf["red"], ctf["blue"]) if team == RED else (ctf["blue"], ctf["red"])
        if not own.get("base") or not enemy.get("base"):
            return self.set_objective(None)
        own_bit, enemy_bit = (1, 2) if team == RED else (2, 1)          # carries: bit 0 red, bit 1 blue
        own_taker = next((p for p in living if p.get("carries", 0) & own_bit), None)
        enemy_taker = next((p for p in [me] + living if p.get("carries", 0) & enemy_bit), None)
        # A flag lying away from its base as a ground item (GRFLAG / GBFLAG) is a dropped one. Checked
        # alongside the game's flag pointer in case a dropped flag is a new actor the pointer doesn't follow.
        def flag_at(side, name):
            away = [it for it in self.bot.items
                    if it.get("name") == name and flat_dist(it, side["base"]) > FLAG_HOME]
            return away[0] if away else side.get("flag")
        own_name, enemy_name = ("GRFLAG", "GBFLAG") if team == RED else ("GBFLAG", "GRFLAG")
        own_flag, enemy_flag = flag_at(own, own_name), flag_at(enemy, enemy_name)
        if me.get("carries", 0) & enemy_bit:
            return self.set_objective("bring their flag home", own["base"])
        if own_taker is None and own_flag and flat_dist(own_flag, own["base"]) > FLAG_HOME:
            return self.set_objective("return our dropped flag", own_flag)
        if enemy_taker is None:
            return self.set_objective("take their flag", enemy_flag or enemy["base"])
        if own_taker is not None:
            return self.set_objective("chase our flag carrier", own_taker)
        return self.set_objective("escort our carrier", enemy_taker)

    STATS_NEAR = 60.0              # enemies this close to a dying human might have killed them (else: a suicide)
    STATS_KILL = 35.0              # a bot dying with the human the nearest enemy within this: the human's kill

    SUICIDE_MSGS = (("committed suicide!", "suicide"), ("died from a fall!", "fall"), ("drowned!", "drowned"),
                    ("got crushed!", "crushed"), ("got telefragged!", "telefrag"), ("self-destructed!", "self-destruct"))

    def fmt_pump(self, now):
        """Read the game's own message text (kill feed) once a second; log it when BOT_TRACEFMT is set and feed the stats."""
        if not getattr(self, "fmt_on", False):
            self.fmt_on = True
            self.log(f"TRACEFMT: {self.bot.api.trace_format()}")
        if now - getattr(self, "fmt_at", 0.0) > 1.0:
            self.fmt_at = now
            for line in self.bot.api.drain_formats() or []:
                if os.environ.get("BOT_TRACEFMT"):
                    self.log("FMT: " + line)
                if line.startswith("G ") and self.stats_on and self.stats_obs:
                    self.stats_message(line[2:].strip(), now)

    def stats_message(self, text, now):
        """One kill-feed line. The observing bot sees everyone in the third person ('A killed B!', 'A fell...'), and
        'A killed you!' when it is the victim itself."""
        import re as _re
        from pathlib import Path
        d = Path(__file__).resolve().parent / "state"
        mj = _re.match(r"^(.+) joined the (?:game|red team|blue team|Survivors|Horde)!$", text)   # team games say which team
        if mj:
            name = mj.group(1)
            bots = {self.my_display}
            for f in d.glob("name_*.txt"):
                try:
                    bots.add(f.read_text().strip())
                except OSError:
                    pass
            if name not in bots and name not in self.st_joined:
                self.st_joined.append(name)
            return
        if self.st_name is None:
            bots = {self.my_display}
            for f in d.glob("name_*.txt"):
                try:
                    bots.add(f.read_text().strip())
                except OSError:
                    pass
            humans = [n for n in self.st_joined if n not in bots]
            if not humans:                                 # not seen joining: the first name in a kill line that isn't one of ours
                for g in (_re.match(r"^(.+) killed you!$", text), _re.match(r"^(.+) blew you up!$", text),
                          _re.match(r"^(.+) blew up (.+)!$", text), _re.match(r"^(.+) killed (.+)!$", text)):
                    if g:
                        humans = [n for n in g.groups() if n not in bots and n != "you"
                                  and not _re.match(r"^(Zombie|Bot|Host Bot)( \d+)?$", n)]
                        break
            if humans:
                self.st_name = humans[0]
                self.log(f"STATS: human is '{self.st_name}' (exact counting from the game's messages)")
        if self.st_name is None:
            return
        if text == self.st_last_msg[0] and now - self.st_last_msg[1] < 0.4:
            return                                         # the same line twice in a moment
        self.st_last_msg = (text, now)
        me, ex = self.st_name, self.st_ex
        def death(cause, suicide):
            # The game credits a fall or a blast of your own to the nearest zombie ("Zombie 3 killed you!"). The position
            # watcher (below) saw the fall / the explosion with nobody near a moment before or after: that was a suicide.
            est = getattr(self, "st_est", None)
            if not suicide and est and not est[2] and abs(now - est[0]) < 4.0:
                est[2] = True
                cause, suicide = est[1], True
            ex["deaths"] += 1
            ex["causes"][cause] = ex["causes"].get(cause, 0) + 1
            if suicide:
                ex["suicides"] += 1
            self.st_last_exact = [now, cause, suicide]
            self.log(f"STATS: {me} died: {cause} (kills {ex['kills']}, deaths {ex['deaths']}, suicides {ex['suicides']})")
        def kill(victim):
            ex["kills"] += 1
            self.log(f"STATS: {me} killed {victim} (kills {ex['kills']})")
        m = _re.match(r"^(.+) killed you!$", text) or _re.match(r"^(.+) blew you up!$", text)
        if m:
            if m.group(1) == me:
                kill("the observer")
            return
        m = _re.match(r"^(.+) blew up (.+)!$", text) or _re.match(r"^(.+) killed (.+)!$", text)
        if m:
            killer, victim = m.groups()
            if killer == me and victim != me:
                kill(victim)
            elif victim == me:
                death("killed by " + ("explosion" if " blew up " in text else "a player"), killer == me)
            return
        if not text.startswith(me + " "):
            return
        rest = text[len(me) + 1:]
        for tail, cause in self.SUICIDE_MSGS:
            if rest == tail:
                death(cause, True)
                return
        if rest == "blew up!":
            death("blew themselves up", True)
        elif rest == "Got shot to death!":
            death("shot to death", False)
        elif rest == "died!":
            death("died", False)

    def stats_tick(self, me, others, now):
        """Launcher games: every bot publishes its position (state/pos_<pid>.txt); the hosting bot finds the human as
        the player actor no bot is standing on, follows their deaths (suicide when no enemy was within STATS_NEAR) and
        the bots that die next to them (an estimated kill), and saves it all to ranked.db as an unranked game."""
        from pathlib import Path
        d = Path(__file__).resolve().parent / "state"
        if now - self.st_pos_at > 0.5 and not os.environ.get("BOT_STATS_HIDE"):
            self.st_pos_at = now
            try:
                d.mkdir(exist_ok=True)
                (d / f"pos_{os.getpid()}.txt").write_text(f"{me['x']:.1f} {me['z']:.1f} {me['y']:.1f} {time.time():.2f}")
                (d / f"name_{os.getpid()}.txt").write_text(self.my_display)
            except OSError:
                pass
        if not self.stats_obs:
            return
        t = time.time()
        pos = []
        for f in d.glob("pos_*.txt"):
            if f.name == f"pos_{os.getpid()}.txt":
                continue
            try:
                x, z, y, ts = map(float, f.read_text().split())
            except (OSError, ValueError):
                continue
            if t - ts < 3.0:
                pos.append((x, z))
        for p in others:                                   # actors standing where a bot says it is are bots (remembered)
            if p["addr"] not in self.st_bots and any(math.hypot(p["x"] - x, p["z"] - z) < 8.0 for x, z in pos):
                self.st_bots.add(p["addr"])
        humans = [p for p in others if p["addr"] not in self.st_bots]
        if self.st_human is None and humans:
            alive_h = [p for p in humans if not p["dead"]]
            if alive_h and now - self.st_t0 > 20.0 and pos:      # bots have had time to publish their positions
                self.st_human = alive_h[0]["addr"]
                self.st_sid = f"{t:.0f}-{os.getpid()}"
                self.log("STATS: human is actor " + self.st_human)
        if self.st_human is None:
            return
        team = me.get("team") or 0
        h = next((p for p in others if p["addr"] == self.st_human), None)
        alive = h is not None and not h["dead"]
        if alive:
            self.st_team = h.get("team") or 0
        def near_enemies(x, z, y, skip, radius=None):
            n = 0
            ht = getattr(self, "st_team", 0)
            tm = (self.bot.game or {}).get("mode") in TEAM_MODES
            for p in list(others) + [me]:
                if p.get("addr") == skip or p.get("dead") or (tm and ht and p.get("team") == ht):
                    continue
                if math.hypot(p["x"] - x, p["z"] - z) < (radius or self.STATS_NEAR) and abs(p["y"] - y) < 25.0:
                    n += 1
            return n
        if alive:
            self.st_last = (h["x"], h["z"], h["y"])
            self.st_hist = [q for q in getattr(self, "st_hist", []) if t - q[0] < 2.5] + [(t, h["y"], h.get("vy") or 0.0)]
            if any(math.hypot(e["x"] - h["x"], e["z"] - h["z"]) < 14.0 and abs(e["y"] - h["y"]) < 10.0
                   for e in self.bot.explosives):
                self.st_expl_at = t
        if self.st_alive and not alive and self.st_last:
            self.st_deaths += 1
            n = near_enemies(*self.st_last, skip=self.st_human)
            n_close = near_enemies(*self.st_last, skip=self.st_human, radius=40.0)
            hist = getattr(self, "st_hist", [])
            fell = bool(hist) and (hist[-1][2] < -45.0 or max(q[1] for q in hist) - hist[-1][1] > 18.0)
            exploded = t - getattr(self, "st_expl_at", -99.0) < 3.0 and n_close == 0
            cause = "fall" if fell else "explosion with nobody near" if exploded else "nobody near" if n == 0 else "enemy"
            if cause != "enemy":
                self.st_suic += 1
            if cause in ("fall", "explosion with nobody near"):
                lx = getattr(self, "st_last_exact", None)
                if lx and not lx[2] and abs(now - lx[0]) < 4.0:      # the game's message came first: change that death into a suicide
                    lx[2] = True
                    ex_ = self.st_ex
                    ex_["suicides"] += 1
                    ex_["causes"][lx[1]] = max(0, ex_["causes"].get(lx[1], 1) - 1)
                    ex_["causes"][cause] = ex_["causes"].get(cause, 0) + 1
                    self.log(f"STATS: {self.st_name} reclassified: {cause}")
                else:
                    self.st_est = [now, cause, False]
            self.log(f"STATS: human died near={n} cause={cause} (deaths {self.st_deaths}, suicides {self.st_suic})")
        self.st_alive = alive
        if h is not None and alive:
            for p in others:                               # bots dying next to the human
                if p["addr"] == self.st_human or p["addr"] not in self.st_bots:
                    continue
                was = self.st_dead.get(p["addr"], False)
                self.st_dead[p["addr"]] = p["dead"]
                if p["dead"] and not was:
                    ds = [(math.hypot(q["x"] - p["x"], q["z"] - p["z"]), q) for q in list(others) + [me]
                          if q["addr"] != p["addr"] and not q.get("dead")]
                    ds.sort(key=lambda a: a[0])
                    if ds and ds[0][0] < self.STATS_KILL and ds[0][1]["addr"] == self.st_human:
                        self.st_kills += 1
                        self.log(f"STATS: human kill (estimated) {self.st_kills}")
        if now - self.st_saved > 10.0 and not os.environ.get("BOT_STATS_NOSAVE"):
            self.st_saved = now
            try:
                import ranked
                ex = self.st_ex if self.st_name else None          # exact counts when the game's own messages are readable
                ranked.save_session(self.st_sid, os.environ["BOT_STATS_PLAYER"], os.environ.get("BOT_STATS_CHAR", ""),
                                    self.level_name or "unknown", ex["kills"] if ex else self.st_kills,
                                    ex["deaths"] if ex else self.st_deaths, self.st_t0,
                                    ex["suicides"] if ex else self.st_suic, False, ex["causes"] if ex else None)
            except Exception as e:
                self.log(f"STATS: could not save: {e}")

    def rank_watch(self, me, others, now):
        """Horde stats: the red team is the human. Log 'RANK: player died near=N' when their actor dies or vanishes for
        a moment (N = enemies within 60 units of where they were last seen alive; 0 means nobody was near enough to
        have killed them: their own TNT, a fall, a crush) and 'RANK: player alive' when they are back."""
        red = [p for p in others if p.get("team") == RED and p.get("team") != me.get("team")]
        alive = [p for p in red if not p["dead"]]
        if alive:
            p = alive[0]
            self.rank_seen_at, self.rank_gone_at = now, None
            self.rank_last = (p["x"], p["z"], p["y"])
            if self.rank_present is False:
                self.log("RANK: player alive")
            self.rank_present = True
        elif self.rank_present:
            if self.rank_gone_at is None:
                self.rank_gone_at = now
            elif now - self.rank_gone_at > 1.0:
                self.rank_present = False
                near = 0
                if getattr(self, "rank_last", None):
                    lx, lz, ly = self.rank_last
                    near = sum(1 for p in list(others) + [me]
                               if p.get("team") != RED and not p.get("dead") and math.hypot(p["x"] - lx, p["z"] - lz) < 60.0
                               and abs(p["y"] - ly) < 25.0)
                self.log(f"RANK: player died near={near}")

    def objective_keep(self):
        """How close to get to the objective: stay a few units off a teammate we escort."""
        return 6.0 if self.objective and self.objective[0] == "escort our carrier" else 1.0

    def set_objective(self, label, where=None):
        if label is None:
            self.objective = None
            return None
        if self.objective is None or self.objective[0] != label:
            self.log(f"CTF: {label}")
        goal = {"x": where["x"], "y": where["y"], "z": where["z"]}
        self.objective = (label, goal)
        return goal

    # -- main loop ------------------------------------------------------------------------------------
    def run(self, seconds=None):
        end = None if seconds is None else time.time() + seconds
        self.bot.api.set_look_step(200)         # the brain limits turn speed itself
        try:
            while end is None or time.time() < end:
                started = time.time()
                self.tick(started)
                time.sleep(max(0.0, self.TICK - (time.time() - started)))
        finally:
            if self.bench:
                self.bench.leave()           # stops counting as sitting out; the game copy stays dead
            self.set_keys(set())
            self.stop_reload()
            self.release_fire()
            for key in list(self.tapped):
                self.bot.press(key, False)
            self.tapped.clear()
            self.bot.api.set_look(0, 0)
            self.bot.api.set_look_step(15)
