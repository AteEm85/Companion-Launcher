@echo off
cd /d "%~dp0"
taskkill /IM OutlawsAHOM.exe /F >nul 2>&1
timeout /t 2 /nobreak >nul
".venv\Scripts\python.exe" teamcolors.py off
timeout /t 3 >nul
