"""Pathing check: plays bots alone on each map and reports where they got stuck.

    pathcheck.cmd                      every map, 4 minutes each
    pathcheck.cmd --minutes 2 --maps hargrove fort
    pathcheck.cmd --report-only        just rebuild the report from the data already collected

Close your own Outlaws window first: the script ends every OutlawsAHOM.exe between maps.
Results: pathcheck_report.txt (read this) and pathcheck_data.csv (every stuck event: map, bot, time, kind, x, y, z).
The x/z values are the game's world coordinates, the same ones the bots print in their logs.
"""
import argparse
import collections
import subprocess
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE / "tntcheck_data.csv"
REPORT = HERE / "tntcheck_report.txt"
LOGS = HERE / "tntcheck_logs"
BOTS = ["pc1:sanchez:sapper", "pc2:mary", "pc3:james"]
CELL = 8.0                                  # stuck events within this many units count as one place


def run_quiet(*cmd):
    subprocess.run(list(cmd), capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def kill_everything(procs):
    for p in procs:
        run_quiet("taskkill", "/PID", str(p.pid), "/T", "/F")
    run_quiet("taskkill", "/IM", "OutlawsAHOM.exe", "/F")


def pump(p, path):
    with open(path, "w", errors="replace") as f:
        for line in p.stdout:
            f.write(line)
            f.flush()


def play_map(level, mode, minutes, env):
    LOGS.mkdir(exist_ok=True)
    procs = []

    def start(i, host):
        cmd = [sys.executable, "-u", str(HERE / "botctl.py"), BOTS[i], "--slot", str(i), "--fps", "60",
               "--size", "320x180", "--fight", "--no-taunts", "--window-mode", "hidden", "--no-bench"]
        if host:
            cmd += ["--host", "--map", level, "--mode", mode, "--wait-for", "0"]
        else:
            cmd += ["--join", "127.0.0.1"]
        e = dict(env, BOT_TAG=BOTS[i].split(":")[0], PYTHONUNBUFFERED="1")
        p = subprocess.Popen(cmd, cwd=str(HERE), env=e, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, errors="replace", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        threading.Thread(target=pump, args=(p, LOGS / f"{level}_{BOTS[i].split(':')[0]}.log"), daemon=True).start()
        procs.append(p)
        return p

    try:
        host = start(0, True)
        log0 = LOGS / f"{level}_pc1.log"
        end = time.time() + 150
        while time.time() < end and host.poll() is None:          # the host's lobby is up once it has attached
            time.sleep(2)
            try:
                if "attached to" in log0.read_text(errors="replace"):
                    break
            except OSError:
                pass
        if host.poll() is not None:
            print(f"  the host bot exited early (see {log0.name})")
            return False
        time.sleep(12)
        for i in range(1, len(BOTS)):
            start(i, False)
            time.sleep(8)
        print(f"  {len(BOTS)} bots playing for {minutes} min...")
        end = time.time() + minutes * 60
        while time.time() < end:
            time.sleep(5)
        return True
    finally:
        kill_everything(procs)
        time.sleep(4)


def build_report():
    rows = []
    if DATA.exists():
        for line in DATA.read_text().splitlines():
            parts = line.split(",")
            if len(parts) == 7:
                try:
                    rows.append((parts[0], parts[1], float(parts[2]), parts[3], float(parts[4]), float(parts[5]),
                                 float(parts[6])))
                except ValueError:
                    pass
    out = ["Pathing check report", "=" * 20, "",
           "Each place is where bots stopped making progress (stuck) or gave up on a route (give-up).",
           "Coordinates are world x, y (height), z. Give-ups are the strongest signal: a route the map data says is",
           "open but the bot could not get through.", ""]
    by_map = collections.defaultdict(list)
    for r in rows:
        by_map[r[0]].append(r)
    if not by_map:
        out.append("No stuck events were recorded.")
    for level in sorted(by_map):
        cells = collections.defaultdict(list)
        for r in by_map[level]:
            cells[(round(r[4] / CELL), round(r[6] / CELL))].append(r)
        ranked = sorted(cells.values(), key=lambda c: (-sum(1 for r in c if r[3].startswith("giveup")), -len(c)))
        out.append(f"{level}: {len(by_map[level])} events in {len(cells)} places")
        for c in ranked[:12]:
            n_give = sum(1 for r in c if r[3].startswith("giveup"))
            xs = sorted(r[4] for r in c)
            ys = sorted(r[5] for r in c if r[5])
            zs = sorted(r[6] for r in c)
            med = lambda v: v[len(v) // 2]
            who = len({r[1] for r in c})
            out.append(f"   x={med(xs):7.1f}  z={med(zs):7.1f}  y={med(ys) if ys else float('nan'):6.1f}   "
                       f"{len(c)} times ({n_give} give-ups), {who} bot(s)")
        out.append("")
    REPORT.write_text("\n".join(out))
    return "\n".join(out)


PHASES = [("TheDip1s", "dm", ["pc1:sanchez:sapper", "pc2:mary", "pc3:james"]),
          ("Stone", "team", ["pc1:sanchez:sapper:red", "pc2:mary:red", "pc3:james:blue"])]


def summarise():
    out = ["TNT check", "=" * 9, ""]
    for level, mode, bots in PHASES:
        out.append(f"{level} ({mode})")
        for b in bots:
            f = LOGS / f"{level}_{b.split(':')[0]}.log"
            try:
                lines = [l.rstrip() for l in f.read_text(errors="replace").splitlines() if "TNT" in l or "teammate" in l]
            except OSError:
                lines = ["(no log)"]
            out.append(f"  {b}: {len(lines)} TNT lines")
            out += ["    " + l for l in lines[:60]]
        out.append("")
    REPORT.write_text("\n".join(out))
    return "\n".join(out)


def main():
    global BOTS
    ap = argparse.ArgumentParser()
    ap.add_argument("--minutes", type=float, default=3.0)
    args = ap.parse_args()
    sys.path.insert(0, str(HERE))
    print("Close your own Outlaws window now: it gets ended between maps.")
    import os
    for level, mode, bots in PHASES:
        BOTS = bots
        print(f"{level} ({mode}): {bots}")
        env = dict(os.environ, BOT_MAP=level, BOT_NO_GATLING="1")
        play_map(level, mode, args.minutes, env)
        summarise()
    print(summarise())
    print(f"\nSaved to {REPORT}")


if __name__ == "__main__":
    main()
