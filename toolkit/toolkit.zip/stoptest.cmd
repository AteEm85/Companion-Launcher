@echo off
rem Ends a test run: every Outlaws copy (the bots' and yours) and the test scripts (botctl, rotation, follow, hostnext, horde, ghosts, autojoin, missiontest).
rem The launcher itself is left alone.
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'OutlawsAHOM.exe' -or ($_.Name -eq 'python.exe' -and $_.CommandLine -match 'botctl\.py|rotation\.py|follow\.py|hostnext|horde\.py|ghost\.py|autojoin\.py|missiontest\.py') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
