"""Propose jump links from the bot logs.   python linkscan.py MAP [logdir]   (e.g. python linkscan.py civpow2)

Reads "STUCK at (x, z) sector N" lines (bots run with BOT_STUCK_LOG, as the pathcheck scripts do), groups them by sector,
and for each sector with repeated stucks looks for a higher sector close by that the router has no edge to. Those are
written to nav_links_proposed.json in the nav_links.json format, with the reason, for you to read, test and copy over
into nav_links.json (never applied by itself)."""
import json
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
STUCK = re.compile(r"STUCK at \((-?[\d.]+), (-?[\d.]+)\) sector (\d+)")
MIN_STUCKS = 3
MAX_RISE = 9.0
MAX_GAP = 9.0


def stucks(logdir):
    spots = defaultdict(list)
    for p in Path(logdir).glob("*.log"):
        for line in p.read_text(errors="replace").splitlines():
            m = STUCK.search(line)
            if m:
                spots[int(m.group(3))].append((float(m.group(1)), float(m.group(2))))
    return spots


def bounds(sec):
    xs = [v[0] for v in sec.vertices]
    zs = [v[1] for v in sec.vertices]
    return min(xs), max(xs), min(zs), max(zs)


def gap_between(a, b):
    ax0, ax1, az0, az1 = bounds(a)
    bx0, bx1, bz0, bz1 = bounds(b)
    dx = max(bx0 - ax1, ax0 - bx1, 0.0)
    dz = max(bz0 - az1, az0 - bz1, 0.0)
    return math.hypot(dx, dz)


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def propose(key, logdir):
    import lvt
    import nav
    sectors = lvt.load(key)
    lvl = nav.Level(sectors, lvt.load_inf(key), name=key)
    out, notes = [], []
    for idx, pts in sorted(stucks(logdir).items(), key=lambda kv: -len(kv[1])):
        if len(pts) < MIN_STUCKS or idx >= len(sectors) or not sectors[idx].walls:
            continue
        here = sectors[idx]
        linked = {e.to for e in lvl.edges.get(idx, ())}
        cx = sum(p[0] for p in pts) / len(pts)
        cz = sum(p[1] for p in pts) / len(pts)
        best = None
        for o in sectors:
            if not o.walls or o.index == idx or o.index in linked or o.index in lvl.no_go:
                continue
            rise = o.floor - here.floor
            gap = gap_between(here, o)
            if 2.0 < rise <= MAX_RISE and gap <= MAX_GAP and o.index in lvl.main:
                score = gap + rise
                if best is None or score < best[0]:
                    best = (score, o, rise, gap)
        if best:
            _, o, rise, gap = best
            x0, x1, z0, z1 = bounds(o)[0], bounds(o)[1], bounds(o)[2], bounds(o)[3]
            land = (round(clamp(cx, x0 + 1, x1 - 1), 1), round(clamp(cz, z0 + 1, z1 - 1), 1))
            out.append({"from": idx, "to": o.index, "landing": list(land), "takeoff": [round(cx, 1), round(cz, 1)],
                        "rise": round(rise, 1), "gap": round(gap, 1), "stucks": len(pts)})
            notes.append(f"sector {idx} ({len(pts)} stucks near {cx:.0f},{cz:.0f}): jump to {o.index}, {rise:.1f} up over a {gap:.1f} gap")
        else:
            notes.append(f"sector {idx} ({len(pts)} stucks near {cx:.0f},{cz:.0f}): nothing close to jump to")
    return out, notes


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    key = sys.argv[1]
    logdir = sys.argv[2] if len(sys.argv) > 2 else HERE / "botlogs"
    out, notes = propose(key, logdir)
    proposal = {key: {"gaps": [[o["from"], o["to"], o["landing"], o["takeoff"]] for o in out],
                      "_why": out}}
    (HERE / "nav_links_proposed.json").write_text(json.dumps(proposal, indent=1))
    print("\n".join(notes) or "no sector with repeated stucks")
    print(f"{len(out)} link(s) proposed in nav_links_proposed.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
