@echo off
rem Start or re-attach bots. See botctl.py for the options, e.g.:  bots sanchez mary bob --fight
rem The first run makes a Python venv next to this file (.venv) and installs requirements.txt into it.
rem (No ( ) blocks here: a game folder under "Program Files (x86)" has a ")" in its path, which would end the block early.)
set "VENV=%~dp0.venv"
if exist "%VENV%\Scripts\python.exe" goto run
echo setting up the bots' Python in "%VENV%" ...
py -3 -m venv "%VENV%" 2>nul
if exist "%VENV%\Scripts\python.exe" goto install
python -m venv "%VENV%"
if exist "%VENV%\Scripts\python.exe" goto install
echo Python 3 not found; install it from python.org (tick "Add python.exe to PATH")
exit /b 1
:install
"%VENV%\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r "%~dp0requirements.txt"
if not errorlevel 1 goto run
echo could not install the requirements (see the error above)
rmdir /s /q "%VENV%"
exit /b 1
:run
"%VENV%\Scripts\python.exe" "%~dp0botctl.py" %*
