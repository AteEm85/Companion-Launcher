@echo off
rem Start or re-attach bots. See botctl.py for the options, e.g.:  bots sanchez mary bob --fight
rem The first run makes a Python venv next to this file (.venv) and installs requirements.txt into it.
set "VENV=%~dp0.venv"
if not exist "%VENV%\Scripts\python.exe" (
    echo setting up %VENV% ...
    py -3 -m venv "%VENV%" 2>nul || python -m venv "%VENV%" || (echo Python 3 not found; install it from python.org & exit /b 1)
    "%VENV%\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r "%~dp0requirements.txt" || (rmdir /s /q "%VENV%" & exit /b 1)
)
"%VENV%\Scripts\python.exe" "%~dp0botctl.py" %*
