"""Look-while-dead probe, round 3 (lookprobe3.cmd): where the mouse up/down value goes missing while dead.\nRound 2 (lookprobe2.cmd). Round 1 found the pitch is written at Steam 0xb8cc3 alive and dead; this one
shows which way the look code decides at each step, alive and dead.

Look-while-dead probe: finds the game code that turns the mouse into looking up/down, and what stops it while you are dead.

Attaches to YOUR game copy only (the one without -userpath; the bots' copies are left alone), finds your player in memory the
way the bots' agent does (the player physics routine's first argument), and puts two hardware watchpoints on it: one on the
pitch (up/down) and one on the heading (left/right). Every time the game writes either one it notes which instruction did it
(and the calls that led there), separately for alive and dead. Once a second it notes whether you are dead and where you look.

Nothing in the game is changed: it only watches. Writes state\\lookprobe.txt.

  python lookprobe.py [seconds]      (default 240)
"""
import json
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

import frida

HERE = Path(__file__).resolve().parent
OUT = HERE / "state" / "lookprobe3.txt"
SECS = float(sys.argv[1]) if len(sys.argv) > 1 else 240.0

JS = r"""
// Round 3 (Steam build only): where the mouse's up/down value is read, stored and used, alive and dead. Round 2: counts which way the game's look code goes at each decision, alive and dead, with the values it
// decides on. Addresses are inside the player physics routine (Steam 0xb68f0): pitch is written at 0xb8cc3 ([r13+0x44]).
const exe = Process.mainModule;
const stamp = exe.base.add(exe.base.add(0x3c).readU32() + 8).readU32();
if (stamp !== 0x6a39ed68) send({ kind: 'error', message: 'this probe knows the Steam build only (0x' + stamp.toString(16) + ')' });
let actor = null;
const counts = {}, samples = {};
const G = { g5a0: 0x13545a0, g570: 0x1354570, g59c: 0x135459c, g574: 0x1354574, g53c: 0x135453c };
function dead() { try { return (actor.add(0x10).readU32() & 0x4000) !== 0; } catch (e) { return null; } }
function note(name, ctx, extra) {
  const k = name + ' | ' + (dead() ? 'dead' : 'alive');
  counts[k] = (counts[k] || 0) + 1;
  if (!samples[k]) samples[k] = [];
  if (samples[k].length < 6 && counts[k] % 40 === 1) {
    const v = {};
    try { v.rsp48 = ctx.rsp.add(0x48).readFloat(); } catch (e) {}
    try { v.rbp_48 = ctx.rbp.sub(0x48).readS32(); v.rbp_4c = ctx.rbp.sub(0x4c).readS32(); } catch (e) {}
    for (const g in G) { try { v[g] = exe.base.add(G[g]).readS32(); } catch (e) {} }
    try { v.pitch = actor.add(0x44).readS16(); } catch (e) {}
    Object.assign(v, extra || {});
    samples[k].push(v);
  }
}
Interceptor.attach(exe.base.add(0xb68f0), { onEnter(a) { actor = a[0]; } });
const POINTS = {
  0xb69d4: 'S1 0xb69d4 mouse-y slot cleared at the start',
  0xb7867: 'K 0xb7867 keyboard-turn path (no mouse look)',
  0xb791a: 'M 0xb791a mouse-look path',
  0xb792c: 'R 0xb792c mouse-y read from the input',
  0xb7958: 'S2 0xb7958 mouse-y stored',
  0xb7bdb: 'S3 0xb7bdb mouse-y stored (other path)',
  0xb7ef8: 'X 0xb7ef8 xmm11 reloaded',
  0xb7fba: 'S4 0xb7fba mouse-y stored (copy)',
  0xb864f: 'S5 0xb864f mouse-y set to a constant',
  0xb85c7: 'U1 0xb85c7 mouse-y used',
  0xb85ff: 'U2 0xb85ff mouse-y used',
  0xb865d: 'U3 0xb865d mouse-y used'
};
for (const a in POINTS) {
  const name = POINTS[a];
  try {
    Interceptor.attach(exe.base.add(parseInt(a)), function () {
      const c = this.context;
      const x = { ebx: c.rbx.toInt32() };
      try { x.in_dx = c.r11.add(0x8).readFloat(); x.in_dy = c.r11.add(0xc).readFloat(); } catch (e) {}
      try { x.r14_2c = c.r14.add(0x2c).readFloat(); } catch (e) {}
      note(name, c, x);
    });
  } catch (e) { send({ kind: 'error', message: 'could not watch ' + name + ': ' + e }); }
}
setInterval(function () {
  const c = Object.assign({}, counts); for (const k in counts) delete counts[k];
  const s = samples; for (const k in samples) delete samples[k];
  send({ kind: 'tick', dead: actor ? dead() : null, counts: c, samples: JSON.parse(JSON.stringify(s)) });
}, 1000);
send({ kind: 'ready', build: 'Steam' });
"""


def own_game_pid():
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='OutlawsAHOM.exe'\" | "
          "ForEach-Object { '{0}|{1}' -f $_.ProcessId, $_.CommandLine }")
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True, timeout=30)
    mine = [int(l.split("|", 1)[0]) for l in r.stdout.splitlines() if l.strip() and "-userpath" not in l]
    return mine[0] if mine else None


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    print("waiting for your own game (start it, get into a match)...")
    pid = None
    for _ in range(300):
        pid = own_game_pid()
        if pid:
            break
        time.sleep(2)
    if not pid:
        print("your game was not found"); return
    print(f"watching your game (pid {pid}) for {SECS:.0f} s: die a few times and move the mouse up and down while dead")
    log = open(OUT, "w", encoding="utf-8")
    total = Counter(); last_state = [None]

    def on_msg(msg, data):
        if msg.get("type") == "error":
            print("script error:", msg.get("description")); log.write("script error: %s\n" % msg.get("description")); return
        pl = msg.get("payload") or {}
        k = pl.get("kind")
        if k in ("ready", "armed", "error"):
            print(k, {x: y for x, y in pl.items() if x != "kind"}); log.write(json.dumps(pl) + "\n"); log.flush(); return
        if k == "tick":
            st = "dead" if pl.get("dead") else "alive"
            if st != last_state[0]:
                print(f"you are {st}"); last_state[0] = st
            log.write(f"{time.strftime('%H:%M:%S')} {st:5s} " + json.dumps(pl.get("counts")) + "\n")
            for kk, v in (pl.get("samples") or {}).items():
                for smp in v: log.write(f"      {kk}: {json.dumps(smp)}\n")
            for kk, v in (pl.get("counts") or {}).items():
                total[kk] += v
            log.flush()

    s = frida.get_local_device().attach(pid)
    sc = s.create_script(JS)
    sc.on("message", on_msg)
    sc.load()
    t_end = time.time() + SECS
    try:
        while time.time() < t_end:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    log.write("\n== totals (decision point | alive/dead): count\n")
    for kk, v in total.most_common(80):
        log.write(f"{v:7d}  {kk}\n")
    log.close()
    try:
        sc.unload(); s.detach()
    except Exception:
        pass
    print(f"done: {OUT}")


if __name__ == "__main__":
    main()
