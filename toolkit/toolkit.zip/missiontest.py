"""Seamless Co-op Mission test (missiontest.cmd), the launcher's part played by this script:
  1. horde.py runs mission 1 (Silent Night Siege); once its lobby is up your own game starts and joins it, with autojoin.py
     (the Survivors team) and follow.py attached, as the launcher does;
  2. the mission's steps are skipped one after another (the test cheat, state\\cheat_skip.flag; needs
     state\\mission_cheats.txt) until it is won;
  3. horde.py ends, leaving the host bot up (state\\chain_host.json); this script starts mission 2 at once, as the launcher
     will: the host bot should host mission 2's map in the same game and your game should follow by itself.
Then it waits 90 s in mission 2 and stops. Logs: state\\missiontest.txt (and horde_logs\\follow_log.txt)."""
import json
import subprocess
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
GAME = HERE.parent / "OutlawsAHOM.exe"
OUT = HERE / "state" / "missiontest.txt"
CHAIN = HERE / "state" / "missiontest_chain.json"
PY = sys.executable
log_f = open(OUT, "w", encoding="utf-8")


def w(msg):
    line = f"{time.strftime('%H:%M:%S')} {msg}"
    print(line, flush=True)
    log_f.write(line + "\n")
    log_f.flush()


def run_horde(mission, on_line):
    import os
    p = subprocess.Popen([PY, "-u", str(HERE / "horde.py"), "--map", "civpow2", "--minutes", "30", "--users", "1", "--mission", mission],
                         cwd=str(HERE), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace",
                         env=dict(os.environ, HORDE_CHAIN_FILE=CHAIN.name))     # (not mission_chain.json: an open launcher acts on that one)
    for line in p.stdout:
        line = line.rstrip()
        w(f"[{mission}] {line}")
        on_line(line)
    p.wait()
    w(f"[{mission}] horde.py ended ({p.returncode})")


def main():
    if not (HERE / "state" / "mission_cheats.txt").exists():
        w("state\\mission_cheats.txt is missing: the steps can't be skipped")
        return
    (HERE / "state" / "chain_host.json").unlink(missing_ok=True)
    CHAIN.unlink(missing_ok=True)
    st = {"game": None, "skipping": False, "won": False, "in2": False}

    def skipper():
        while not st["won"]:
            time.sleep(10)
            if st["skipping"] and not st["won"]:
                (HERE / "state" / "cheat_skip.flag").write_text("skip")

    def on1(line):
        if "lobby up" in line and st["game"] is None:
            st["game"] = subprocess.Popen([str(GAME), "-netdriver", "lan", "-skipintromovies", "-join", "127.0.0.1"], cwd=str(GAME.parent))
            w(f"your game started (pid {st['game'].pid})")
            subprocess.Popen([PY, "-u", str(HERE / "autojoin.py"), str(st["game"].pid), "red", str(HERE / "horde_logs" / "autojoin_log.txt")], cwd=str(HERE))
            subprocess.Popen([PY, "-u", str(HERE / "follow.py"), str(st["game"].pid), "red", str(HERE / "horde_logs" / "follow_log.txt")], cwd=str(HERE))
        if "mission step 1/" in line:
            st["skipping"] = True
        if "MISSION COMPLETE" in line:
            st["won"] = True

    threading.Thread(target=skipper, daemon=True).start()
    run_horde("siege", on1)
    try:
        chain = json.loads(CHAIN.read_text())
    except (OSError, ValueError):
        chain = {}
    w(f"mission chain: {chain}")
    try:
        w(f"host kept: {(HERE / 'state' / 'chain_host.json').read_text()}")
    except OSError:
        w("no host kept (state\\chain_host.json missing)")
    CHAIN.unlink(missing_ok=True)
    if not chain.get("next"):
        return
    t2 = time.time()

    def on2(line):
        if "lobby up" in line:
            w(f"mission 2 lobby up {time.time() - t2:.0f}s after mission 1 ended")
        if "mission step 1/" in line and not st["in2"]:
            st["in2"] = True
            w("mission 2 is running; stopping in 90 s")
            threading.Timer(90, lambda: subprocess.run(["cmd", "/c", str(HERE / "stoptest.cmd")])).start()

    st["won"] = True
    run_horde(chain["next"], on2)


if __name__ == "__main__":
    main()
