@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" labextract.py olobj.lab JAMES.NWX MARY.NWX Bobgrahm.NWX DRDEATH.NWX SANCHEZ.NWX TWOFEATH.NWX JAMES.ITM
".venv\Scripts\python.exe" labextract.py outlaws.lab OLPAL.PCX
echo.
echo Done. Tell Claude it finished.
pause
