"""Hosts a LAN bot game for the Outlaws Companion: companionhost.py settings.json
settings: kind ("bots" | "horde"), map, mode, count, difficulty, users (humans that will join, you included), horde ("normal"|"challenge"|"dark")
Starts the mod server (so friends' companions get the mods), clears leftover game copies, then runs botctl.py / horde.py
and passes their output on. Uses launcher.py's own argument builder so a hosted game matches the launcher's.
companionhost.py --cleanup   takes the Horde mods out again (zombie skins, team colours, Dark Mode map files),
                             waiting for every game window to close first. The companion runs it when hosting stops."""
import sys, os, json, subprocess, threading, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import launcher as L
import modserver


def game_running():
    try:
        out = subprocess.run(["tasklist"], capture_output=True, text=True, creationflags=L.NO_WINDOW).stdout.lower()
        return "outlawsahom.exe" in out
    except Exception:
        return False


def close_games(wait=20):
    """End every game copy and wait until they are really gone: horde.py skips the mods when it sees the game open."""
    subprocess.run(["taskkill", "/IM", "OutlawsAHOM.exe", "/F"], capture_output=True, creationflags=L.NO_WINDOW)
    end = time.time() + wait
    while game_running() and time.time() < end:
        time.sleep(1)
    time.sleep(1)


def cleanup(wait=True):
    """Put the game folder back: team colours, zombie skins and Dark Mode item files. Waits for the game to close."""
    while wait and game_running():
        time.sleep(5)
    time.sleep(2)
    for _ in range(20):
        ok = True
        try:
            import teamcolors
            if teamcolors.dirty():
                ok = bool(teamcolors.set_theme("off", quiet=True)) and ok
        except Exception as e:
            print("cleanup: team colours:", e, flush=True); ok = False
        try:
            import zombieskins
            ok = zombieskins.off() and ok
        except Exception as e:
            print("cleanup: zombie skins:", e, flush=True); ok = False
        try:
            import darkitems
            ok = bool(darkitems.restore()) and ok
        except Exception as e:
            print("cleanup: dark mode files:", e, flush=True); ok = False
        if ok:
            print("cleanup: game folder restored", flush=True); return True
        time.sleep(5)
    return False


def trim_loop():
    first = True
    while True:
        time.sleep(30)
        try:
            pids = L.bot_game_pids()
            if pids:
                n = L.trim_working_sets(pids)
                if first: print("trimming idle memory of %d of %d bot windows (every 30 s)" % (n, len(pids)), flush=True); first = False
        except Exception:
            pass


def main():
    if sys.argv[1:2] == ["--cleanup"]:
        sys.exit(0 if cleanup() else 1)
    cfg = json.load(open(sys.argv[1]))
    kind, mp = cfg.get("kind", "bots"), cfg.get("map", "drygulch")
    modserver.start(("dark" if cfg.get("horde") == "dark" else "horde") if kind == "horde" else cfg.get("mode", "dm"), mp)
    close_games()
    users = max(1, int(cfg.get("users", 1)))
    if kind == "horde":
        args = ["horde.py", "--map", mp, "--minutes", "10", "--users", str(users), "--player", cfg.get("player", "Player")]
        if cfg.get("horde") == "challenge": args.append("--challenge")
        if cfg.get("horde") == "dark": args.append("--dark")
        cmd = [sys.executable, "-u", os.path.join(HERE, args[0])] + args[1:]
    else:
        n = max(1, min(10, int(cfg.get("count", 3))))
        bots = [{"name": "", "char": L.CHAR_DEFAULT, "beh": L.BEH_DEFAULT, "team": "Auto"} for _ in range(n)]
        c = dict(count=n, mode=cfg.get("mode", "dm"), map=mp, bots=bots, difficulty=cfg.get("difficulty", "Normal"),
                 wait_for_me=False, wait_users=users, size="320x180", fps=60, window_mode="hidden",
                 real_names=False, timelimit=cfg.get("timelimit", ""), fraglimit=cfg.get("fraglimit", ""))
        cmd = [sys.executable, "-u", os.path.join(HERE, "botctl.py")] + L.build_args(c)
    if cfg.get("trim"):                 # Trim Idle Bot Memory: the bots' idle RAM goes to the page file every 30 s
        threading.Thread(target=trim_loop, daemon=True).start()
    p = subprocess.Popen(cmd, cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace",
                         env=dict(os.environ, PYTHONUNBUFFERED="1"), creationflags=L.NO_WINDOW)
    for line in p.stdout:
        print(line, end="", flush=True)
    code = p.wait()
    if code == 0 and kind != "horde":   # botctl with several bots only starts them and exits: keep the mod server up
        print("HOSTED: game is up", flush=True)
        threading.Event().wait()
    sys.exit(code)                      # horde.py only exits when the match is over (it has removed its mods itself)

if __name__ == "__main__":
    main()
