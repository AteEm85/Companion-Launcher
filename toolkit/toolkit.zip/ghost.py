"""Headless-player experiment: a stand-alone UDP client that joins a LAN host WITHOUT running the game.
Replays the recorded join handshake, waits for the host's spawn message, then creates its own player entity there
and sends movement packets (a recorded ~3 s walk, looped). Everything received is logged to state\\ghost\\ghost_rx.jsonl.

  python ghost.py [host_ip] [port] [host_player_name]     (default 127.0.0.1 5069 T4H_WaRRioR)
  env: GHOST_ID=4e (entity id, hex)   GHOST_STAY=40 (seconds to keep walking)
"""
import json, os, socket, struct, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
HOST = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 5069
HOSTNAME = (sys.argv[3] if len(sys.argv) > 3 else "T4H_WaRRioR").encode()
NAME = b"GhostBot_01"          # 11 chars (same length as the recorded name so inner fields stay valid)
GAME = b"Outlaws + Handful of Missions: Remaster"
GID = int(os.environ.get("GHOST_ID", "4e"), 16)
STAY = float(os.environ.get("GHOST_STAY", "60"))
D = json.load(open(os.path.join(HERE, "ghostscript2.json")))
RESP = json.load(open(os.path.join(HERE, "respawn_templates.json")))   # recorded respawn messages of a real client
HP = float(os.environ.get("GHOST_HP", "15"))           # damage units a ghost life can take (fits 2 recorded deaths; tune if needed)
REC_SPAWN = (struct.unpack("<f", bytes.fromhex("aef70444"))[0], struct.unpack("<f", bytes.fromhex("29fcf543"))[0])
out_dir = os.path.join(HERE, "state", "ghost"); os.makedirs(out_dir, exist_ok=True)
log = open(os.path.join(out_dir, "ghost_rx.jsonl"), "w")

def hdr(ln, fl): return struct.pack(">H", (ln << 4) | fl)
def split(b):
    out, i = [], 0
    while i + 2 <= len(b):
        v = struct.unpack(">H", b[i:i+2])[0]; ln = v >> 4
        if ln < 2 or i + ln > len(b): break
        out.append((v & 15, b[i:i+ln])); i += ln
    return out

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(("0.0.0.0", 0)); s.settimeout(0.02)
dst = (HOST, PORT)
t0 = time.time()
def log_rx(kind, data): log.write(json.dumps({"t": round(time.time() - t0, 3), "k": kind, "hex": data.hex()}) + "\n"); log.flush()

body = b"\x80\x08CRANTIME" + bytes([len(GAME)]) + GAME + b"\x01" + bytes([len(HOSTNAME)]) + HOSTNAME + bytes([len(NAME) + 4]) + NAME + b" (1)"
pkt = hdr(len(body) + 2, 0) + body
s.sendto(pkt, dst); log_rx("tx_connect", pkt); print("connect sent to", dst)

host_rel = 0; our_seq = 0; our_rel = 0
accepted = False; send_t0 = None; last_rx = time.time(); n_rx = 0
hand = list(D["hand"]); hi = 0
spawn_pos = None; spawned_at = None; spawn_wait_from = None; walker = None; next_state = 0
slot = 0x1802; hp = HP; alive = True; died_at = None; respawn_req = None; last_spawn = None; lives = 0; kills_taken = 0
pool = []

def send_msg(fl, b):
    global our_seq, our_rel
    our_seq += 1
    if fl == 3: our_rel += 1
    s.sendto(hdr(6 + len(b), fl) + struct.pack(">HH", our_seq & 0xFFFF, our_rel) + b, dst)

def ack(): s.sendto(hdr(6, 0) + b"\x82\x00" + struct.pack(">H", host_rel), dst)

def plain_of(m):
    h = m[6:]
    return h[1:] if h[:1] == b"\x00" else None       # compressed bodies are not needed here

def make_create(x, y, z, gid=None, slot=0x1802):
    b = bytearray(bytes.fromhex(D["spawn"][2]["b"]))
    b[18:22] = struct.pack("<I", GID if gid is None else gid); b[22:24] = struct.pack("<H", slot); b[30:34] = struct.pack("<f", x); b[34:38] = struct.pack("<f", y); b[38:42] = struct.pack("<f", z)
    return bytes(b)

import math
TEMPLATE = bytes.fromhex(D["life"][-1]["b"])          # a recorded movement packet, used as the frame
YAW_UNITS = 16384.0                                  # full circle in the packet's angle fields (measured)
SPEED = float(os.environ.get("GHOST_SPEED", "30"))   # 30 = walk (W only), ~44 = run
# route = list of (dx, dz) offsets from the spawn point; the ghost walks them in a loop, pausing at each one
ROUTE = [tuple(float(v) for v in p.split(",")) for p in os.environ.get("GHOST_ROUTE", "-60,-20;0,0").split(";")]

def make_state(x, y, z, yaw_rad, pitch_units, vx, vz, moving, dying=False):
    b = bytearray(TEMPLATE)
    if dying: b[57] = 0x41
    b[18:22] = struct.pack("<I", ((0x15 if dying else (1 if moving else 0)) << 16) | (GID & 0xFFFF))
    b[22:26] = struct.pack("<f", x); b[26:30] = struct.pack("<f", y); b[30:34] = struct.pack("<f", z)
    b[34:36] = struct.pack("<h", int(pitch_units)); b[36:38] = struct.pack("<H", int(round(yaw_rad / (2 * math.pi) * YAW_UNITS)) % int(YAW_UNITS))
    b[40:44] = struct.pack("<f", vx); b[44:48] = struct.pack("<f", 0.0); b[48:52] = struct.pack("<f", vz)
    return bytes(b)

class Walker:
    def __init__(self, sx, sy, sz):
        self.x, self.y, self.z = sx, sy, sz; self.sx, self.sz = sx, sz
        self.k = 0; self.yaw = 0.0; self.pitch = 0; self.pause_until = 0.0; self.last = None; self.moving = False; self.sweep = 1
    def target(self): dx, dz = ROUTE[self.k % len(ROUTE)]; return self.sx + dx, self.sz + dz
    def step(self, now):
        dt = 0.15 if self.last is None else min(now - self.last, 0.5); self.last = now
        if now < self.pause_until:
            self.moving = False
            return make_state(self.x, self.y, self.z, self.yaw, self.pitch, 0.0, 0.0, False), 1.0 if self.pitch == 0 else 0.3
        tx, tz = self.target(); dx, dz = tx - self.x, tz - self.z; d = math.hypot(dx, dz)
        if d < 1.5:                                   # arrived: pause, look up/down a little, go to the next point
            self.k += 1; self.pause_until = now + 2.0; self.sweep = -self.sweep; self.pitch = 900 * self.sweep; self.moving = False
            return make_state(self.x, self.y, self.z, self.yaw, self.pitch, 0.0, 0.0, False), 0.3
        self.pitch = 0; self.moving = True
        ux, uz = dx / d, dz / d; self.yaw = math.atan2(ux, uz)    # forward = (sin yaw, cos yaw) in the (x, z) plane (measured)
        stp = min(SPEED * dt, d); self.x += ux * stp; self.z += uz * stp
        return make_state(self.x, self.y, self.z, self.yaw, self.pitch, ux * SPEED, uz * SPEED, True), 0.15

while True:
    try: data, addr = s.recvfrom(4096)
    except socket.timeout: data = None
    except ConnectionResetError: print("host refused / not listening"); break
    now = time.time()
    if data:
        last_rx = now; n_rx += 1; log_rx("rx", data)
        got_rel = False
        for fl, m in split(data):
            if fl == 0 and b"CRANTIME" in m and not accepted:
                accepted = True; send_t0 = now; print("host accepted the connection")
            if fl == 0 and len(m) > 20 and m[2] == 0x83:
                s.sendto(hdr(11, 0) + b"\x83" + m[3:11][::-1], dst)       # ping: echo the 8 timestamp bytes reversed
            if fl == 3 and len(m) >= 6:
                rel = struct.unpack(">H", m[4:6])[0]
                if rel > host_rel: host_rel = rel; got_rel = True
            if fl in (2, 3):
                p = plain_of(m)
                if p and p[:1] == b"\x47" and len(p) >= 33:
                    ty = struct.unpack("<H", p[13:15])[0]
                    if ty == 0x407:
                        last_spawn = struct.unpack("<3f", p[21:33])
                        if spawn_pos is None: spawn_pos = last_spawn; print("host spawn point:", spawn_pos)
                    if ty == 0x413: respawn_req = p[17:]                     # host asks us to respawn (spawn info + model name)
                    if ty == 0x7d1 and len(p) >= 59 and alive and walker is not None and struct.unpack("<H", p[1:3])[0] == slot:
                        dmg = struct.unpack("<f", p[19:23])[0]; hp -= dmg
                        print(f"hit! damage {dmg:.2f}, health {max(hp, 0):.1f}/{HP:.0f}")
                        if hp <= 0: alive = False; died_at = now; print("ghost died")
        if got_rel: ack()
    if accepted:
        el = now - send_t0
        while hi < len(hand) and hand[hi]["t"] <= el:
            send_msg(hand[hi]["f"], bytes.fromhex(hand[hi]["b"])); hi += 1
        if hi >= len(hand):
            if spawn_wait_from is None: spawn_wait_from = now
            if spawned_at is None and (spawn_pos is not None or now - spawn_wait_from > 6):
                if spawn_pos is None:
                    spawn_pos = (REC_SPAWN[0], -0.5, REC_SPAWN[1]); print("no spawn message seen, using the recorded spawn point")
                for x in D["spawn"][:2]: send_msg(x["f"], bytes.fromhex(x["b"]))
                send_msg(2, make_create(*spawn_pos))
                walker = Walker(*spawn_pos); next_state = now; spawned_at = now
                print(f"ghost entity {GID:#x} created at {spawn_pos[0]:.0f},{spawn_pos[2]:.0f}; walking the route {ROUTE}")
            if spawned_at is not None:
                if now >= next_state:
                    if alive:
                        st, gap = walker.step(now); send_msg(2, st); next_state = now + gap
                    else:                                       # dying: stand still with the "dying" flag set
                        send_msg(2, make_state(walker.x, walker.y, walker.z, walker.yaw, 0, 0.0, 0.0, False, dying=True)); next_state = now + 0.3
                if not alive and now - died_at > 2.5 and (respawn_req is not None or now - died_at > 8):
                    lives += 1; slot += 1
                    pos = last_spawn or spawn_pos
                    t6 = bytearray(bytes.fromhex(RESP["out_3f6"][1])); t6[10:12] = struct.pack("<H", slot - 1)
                    if respawn_req is not None: t6[18:] = respawn_req                  # echo the host's spawn info
                    send_msg(2, bytes(t6))
                    t3 = bytearray(bytes.fromhex(RESP["out_3ff"][1])); t3[10:12] = struct.pack("<H", slot - 1); send_msg(3, bytes(t3))
                    send_msg(2, bytes.fromhex(RESP["out_3f1"][1])); send_msg(2, bytes.fromhex(RESP["out_3f7"][1]))
                    gid = 0x00150000 | (GID & 0xFFFF)
                    send_msg(2, make_create(pos[0], pos[1], pos[2], gid, slot))
                    GID = gid; walker = Walker(*pos); hp = HP; alive = True; respawn_req = None; next_state = now + 0.3
                    print(f"ghost respawned (life {lives + 1}) at {pos[0]:.0f},{pos[2]:.0f}")
                if now - spawned_at > STAY: print("done, rx packets:", n_rx); break
    elif now - t0 > 5:
        print("no answer from the host within 5 s (is a LAN game running, and is it on port", PORT, "?)"); break
    if now - last_rx > 10 and accepted:
        print("host went silent for 10 s (crashed or closed the connection?)"); break
print("log: state\\ghost\\ghost_rx.jsonl")
