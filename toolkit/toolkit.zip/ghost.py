"""Headless-player experiment: a stand-alone UDP client that joins a LAN host WITHOUT running the game.
Replays the recorded join handshake, waits for the host's spawn message, then creates its own player entity there
and sends movement packets (a recorded ~3 s walk, looped). Everything received is logged to GhostLogs\\ghost_rx.jsonl.

  python ghost.py [host_ip] [port] [host_player_name]     (default 127.0.0.1 5069 T4H_WaRRioR)
  env: GHOST_ID=4e (entity id, hex)   GHOST_STAY=40 (seconds to keep walking)
"""
import re, math, json, os, socket, struct, sys, time, base64, random
HERE = os.path.dirname(os.path.abspath(__file__))
# Run straight from the repo (botctl\netre\ghost.py), the recordings and the bots' modules (nav, brain, tnt, lvt) are one folder up;
# a deployed copy has them beside it (those win).
UP = os.path.dirname(HERE)
if UP not in sys.path: sys.path.append(UP)
def data_file(name):
    p = os.path.join(HERE, name)
    return p if os.path.exists(p) else os.path.join(UP, name)
# ghost_options.json beside this file: {"GHOST_RELAY": "0", ...} switches features for testing without code changes (it wins over the launcher's settings).
OPTIONS = {}
try:
    OPTIONS = {str(k): str(v) for k, v in json.load(open(os.path.join(HERE, "ghost_options.json"))).items() if not str(k).startswith("_")}
    os.environ.update(OPTIONS)
except FileNotFoundError: pass
except Exception as e: print("ghost_options.json unreadable:", e)
HOST = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 5069
HOSTNAME = (os.environ.get("GHOST_CONN") or (sys.argv[3] if len(sys.argv) > 3 else "T4H_WaRRioR")).encode()      # the first name in the connect packet: the host keeps ONE connection per name (a 2nd ghost with the same one replaces the 1st), so several ghosts need different ones (GHOST_CONN)
NAME = os.environ.get("GHOST_NAME", "GhostBot_01").encode()[:15]          # any length now (the recorded name's length byte is rewritten too)
print("LIVE me " + NAME.decode(errors="replace"), flush=True)     # (livestats.py: whose shot lines these are)
GAME = b"Outlaws + Handful of Missions: Remaster"
GID = int(os.environ.get("GHOST_ID", "4e"), 16)
STAY = float(os.environ.get("GHOST_STAY", "60"))
# ---- Game modes (horde.py --ghosts): the mode script talks to its ghosts through flag files in botctl\state, the same ones its bots read:
# go_<run>_<tag>.flag (let into the game: the ghost waits for it before connecting, GHOST_HOLD=1), level_<run>_<tag>.flag (a new tier:
# "hard" or "hard+strong"), leave_<run>_<tag>.flag / stop_<run> (leave the match). GHOST_FRIENDS: a regex of names the ghost never
# fights (its own side: the other zombies, the host bot). Deaths are logged like a bot's ("died", "FMT: G <killer> killed you!").
MODE_RUN, MODE_TAG = os.environ.get("GHOST_RUN", ""), os.environ.get("GHOST_TAG", "")
MODE_STATE = os.environ.get("GHOST_STATE_DIR") or os.path.join(os.path.dirname(HERE) if os.path.basename(HERE).lower() == "netre" else HERE, "state")
FRIENDS = re.compile(os.environ["GHOST_FRIENDS"].encode()) if os.environ.get("GHOST_FRIENDS") else None
def mode_flag(kind):
    return os.path.join(MODE_STATE, f"{kind}_{MODE_RUN}_{MODE_TAG}.flag")
if MODE_RUN and MODE_TAG and os.environ.get("GHOST_HOLD", "0") == "1":
    print("fighting; waiting to be let into the game", flush=True)          # (horde.py's release_when_ready waits for "fighting;")
    while not os.path.exists(mode_flag("go")):
        if os.path.exists(os.path.join(MODE_STATE, f"stop_{MODE_RUN}")) or os.path.exists(mode_flag("leave")): sys.exit(0)
        time.sleep(0.25)
    print("let into the game", flush=True)
D = json.load(open(data_file("ghostscript2.json")))
RESP = json.load(open(data_file("respawn_templates.json")))   # recorded respawn messages of a real client
# A player has 10 (the HUD's 10 cards; the bots read 10 from the game too): in the user's Team Play captures two bots died at 10.7
# (the user's 3 hits) and 10.0 (5 pistol hits of 2). It was 20 (fitted to a punch test on the user's own Mary): twice a bot's life.
HP = float(os.environ.get("GHOST_HP", "10"))
# dynamite: the blast numbers (the user's own 24.0, the ghosts' blast_dmg) were tuned to 20 - a direct hit leaves Mary 1 card and kills
# the rest - so a blast counts half against the 10 (the same share of a life as before)
BLAST_TAKE = float(os.environ.get("GHOST_BLAST_TAKE", "0.5"))
_HP_OLD_NOTE = 20     # the user's Mary survived 15.1 and died at 24.9 (after her 0.8): a player has 20           # damage units a ghost life can take (fits 2 recorded deaths; tune if needed)
REC_SPAWN = (struct.unpack("<f", bytes.fromhex("aef70444"))[0], struct.unpack("<f", bytes.fromhex("29fcf543"))[0])
out_dir = os.path.join(HERE, "GhostLogs"); os.makedirs(out_dir, exist_ok=True)      # every ghost log (packets) goes here; the launcher puts each ghost's console log here too
log = open(os.path.join(out_dir, os.environ.get("GHOST_LOG", "ghost_rx") + ".jsonl"), "w")

def hdr(ln, fl): return struct.pack(">H", (ln << 4) | fl)
try:
    import zstdpy
except Exception:
    zstdpy = None

def split(b):
    out, i = [], 0
    while i + 2 <= len(b):
        v = struct.unpack(">H", b[i:i+2])[0]; ln = v >> 4
        if ln < 2 or i + ln > len(b): break
        out.append((v & 15, b[i:i+ln])); i += ln
    return out

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind((os.environ.get("GHOST_BIND", "0.0.0.0"), 0)); s.settimeout(0.02)      # GHOST_BIND=127.0.0.2: another source address (the host seems to key its players by address, so ghosts on one PC need different ones)
dst = (HOST, PORT)
t0 = time.time()
def log_rx(kind, data): log.write(json.dumps({"t": round(time.time() - t0, 3), "k": kind, "hex": data.hex()}) + "\n"); log.flush()

# GHOST_GUESTS=n (1..3): split-screen test. The engine (KEX) knows local guests: its lobby player info has IsGuest / IsSplitscreen, and there
# is "Kicking local player 0 is currently unsupported". Guess under test: the connect packet's byte before the names (always 01) is the
# number of players on this connection. With n guests it says 1+n and lists a name per guest ("GhostGuest1 (2)" ...); after the
# handshake each guest's name goes to the session list too (GHOST_GUEST_FD: a = fd <k> ..., b = fd 00 <k> ... like the host's own
# entries, none = not sent). Everything the host answers about it is printed and saved in GhostLogs\guest_test.json.
GUESTS = max(0, min(3, int(os.environ.get("GHOST_GUESTS", "0") or 0)))
GUEST_FD = os.environ.get("GHOST_GUEST_FD", "a").lower()
GUEST_REPORT_AT = float(os.environ.get("GHOST_GUEST_REPORT", "60"))     # seconds after the accept for the result summary
GUEST_NAMES = [b"GhostGuest" + str(k).encode() for k in range(1, GUESTS + 1)]
# Learned from the 1st guest test (7 Nov): the accept packet is CRANTIME <our position X> <every player's id>: 01|01 02 = we are 2,
# 03|01 02 03 04 = we are 4, 01|02 03 04 with a guest = host 2, us 3, guest 4. The host is NOT always id 1: with a guest on the
# connection its messages came relayed from 2 to (3, 4), and some to the guest (4) alone. HOST_ID is the first id of the list.
HOST_ID = 1; GUEST_IDS = []
body = b"\x80\x08CRANTIME" + bytes([len(GAME)]) + GAME + bytes([1 + GUESTS]) + bytes([len(HOSTNAME)]) + HOSTNAME + bytes([len(NAME) + 4]) + NAME + b" (1)"
for _k, _g in enumerate(GUEST_NAMES):
    _g = _g + f" ({_k + 2})".encode(); body += bytes([len(_g)]) + _g
pkt = hdr(len(body) + 2, 0) + body
s.sendto(pkt, dst); log_rx("tx_connect", pkt); print("connect sent to", dst)
print("ghost_options.json:", OPTIONS or "none (all defaults)")
GT = {"guests": GUESTS, "guest_fd": GUEST_FD, "connect_hex": pkt.hex(), "accept_hex": None, "accept_ids": None, "session": {}, "control": [],
      "guest_names_seen": [], "our_index_from_session": None, "our_cid": None}
GT_DONE = [False]
if GUESTS: print(f"GUEST TEST: the connect packet says {1 + GUESTS} players on this connection:", NAME.decode(), "+", ", ".join(g.decode() for g in GUEST_NAMES))
def guest_report(why):
    """GHOST_GUESTS: what the host made of the extra players (printed once, and saved for Claude to read)."""
    if not GUESTS or GT_DONE[0]: return
    GT_DONE[0] = True; GT["why"] = why; GT["our_cid"] = CID
    # The session list names a client by its connection name (GHOST_CONN), so a guest may show up as a guest name, as "... (2)",
    # as GUEST_..., or as our connection name a second time.
    ours = [i for i, n in names.items() if n == HOSTNAME]
    seen = [f"{i}: {n.decode(errors='replace')}" for i, n in sorted(names.items())
            if i in GUEST_IDS or b"guest" in n.lower() or re.search(rb"\((?:[2-9])\)$", n) or (n == HOSTNAME and len(ours) > 1)]
    GT["guest_names_seen"] = seen; GT["players_in_session"] = {i: n.decode(errors="replace") for i, n in sorted(names.items())}
    g_ = globals().get("GUEST") or {}
    GT.update(host_id=HOST_ID, guest_ids=GUEST_IDS, ghost_spawned=globals().get("spawned_at") is not None,
              guest_spawned=g_.get("spawned") is not None, guest_spawn_from_host=g_.get("spawn407"), guest_rx_types=g_.get("rx"),
              guest_hits=g_.get("hits"), guest_402_answers=g_.get("answered402"))
    print("=" * 70); print(f"GUEST TEST RESULT ({why})")
    print("  accept packet:", GT["accept_hex"] or "NONE (the host never accepted the connection)")
    print("  player ids in it:", GT["accept_ids"])
    print("  session list (index: key = value):")
    for k_, v_ in sorted(GT["session"].items()): print(f"    {k_} = {v_}")
    print("  guest names in the host's session list:", seen or "none")
    if GT["control"]: print("  other control messages from the host:", GT["control"][:10])
    print(f"  ids: host {HOST_ID}, ghost {CID}, guest(s) {GUEST_IDS}")
    print(f"  ghost body created: {GT['ghost_spawned']}   guest body created: {GT['guest_spawned']}"
          + (" (at the host's spawn point)" if GT["guest_spawn_from_host"] else ""))
    print(f"  messages for the guest alone: {GT['guest_rx_types'] or 'none'}   hits on the guest: {GT['guest_hits']}   entity requests answered: {GT['guest_402_answers']}")
    print("  verdict:", "the host LISTED a guest - split-screen guests reach the lobby" if seen else
          "no guest in the host's lists" + ("" if GT["accept_hex"] else " (and no accept: the host may reject a count above 1)"))
    print("=" * 70)
    try: json.dump(GT, open(os.path.join(out_dir, "guest_test.json"), "w"), indent=1)
    except Exception as e: print("could not save guest_test.json:", e)

host_rel = 0; our_seq = 0; our_rel = 0
host_acked = False; seen_host = None; seen_host_t = None; accepted = False; send_t0 = None; last_rx = time.time(); n_rx = 0
hand = list(D["hand"]); hi = 0
spawn_pos = None; spawned_at = None; spawn_wait_from = None; walker = None; next_state = 0
slot = int(os.environ.get('GHOST_SLOT', '1802'), 16)
# The recorded join hello and the 0x3f7 echoes carry the client's player id (a u64 plus the same number in base64). The recording was client 2, so three ghosts all claimed to be
# player 2: the host answered only the first one (its welcome, spawn reply 0x407 and the score list entry all went to ghost 1's connection). Every ghost gets its own id now: 2, 3, 4.
CID = int(os.environ.get('GHOST_CID') or (2 + ((slot - 0x1802) >> 8))); welcome_id = None
# Every message names its sender with an address the host gives each joining client in join order. Measured from a real game with three bot clients joining (netcap):
# host 0x0800, 1st client 0x1800 (player id 2), 2nd 0x2000 (id 3), 3rd 0x2800 (id 4): address = 0x800 * (id + 1); the entity slots follow it (0x1802, 0x2002, 0x2802).
# The recording was the first client, so all ghosts said 0x1800: the host sent their spawn answers to ghost 1's connection and never registered ghosts 2 and 3.
# The id is the last number of the host's accept packet (CRANTIME 01 01 02 = we are 2; 03 01 02 03 04 = we are 4), so it also stays right when bots are already in the game.
NS_OFF = os.environ.get("GHOST_NS", "1") == "0"          # GHOST_NS=0 = the old behaviour (every ghost 0x1800)
def set_identity(cid):
    global CID, NS, slot
    CID = cid; NS = 0x1800 if NS_OFF else 0x800 * (cid + 1); slot = NS | (slot & 0xFF)
NS = 0x1800
set_identity(CID)
hp = HP; last_hit_t = 0.0; alive = True; died_at = None; respawn_req = None; last_spawn = None; lives = 0; kills_taken = 0
pool = []

LEFT_BODY = []
def leave():
    """The clean leave real clients send; also on Ctrl+C and when the console window is closed (the host would otherwise wait ~20 s).
    (16 Nov, the user: after Santa came and the elves left, two elves still STOOD in a doorway on his game, off the scoreboard. The
    host takes a leaving player off the scoreboard, but the body each ghost relayed to the other games stays in them. Now the ghost
    removes its own body - at the host and relayed to every other game - before it says goodbye. GHOST_LEAVE_REMOVE=0: the old way.)"""
    if accepted and not LEFT_BODY and os.environ.get("GHOST_LEAVE_REMOVE", "1") == "1":
        LEFT_BODY.append(1)
        for _ in range(2):
            try: ent_destroy(slot)
            except Exception as ex_: print("could not remove our body:", ex_); break
            time.sleep(0.15)
        print(f"removed our body {slot:#x} from every game")
    if accepted:
        for _ in range(3):
            try: s.sendto(hdr(14, 0) + b"\xfe\x0adisconnect", dst)
            except OSError: pass
try:
    import ctypes
    _H = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_uint)
    def _on_console(ev):
        leave(); return 0                       # 0 = then the default action (end the program)
    _keep = _H(_on_console)
    ctypes.windll.kernel32.SetConsoleCtrlHandler(_keep, 1)
except Exception:
    pass

def send_msg(fl, b):
    global our_seq, our_rel
    our_seq += 1
    log_rx("tx", bytes([fl]) + b)
    if fl == 3: our_rel += 1
    s.sendto(hdr(6 + len(b), fl) + struct.pack(">HH", our_seq & 0xFFFF, our_rel) + b, dst)

def ack(): s.sendto(hdr(6, 0) + b"\x82\x00" + struct.pack(">H", host_rel), dst)

def unzstd(b):
    """a compressed body (7f <fl> [00] + a zstd frame) -> the plain message, or None. (11 Nov: the host sends the map's item list
    compressed, so the ghosts never knew there were rifles, shotguns or canteens to pick up; zstdpy.py is a decoder in plain Python.)"""
    j = b.find(b"\x28\xb5\x2f\xfd", 0, 6)
    if j < 0 or zstdpy is None: return None
    try: return zstdpy.decompress(b[j:])
    except Exception: return None

def plain_of(m):
    h = m[6:]
    if h[:1] == b"\x00": return h[1:]
    if h[:1] == b"\x7f": return unzstd(h)
    return None

def ns_fix(b):
    """recorded messages say the sender is 0x18xx (first client): rewrite those header ids to this ghost's own range"""
    if NS == 0x1800 or b[:2] != b"\x00\x47" or len(b) < 16: return b
    b = bytearray(b)
    for off in (2, 6, 10):
        v = struct.unpack("<H", b[off:off + 2])[0]
        if (v & 0xFF00) == 0x1800: b[off:off + 2] = struct.pack("<H", NS | (v & 0xFF))
    return bytes(b)

def with_cid(b, cid=None):
    """put this ghost's player id into a recorded message that carries one (u64 right before its base64 copy)"""
    cid = CID if cid is None else cid
    key = base64.b64encode(struct.pack("<Q", 2))
    i = b.find(key)
    if i < 8: return b
    b = bytearray(b); b[i - 8:i] = struct.pack("<Q", cid); b[i:i + len(key)] = base64.b64encode(struct.pack("<Q", cid))
    if bytes(b[14:16]) == b"\xf7\x03": b[18:22] = struct.pack("<I", cid + 1)        # the welcome echo also carries the next free id (host's welcome to the 2nd client was (4, host 1, id 3))
    return bytes(b)

# (13 Nov, a hosted game: a player said the ghosts couldn't hurt him. They hit him 163 times in that game and never once hurt him: his
#  bodies were numbered 0x50xx - the block of player 9, who had left - while he was player 10 (then 11 after rejoining). A real
#  client's block is NOT always 0x800 * (its id + 1): the game hands a newcomer the block a player who left was using. Every hit went
#  to player 9, who wasn't there. Now the block -> player id comes from who actually sends that block's messages (the relay's sender).)
NS_OWNER = {}
def addr_id(a):
    """player id of a sender address / slot: the host is 0x08xx (id 1), client k is normally 0x800*(k+1), but see NS_OWNER"""
    a &= 0xFFFF
    if (a >> 11) in NS_OWNER: return NS_OWNER[a >> 11]
    return 1 if (a >> 11) == 1 else (a >> 11) - 1

names = {}                 # player id -> name, from the host's session list (fd 00 <index> "playername" <name>)
# The session list is in join order with no gaps, but player ids are handed out in join order AND keep the gap a player who left
# leaves behind (11 Nov: the user left and came back; the list said index 2 = the user, index 3 = Normal 1, but the ids were
# ghost 3, user 4, Normal 1 5 ... so index + 1 named the user "Normal 1" and every kill of theirs read "Normal 1 killed ..."). So the
# names go to the ids in order: the k-th entry to the k-th smallest id among the players actually here. A victim's own kill message
# (0x40a $$code$$killer$$victim$$, sent by the victim) names its sender for certain, and overrides.
SESS_NAME = {}; SESS_TEAM = {}; LEARNED = {}; SEEN_IDS = {1}; REMAP_T = [0.0]
# (23 Nov, the user: in the second mission of a chain the enemies stopped shooting and the kills stopped counting) a host game
# that runs on from mission to mission has had dozens of players come and go, and the session list's order no longer lined up
# with the ids: the user got a ghost's name - a teammate to the enemies, and no kill message for their kills. Every ghost of a
# run says who it is in state/gid_<run>_<tag>.txt ("id\nname"); an id that is no ghost and not the host is a human, never named
# as one of the ghosts; when one human id is left without a name and one name in the list is no ghost's, that is theirs.
GIDS = {"t": 0.0, "ids": {}}
def gid_write():
    if not MODE_RUN or not MODE_TAG: return
    try:
        with open(os.path.join(MODE_STATE, f"gid_{MODE_RUN}_{MODE_TAG}.txt"), "w") as f: f.write(f"{CID}\n{NAME.rstrip(b'_').decode(errors='replace')}")
    except OSError: pass
def gid_clear():
    try: os.remove(os.path.join(MODE_STATE, f"gid_{MODE_RUN}_{MODE_TAG}.txt"))
    except OSError: pass
import atexit as _atexit
_atexit.register(gid_clear)
# (25 Nov: the launcher's Online tab counts only real players) every ghost touches state/alive_<pid>.txt every 5 s while it
# runs (modserver.bots_now counts the fresh ones), and takes it away when it ends
def _alive_loop():
    p_ = os.path.join(MODE_STATE, f"alive_{os.getpid()}.txt")
    while True:
        try:
            with open(p_, "w") as f: f.write(str(time.time()))
        except OSError: pass
        time.sleep(5)
def _alive_clear():
    try: os.remove(os.path.join(MODE_STATE, f"alive_{os.getpid()}.txt"))
    except OSError: pass
_atexit.register(_alive_clear)
if __name__ == "__main__":
    import threading as _th
    _th.Thread(target=_alive_loop, daemon=True).start()
def ghost_ids():
    """{player id: name} of this run's ghosts (read every 2 s)"""
    if not MODE_RUN: return {}
    t_ = time.time()
    if t_ - GIDS["t"] > 2.0:
        GIDS["t"] = t_; ids = {}
        try:
            for fn in os.listdir(MODE_STATE):
                if fn.startswith(f"gid_{MODE_RUN}_"):
                    try:
                        a_, b_ = open(os.path.join(MODE_STATE, fn)).read().split("\n", 1); ids[int(a_)] = b_.encode()
                    except (OSError, ValueError): pass
        except OSError: pass
        if isinstance(globals().get("CID"), int): ids[CID] = NAME.rstrip(b"_")
        GIDS["ids"] = ids
    return GIDS["ids"]
def is_human_id(i):
    g_ = ghost_ids()
    return bool(g_) and isinstance(i, int) and i > 1 and i not in g_
def fix_human_names():
    g_ = ghost_ids()
    if not g_: return
    gn = {n for n in g_.values()}
    pl_ = globals().get("players") or {}; t_ = time.time()
    here = {addr_id(w) for w, pv in list(pl_.items()) if t_ - pv[0] < 10.0}
    hum = [i for i in here if is_human_id(i)]
    for i in hum:
        if names.get(i) is not None and names[i].rstrip(b"_") in gn: names.pop(i, None)
    for i, n in g_.items(): names[i] = n
    unnamed = [i for i in hum if names.get(i) is None]
    free = [n for n in set(SESS_NAME.values()) if n.rstrip(b"_") not in gn and n not in names.values() and n != SESS_NAME.get(0)]
    if len(unnamed) == 1 and len(free) == 1: names[unnamed[0]] = free[0]
def remap_names():
    t_ = time.time(); pl_ = globals().get("players") or {}
    here = {addr_id(w) for w, pv in list(pl_.items()) if t_ - pv[0] < 10.0}         # (a dead player still sends a state a second)
    ids = sorted(here | {1} | ({CID} if isinstance(globals().get("CID"), int) else set()))
    idx = sorted(SESS_NAME)
    if len(ids) == len(idx) and ids:
        m = dict(zip(ids, idx))
        names.clear(); names.update({i: SESS_NAME[k] for i, k in m.items()})
        TEAMS.update({i: SESS_TEAM[k] for i, k in m.items() if k in SESS_TEAM})
    live = set(SESS_NAME.values())
    for i, n in LEARNED.items():
        if n in live: names[i] = n
    try: fix_human_names()
    except Exception: pass
# ---- Team games (Team Play, Survival Horde ...): the host's session list also has "team" = SERVER_TEAM_RED / SERVER_TEAM_BLUE for every
# player. A joining player picks a team before it can come out of the lobby (until then its name is white and it never appears):
# fd 00 04 "team" <SERVER_TEAM_..>, then the usual 0x3ff (its lobby object is ..1f in a team game, ..01 otherwise) and 0x3f1 whose
# last byte is the team (1 red, 2 blue; 1 in other modes), and 0x3f1 with the team again at every respawn (recorded from the user's game
# and 4 bots in 3 Team Play games). GHOST_TEAM = red / blue / auto (auto: the team with fewer players; blue on a tie).
TEAMS = {}                 # player id -> b"SERVER_TEAM_RED" / b"SERVER_TEAM_BLUE"
TEAM_GAME = [False]; MY_TEAM = [None]
TEAM_PREF = os.environ.get("GHOST_TEAM", "auto").strip().lower()

def pick_team():
    if TEAM_PREF in ("red", "blue"): return TEAM_PREF
    n = {"red": 0, "blue": 0}
    for pid, t in TEAMS.items():
        if names.get(pid, b"").rstrip(b"_") == NAME.rstrip(b"_"): continue
        n["red" if t.endswith(b"RED") else "blue"] += 1
    return "red" if n["red"] < n["blue"] else "blue"

def team_byte():
    return (1 if MY_TEAM[0] == "red" else 2) if TEAM_GAME[0] and MY_TEAM[0] else 1
relay_ids = set()          # ids seen as the source of relayed messages (other clients)
def display_name(i):
    """the in-game name of player i (the session list has the connection name; the launcher's ghosts are GhostLanN = GhostBot_0N)"""
    n = names.get(i)
    if n is None: return None
    m = re.fullmatch(rb"GhostLan(\d+)", n)
    return b"GhostBot_%02d" % int(m.group(1)) if m else n

NEUTRAL = re.compile(os.environ.get("GHOST_NEUTRAL", r"Present \d+$").encode())
def is_friend(who):
    """a player on this ghost's own side in a game mode (its name matches GHOST_FRIENDS)"""
    # (20 Nov, the user: the elves shot at Mission 1's piles of presents - ghosts on the players' team, so by team they were fair
    #  game. A NEUTRAL name - "Present N": the piles, and the exploding presents, which are the elves' own side anyway - is never
    #  a target, whatever its team.)
    n0 = display_name(addr_id(who))
    if n0 and NEUTRAL.match(n0.rstrip(b"_")): return True
    # (24 Nov, the user's friend: the elves killed Elf 5 over and over, every enemy shooting at it as it spawned. The exploding
    #  presents come and go all through Mission 1's step 2, the session list's order slipped, and Elf 5 was given a Players
    #  team from it. A ghost of this run says itself who it is - state/gid_<run>_<tag>.txt, read by ghost_ids() - so that
    #  decides first: one whose own name is on this ghost's side is a friend, whatever team the list gave it.)
    gn_ = ghost_ids().get(addr_id(who))
    if gn_ is not None and FRIENDS is not None and FRIENDS.match(gn_.rstrip(b"_")): return True
    if FRIENDS is not None and is_human_id(addr_id(who)) and (n0 is None or n0.rstrip(b"_") in set(ghost_ids().values())):
        return False                                     # (a human - no ghost of this run: never on the enemies' side)
    if TEAM_GAME[0] and MY_TEAM[0] and TEAMS.get(addr_id(who)):
        # (17 Nov: a known team decides. Santa and the late presents never learned the user's NAME (it only comes with a kill
        #  message), so the unknown-name rule below made him a "friend": Santa walked about and never threw a present.)
        return TEAMS.get(addr_id(who)) == b"SERVER_TEAM_" + MY_TEAM[0].upper().encode()   # a teammate: never a target, takes no blast
    if FRIENDS is None: return False
    n = display_name(addr_id(who))
    if not n:                     # (17 Nov: a player whose name isn't known yet - a boss that just came in - is NOT a target: the elves
        return True               #  stabbed Jack Frost to death as "0x6021" before his name arrived. The players' names come at once.)
    return bool(FRIENDS.match(n.rstrip(b"_")))

def peer_ids():
    """the other clients in the game (not the host, not us): real clients relay their moves to them through the host"""
    return sorted(i for i in (set(names) | relay_ids) if i not in (1, HOST_ID, CID) and i not in GUEST_IDS and 2 <= i <= 30)

RELAY = os.environ.get("GHOST_RELAY", "1") == "1"      # GHOST_RELAY=0: do not send our moves / hits to the other clients
def relay_msg(fl, body, dsts):
    """a message for other clients, the way real clients send it: 84 <our id> <n> <their ids> 00 <fl> <message>; the host forwards it to each of them"""
    if not dsts: return
    send_msg(fl, b"\x84" + bytes([CID & 0xFF, len(dsts)]) + bytes(dsts) + b"\x00" + bytes([fl]) + (body[1:] if body[:1] == b"\x00" else body))

VIA_RELAY = os.environ.get("GHOST_VIA_RELAY", "1") == "1"
def now_pos(who, pv):
    """where a player probably is NOW: its last state moved on by its speed (teammates' states come 3x less often)"""
    age = min(0.4, max(0.0, time.time() - pv[0])); v = VEL.get(who, (0.0, 0.0))
    return (pv[1][0] + v[0] * age, pv[1][1], pv[1][2] + v[1] * age)

TEAM_STATE_EVERY = int(os.environ.get("GHOST_TEAM_STATE_EVERY", "3")); STATE_N = [0]
def friend_id(pid):
    """a player id on this ghost's own side (the other zombies): by team in a team game, else by name (GHOST_FRIENDS)"""
    if TEAM_GAME[0] and MY_TEAM[0]:
        return TEAMS.get(pid) == b"SERVER_TEAM_" + MY_TEAM[0].upper().encode()
    n = names.get(pid)
    return bool(FRIENDS is not None and n and FRIENDS.match(n.rstrip(b"_")))

STATE_GAP = float(os.environ.get("GHOST_STATE_GAP", "0.15")); LAST_STATE = [0.0, None]
# ---- Moves sent one state late, with the speed that really takes it to the next one (11 Nov). The other games carry a player on at
# the speed in its last state until the next arrives; a ghost's speed changes between its states (turns, strafes, shoves), so ~20%
# of its states landed 3+ units from where the others had it (bots 7-10%) - the jumping about. Sent one state behind (0.15 s, like a
# little ping), the speed is the one that DOES take it from this position to the next, and the only error left is the timing.
# (11 Nov: the full state behind felt laggy to the user. Half of it - 0.075 s - still cuts the jumps from ~18% to ~7% on the
#  recordings, about the bots' own; GHOST_LAG_FRAC 1.0 = the full state, 0 = off.)
LAG_ON = os.environ.get("GHOST_LAG", "1") == "1"; LAG = {}
LAG_FRAC = max(0.0, min(1.0, float(os.environ.get("GHOST_LAG_FRAC", "0.5"))))
# ---- No fake falls off edges (11 Nov, the user: on rooftop edges the ghosts "fall then appear right back up"). The other games carry
# a player on at its last speed until the next state and drop it when that takes it off a ledge; a ghost that walked up to a roof's
# edge and stopped there (or turned along it) still had a speed pointing over it, so for a moment it fell on the other screens, then
# its next state put it back on the roof. A ghost standing on a floor never sends a speed that would carry it off that floor within
# EDGE_AHEAD s (it is cut to what stays on it). One that really goes over keeps its speed - and really falls.
EDGE_AHEAD = float(os.environ.get("GHOST_EDGE_AHEAD", "0.3")); EDGE_DROP = 1.5
def edge_clip(x, y, z, vx, vz):
    F = getattr(walker, "F", None)
    if F is None or EDGE_AHEAD <= 0 or (vx == 0.0 and vz == 0.0): return vx, vz
    for k in (1.0, 0.75, 0.5, 0.3, 0.15):
        hx, hz = x + vx * EDGE_AHEAD * k, z + vz * EDGE_AHEAD * k
        try: fb = F.floor_below(hx, hz, y + 0.6)
        except Exception: return vx, vz
        if fb is not None and fb[0] >= y - EDGE_DROP:
            return vx * k, vz * k
    return 0.0, 0.0
def lag_state(now, st):
    """the state to send for the move st (None: not sent this tick anyway)"""
    key = (st[20], st[56], st[57])
    if key == LAST_STATE[1] and now - LAST_STATE[0] < STATE_GAP - 0.01: return None
    x, y, z = struct.unpack("<3f", st[22:34]); p = LAG.get("p"); LAG["p"] = (now, x, y, z, bytes(st[18:20]))
    if not LAG_ON or LAG_FRAC <= 0.0 or p is None or not 0.03 < now - p[0] < 0.6: return st
    dt = now - p[0]; vx, vy, vz = (x - p[1]) / dt, (y - p[2]) / dt, (z - p[3]) / dt
    if math.hypot(vx, vz) > 90.0 or abs(vy) > 150.0: return st             # a jump in place (a respawn, a big throw): shown at once
    f = LAG_FRAC; b = bytearray(st); mx, my, mz = x - f * (x - p[1]), y - f * (y - p[2]), z - f * (z - p[3])
    # the sector of the point actually sent: a position outside the sector its state names makes the ghost VANISH on the other
    # screens (11 Nov: half-way points with the end's sector - 3% of the states, ghosts blinking out at sector edges)
    cur = struct.unpack("<H", st[18:20])[0]; prv = struct.unpack("<H", p[4])[0]
    ms = sector_of(mx, my, mz, prefer=cur)
    if ms is None: ms = sector_of(mx, my, mz, prefer=prv)
    if ms is None:                                                           # (no sector known there: send the real spot instead)
        return st
    b[18:20] = struct.pack("<H", ms & 0xFFFF); b[22:34] = struct.pack("<3f", mx, my, mz)
    if abs(vy) < 1.0:
        vx, vz = edge_clip(mx, my, mz, vx, vz)
    b[40:52] = struct.pack("<3f", vx, vy if abs(vy) > 0.5 else 0.0, vz)
    return bytes(b)

# GHOST_WAIT_PLAYER=1 (a host-only server's Map Rotation): spawn, then stand still and do nothing until a real player is in the game:
# anyone but the host and the ghosts (GHOST_PEERS: a regex of the ghosts' names).
WAIT_PLAYER = os.environ.get("GHOST_WAIT_PLAYER", "0") == "1"
PEERS = re.compile(os.environ.get("GHOST_PEERS", r"GhostBot_\d+|GhostLan\d+").encode())
WAIT_NOTE = [None]
# Who else is in the game (anyone but the host and the ghosts - bots included; a watcher tells them apart by their logs), logged when
# it changes: "players in the game: A, B" (or "players in the game: nobody"). For phone notifications when someone joins.
PLAYERS_SEEN = [None]
def report_players(now):
    cur = []; here = {addr_id(w) for w, pv in list(players.items()) if now - pv[0] < 10.0}     # (moving in the last 10 s: still in)
    for pid, n in list(names.items()):
        if pid in (HOST_ID, CID) or not n or pid not in here: continue
        n = n.rstrip(b"_")
        if n == NAME.rstrip(b"_") or PEERS.fullmatch(n): continue
        cur.append(n.decode("latin1"))
    cur = sorted(set(cur))
    if cur != PLAYERS_SEEN[0]:
        PLAYERS_SEEN[0] = cur; print("players in the game: " + (", ".join(cur) if cur else "nobody"))
def waiting_for_player():
    if not WAIT_PLAYER or WAIT_NOTE[0] is True: return False      # (once a player has been in, keep fighting even after they leave)
    for pid, n in list(names.items()):
        if pid in (HOST_ID, CID) or not n: continue
        n = n.rstrip(b"_")
        if n == NAME.rstrip(b"_") or PEERS.fullmatch(n): continue
        if WAIT_NOTE[0] is not True:
            WAIT_NOTE[0] = True; print(f"a player is in ({n.decode('latin1')}): fighting")
        return False
    if WAIT_NOTE[0] is not False:
        WAIT_NOTE[0] = False; print("no players yet besides the host and the ghosts: standing still")
    return True
# (13 Nov, the user: ghosts sank into the barn's stairs. Those stairs are steps 1 unit deep and 2 high; a ghost walking up them at
#  30-44 units a second crosses 5-6 steps between two states, and the other games carry it on level in between (a state only says
#  how fast it goes sideways), so it went through the steps until the next state lifted it. On stairs the states now go 3x as often.)
CLIMB = [False]
def send_state(body):
    """our move: to the host and every other player, like to_all - but the other ZOMBIES (our own side) only get every
    TEAM_STATE_EVERY-th one. They only need it to keep their distance; everyone's moves to everyone grew with the square of the
    horde (25 zombies: ~10000 messages a second through the host bot - the game got laggy).
    At most one every STATE_GAP s, like real players (the user's game and the bots: one every 0.15 s, 4-5.5 a second; the ghosts
    sent 11 a second, 20 while fighting); a new pose, a death or a revive still goes at once."""
    now = time.time(); key = (body[20], body[56], body[57]) if len(body) > 57 else None
    if key == LAST_STATE[1] and now - LAST_STATE[0] < STATE_GAP - 0.01 and not (CLIMB[0] and now - LAST_STATE[0] >= 0.045): return   # (stairs: see CLIMB)
    LAST_STATE[0] = now; LAST_STATE[1] = key
    STATE_N[0] += 1
    if not (VIA_RELAY and RELAY) or TEAM_STATE_EVERY <= 1 or STATE_N[0] % TEAM_STATE_EVERY == 0:
        to_all(2, body); return
    relay_msg(2, body, [HOST_ID] + [i for i in peer_ids() if not friend_id(i)])

def to_all(fl, body):
    """moves (0x418), pose changes (0x403) and impact marks (0x40e): real clients send ALL of these (1223 of 1223 states in a 4-player
    capture) as one relayed message whose destinations include the host (84 <us> <n> 01 <others> ...), never straight to the host.
    The ghosts sent them straight to the host - the host drew them, but (apparently) not always as a PLAYER: no name over the head,
    could not be hit. GHOST_VIA_RELAY=0 = the old way."""
    if VIA_RELAY: relay_msg(fl, body, [HOST_ID] + (peer_ids() if RELAY else []))
    else:
        send_msg(fl, body)
        if RELAY: relay_msg(fl, body, peer_ids())

def relay_body(h):
    """(plain message, source id) from a relay the host forwarded (84 <src> <n> <dsts> 00 <fl> 47 ...); None for compressed ones"""
    try:
        src, n = h[1], h[2]; i = 3 + n
        if h[i] == 0x7f:
            p = unzstd(h[i:])
            return (p, src) if p else None
        if h[i] != 0: return None
        return h[i + 2:], src
    except IndexError: return None

CREATED_AT = [0.0]
ASK402_WAIT = float(os.environ.get("GHOST_402_WAIT", "10")); ANSWERED402 = set()
# (13 Nov midday: back to answering every ask, as a real client does. The captures of real games (state\netcap 24684, a game hosting
#  real game clients) show each respawn as: the client sends 0x3f6 (old body), 0x3f1 and its create of the new body (flag 6f); the
#  host answers 0x413 and at once asks "send me <new body>" (0x402, 0x20 | slot); the client answers straight away with the create
#  again, flag ef, addressed to the host (and to any other client that asks, through the host). So a real client sends BOTH. The
#  12 Nov reading (two bodies from answering) was from one recording; not answering left the frozen standing ghosts at spawn
#  points all the same. GHOST_402_WAIT=10: the 12 Nov way, no answer for 10 s after a create.)
# (13 Nov 11:44, the user: answering made MORE frozen ghosts (3 in a heap early in the game). Back to 10 s silence by default.
#  The heap is always the same spot whatever the characters, early on, bullets go through: the join's stand-in body (slot-1, flag
#  6b, created at 0,0,0 in the handshake and removed 1.4 s later) left behind where the game puts a player with no place yet.
#  Its removal is now sent again a few times: JOIN_REDELETE.)
# (13 Nov 12:15, found in the ghosts' own records: after each spawn / respawn request the host answers 0x407 with the spawn point IT
#  chose (x, y, z, facing) - 0.0 s later, and nearly never the one the ghost picked. A real client goes where it is told; the ghosts
#  ignored it and appeared at their own pick, while the host's game put the player at its point as well: the frozen, unhittable ghosts
#  standing at spawn points, removed only when that ghost died again. Now the ghost waits up to WAIT407 s for that answer and spawns
#  where the host says. GHOST_WAIT407=0: the old way.)
WAIT407 = float(os.environ.get("GHOST_WAIT407", "0.8")); HOST407 = []; SPAWN_PEND = []
REQ_AFTER_DELETE = float(os.environ.get("GHOST_REQ_DELAY", "0"))          # (the removal now comes after the request: REMOVE_AFTER_REQ)
REMOVE_AFTER_REQ = float(os.environ.get("GHOST_REMOVE_AFTER", "4.0")); REMOVED_ONCE = set()   # (4 s for now: tells apart when the game makes the corpse)
# (16 Nov, the user's Christmas Horde (a team game): a nameless elf standing upright where it had just been killed, 2 s after the
#  respawn request. In a team game the request names the NEW body (as real team clients do), so the old body is never turned into
#  the game's corpse: it stays a player entity nobody drives, drawn standing, until our removal REMOVE_AFTER_REQ s later. It is now
#  removed REMOVE_AFTER_REQ_TEAM s after the request in a team game (it has lain dead for the whole DEAD_TIME by then).)
REMOVE_AFTER_REQ_TEAM = float(os.environ.get("GHOST_REMOVE_AFTER_TEAM", "0.3"))
CORPSE_DROP = float(os.environ.get("GHOST_CORPSE_DROP", "300"))
JOIN_REDELETE = [float(x) for x in os.environ.get("GHOST_JOIN_REDELETE", "2,5,10,20").split(",") if x.strip()]
# (13 Nov, the user's own game with the prestige test: no ask was answered any more, yet "leftover" dark bodies still stood at
#  spawn points. The logs: on about half the respawns the host asked for the new body 0.0 s after our own create had gone out,
#  i.e. it asked BEFORE the create reached it, and was told nothing. A real client does not send its create unasked after a
#  respawn: it waits for this ask and answers it. Now the ghost does the same: after the respawn request it waits up to
#  RESPAWN_WAIT s; the host's ask is answered with the create; with no ask by then, it sends the create itself as before.
#  Nothing moves or shoots until the create is out. GHOST_RESPAWN_WAIT=0: the old way.)
RESPAWN_WAIT = float(os.environ.get("GHOST_RESPAWN_WAIT", "0")); PENDING_CREATE = []
# (13 Nov midday, next game: with the wait, 88 of 93 asks still came 0.0 s AFTER our create, so the ask answers the create; the wait
#  only froze each ghost 0.6 s. Off again by default. The bodies: the user's screenshot shows two ghosts STANDING frozen on one spot,
#  i.e. live-looking players nobody drives, not corpses. The respawn request (0x3f6) names the OLD body (as a real client's does) with
#  the spawn point; the old body's removal goes on another channel at the same moment. If the host handles the respawn after the
#  removal, it brings the old body back, standing at the spawn point: the frozen ghost. A real client removes its old body only after
#  the host's answer. Now the old body's removal is sent again REDELETE_AFTER seconds later (removing a gone body does nothing).
#  GHOST_REDELETE="": off.)
REDELETE_AFTER = [float(x) for x in os.environ.get("GHOST_REDELETE", "1.0,3.0").split(",") if x.strip()]; REDELETES = []
# (13 Nov 11:51, the user: frozen ghosts still appear, at random spawn points; they vanish after a while and turn up elsewhere,
#  bullets go through them. Both games' captures show the pattern: a body's create sent as "6f" (a short announcement) makes every
#  game that gets it ask for the full body (0x402, 0x20 | slot); a real client answers with "ef" (the full body, choreography word 0).
#  Unanswered, that game keeps a half-made body: frozen where it was created (a spawn point), not hittable, until the ghost removes
#  that body at its next respawn - then the next one appears at the next spawn point. Answering after the fact made more of them.
#  Now the ghost sends the full "ef" body in the first place, so there is nothing left to ask for. GHOST_CREATE_EF=0: the old "6f".)
CREATE_EF = os.environ.get("GHOST_CREATE_EF", "1") == "1"
def send_create(body):
    """The ghost's player create (spawn and respawn): to the host AND relayed to every other client, like a real client does (a joining
    bot's create reached the user's game as its own relay). When a BOT hosts and the user joins, the host does not pass a client's create
    on: sent to the host only, the user's game never made the ghost's player (Survival Horde with ghost zombies: "Player 3 connected",
    the ghost fought, but it never appeared and was not on the scoreboard). GHOST_CREATE_RELAY=0: the old way."""
    CREATED_AT[0] = time.time()
    if CREATE_EF and len(body) > 26 and body[26] == 0x6f:
        b_ = bytearray(body); b_[26] = 0xef; b_[20:22] = b"\x00\x00"; body = bytes(b_)    # (see CREATE_EF)
    send_msg(2, body)
    if RELAY and os.environ.get("GHOST_CREATE_RELAY", "1") == "1":
        pids = peer_ids()
        if pids: relay_msg(2, body, pids)

def make_create(x, y, z, gid=None, slot=0x1802):
    b = bytearray(ns_fix(with_model(bytes.fromhex(D["spawn"][2]["b"]))))
    # This word is NOT an entity id: like the state's id word it is (choreography << 16) | SECTOR (the recording spawned in sector 78 = 0x4e).
    # Every ghost was created in a fixed sector: 0x4e/0x4f/0x50 = 78/79/80, and 79/80 are the scenery ring outside Hargrove: the game put
    # the player there - not drawn, no name, could not be hit - until it caught up (Sanchez, ghost 2, was invisible from the start).
    sec = sector_of(x, y, z)
    if sec is None: sec = LAST_SEC[0] if LAST_SEC[0] is not None else (GID & 0xFFFF)
    hi = ((GID if gid is None else gid) >> 16) & 0xFFFF                      # 0x15 (die/revive) on a respawn, like the real client
    mi = b.lower().find(b".nwx"); ms = b.rfind(b"\x00", 0, mi) + 1 if mi > 0 else -1
    if ms >= 4 and b[ms - 4] & 0xF0 == 0x90:
        # the byte before the model name: 0x90 no team, 0x91 red, 0x92 blue (every real player's create in Team Play: the user's red Mary
        # 91, the blue bots 92, the ghost 90 - drawn, but on no team in the user's game)
        b[ms - 4] = 0x90 | (team_byte() if TEAM_GAME[0] and MY_TEAM[0] else 0)
    b[18:22] = struct.pack("<I", (hi << 16) | (sec & 0xFFFF)); b[22:24] = struct.pack("<H", slot); b[30:34] = struct.pack("<f", x); b[34:38] = struct.pack("<f", y); b[38:42] = struct.pack("<f", z)
    return bytes(b)

import math
TEMPLATE = bytes.fromhex(D["life"][-1]["b"])          # a recorded movement packet, used as the frame
YAW_UNITS = 16384.0                                  # full circle in the packet's angle fields (measured)
SPEED = float(os.environ.get("GHOST_SPEED", "30"))   # 30 = walk (W only), ~44 = run
# route = list of (dx, dz) offsets from the spawn point; the ghost walks them in a loop, pausing at each one
ROUTE = [tuple(float(v) for v in p.split(",")) for p in os.environ.get("GHOST_ROUTE", "-60,-20;0,0").split(";")]

LVL = None; LVL_TRIED = False; LEVEL_NAME = os.environ.get("GHOST_LEVEL") or None      # the launcher knows the map it hosted (ghosts 2 and 3 never got the host's map message)
STAGGER = min(float(os.environ.get("GHOST_STAGGER", "0")), 1.0)      # seconds to wait after the match starts before this ghost appears (ghosts that all appear in the same instant: the host only registered the first)
WAIT_HOST = os.environ.get("GHOST_WAIT_HOST", "0") == "1"      # the human hosts: stay in the lobby until the match starts (the first player position), then spawn
def sector_of(x, y, z, prefer=None):
    """Map sector a standing player at the point is in (the state packet's id word is the sector index); None if unknown.
    Same rule as the fighter (fighter.stand_locate): no crawl spaces, and the current sector is kept until a wall is crossed."""
    global LVL, LVL_TRIED
    if LVL is None and not LVL_TRIED and LEVEL_NAME:
        LVL_TRIED = True
        try:
            import nav
            LVL = nav.Level(nav.lvt.load(LEVEL_NAME), nav.lvt.load_inf(LEVEL_NAME), name=LEVEL_NAME)
            chk = LVL.locate(REC_SPAWN[0], -0.5, REC_SPAWN[1]) if LEVEL_NAME.upper() == "HARGROVE" else None
            print(f"sector lookup ready for {LEVEL_NAME}" + (f" (recorded spawn is in sector {chk}, expected 78)" if chk is not None else ""))
        except Exception as e:
            print("sector lookup unavailable:", e); LVL = None
    if LVL is None: return None
    try:                                                      # swimming (under Orleans' ice): the water sector it is in
        w_ = LVL.water_at(x, y, z)
        if w_ is not None and LVL.water_at(x, y + 1.5, z) is not None: return w_
    except Exception: pass
    from fighter import stand_locate
    for dy in (0.0, 0.5, 1.0, 2.0, 4.0):                      # a little higher too (stairs, slopes)
        sec = stand_locate(LVL, x, y + dy, z, prefer)
        if sec is not None: return sec
    return None

LAST_SEC = [None]; SEC_MISS = [0.0]

def can_move(x, y, z, nx, nz):
    """a straight move that stays on open floor: no wall, fence or ledge in between (the knockback used to check only that the end point was in
    some sector, and pushed a ghost through Hargrove's boundary fence into the scenery ring around the map, where it was stuck for good)"""
    if LVL is None: return True
    sec = sector_of(x, y, z, prefer=LAST_SEC[0])
    if sec is None: return False
    dest = sector_of(nx, y, nz, prefer=sec)
    try: path = LVL._march(sec, (x, z), (nx, nz))
    except Exception: return False
    return path is not None and dest is not None and dest in path

def fly_clear(x, y, z, nx, nz):
    """a flying body's step (13 Nov, the user: bodies thrown by dynamite stopped at every sector edge, even the invisible ones you
    walk through; only real walls and the map's edge should stop them). can_move is the WALKING test (ledges, tables, steps are
    walls to it). This one follows the line through every opening: it stops only at a solid wall (no sector behind it), a wall
    flagged impassable (the map's boundary fences, bars, glass), or an opening whose floor is above the body / ceiling below it."""
    if LVL is None: return True
    import nav
    sec = sector_of(x, y, z, prefer=LAST_SEC[0])
    if sec is None:
        f_, sec = floor_under(x, z, y + 1.0)
        if sec is None: return can_move(x, y, z, nx, nz)
    dx, dz = nx - x, nz - z
    if abs(dx) + abs(dz) < 1e-6: return True
    cur, t0 = sec, 0.0
    try:
        for _ in range(32):
            S = LVL.sectors[cur]; best = None
            for w in S.walls:
                (x1, z1), (x2, z2) = S.vertices[w.v1], S.vertices[w.v2]
                sx, sz = x2 - x1, z2 - z1; den = dx * sz - dz * sx
                if abs(den) < 1e-9: continue
                wx, wz = x1 - x, z1 - z
                u = (wx * dz - wz * dx) / den; t = (wx * sz - wz * sx) / den
                if -1e-6 <= u <= 1 + 1e-6 and t0 + 1e-6 < t <= 1.0 and (best is None or t < best[0]): best = (t, w)
            if best is None: return True                                   # the step ends inside this sector
            t, w = best
            if w.adjoin is None or w.adjoin < 0 or (w.flags & nav.IMPASSABLE): return False
            px, pz = x + dx * t, z + dz * t
            fl = LVL.floor_at(w.adjoin, px, pz); ce = LVL.ceiling_at(w.adjoin, px, pz)
            if fl > y + 0.5 or ce < y + 1.0: return False                  # the face of a higher floor, or under a low ceiling
            cur, t0 = w.adjoin, t
    except Exception:
        return can_move(x, y, z, nx, nz)
    return False                                                          # (lost in a tangle of sectors: treat it as a wall)

def valid_pos(x, y, z):
    """False only when the level is loaded and the point is outside every sector (inside a wall / outside the map)."""
    if sector_of(0, 0, 0) is None and LVL is None: return True            # no level data: cannot tell
    return sector_of(x, y, z) is not None

# Pose 15 is what the user's own game sends for EVERY punch, knife stab and throw (recorded 7 Nov: THROW.wav, 0x403 15, back to 0 after
# 0.2-0.4 s). It was switched off when ghosts vanished during throws; it's back on, sent exactly that way (never in the states).
THROWPOSE = os.environ.get("GHOST_THROWPOSE", "1") == "1"
# (17 Nov: a small mission enemy's gun flash is drawn where a full-size character's gun would be - over a little nutcracker's head.
#  GHOST_NOFLASH=1: its shots use the throw pose and not the gun's, so no flash.)
NOFLASH = os.environ.get("GHOST_NOFLASH") == "1"
SWING = ("knife", "stab", "fist")
SHOOT_UNTIL = [0.0]; THROW_UNTIL = [0.0]; LAST_CHOR = [None]; CHOR_MSGS = []; THROW_RESET = [None]
def throw_pose():
    """a throw (knife or dynamite), exactly as the host sends its own: 0x403 pose 15, then 0.2 s later back to the current pose; the states
    meanwhile keep their plain stand/walk pose (a shoot pose 10 in them is what made the throws look like shots)"""
    # OFF: pose 15 from a ghost makes the user's game stop drawing it (no name tag, can't be hit) until another pose comes - the vanishing
    # came back with the throws. (The host's own player sends 15 for its throws; for a remote player the game has no such pose.)
    if THROWPOSE:
        to_all(2, b"\x00\x47" + struct.pack("<III", slot - NS, NS, slot) + struct.pack("<H", 0x403) + b"\x00\x00" + struct.pack("<H", 0x0f))
        THROW_RESET[0] = time.time() + 0.2
def make_state(x, y, z, yaw_rad, pitch_units, vx, vz, moving, dying=False, revive=False, vy=0.0, sec=None, crouch=False):
    b = bytearray(TEMPLATE)
    b[6:10] = b[10:14] = struct.pack("<I", 0x00200000 | (slot & 0xFFFF))      # who the state is from: the CURRENT slot (the template has the recorded 0x1802; after a respawn or for the 2nd/3rd ghost it must follow)
    if dying: b[57] = 0x41
    if revive: b[56] = 0x6f
    if sec is None: sec = sector_of(x, y, z, prefer=LAST_SEC[0])         # (a recorded jump move brings the real player's own sector numbers)
    if sec is None:
        sec = LAST_SEC[0]                                                   # off the map data: keep the last sector the host knows (a wrong one makes the ghost vanish and unhittable)
        if time.time() - SEC_MISS[0] > 5.0:                                 # (a diagnostic for ghosts that go dark / vanish: where it happened)
            SEC_MISS[0] = time.time(); print(f"SECTOR: no sector at {x:.1f},{y:.1f},{z:.1f}; keeping {LAST_SEC[0]}")
    else: LAST_SEC[0] = sec
    chor = 0x15 if (dying or revive) else 3 if crouch else 10 if time.time() < SHOOT_UNTIL[0] else (1 if moving else 0)      # the state carries the choreography (0 stand, 1 walk, 3 crouch (crouch-walking too: recorded 7 Nov), 10 shoot, 0x15 die: the game's cid files): while shooting it must say 10 or the next state wipes the shot animation
    b[18:22] = struct.pack("<I", (chor << 16) | ((sec if sec is not None else GID) & 0xFFFF))
    if chor != LAST_CHOR[0]: LAST_CHOR[0] = chor; CHOR_MSGS.append(chor)          # a real client announces every pose change with 0x403
    b[22:26] = struct.pack("<f", x); b[26:30] = struct.pack("<f", y); b[30:34] = struct.pack("<f", z)
    b[34:36] = struct.pack("<h", int(pitch_units)); b[36:38] = struct.pack("<H", int(round(yaw_rad / (2 * math.pi) * YAW_UNITS)) % int(YAW_UNITS))
    b[40:44] = struct.pack("<f", vx); b[44:48] = struct.pack("<f", vy); b[48:52] = struct.pack("<f", vz)
    return bytes(b)

DROP = os.environ.get("GHOST_DROP", "0") == "1"; dropped = False
# ---- Killed by dynamite: the body is thrown away from the blast (straight up when it went off at its feet) and falls back down.
BOOMS = []; FLY = {}; BODY_G = 60.7                 # (the jump's measured gravity)
def boom_near(now):
    """a dynamite went off close to the ghost just now (its death text is then "blew up")"""
    if walker is None: return False
    return any(now - t <= 0.8 and math.dist(bp, (walker.x, walker.y + 2.5, walker.z)) <= 60.0 for t, bp in BOOMS)
KICK = []                       # [time, (vx, vy, vz)]: the kick of the last hit taken (the game's rule, see kick_vel)
FALL_HIT = []                   # landing speeds to check for fall damage
def blast_launch(now):
    """called when the ghost dies: if a dynamite went off close by just now, start the body's flight (a flight a shot started is
    only replaced when there WAS a blast)"""
    if walker is None: return False
    best = None
    for t, (bx, by, bz) in BOOMS:
        if now - t > 0.8: continue
        d = math.dist((bx, by, bz), (walker.x, walker.y + 2.5, walker.z))
        if d <= 60.0 and (best is None or d < best[0]): best = (d, bx, by, bz)
    if best is None: return False
    FLY.clear()
    d, bx, by, bz = best; k = max(0.15, 1.0 - d / 60.0)                   # 1 = right on it
    dx, dz = walker.x - bx, walker.z - bz; h = math.hypot(dx, dz)
    if h < 4.0:                                                          # at its feet: up into the air, a little drift
        a = random.uniform(0, 2 * math.pi); ux, uz = math.cos(a), math.sin(a); vh = 8.0 + 10.0 * k; vy = 60.0 + 45.0 * k
    else:
        ux, uz = dx / h, dz / h; vh = 40.0 + 70.0 * k; vy = 30.0 + 35.0 * k
    FLY.update(v=[ux * vh, vy, uz * vh], landed=False, floor=walker.y, t0=now, x0=walker.x, y0=walker.y, z0=walker.z)
    print(f"blown away by dynamite {d:.0f} away: flying {vh:.0f} sideways, {vy:.0f} up")
    return True
def fly_step(dt):
    """one step of the body's flight; returns the velocity to put in the state"""
    if not FLY or FLY.get("landed"): return (0.0, 0.0, 0.0)
    v = FLY["v"]; nx, ny, nz = walker.x + v[0] * dt, walker.y + v[1] * dt, walker.z + v[2] * dt
    v[1] -= BODY_G * dt
    if not fly_clear(walker.x, walker.y, walker.z, nx, nz): nx, nz = walker.x, walker.z; v[0] *= -0.2; v[2] *= -0.2     # a wall: slides down it (fly_clear)
    f, s = floor_under(nx, nz, max(walker.y, FLY["floor"]))
    if f is None: f = FLY["floor"]                                       # (no floor found in the air: the last one known)
    else: FLY["floor"] = f
    FLY["top"] = max(FLY.get("top", ny), ny)
    landed_ = time.time() - FLY["t0"] > 3.0
    if ny <= f and v[1] < 0:                                             # on the floor: slides to a stop (friction)
        ny = f; v[1] = 0.0; hv = math.hypot(v[0], v[2]); dec = KNOCK_FRICTION * dt
        if hv <= dec + 1.0: landed_ = True
        else: v[0] *= (hv - dec) / hv; v[2] *= (hv - dec) / hv
    if landed_:
        ny = max(ny, f); FLY["landed"] = True
        print(f"body landed {math.hypot(nx - FLY['x0'], nz - FLY['z0']):.0f} away after {time.time() - FLY['t0']:.1f} s, {FLY['top'] - FLY['y0']:.0f} high at the top")
    walker.x, walker.y, walker.z = nx, ny, nz
    return tuple(v) if not FLY["landed"] else (0.0, 0.0, 0.0)
# ---- Blast knockback on a LIVING ghost (user: any dynamite that hurts a player throws it; the closer, the harder): the same flight
# as a dead body's, then it lands and carries on.
BLASTKNOCK = {}
def cancel_moves():
    """a knock (shot or blast) throws the ghost off whatever it was doing: an unstick step (it slid on from where it had been - the
    ghost snapped back close to the user after being knocked away), a recorded jump, a crouch-jump, its route"""
    if isinstance(walker, FightWalker):
        F = walker.F; F.slide = None; F.play = None; F.cj = None; F.path = []; F.path_t = -99.0; F.vel = (0.0, 0.0); F.fall_vy = 0.0

def knock_from(now, bp, d):
    """a blast at bp, d away, hurt us: get thrown (k = 1 right on it, 0 at the edge of the blast); at its feet mostly straight up"""
    if walker is None or not alive: return
    k = max(0.1, 1.0 - d / 50.0)
    dx, dz = walker.x - bp[0], walker.z - bp[2]; h = math.hypot(dx, dz)
    if h < 4.0: a = random.uniform(0, 2 * math.pi); ux, uz = math.cos(a), math.sin(a); vh = 6.0 + 10.0 * k; vy = 25.0 + 40.0 * k
    else: ux, uz = dx / h, dz / h; vh = 15.0 + 55.0 * k; vy = 10.0 + 30.0 * k
    BLASTKNOCK.clear(); BLASTKNOCK.update(v=[ux * vh, vy, uz * vh], floor=walker.y, t0=now); cancel_moves()
    print(f"knocked back by a blast {d:.0f} away ({vh:.0f} sideways, {vy:.0f} up)")
# ---- Knockback from a shot, a punch or a blast: the game's own rule (read out of the exe, 11 Nov - the player hit handler at 0x1400ba920):
# every hit record carries a momentum (its third number: pistol 270, rifle 360, a shotgun pellet 180, a punch / stab 480, a thrown knife
# 120, a blast 75 x its damage) and a direction (two words: heading and pitch, 16384 to a full turn). The victim's velocity gets
#   momentum x (the second number, 1.0) / MASS x 10
# along that direction (MASS from the character file: 150, Mary 170). A recorded bot hit by 1078 went back at ~70 a second (1078 / 15 = 72).
# The same kick throws a body that the hit killed. The ghost used to make up its own (momentum / 25, or a guessed blast flight).
LAST_HIT = {}; POSE = {}
KNOCK_FRICTION = float(os.environ.get("GHOST_KNOCK_FRICTION", "140"))
EYE_STAND, EYE_CROUCH = 5.6, 2.6
def kick_vel(mom, f2, yaw_w, pitch_w):
    """the game's hit kick: (vx, vy, vz)"""
    sp = mom * f2 / (170.0 if CHAR == "mary" else 150.0) * 10.0     # (MASS: cidmary.itm 170, the others 150)
    a = (yaw_w & 0x3FFF) / 16384.0 * 2 * math.pi
    pw = pitch_w & 0x3FFF
    if pw >= 8192: pw -= 16384
    pa = pw / 16384.0 * 2 * math.pi
    return (math.sin(a) * math.cos(pa) * sp, math.sin(pa) * sp, math.cos(a) * math.cos(pa) * sp)
def hit_words(src, dst, src_eye=EYE_STAND, dst_mid=3.0):
    """the direction words of a hit going from src to dst (heading as atan2(dx, dz), pitch up positive)"""
    dx, dz = dst[0] - src[0], dst[2] - src[2]; dy = (dst[1] + dst_mid) - (src[1] + src_eye)
    yw = int(round(math.atan2(dx, dz) / (2 * math.pi) * 16384)) & 0x3FFF
    pw = int(round(math.atan2(dy, math.hypot(dx, dz) or 1e-6) / (2 * math.pi) * 16384)) & 0xFFFF
    return yw, pw
def hit_knock_vel(now, src_pos=None, crouched=False):
    """the velocity the last hit gives the ghost (None: no hit with momentum just now)"""
    if walker is None or not LAST_HIT or now - LAST_HIT.get("t", -9) > 0.5: return None
    h = dict(LAST_HIT); LAST_HIT.clear()
    if h["mom"] <= 0: return None
    vx, vy, vz = kick_vel(h["mom"], h.get("f2", 1.0), h["yaw"], h["pitch"])
    if math.hypot(vx, vz) < 1.0 and abs(vy) < 1.0: return None
    return (vx, max(0.0, vy), vz)                                   # (standing on the floor: pushed down = not at all)

def knock_hit(now, src_pos=None, crouched=False, v_=None):
    if not alive or STILL: return False
    if v_ is None: v_ = hit_knock_vel(now, src_pos, crouched)
    if v_ is None: return False
    vx, vy, vz = v_; hv = math.hypot(vx, vz)
    if not BLASTKNOCK and vy < 3.0 and hv < 45.0 and isinstance(walker, FightWalker):
        # a pistol / rifle / pellet or two: added to its velocity and it keeps going (a real player keeps running with the keys
        # held; the old way stopped everything for a short slide each hit - a stutter on every hit)
        walker.F.push(vx, vz, hv)
        print(f"knocked by a hit: {hv:.0f} sideways (keeps going)")
        return True
    cancel_moves()
    if BLASTKNOCK:
        BLASTKNOCK["v"][0] += vx; BLASTKNOCK["v"][1] += vy; BLASTKNOCK["v"][2] += vz
    else:
        BLASTKNOCK.clear(); BLASTKNOCK.update(v=[vx, vy, vz], floor=walker.y, t0=now, top=walker.y)
    print(f"knocked by a hit: {math.hypot(vx, vz):.0f} sideways, {vy:.0f} up")
    return True

def knock_step(dt):
    v = BLASTKNOCK["v"]; nx, ny, nz = walker.x + v[0] * dt, walker.y + v[1] * dt - 0.5 * BODY_G * dt * dt, walker.z + v[2] * dt
    v[1] -= BODY_G * dt
    if not can_move(walker.x, walker.y, walker.z, nx, nz): nx, nz = walker.x, walker.z; v[0] = v[2] = 0.0
    f, s = floor_under(nx, nz, max(walker.y, BLASTKNOCK["floor"]))
    if f is None: f = BLASTKNOCK["floor"]
    else: BLASTKNOCK["floor"] = f
    done = time.time() - BLASTKNOCK["t0"] > 2.5
    if ny <= f and v[1] <= 0:                                       # on the floor: slide, slowing down (friction), then it's over
        if v[1] < -1.0: FALL_HIT.append(-v[1])                       # (landing hard after being thrown hurts, as any fall)
        ny = f; v[1] = 0.0
        hv = math.hypot(v[0], v[2]); dec = KNOCK_FRICTION * dt
        if hv <= dec + 1.0: done = True
        else: v[0] *= (hv - dec) / hv; v[2] *= (hv - dec) / hv
    # (18 Nov, the user: enemies falling off a high ledge "look like they just teleport down". A throw that had not landed after 2.5 s
    #  was put on the floor below at once - a long drop (Thud Tower's walkways and tower) ended in a snap. Still in the air then, the
    #  fall carries on under the fighter's own gravity, with the speed it had, and lands the way a fall off a ledge does.)
    air = ny > f + 0.05
    walker.x, walker.y, walker.z = nx, ny, nz
    if done:
        BLASTKNOCK.clear(); F = walker.F
        F.cur_y = ny; F.cur_sec = F.sector(nx, ny, nz, prefer=s) or s or F.cur_sec; F.path = []; F.path_t = -99.0
        if air: F.fall_vy = min(v[1], -1.0); F.vel = (v[0], v[2]); print(f"thrown and still falling after 2.5 s ({ny - f:.0f} up): falling on")
        else: F.vel = (0.0, 0.0)
        F.last = time.time()   # (its last step was before the knock: the next one covered the whole flight's time at a run - it snapped back past the user)
        return ((v[0], v[1], v[2]) if air else (0.0, 0.0, 0.0)), s
    return tuple(v), s
DEATHSND = os.environ.get("GHOST_DEATHSND", "1") == "1"; death_snd = False
# the ghost's own voice: each character's sounds start with a prefix (Mary BM, Bob BO, James JA, Dr Death DR, Sanchez SZ, Two Feathers TF); BMHIT.wav / BMDIE.wav are Mary's
CHAR = os.environ.get("GHOST_CHAR", "mary").lower()
if CHAR not in ("mary", "bob", "james", "drdeath", "sanchez", "twofeathers"): CHAR = "mary"
VOICE = {"mary": "BM", "bob": "BO", "james": "JA", "drdeath": "DR", "sanchez": "SZ", "twofeathers": "TF"}[CHAR]
# The model (sprite set) is named in the join and create messages ("mary.nwx" in the recording): each character's own PLAYER_WAX from the game's cid<name>.itm.
MODEL = {"mary": "mary.nwx", "bob": "bobgrahm.nwx", "james": "james.nwx", "drdeath": "drdeath.nwx", "sanchez": "sanchez.nwx", "twofeathers": "twofeath.nwx"}[CHAR]
# Prestige looks (13 Nov): GHOST_TIER=BRZ / SLV / GLD wears the bronze / silver / gold copy of the character (prestigeskins.py packs
# them for the game; the name keeps 8.3 like xp.variant_model: JAMESGLD, MARYGLD, SANCHGLD, TWOFEGLD, DRDEAGLD, BobgrGLD).
TIER = os.environ.get("GHOST_TIER", "").strip().upper()
if TIER in ("BRZ", "SLV", "GLD"):
    MODEL = {"mary": "mary", "bob": "bobgr", "james": "james", "drdeath": "drdea", "sanchez": "sanch", "twofeathers": "twofe"}[CHAR] + TIER.lower() + ".nwx"
    print(f"prestige look: {MODEL}")
if os.environ.get("GHOST_MODEL", "").strip():       # a look of a game mode's own (the Halloween Horde's skeletons: skeljame.nwx)
    MODEL = os.environ["GHOST_MODEL"].strip().lower()
    print(f"model: {MODEL}")
def with_model(b):
    """A recorded message with its model name ("mary.nwx" / "MARY.NWX") swapped for this ghost's character."""
    return b.replace(b"mary.nwx", MODEL.encode()).replace(b"MARY.NWX", MODEL.upper().encode())
# What the game's own character files (cid<name>.itm in olobj/olpatch4.lab) say about each multiplayer character:
#   dmg  = DAMAGE_MULTIPLIER (scales the damage they deal), start = START_WEAPON (2 pistol, 4 sawed-off, 5 double-barrel, 8 knife).
#   Health and walk/run speed are not in those files, so every character shares the ghost's measured pace and health.
CHAR_STATS = {"sanchez": dict(dmg=1.15, start=2), "james": dict(dmg=1.0, start=2), "twofeathers": dict(dmg=0.90, start=8),
              "bob": dict(dmg=0.95, start=5), "drdeath": dict(dmg=1.05, start=2), "mary": dict(dmg=0.80, start=4)}
# ---- Stamina: each character file's "# energy usage" block (FLOAT E_REST / E_MOVE / E_JUMP / E_TURN / E_CROUCH), read from the game's own
# cid<name>.itm at start-up (a later patch lab overrides olobj.lab: olpatch4 has Bob and James again, same numbers). Taken as: E_REST per second
# whenever it isn't losing any, E_MOVE per second while running SIDEWAYS (a strafe, or a diagonal: players keep a straight run free by tapping
# W / S, so forward and back cost nothing), E_JUMP per jump. E_TURN is ignored (Two Feathers' -2 for turning was patched out of the game) and
# E_CROUCH too (a crouch costs nothing that we know of). The files have no maximum: GHOST_STAMINA_MAX.
CHAR_FILE = {"mary": "cidmary.itm", "bob": "cidbob.itm", "james": "cidjames.itm", "drdeath": "ciddeath.itm", "sanchez": "cidsanch.itm", "twofeathers": "cidfeath.itm"}
ENERGY_FALLBACK = {"mary": (11, -10, -5.0, 0.0, 2.0), "james": (11, -10, -5.0, 0.0, 2.0), "twofeathers": (11, -10, -5.0, -2.0, 2.0),
                   "bob": (10, -9, -6.0, 0.0, 2.0), "drdeath": (15, -14, -5.5, 0.0, 2.0), "sanchez": (15, -14, -6.0, 0.0, 2.0)}   # (the files' values, if the labs can't be read)
def char_energy(ch):
    """{rest, move, jump, turn, crouch} from the game's cid<name>.itm, and where they came from"""
    keys = ("rest", "move", "jump", "turn", "crouch")
    here_ = os.path.dirname(os.path.abspath(__file__))           # botctl\ghost.py: the game is one up; botctl\netre\ghost.py (or the repo): two up
    gdir = os.environ.get("GHOST_GAME_DIR") or next((d for d in (os.path.dirname(here_), os.path.dirname(os.path.dirname(here_)))
                                                     if any(os.path.exists(os.path.join(d, n)) for n in ("olobj.lab", "OLOBJ.LAB", "olpatch4.lab"))),
                                                    os.path.dirname(os.path.dirname(here_)))
    want = CHAR_FILE[ch]; found = None
    for lab in ("olobj.lab", "olpatch1.lab", "olpatch2.lab", "olpatch3.lab", "olpatch4.lab", "olpatch5.lab", "olpatch6.lab", "olremaster1.lab", "olremaster2.lab"):
        try:
            with open(os.path.join(gdir, lab), "rb") as f:        # only the directory and the one file: the labs are up to 130 MB
                hd = f.read(16)                                       # (7 ghosts reading them whole at once ran out of memory)
                if hd[:4] != b"LABN": continue
                n, nsz = struct.unpack("<II", hd[8:16])
                dr = f.read(16 * n); names = f.read(nsz)
                for i in range(n):
                    no, off, sz, _ = struct.unpack("<IIII", dr[16 * i:16 * i + 16])
                    if names[no:names.index(b"\0", no)].decode("latin1").lower() == want:
                        f.seek(off); found = (lab, f.read(sz).decode("latin1"))
        except (OSError, ValueError, struct.error): pass
    if found:
        v = {}
        for ln in found[1].splitlines():
            m = re.match(r"\s*FLOAT\s+E_(REST|MOVE|JUMP|TURN|CROUCH)\s+(-?[\d.]+)", ln.split("#")[0], re.I)
            if m: v[m.group(1).lower()] = float(m.group(2))
        if all(k in v for k in keys): return v, f"{found[0]}:{want}"
    return dict(zip(keys, map(float, ENERGY_FALLBACK[ch]))), f"built-in copy of {want} (game labs not found)"
STAMINA_ON = os.environ.get("GHOST_STAMINA", "1") == "1"
STAMINA_MAX = float(os.environ.get("GHOST_STAMINA_MAX", "100"))
STAMINA_RESUME = float(os.environ.get("GHOST_STAMINA_RESUME", "0.25"))     # once out of breath: walk until this share of the maximum is back
ENERGY, ENERGY_SRC = char_energy(CHAR)
# out of breath: Mary's file has SND_TIRED bmtired.wav; nobody else has one, so they pant the game's generic tired.wav (like hit.wav for SND_GOTSHOT)
# ---- Zombie groans (Survival Horde, GHOST_MOANS = comma list of WAVs in the zombie archive, e.g. ZMOAN1.WAV,...): while alive the
# ghost groans every GHOST_MOAN_GAP seconds (random in "min,max"), as a sound OF its player (the fuse form: 40 40 01) so it comes from
# where the zombie is and fades with distance; the files themselves are quiet (made from the user's clips: zombie\ZMOANn.WAV).
MOANS = [w.strip().encode() for w in os.environ.get("GHOST_MOANS", "").split(",") if w.strip()]
MOAN_GAP = tuple(float(v) for v in os.environ.get("GHOST_MOAN_GAP", "5,11").split(","))
NEXT_MOAN = [time.time() + random.uniform(1.0, MOAN_GAP[1])]
# teammates keep a little room between them (a pack of zombies piled into one spot, running into each other): a soft shove apart,
# stronger the closer they are (GHOST_SPACING units; 0 = off)
SPACING = float(os.environ.get("GHOST_SPACING", "6")); SPACE_T = [0.0]
BODY_GAP = float(os.environ.get("GHOST_BODY_GAP", "4.0"))         # teammates never step closer than this to each other
MELEE_DY = float(os.environ.get("GHOST_MELEE_DY", "4.5"))         # a punch / stab misses anyone whose feet are more than this above or below its own
MELEE_KEEP = float(os.environ.get("GHOST_MELEE_KEEP", "4.5"))     # how close a puncher / stabber comes (reach 8; 2 put it INSIDE the target: bodies 1.5 + 1.5)
LAST_MOAN = [None]
TIRED_WAV = os.environ.get("GHOST_TIREDSND", "bmtired.wav" if CHAR == "mary" else "tired.wav").encode()
# start weapon -> shot sound, damage per hit, seconds between shots, reach. Only the pistol is verified; the rest are estimates
# (a shotgun barrel measured 9.1 close up, the sound names exist in the game; the knife's damage and reach are guesses).
# From the game's own weapon files (olweap.lab: i<character><weapon>.itm, e.g. impistol.itm = Mary's pistol): START_WEAPON is a weapon SLOT
# (2 pistol, 4 single-barrel shotgun, 5 double-barrel, 6 sawed-off, 8 knife). dmg = per shot as the ghost deals it (pellets x damage, most hitting),
# reach = effective range. (Before: slot 4 was taken for the sawed-off, so Mary played sawed.wav; the knife was a 8-unit stab with knifehit.wav,
# but the game's primary knife action is a THROW, range 30, damage 4.)
START_WEAPONS = {2: dict(snd="pistol3.wav", dmg=2.0, gap=1.2, reach=None),          # pistol: 1 x 2.0, range 120
                 4: dict(snd="single.wav", dmg=6.0, gap=1.6, reach=None),           # single-barrel shotgun (Mary): 6 pellets x 1.5, range 120
                 5: dict(snd="double.wav", dmg=4.5, gap=1.4, reach=100.0),          # double-barrel (Bob): 5 pellets x 0.9 per barrel, range 100
                 6: dict(snd="sawed.wav", dmg=8.0, gap=2.0, reach=15.0),            # sawed-off: 30 pellets x 2.0, spread 20, range 15
                 8: dict(snd="throw.wav", dmg=4.0, gap=1.0, reach=30.0)}            # knife: thrown, 4.0, range 30
# Each character has their OWN pistol (same slot, different file): James pistol2.wav, Dr Death and Sanchez BADGUN.wav (and 2.5 damage), the rest pistol3.wav.
CHAR_PISTOL = {"james": ("pistol2.wav", 2.0), "drdeath": ("badgun.wav", 2.5), "sanchez": ("badgun.wav", 2.5),
               "mary": ("pistol3.wav", 2.0), "bob": ("pistol3.wav", 2.0), "twofeathers": ("pistol3.wav", 2.0)}
START_WEAPONS[2] = dict(START_WEAPONS[2], snd=CHAR_PISTOL[CHAR][0], dmg=CHAR_PISTOL[CHAR][1])

# ---- Fighting styles: each character fights with what the game gives them at the start (cid<name>.itm START_ITEMs, weapons from olweap.lab).
# gap = seconds between shots, mag = shots before reloading (SHOT_CAPACITY), reload = seconds from the magazine's last shot to the next
# shot, clicks = the reload sounds (seconds after that last shot to the first, seconds apart, how many), ammo = shots per life
# (START_COUNT), range = EFFRANGE.
#
# The timing is the game's own, read from the weapon animations (10 Nov; it was guessed before: rifle 1.5 s, pistol 0.155 s for all).
# A weapon's .itm names its animation (.nwx) and the choreography of each action (FIRE_CHOR_1 primary, FIRE_CHOR_2 secondary,
# RELOAD_CHOR). In the .nwx (WAXF), section CHOT holds, per choreography, the frames per second and the list of frames, with
# "-5, 1, 1" where the action happens (the shot; each round loaded). Every character's files were read (olweap.lab, olpatch4.lab):
#   primary fire: 5 frames at 10 fps for every pistol, rifle and shotgun, except Sanchez's pistol, 5 frames at 18 fps
#   reload: pistol 14 frames (6 rounds, 2 frames apart); rifle 25 frames (8 sounds, 3 apart), James's 38 (12 sounds);
#           all three shotguns 9 frames (2 sounds, 3 apart); all at 10 fps
# How frames turn into time was checked against the user's own Sanchez pistol in a recording (9 Nov, 264 shots, 36 reloads):
#   holding fire, a shot every 0.23 s            = (frames - 1) / fps = 4 / 18 = 0.222: the next shot can start on the last frame
#   last shot to the first reload sound, 0.40 s  = the whole fire animation, 5 / 18 = 0.278, + the reload's first frame, 0.1
#   reload sounds 0.20 s apart                   = 2 frames at 10 fps
#   last reload sound to the next shot, 0.19 s   = (14 - 1 - 11) / 10 = 0.2
# So: gap = (fire frames - 1) / fps; reload = fire frames / fps + (reload frames - 1) / fps.
# (Secondary fire: the pistol's fanning is 2 frames, less accurate, range 90 - the higher tiers fan, see FAN; rifle and shotguns as primary.)
_FPS = 18.0 if CHAR == "sanchez" else 10.0                       # the pistol's fire animation
_P_GAP, _P_FIRE = 4.0 / _FPS, 5.0 / _FPS
_R_RELOAD, _R_ROUNDS = (38, 12) if CHAR == "james" else (25, 8)
# Damage is the files' own too (DAMAGE_1, "average damage done"; x SHOT_MULTIPLES pellets for the shotguns), per character:
#   pistol 2.0 (Dr Death and Sanchez 2.5: CHAR_PISTOL), rifle 2.0 for everyone (it was 3.0 here, from no file),
#   single-barrel shotgun 6 pellets x 1.5 = 9.0 (was 6.5), double-barrel 5 pellets a barrel x the character's own pellet
#   (Bob 0.75, James 1.0, the others 0.9; was 4.5 for all), thrown knife 4.0, dynamite 12.0 within 50 (pdynam.itm).
# Not from a file, measured in the user's game instead and kept: a knife stab 12 and the fists (the files' values x 3).
# The shotguns' loss with distance (falloff: fewer pellets land) is this script's own estimate; the files give the spread (4 and 2 degrees).
_DB_PELLET = {"bob": 0.75, "james": 1.0}.get(CHAR, 0.9)
# The thrown knife is wound up like dynamite (the exe's Weapon_KnifeHandler, 0xda6b0; read 11 Nov): primary fire plays the wind-up
# (chor 5: 1 frame at 10 fps), then the weapon waits with the button held and notes the time; letting go throws with
# power = clamp(seconds held since, 0.5, 1.0) (0xda770: / 1000, min 0.5, max 1.0), speed = power x RATE_1 (120), pitched THROW_PITCH
# (pknife.itm: 5 degrees) above the aim; then 2 frames of follow-through. So a far throw takes a long hold: the knife's soft cooldown.
# The user (11 Nov): the ghosts threw knives much too quickly. GHOST_KNIFE_WINDUP=0: the old flat 0.8 s between throws.
KNIFE_WINDUP = os.environ.get("GHOST_KNIFE_WINDUP", "1") == "1"
WEAPONS = {
    "pistol":  dict(snd=CHAR_PISTOL[CHAR][0], dmg=CHAR_PISTOL[CHAR][1], gap=_P_GAP, mag=6, reload=_P_FIRE + 1.3, clicks=(_P_FIRE + 0.1, 0.2, 6), rsnd="PRELOAD.wav", ammo=None, range=120.0),
    # (rifle: the user timed it in game, 13 Nov: holding fire, 12 rounds took 5.5-6 s, a shot every 0.5 s, not the 0.4 the
    #  animation's frames gave. GHOST_RIFLE_GAP to change it.)
    "rifle":   dict(snd="rifle.wav", dmg=2.0, gap=float(os.environ.get("GHOST_RIFLE_GAP", "0.5")), mag=12, reload=0.5 + (_R_RELOAD - 1) / 10.0, clicks=(0.7, 0.3, _R_ROUNDS), rsnd="rreload.wav", ammo=16, range=250.0),
    "sgun":    dict(snd="single.wav", dmg=9.0, gap=0.4, mag=1, reload=1.3, clicks=(0.8, 0.3, 2), rsnd="sreload.wav", ammo=16, range=120.0, falloff=True),
    "dbsgun":  dict(snd="double.wav", dmg=5 * _DB_PELLET, gap=0.4, mag=2, reload=1.3, clicks=(0.8, 0.3, 2), rsnd="sreload.wav", ammo=8, range=120.0 if CHAR == "drdeath" else 100.0, falloff=True),
    "knife":   dict(snd="THROW.wav", dmg=4.0, gap=0.4 if KNIFE_WINDUP else 0.8, mag=1, reload=0.0, rsnd=None, ammo=6, range=30.0, spin=540.0),   # thrown: spins the victim round
    "stab":    dict(snd="THROW.wav", dmg=12.0, gap=0.6, mag=1, reload=0.0, rsnd=None, ammo=None, range=8.0),           # the knife's secondary action, up close
    "fist":    dict(snd="THROW.wav", dmg=1.0, gap=0.5, mag=1, reload=0.0, rsnd=None, ammo=None, range=8.0),           # ifist.itm: DAMAGE_1 1.0, range 8
    "dynamite": dict(snd="throw.wav", dmg=12.0, gap=3.0, mag=1, reload=0.0, rsnd=None, ammo=6, range=85.0, blast=50.0, fuse=1.6),
    # (the Co-op Missions' evil snowmen: a thrown snowball does a thrown knife's damage, but lands as a plain hit - no spin)
    "snowball": dict(snd="THROW.wav", dmg=4.0, gap=1.1, mag=1, reload=0.0, rsnd=None, ammo=None, range=60.0),
}
# Fanning: the pistol's secondary fire (FIRE_CHOR_2, chor 6: "6, -5, 7, -2" - a frame, the shot, a frame, and round again while it's
# held), so a shot every 2 frames: 0.2 s (Sanchez's 13 fps: 0.154) against primary's 0.4 (0.222). EFFRANGE_2 90 (primary 120),
# VARIANCE_2 2.0 against VARIANCE_1 1.0 (James 2.5 / 1.5): a degree more scatter a shot, on top of the aim the tiers are tuned for;
# DAMAGE_2 2.0 (Dr Death and Sanchez 3.0, against 2.5); the same sound and momentum (MASS_2 0.3 x RATE_2 900 = 270).
# Every bot tier fans (brain.Skill.primary_slots leaves the pistol out); the ghosts never did. The user (11 Nov): the higher tiers
# should. GHOST_FAN_LEVELS: the tiers that fan, comma separated ("" = none).
FAN_LEVELS = tuple(t.strip() for t in os.environ.get("GHOST_FAN_LEVELS", "hard,nightmare,hell").lower().split(",") if t.strip())
_FAN_FPS = 13.0 if CHAR == "sanchez" else 10.0
FAN = dict(gap=2.0 / _FAN_FPS, fire=2.0 / _FAN_FPS, range=90.0, scatter=1.0, dmg=3.0 if CHAR in ("drdeath", "sanchez") else 2.0)
if CHAR == "james": WEAPONS["rifle"]["range"] = 600.0         # James's rifle (ijrifle.itm) reaches 600, Dr Death's (idrifle.itm) 250
if CHAR == "drdeath" and not os.environ.get("GHOST_BOSS_ARMS"): WEAPONS["rifle"]["ammo"] = 12
# keep = distance it fights from, retreat = backs off when closer than this, sprint/strafe = share of the time running / sidestepping
STYLES = {
    "twofeathers": dict(arms=("knife", "stab", "pistol"), keep=8.0, retreat=0.0, sprint=1.0, strafe=0.55,      # Chief: charges in throwing knives
                        note="aggressive: rushes in throwing knives, pistol when they are gone"),
    "mary":    dict(arms=("sgun", "pistol"), keep=14.0, retreat=0.0, sprint=0.95, strafe=0.6,         # close-quarters combatant with the shotgun
                    note="combatant: closes in with the shotgun"),
    "bob":     dict(arms=("dbsgun", "pistol"), keep=32.0, retreat=16.0, sprint=0.6, strafe=0.85,      # double-barrel reaches a bit further, slow reload: hangs back more
                    note="steady: double-barrel from a little further back, careful (slow reload)"),
    "sanchez": dict(arms=("pistol", "dynamite"), keep=40.0, retreat=20.0, sprint=0.8, strafe=0.85,    # six-shooter, and dynamite into groups
                    note="gunslinger: six-shooter, throws dynamite into groups"),
    "james":   dict(arms=("rifle", "pistol"), keep=140.0, retreat=95.0, sprint=0.7, strafe=0.7,       # rifleman: keeps his distance
                    note="rifleman: keeps his distance"),
    "drdeath": dict(arms=("rifle", "pistol"), keep=75.0, retreat=50.0, sprint=0.7, strafe=0.75,       # rifle far, his strong pistol close; med bags
                    note="doctor: rifle at range, strong pistol up close, uses his med bags"),
}
# Chief like the bots' Chief (11 Nov, a Normal game of 3 bots + 3 ghosts: the two knife-rushing Chief ghosts made 30 and 29 kills, the
# bots 4-8; their stabs landed 47 of 47 for ~11 of 10 health, the thrown knives 72-80%). The bots' Two Feathers likes the rifle (50)
# and the pistol (35) and is the least aggressive of them (brain.LIKING / CHAR_AGGRESSION). Easiest .. Hard ghosts now fight like that:
# rifle and pistol, the knife's jab only point blank. Nightmare / Hell keep the knife-rushing Chief. GHOST_CHIEF_KNIVES=1: always.
BOTLIKE_TIER = os.environ.get("GHOST_DIFFICULTY", "normal").lower() in ("easiest", "easy", "normal", "average", "hard")
# (12 Nov, the user's favourites: Chief's is the knife, on every tier - the bot-like rifle Chief only with GHOST_CHIEF_BOTLIKE=1)
CHIEF_BOTLIKE = BOTLIKE_TIER and os.environ.get("GHOST_CHIEF_BOTLIKE", "0") == "1"
if CHIEF_BOTLIKE:
    STYLES["twofeathers"] = dict(arms=("rifle", "pistol", "stab"), keep=60.0, retreat=30.0, sprint=0.7, strafe=0.6,
                                 note="like the bots' Chief: rifle and pistol, the knife only point blank")
STYLE_ON = os.environ.get("GHOST_STYLE", "1") == "1"
# The launcher's Weapons choice (Ghosts tab), or the bots' own game being TNT only / Melee Only Deathmatch:
# melee = fists (Chief: his knife, up close), tnt = dynamite (plenty), then the knife or fists once it runs out.
WMODE = os.environ.get("GHOST_WEAPONS", "normal").lower()
MELEE = os.environ.get("GHOST_MELEE") or ("stab" if CHAR == "twofeathers" else "fist")      # GHOST_MELEE=fist: fists for everyone (tests)
if WMODE == "melee":
    for _k in STYLES: STYLES[_k] = dict(STYLES[_k], arms=(MELEE,), keep=2.0, retreat=0.0, note="melee only: " + ("the knife" if MELEE == "stab" else "fists"))
elif WMODE == "tnt":
    WEAPONS["dynamite"]["ammo"] = int(os.environ.get("GHOST_TNT_STICKS", "50"))
    for _k in STYLES: STYLES[_k] = dict(STYLES[_k], arms=("dynamite", MELEE), keep=60.0, retreat=45.0, note="TNT only: dynamite, then " + ("the knife" if MELEE == "stab" else "fists"))
DRDEATH_RIFLE = float(os.environ.get("GHOST_DRDEATH_RIFLE", "30"))   # (Dr Death: the rifle beyond this, his pistol closer)
SANCHEZ_TNT = float(os.environ.get("GHOST_SANCHEZ_TNT", "0.5"))   # (a lone target in throwing range: dynamite this often - the user: "a mix of TNT and pistol")
MEDBAGS = {"drdeath": 5}                                         # ciddeath.itm: idocbag x5 (Inv_HealthObject, use sound cool.wav)
MEDBAG_HEAL = float(os.environ.get("GHOST_MEDBAG_HEAL", "3"))

# ---- Weapons from the map (11 Nov, the user: "ghosts need to be able to pickup weapons and use them"). With GHOST_PICKUPS on (the
# default, normal weapons only), a ghost starts each life with what a real player gets - the pistol and the character's own start item
# (cid<name>.itm: Mary the shotgun, Bob the double-barrel, Two Feathers his knife) - and takes the rest from the map like the bots:
# g<weapon>.itm gives the gun and its ammo (rifle + 12 cartridges, shotgun / double-barrel + 6 shells), a stick of dynamite 1, a box of
# it 10, a canteen 10 health. Which gun it then fights with follows the bots' liking for that character (brain.LIKING).
# ---- a Co-op Mission's mini-boss (horde.py / missions.py): its own weapons, endless ammo, its own shot sound, and something visible flying
# out of the gun (GHOST_PROJ: a sprite of the boss's own, e.g. SNOWBALL.NWX, made as a flying object like a thrown knife)
BOSS_ARMS = [a_ for a_ in os.environ.get("GHOST_BOSS_ARMS", "").split(",") if a_ in WEAPONS]
# (20 Nov, the user: every mission enemy carries a knife, used only swimming after a player - guns don't work under the water)
if BOSS_ARMS and os.environ.get("GHOST_WATER_KNIFE") == "1" and "stab" not in BOSS_ARMS and "fist" not in BOSS_ARMS:
    BOSS_ARMS.append("stab")
if BOSS_ARMS:
    STYLES[CHAR] = dict(STYLES.get(CHAR, {}), arms=tuple(BOSS_ARMS), note="a mini-boss: " + ", ".join(BOSS_ARMS))
    for a_ in BOSS_ARMS:
        WEAPONS[a_]["ammo"] = None                                   # never runs out
    if os.environ.get("GHOST_BOSS_DMG"): WEAPONS[BOSS_ARMS[0]]["dmg"] = float(os.environ["GHOST_BOSS_DMG"])
    if os.environ.get("GHOST_BOSS_GAP"): WEAPONS[BOSS_ARMS[0]]["gap"] = float(os.environ["GHOST_BOSS_GAP"])
    if os.environ.get("GHOST_BOSS_MAG"): WEAPONS[BOSS_ARMS[0]]["mag"] = int(os.environ["GHOST_BOSS_MAG"])
    if os.environ.get("GHOST_BOSS_RELOAD"):                          # (25 Nov: the Nutcracker General's bursts - a short quiet pause, no reload sounds)
        WEAPONS[BOSS_ARMS[0]]["reload"] = float(os.environ["GHOST_BOSS_RELOAD"]); WEAPONS[BOSS_ARMS[0]]["rsnd"] = None
    if os.environ.get("GHOST_SHOTSND"): WEAPONS[BOSS_ARMS[0]]["snd"] = os.environ["GHOST_SHOTSND"]
    if os.environ.get("GHOST_KEEP"): STYLES[CHAR]["keep"] = float(os.environ["GHOST_KEEP"])
    if os.environ.get("GHOST_RETREAT"): STYLES[CHAR]["retreat"] = float(os.environ["GHOST_RETREAT"])
# ---- the Co-op Missions' exploding presents (GHOST_KAMIKAZE=1): no weapon; it runs at the nearest player and blows up when it gets
# next to them (KAMI_TRIGGER), or wherever it is when it is shot dead. The blast: KAMI_DMG (20 = 10 hearts) within KAMI_FULL, falling off
# to nothing at KAMI_R; other elves are not hurt.
KAMI = os.environ.get("GHOST_KAMIKAZE") == "1"
KAMI_DMG = float(os.environ.get("GHOST_KAMI_DMG", "20")); KAMI_FULL = float(os.environ.get("GHOST_KAMI_FULL", "6"))
KAMI_R = float(os.environ.get("GHOST_KAMI_R", "45")); KAMI_TRIGGER = float(os.environ.get("GHOST_KAMI_TRIGGER", "5"))
KAMI_AT = [0.0]
# (17 Nov: a sprite (.NWX) in a flying object's 3DO slot crashed the user's game - "Exception caught in main" - the moment a snowman
#  threw: only real 3DO models fly. GHOST_PROJ_NWX=1 lets a sprite through again, for testing.)
_SAFE_MODEL = lambda m_: m_ if (m_.upper().endswith(".3DO") or os.environ.get("GHOST_PROJ_NWX") == "1") else ""
PROJ_MODEL = _SAFE_MODEL(os.environ.get("GHOST_PROJ", "").strip()).encode()
PROJ_N = int(os.environ.get("GHOST_PROJ_N", "1") or 1)
PROJ_SPEED = float(os.environ.get("GHOST_PROJ_SPEED", "220"))
TNT_MODEL = _SAFE_MODEL(os.environ.get("GHOST_TNT_MODEL", "").strip()).encode()       # (Santa's sticks drawn as presents: PRESENT.NWX)
PICKUPS = os.environ.get("GHOST_PICKUPS", "1") == "1" and STYLE_ON and WMODE == "normal"
WEAPON_ITEMS = {"GRIFLE": ("rifle", 12), "GSGUN": ("sgun", 6), "GDBSGUN": ("dbsgun", 6), "GDYNAM": ("dynamite", 1), "GAMBOXT": ("dynamite", 10),
                "GKNIFE": ("knife", 1)}
# Health on the ghosts' 10-point scale (the user, 11 Nov): a canteen 1, an elixir all of it; a med bag (GDOCBAG) goes in the bag
# count and heals 3 when the ghost uses it (MEDBAG_HEAL), not at once.
HEAL_ITEMS = {"GCANTEEN": 1.0, "GELIXIR": 999.0}; BAG_ITEMS = ("GDOCBAG",); BAG_MAX = 9; BAG_COUNT = 3      # (gdocbag.itm: COUNT 3)
# (16 Nov, the user: in the Christmas Horde the Chiefs' thrown knives spin him round all the time, so he can't shoot the elves -
#  players would hate it. GHOST_NO_KNIFE_THROW=1 (set by the Christmas Horde): no knife throws, the Chief stabs up close and shoots.)
NO_KNIFE_THROW = os.environ.get("GHOST_NO_KNIFE_THROW", "0") == "1"
LIKED = {"mary": ["sgun", "pistol", "dbsgun", "rifle"], "james": ["rifle", "pistol"], "drdeath": ["rifle", "pistol"],
         "sanchez": ["pistol", "dbsgun", "sgun", "dynamite"], "twofeathers": ["rifle", "pistol", "sgun"], "bob": ["dbsgun", "sgun", "pistol"]}
START_ARMS = {2: ["pistol"], 4: ["sgun", "pistol"], 5: ["dbsgun", "pistol"], 8: ["knife", "stab", "pistol"]}
# Each character's favourite weapons, which they start every life with (12 Nov, the user: "James was using his pistol far too often when
# his rifle is his best starting weapon"): James the rifle, Mary the shotgun, Bob the double-barrel, Chief the knife, Sanchez dynamite
# and the pistol, Dr Death the rifle and the pistol. What they pick up after that still counts (Loadout.add).
CHAR_START_ARMS = {"james": ["rifle", "pistol"], "mary": ["sgun", "pistol"], "bob": ["dbsgun", "pistol"],
                   "twofeathers": ["knife", "stab", "pistol"], "sanchez": ["pistol", "dynamite"], "drdeath": ["rifle", "pistol"]}
class Loadout:
    """The weapons this life (ammo per life like a real respawn), which one to use at a distance, and reloading."""
    def __init__(self):
        st = STYLES[CHAR]
        self.arms = [a for a in st["arms"]] if STYLE_ON else ["pistol"]
        if PICKUPS:
            self.arms = list(CHAR_START_ARMS.get(CHAR) or START_ARMS.get(CHAR_STATS[CHAR]["start"], ["pistol"]))
            if CHAR == "twofeathers" and CHIEF_BOTLIKE: self.arms = ["pistol", "knife", "stab"]
        if NO_KNIFE_THROW and "knife" in self.arms:          # (Christmas Horde: no thrown knives - stab and shoot only; see NO_KNIFE_THROW)
            self.arms = [a for a in self.arms if a != "knife"]
            if "stab" not in self.arms: self.arms.append("stab")
        self.ammo = {a: WEAPONS[a]["ammo"] for a in self.arms}
        self.in_mag = {a: WEAPONS[a]["mag"] for a in self.arms}
        self.reloading_until = 0.0; self.next_tnt = 0.0; self.cur = self.arms[0]; self.cur_since = 0.0; self.tnt_decide_next = 0.0; self.tnt_decided = 0.0
        self.fan = False                                  # the pistol fanned (secondary fire) right now (FAN)
        self.bags = 0 if BOSS_ARMS else MEDBAGS.get(CHAR, 0)
    def has(self, a): return a in self.ammo and (self.ammo[a] is None or self.ammo[a] > 0)
    def wants(self, arm):
        """a weapon (or more of its ammo) worth going for: one it likes and lacks, or one of its own running low"""
        if NO_KNIFE_THROW and arm == "knife": return False
        if arm not in LIKED.get(CHAR, []) and not (arm == "knife" and CHAR == "twofeathers"): return False
        if arm not in self.ammo: return True
        a = self.ammo[arm]
        return a is not None and a < (WEAPONS[arm]["ammo"] or 1) / 3.0
    def add(self, arm, n):
        """picked up: a new weapon (with the item's ammo), or more for one it has (at most AMMO_CAP x a full load)"""
        if NO_KNIFE_THROW and arm == "knife":
            if "stab" in self.ammo: return False
            self.ammo["stab"] = None; self.in_mag["stab"] = 1; self.arms.append("stab"); return True
        if arm not in self.ammo:
            self.ammo[arm] = n; self.in_mag[arm] = min(WEAPONS[arm]["mag"], n) if WEAPONS[arm]["mag"] else n
            pref = LIKED.get(CHAR, [])
            self.arms.append(arm); self.arms.sort(key=lambda w: pref.index(w) if w in pref else 99)
            if arm == "knife" and "stab" not in self.ammo: self.ammo["stab"] = None; self.in_mag["stab"] = 1; self.arms.append("stab")
            return True
        if self.ammo[arm] is None: return False
        self.ammo[arm] = min((WEAPONS[arm]["ammo"] or n) * AMMO_CAP, self.ammo[arm] + n); return True
    def choose(self, dist, now, crowd):
        """the weapon for a target at dist (crowd = enemies near that target)"""
        if BOSS_ARMS:                                   # (a mission's own enemy: its own weapons only)
            a = next((w for w in self.arms if dist <= WEAPONS[w]["range"]), self.arms[0])
        elif WMODE == "melee":
            a = MELEE
        elif WMODE == "tnt":
            # dynamite whenever a stick can land 42..85 away (lit one: kept until thrown); closer, or none left: knife / fists, rushing in
            # dynamite as long as he has any (too close: he backs off to throw, never punches); fists / knife only once it's all gone
            a = "dynamite" if (HELD or self.has("dynamite")) else MELEE
        elif CHAR == "twofeathers" and STYLE_ON and CHIEF_BOTLIKE:
            a = "stab" if (dist <= 8.0 and self.has("stab")) else next((w for w in ("rifle", "sgun", "pistol") if self.has(w) and (w != "sgun" or dist <= 40.0)), "pistol")
            if a == "pistol" and self.has("knife") and 10.0 < dist <= 30.0: a = "knife"
        elif CHAR == "twofeathers" and STYLE_ON:
            # Chief: stab when close, throw knives from a little further, the pistol only when out of knives and far
            a = "stab" if dist <= 10.0 else ("knife" if (self.has("knife") and dist <= 42.0) else ("pistol" if dist > 42.0 or not self.has("knife") else "knife"))
            if a == "pistol" and dist <= 42.0: a = "stab" if dist <= 10.0 else "pistol"
        elif CHAR == "drdeath" and STYLE_ON:
            a = "rifle" if (dist > DRDEATH_RIFLE and self.has("rifle")) else "pistol"
        elif CHAR == "sanchez" and STYLE_ON:
            # decide every 2 s (a decision is kept until the throw): a group (2+ close together) always gets dynamite, a lone target sometimes
            if HELD: a = "dynamite"                                   # a stick is lit in his hand: no gun until it's thrown
            elif self.cur == "dynamite" and self.has("dynamite") and 40.0 <= dist <= 85.0 and now < self.tnt_decided + 3.0: a = "dynamite"
            elif now >= self.tnt_decide_next and self.has("dynamite") and 42.0 <= dist <= 85.0 and now >= self.next_tnt:
                self.tnt_decide_next = now + 2.0
                a = "dynamite" if (crowd >= 2 or random.random() < SANCHEZ_TNT) else "pistol"
                if a == "dynamite": self.tnt_decided = now
            else: a = "pistol"
        else:
            a = next((w for w in self.arms if self.has(w) and (w != "knife" or dist <= WEAPONS[w]["range"] + 10)
                      and (not PICKUPS or w in ("pistol", "rifle") or dist <= WEAPONS[w]["range"] * 0.6)), "pistol")     # (a shotgun up close, as the bots: far off the pistol / rifle)
        if a != self.cur: self.cur = a; self.cur_since = now
        return WEAPONS[a]
    def fired(self, now):
        """one shot of the current weapon used: ammo, magazine; returns the reload sound if it now reloads"""
        a = self.cur; w = WEAPONS[a]
        if self.ammo.get(a) is not None: self.ammo[a] -= 1
        if a == "dynamite": self.next_tnt = now + (float(os.environ["GHOST_TNT_NEXT"]) if os.environ.get("GHOST_TNT_NEXT") else 1.5 if WMODE == "tnt" else 6.0)
        self.in_mag[a] = self.in_mag.get(a, w["mag"]) - 1
        if self.in_mag[a] <= 0 and w["reload"] > 0 and self.has(a):
            # (the reload starts when the fire animation is over: fanning's is 2 frames, primary's 5)
            self.in_mag[a] = w["mag"]; self.reloading_until = now + w["reload"] - ((_P_FIRE - FAN["fire"]) if (a == "pistol" and self.fan) else 0.0)
            return w["rsnd"]
        if self.in_mag[a] <= 0: self.in_mag[a] = w["mag"]
        return None
START_W = START_WEAPONS[CHAR_STATS[CHAR]["start"]] if os.environ.get("GHOST_STARTWEAPON", "1") == "1" else START_WEAPONS[2]
# The characters' DAMAGE_MULTIPLIER (cid<char>.itm) is the damage they TAKE, not deal: the user's Chief stabbed for a full 12, and the
# user's Mary (0.80) took about 0.8 of every hit. The ghosts dealt their hits times it instead; now they take theirs times it.
TAKE_MULT = CHAR_STATS[CHAR]["dmg"] if os.environ.get("GHOST_CHARSTATS", "1") == "1" else 1.0
DMG_MULT = 1.0
DIE_WAV = os.environ.get("GHOST_DIESND", VOICE + "DIE.wav").encode()
# the game ships a hurt sound for Mary only (BMhit.wav; checked in every .lab); the other characters borrow the generic male "outch.wav"
HIT_WAV = os.environ.get("GHOST_HITSND", "BMHIT.wav" if CHAR == "mary" else "hit.wav").encode()      # only Mary has one (SND_GOTSHOT in her file): the others play the game's generic hit.wav
HITFX = os.environ.get("GHOST_HITFX", "1") == "1"; hit_fx = False
KNOCK = float(os.environ.get("GHOST_KNOCK", "6"))      # units the ghost is pushed away from the shooter when hit (the simple walker)
# Seconds a dead ghost lies there before it comes back: 5 (the user's choice, 10 Nov; a real client can be back after 3). The game
# modes' ghosts (Survival Horde) keep their 3.
DEAD_TIME = float(os.environ.get("GHOST_DEAD_TIME", "3.0" if MODE_RUN else "5.0"))
_DT_CACHE = [0.0, None]
def dead_time(now):
    """DEAD_TIME, or what the game mode says right now (state/respawn_<run>.txt: seconds - a mission's escort step gives the
    elves 10 s down, 17 Nov: they kept blocking the jail door)"""
    if now - _DT_CACHE[0] > 2.0:
        _DT_CACHE[0] = now
        try:
            with open(os.path.join(MODE_STATE, f"respawn_{MODE_RUN}.txt")) as f_: _DT_CACHE[1] = float(f_.read().strip())
        except (OSError, ValueError): _DT_CACHE[1] = None
    return _DT_CACHE[1] if (_DT_CACHE[1] is not None and not HOSTAGE) else DEAD_TIME
# Seconds after it appears (the first spawn and every respawn) in which a ghost does not attack: the user's game needs a moment to
# show a player that has just spawned, and a ghost was shooting at them before they could see it (10 Nov).
SPAWN_HOLD = float(os.environ.get("GHOST_SPAWN_HOLD", "1.0"))
KNOCK_SPEED = float(os.environ.get("GHOST_KNOCK_SPEED", "40"))      # the fighting ghost: speed of the shove (slides ~3 units)
# what a real client creates the instant it dies: two body entities (GAMBOXB / GAMBOXS) at the death spot. They are separate
# from the player entity, so the body stays on the map after the player respawns (recorded from a real game).
BODY_T = ["47000000000008000000000000fd030000430000006f0800004f040080bb5ece430000000011f6ba4300000000000001000000000000000000000000000000000000000000000000000000000000000000b76d1b404992a43f0000000000000000000000000004000047414d424f58422e4e5758000047414d424f584200",
          "47000000000008000000000000fd03000043000000700800004f040080bbdece430000000011f6ba430000000000000100000000000000000000000000000000000000000000000000000000000000000000004040" "6edb963f0000000000000000000000000004000047414d424f58532e4e5758000047414d424f585300"]
# OFF by default: the HOST drops these boxes itself when a player dies (its own creates, numbered from its own counter: 0x86f, 0x871...).
# The ghosts created a second set posing as the host (sender 0x0800), all three with the same numbers 0x0a00, 0x0a01...
BODY_ID = int(os.environ.get("GHOST_BODYID", "a00"), 16); BODIES = os.environ.get("GHOST_BODIES", "0") == "1"; body_n = 0

def body_msgs(x, y, z):
    global body_n
    out = []
    for h in BODY_T:
        b = bytearray(bytes.fromhex(h))
        b[21:25] = struct.pack("<I", BODY_ID + body_n); body_n += 1
        b[29:33] = struct.pack("<f", x); b[33:37] = struct.pack("<f", y); b[37:41] = struct.pack("<f", z)
        out.append(b"\x00" + bytes(b))
    return out

def send_sound(body):
    """a sound the ghost makes (shots, punches, its hit and death cries, reloads, the fuse ...): to the host AND every other client,
    like a real client (its 0x41c sounds reach the others as its own relays). Sent to the host only, a joining user never heard them
    when a BOT hosted (Survival Horde with ghost zombies: silent when shot). Real clients send it straight to the host (first word 0x800)
    and one relay per other client, its first word that client's address 0x800*(id+1) (recorded in Team Play)."""
    send_msg(2, body)
    if RELAY:
        for pid in peer_ids():
            relay_msg(2, body[:2] + struct.pack("<I", 0x800 * (pid + 1)) + body[6:], [pid])

def sound_msg(sl, wav, fuse=False, attached=False):
    """a sound event the way real clients announce one (0x41c: sender slot, 7f 40 ..., the WAV name). A lit fuse goes as the host sends
    its own: 40 40 01 (quieter, and the 01 makes it a sound OF that object, fading with distance - sent like a gunshot it sounded
    right next to the user wherever the ghost was)"""
    # (fuse / attached = ..01: a LOOPING sound of that object - right for a lit fuse, which the game stops with the stick; never for a one-off)
    return b"\x00\x47" + struct.pack("<III", 0x800, NS, sl) + struct.pack("<H", 0x41c) + bytes.fromhex(("0000404001000000" if fuse else "00007f4001000000" if attached else "00007f4000000000") + "00") + wav + b"\x00"
# ---- Taunts, like the bots (brain.check_kills; the user, 11 Nov): after each kill a random taunt from oltaunt.lab (taunts.txt, the
# bots' own list: any character's), 0.3-0.8 s after the kill, 2.5 s apart, at most 4 waiting. On the wire a bot's taunt is a sound
# event with 08 and 01 where a plain sound has 00 (recorded: 7f 40 08 00 00 00 01 "bu15t.wav"). GHOST_TAUNTS=0: none.
TAUNTS_ON = os.environ.get("GHOST_TAUNTS", "1") == "1"
try:
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "taunts.txt"), encoding="latin-1") as f_: TAUNT_SOUNDS = [l.strip() for l in f_ if l.strip()]
except OSError: TAUNT_SOUNDS = []
TAUNT = dict(queue=0, at=0.0)
def taunt_msg(sl, wav):
    return b"\x00\x47" + struct.pack("<III", 0x800, NS, sl) + struct.pack("<H", 0x41c) + bytes.fromhex("00007f400800000001") + wav + b"\x00"
def taunt_killed(now):
    """one of ours died on our account: queue a taunt"""
    if not (TAUNTS_ON and TAUNT_SOUNDS): return
    if not TAUNT["queue"]: TAUNT["at"] = max(TAUNT["at"], now + random.uniform(0.3, 0.8))
    TAUNT["queue"] = min(TAUNT["queue"] + 1, 4)
def taunt_step(now):
    if TAUNT["queue"] and now >= TAUNT["at"] and alive:
        TAUNT["queue"] -= 1; TAUNT["at"] = now + 2.5
        w = random.choice(TAUNT_SOUNDS); send_sound(taunt_msg(slot, w.encode())); print(f"taunt: {w}")
FIRE = os.environ.get("GHOST_FIRE", "0") == "1"      # shoot at the host's player (decoded from a real client's shots)
FIRE_GAP = float(os.environ.get("GHOST_FIRE_GAP", "2.0"))
FIRE_DMG = float(os.environ.get("GHOST_FIRE_DMG", START_W["dmg"] * DMG_MULT))
players = {}; target_slot = None; first_seen = {}; NOT_PLAYERS = set(); VEL = {}
MIN_AGE = float(os.environ.get("GHOST_TARGET_AGE", "1.0"))      # only target something seen moving for this long: the host's dynamite / thrown things
                                                                # send states like a player for under a second (0x0889, 0x088d...) and the ghosts shot at them
host_slot_seen = None; host_slot = 0x086e; host_pos = None; next_fire = 0.0; shots = 0
# 0x7d1 tail (hit geometry) copied from a real pistol hit; 0x403 codes: 3,4 idle, 0x0a = fire animation
# The hit record's kind and its tail, copied from the user's own hits on a ghost (7 Nov): 0 = a melee blow (stab / punch, third value 480),
# 1 = a bullet (270), 2 = a thrown knife (the game spins the victim for this kind), 4 = a blast. The ghosts sent every hit as a bullet with
# a third value of 180..360 by damage; the knives didn't spin anyone and some hits went straight through the user's boiler plate.
HIT_KIND = {"stab": 0, "fist": 0, "knife": 2}
FIST_DMG = {"mary": (4.0, 2.3), "james": (0.8, 0.3)}       # i<char>fist.itm DAMAGE_1 / DAMAGE_2 (everyone else 1.0 / 0.3)
HIT_TAIL = {0: (480.0, "c108623f0000000080dc88406cbd0441043a963f80dc884050400400"),
            1: (0.0, "4c190a0000000000a31aa940b2bc8e4200cee3be4635124030640400"),     # (0, not the user's 270: that shoved the user sideways)
            2: (120.0, "82ddd6e8000000007161524288541f25cfe8bf430000874370230400")}
# A hit's momentum (its third number) as real players' hits carry it: MASS x RATE of the weapon file, per pellet that struck. With the
# direction words (from the shooter to the victim) the victim's game throws it back exactly as a bot's shot would (kick_vel).
HIT_MOM = {"pistol": 270.0, "rifle": 360.0, "sgun": 180.0, "dbsgun": 72.0, "knife": 120.0, "stab": 480.0}
PELLET_DMG = {"sgun": 1.5, "dbsgun": _DB_PELLET}
BOSS_KICK = float(os.environ.get("GHOST_KICK", "0"))   # (a mission boss's own gun: this momentum on every hit - Jack Frost's snowballs knock you back)
def hit_momentum(weapon, dmg):                          # (17 Nov: was named KICK - the name of the ghost's own knockback list: every ghost died when hit)
    if BOSS_KICK and weapon in BOSS_ARMS and weapon not in ("stab", "fist"): return BOSS_KICK
    m = HIT_MOM.get(weapon)
    if m is None: return None
    if weapon in PELLET_DMG: return m * max(1, round(dmg / PELLET_DMG[weapon]))
    return m
def fire_burst(slot, hs, hpos, sector, hit_it=True, dmg=None, spin=None, pose=0x0a, kind=1, f3_override=None):
    """a pistol shot at the host's player: fire animation, impact marker at its position, damage record (a miss: animation only)"""
    out = []
    out.append(bytes.fromhex("47") + struct.pack("<III", slot - NS, NS, slot) + struct.pack("<H", 0x403) + b"\x00\x00" + struct.pack("<H", pose))
    if not hit_it:
        return out
    out.append(bytes.fromhex("47") + struct.pack("<III", 0, NS, NS) + struct.pack("<H", 0x40e) + b"\x00\x00" + bytes([5, 0]) + struct.pack("<H", sector & 0xFFFF) + b"\x01\x00" + struct.pack("<3f", *hpos))
    f3, tail = HIT_TAIL.get(kind, HIT_TAIL[1])
    if f3_override is not None: f3 = f3_override
    if walker is not None and hpos is not None:                    # the direction words: from this ghost's eye to the victim
        yw_, pw_ = hit_words((walker.x, walker.y, walker.z), hpos, EYE_CROUCH if getattr(walker, "crouch", False) else EYE_STAND)
        tail = struct.pack("<HH", yw_, pw_).hex() + tail[8:]
    hit = bytes.fromhex("47") + struct.pack("<III", hs, slot, hs) + struct.pack("<H", 0x7d1) + b"\x00\x00" + struct.pack("<H", kind) + struct.pack("<3f", FIRE_DMG if dmg is None else dmg, 1.0, f3) \
          + bytes.fromhex(tail)
    out.append(hit)
    return out

USE_START = os.environ.get("GHOST_STARTPOS", "1") == "1"; STARTS = None
# (17 Nov: Mrs. Claus was put in the jail by GHOST_SPAWN, but the host's spawn point (and the body rebuilt 3 s in) won: she
#  stood on a barn roof. GHOST_SPAWN now holds for every body of hers.)
FIXED_SPAWN = tuple(float(v) for v in os.environ["GHOST_SPAWN"].split(",")) if os.environ.get("GHOST_SPAWN") else None
SPAWN_DY = float(os.environ.get("GHOST_SPAWN_DY", "0"))      # STARTPOS y is the floor, and real players stand exactly on it (the old -0.5 put every ghost half a unit inside the floor all game)

def startpositions():
    """The STARTPOS objects of the map (the object list <map>.obt): [(x, y, z)], read once. [] when not available."""
    global STARTS
    if STARTS is None and LEVEL_NAME:                          # (not cached while the map name is still unknown)
        STARTS = []
        if True:
            try:
                import nav
                raw = nav.lvt.read_from_labs(LEVEL_NAME.lower() + ".obt") or nav.lvt.read_from_labs(LEVEL_NAME.lower() + ".obb") or b""; txt = raw.decode("latin-1")
                STARTS = [(float(m.group(1)), float(m.group(2)) + SPAWN_DY, float(m.group(3))) for m in
                          re.finditer(r"NAME:\s+STARTPOS\b.*?X:\s*(\S+)\s+Y:\s*(\S+)\s+Z:\s*(\S+)", txt)]
                if not STARTS and b"STARTPOS\x00" in raw:
                    # a binary object list (Bunkers, lilbatl): "STARTPOS\0", id u32, sector u32, then x, y, z floats
                    STARTS = [(lambda v: (v[0], v[1] + SPAWN_DY, v[2]))(struct.unpack_from("<3f", raw, m.end() + 8))
                              for m in re.finditer(rb"STARTPOS\x00", raw) if m.end() + 20 <= len(raw)]
                # (23 Nov, the user: enemies spawned in Sanctuary's jail cells) the mission's MAP_TWEAKS "no_starts" are taken out
                # of the map's own list for the host, but a ghost reads the original: GHOST_NO_STARTS="x,z;x,z" leaves them out here
                try:
                    ns_ = no_starts()
                    if ns_: STARTS = [p_ for p_ in STARTS if all(math.hypot(p_[0] - q[0], p_[2] - q[1]) > 2.0 for q in ns_)]
                except ValueError:
                    pass
                print(f"{len(STARTS)} STARTPOS spawn points found for {LEVEL_NAME}")
            except Exception as e:
                print("STARTPOS list unavailable:", e)
    return STARTS or []

# ---- Survival Horde: no hiding where the zombies can't get to (rooftops, ledges). Every ghost tells the game mode once a second which
# players stand somewhere the zombies can't walk to (state/zreach_<run>_<tag>.txt: "name|0 or 1|player id"); horde.py warns the player,
# counts down 3 s, and names one ghost in state/punish_<run>.txt to hurt them (PUNISH_DMG a second) until they come back down.
# Reachable = the map's route finder (the one the ghosts walk by) has a route there from the map's main area: the spawn point that
# reaches, and is reached from, the most other spawns (Dry Gulch has spawns on a roof and a ledge the ground can't get back up to).
REACH = {"hub": None, "cache": {}, "next": 0.0, "pun_next": 0.0}
PUNISH_DMG = float(os.environ.get("GHOST_PUNISH_DMG", "1.5"))
def main_area():
    """the map's main area: the spawn point that reaches, and is reached from, the most other spawns (None: not known)"""
    if REACH["hub"] is None and LVL is not None:
        S = startpositions()
        if not S: return None
        P = lambda q: {"x": q[0], "y": q[1], "z": q[2]}
        score = [sum(1 for b in S if b is not a and LVL.route(P(a), P(b)) is not None) +
                 sum(1 for b in S if b is not a and LVL.route(P(b), P(a)) is not None) for a in S]
        REACH["hub"] = S[score.index(max(score))]
        print(f"zombie reach: the main area is around {REACH['hub'][0]:.0f},{REACH['hub'][2]:.0f} (spawn scores {score})")
    return REACH["hub"]
def zombie_reachable(pos):
    if LVL is None: return True
    try:
        from fighter import stand_locate
        try:                                                      # (15 Nov, the user: "Get down where the zombies can reach you"
            if LVL.in_water(pos[0], pos[1], pos[2]): return True  #  came up while swimming under Orleans' ice: the water's fine)
        except Exception: pass
        sec = stand_locate(LVL, pos[0], pos[1], pos[2])
        if sec is None: return True                               # (off the map data: no punishing on a guess)
        c = REACH["cache"]
        if sec in c: return c[sec]
        P = lambda q: {"x": q[0], "y": q[1], "z": q[2]}
        if main_area() is None: return True
        ok = LVL.route(P(REACH["hub"]), P(pos)) is not None
        c[sec] = ok
        if not ok: print(f"zombie reach: sector {sec} (height {pos[1]:.1f}) can't be reached by the zombies")
        return ok
    except Exception as e:
        print("zombie reach check failed:", e); return True

def reach_report(now):
    """every second: which players (not our own side) stand out of the zombies' reach, for horde.py"""
    if not MODE_RUN or now < REACH["next"]: return
    REACH["next"] = now + 1.0
    lines = []
    for who, pv in list(players.items()):
        if pv[2] or now - pv[0] > 1.5 or who in NOT_PLAYERS or is_friend(who): continue
        n = display_name(addr_id(who))
        if not n: continue
        lines.append(f"{n.rstrip(b'_').decode(errors='replace')}|{1 if zombie_reachable(pv[1]) else 0}|{addr_id(who)}")
    try:
        with open(os.path.join(MODE_STATE, f"zreach_{MODE_RUN}_{MODE_TAG}.txt"), "w") as f: f.write(f"{time.time():.2f}\n" + "\n".join(lines))
    except OSError: pass

POSREP = {"next": 0.0}
WALKER_REF = [None]
def pos_report(now):
    """co-op missions (horde.py): where everyone is, twice a second (state/pos_<run>.txt: "name|x|y|z"), from the ghost that logs the feed"""
    if not FEED_LOG or now < POSREP["next"]: return
    POSREP["next"] = now + 0.25                           # (the director camera draws these: four times a second)
    lines = []
    w_ = WALKER_REF[0]
    if w_ is not None and alive:                          # this ghost itself (the others' list never holds it)
        lines.append(f"{NAME.rstrip(b'_').decode(errors='replace')}|{w_.x:.1f}|{w_.y:.1f}|{w_.z:.1f}")
    for who, pv in list(players.items()):
        if pv[2] or now - pv[0] > 1.5 or who in NOT_PLAYERS: continue
        n = display_name(addr_id(who))
        if n: lines.append(f"{n.rstrip(b'_').decode(errors='replace')}|{pv[1][0]:.1f}|{pv[1][1]:.1f}|{pv[1][2]:.1f}")
    try:
        with open(os.path.join(MODE_STATE, f"pos_{MODE_RUN or 'live'}.txt"), "w") as f: f.write(f"{time.time():.2f}\n" + "\n".join(lines))
    except OSError: pass

# ---- the Horde's Dr. Death (GHOST_HEALER=1): every second he tells the other ghosts where he is (state/heal_<run>.txt); a ghost within
# HEAL_RANGE of him gets HEAL_RATE health a second back (up to its full health), with the med-bag sound now and then. GHOST_REGEN: his own
# health back a second (the twin-boss finale, when there is no one left for him to heal).
HEALER = os.environ.get("GHOST_HEALER") == "1"
HEAL_RANGE = float(os.environ.get("GHOST_HEAL_RANGE", "16"))    # (18 Nov, the user: "only heal those he's next to": was 70)
# GHOST_ESCORT: the boss's name. Once the boss is in, the Healer keeps close to him (goes back once farther than ESCORT_FAR,
# until within ESCORT_NEAR) to keep him healed.
ESCORT = os.environ.get("GHOST_ESCORT", "")
ESCORT_NEAR, ESCORT_FAR = 5.0, 9.0          # (19 Nov: was 8/14 - the boss heal reaches 16 and he still never healed the demon)
HEAL_RATE = float(os.environ.get("GHOST_HEAL_RATE", "1.0"))
REGEN = float(os.environ.get("GHOST_REGEN", "0"))
HEALST = {"next": 0.0, "said": 0.0}
def heal_step(now, w):
    global hp
    if not MODE_RUN or now < HEALST["next"] or w is None: return
    HEALST["next"] = now + 1.0
    hf = os.path.join(MODE_STATE, f"heal_{MODE_RUN}.txt")
    if HEALER:
        try:
            with open(hf, "w") as f: f.write(f"{time.time():.2f}|{w.x:.1f}|{w.y:.1f}|{w.z:.1f}|{1 if alive else 0}")
        except OSError: pass
        if REGEN > 0 and alive and hp < HP:
            hp = min(HP, hp + REGEN)
        return
    try:
        t_, x_, y_, z_, al_ = open(hf).read().split("|")
        if time.time() - float(t_) > 2.5 or al_ != "1": return
    except (OSError, ValueError):
        return
    if alive and hp < HP and math.dist((float(x_), float(y_), float(z_)), (w.x, w.y, w.z)) < HEAL_RANGE:
        hp = min(HP, hp + HEAL_RATE)
        if now - HEALST["said"] > 6.0:
            HEALST["said"] = now; print(f"healed by Dr. Death: health {hp:.1f}/{HP:.0f}")
            try: pickup_sound(b"cool.wav")
            except Exception: pass

# ---- co-op missions: the hostage (GHOST_HOSTAGE=1). She never fights; she waits where she was put until a player (a name not matching
# GHOST_HOSTAGE_SKIP: the elves and bosses) comes within HOSTAGE_FREE of her, then follows that player. A new body (she went down) waits
# again where she wakes up. horde.py reads state/hostage_<run>.txt ("time|x|y|z|freed 0/1|name").
HOSTAGE = os.environ.get("GHOST_HOSTAGE") == "1"
HOSTAGE_SKIP = re.compile(os.environ.get("GHOST_HOSTAGE_SKIP", r"(Zombie|Skeleton|Bot|Host Bot|Elf|Santa|Gingerbread|Snowman|Nutcracker|Present)( \d+| #\d{3}| No\. \d{3})?$|GhostBot"))
HOSTAGE_FREE = float(os.environ.get("GHOST_HOSTAGE_FREE", "14"))
# GHOST_UNLOCK="x,z;x,z": the locked doors (missions.MAP_TWEAKS: they open when someone walks into their sector) - the hostage's
# body visits each door's sector for a moment when she first appears (that opens them), then she stands where she was put.
UNLOCK = [tuple(float(v) for v in p_.split(",")) for p_ in os.environ.get("GHOST_UNLOCK", "").split(";") if p_.strip()]
UNLOCKED_AT = [0.0]
STILL = os.environ.get("GHOST_STILL") == "1"
LOST_LEAVE = float(os.environ.get("GHOST_LOST_LEAVE", "0") or 0)     # (20 Nov: a pile of presents - knocked about by shots it walked off its spot)


# (25 Nov, the user: Mission 2 - at the pile of presents Mrs. Claus picks up a rifle and fires at the enemies, still following
#  close behind the player) horde.py writes state/hostage_armed_<run>.flag. From then on she shoots the mission's enemies (names
#  matching HOSTAGE_SKIP, never a present) while she follows; GHOST_HOSTAGE_ARMED_MODEL is her look with the rifle (its firing
#  frames too): her body is quietly made again in that look, where she stands.
HOSTAGE_ARMED_MODEL = os.environ.get("GHOST_HOSTAGE_ARMED_MODEL", "").strip().lower()
_ARMED = {"t": 0.0, "on": False, "looked": False}
def hostage_armed():
    if not HOSTAGE: return False
    now_ = time.time()
    if not _ARMED["on"] and now_ - _ARMED["t"] > 1.0:
        _ARMED["t"] = now_
        try: _ARMED["on"] = os.path.exists(os.path.join(MODE_STATE, f"hostage_armed_{MODE_RUN}.flag"))
        except Exception: pass
        if _ARMED["on"]: print("HOSTAGE armed: a rifle")
    return _ARMED["on"]
def hostage_foe(who):
    n_ = display_name(addr_id(who))
    if not n_: return False
    nm_ = n_.rstrip(b"_").decode(errors="replace")
    if NEUTRAL.match(n_.rstrip(b"_")): return False                 # (a pile of presents, an exploding present: never)
    return bool(HOSTAGE_SKIP.match(nm_)) and not nm_.startswith("Present")
def arm_check(now):
    """armed: her body made again (quietly, where she stands) in the look with the rifle"""
    global alive, died_at, respawn_req, MODEL, FIXED_SPAWN
    if _ARMED["looked"] or not hostage_armed(): return
    _ARMED["looked"] = True
    try: FIXED_SPAWN = (walker.x, walker.y, walker.z)              # (25 Nov, the user: armed, she comes back at the presents, not the jail)
    except Exception: pass
    if not HOSTAGE_ARMED_MODEL: return
    if MODEL == HOSTAGE_ARMED_MODEL: return                       # (started in that look already: her body made again after it closed)
    MODEL = HOSTAGE_ARMED_MODEL; print(f"model: {MODEL} (armed)")
    keep_spot()
    try: ent_destroy(slot)
    except Exception as ex_: print("could not take the body away:", ex_)
    alive = False; died_at = now - DEAD_TIME + 0.5; respawn_req = None; QUIET_DEATH[0] = True

def hostage_target(w, now):
    if UNLOCK and not getattr(w, "unl_done", False):
        i_ = getattr(w, "unl_i", 0)
        if now >= getattr(w, "unl_t", 0.0):
            if i_ < len(UNLOCK):
                if i_ == 0: w.unl_home = (w.x, w.y, w.z)
                w.x, w.z = UNLOCK[i_]; w.unl_i = i_ + 1; w.unl_t = now + 0.5; print(f"unlocking: through the door at {w.x:.0f},{w.z:.0f}")
            else:
                w.x, w.y, w.z = getattr(w, "unl_home", (w.x, w.y, w.z)); w.unl_done = True; UNLOCKED_AT[0] = now; print("unlocking: done")
        return (w.x, w.y, w.z)
    near, follow = None, None
    for who, (t, pos3, dying) in list(players.items()):
        if now - t > 1.5 or dying or who in NOT_PLAYERS: continue
        n = display_name(addr_id(who))
        if not n: continue
        nm = n.rstrip(b"_").decode(errors="replace")
        if HOSTAGE_SKIP.match(nm) or nm.encode() == NAME.rstrip(b"_"): continue
        d = math.hypot(pos3[0] - w.x, pos3[2] - w.z)
        if abs(pos3[1] - w.y) < 12.0 and (near is None or d < near[0]): near = (d, nm, pos3)
        if nm == getattr(w, "h_who", None): follow = (d, nm, pos3)
    if not getattr(w, "h_free", False) and near and (near[0] < HOSTAGE_FREE or hostage_armed()):    # (armed: she was freed long ago)
        w.h_free, w.h_who = True, near[1]; print(f"HOSTAGE freed by {near[1]}")
    if getattr(w, "h_free", False) and follow is None and near is not None:
        w.h_who = near[1]; follow = near
    try:
        with open(os.path.join(MODE_STATE, f"hostage_{MODE_RUN}.txt"), "w") as f:
            f.write(f"{time.time():.2f}|{w.x:.1f}|{w.y:.1f}|{w.z:.1f}|{1 if getattr(w, 'h_free', False) else 0}|{getattr(w, 'h_who', '') or ''}")
    except OSError: pass
    w.h_fdist = follow[0] if follow is not None else 99.0
    if getattr(w, "h_free", False) and follow is not None and follow[0] > 9.0:
        return follow[2]
    return (w.x, w.y, w.z)                                     # (waiting, or close enough: stand still)

def escort_target(w, now):
    """the Healer: where the boss is, while we should be walking back to him; None to fight as usual"""
    if not ESCORT: return None
    for who, (t, pos3, dying) in list(players.items()):
        if now - t > 1.5 or dying: continue
        n = display_name(addr_id(who))
        if not n or n.rstrip(b"_").decode(errors="replace") != ESCORT: continue
        d = math.dist(pos3, (w.x, w.y, w.z))
        if not getattr(w, "esc_seen", False):
            w.esc_seen = True; print(f"the boss {ESCORT} is in: keeping close to him")
        if d > ESCORT_FAR: w.esc_back = True
        elif d < ESCORT_NEAR: w.esc_back = False
        if now - getattr(w, "esc_said", 0.0) > 10.0:
            w.esc_said = now; print(f"escort: {d:.0f} from {ESCORT}" + (" (going back to him)" if getattr(w, "esc_back", False) else ""))
        w.esc_on = True
        return pos3 if getattr(w, "esc_back", False) else None
    w.esc_on = False
    return None

def punish_step(now):
    """if horde.py named this ghost to punish someone out of reach: hit them for PUNISH_DMG once a second"""
    if not MODE_RUN or now < REACH["pun_next"]: return
    REACH["pun_next"] = now + 1.0
    try: txt = open(os.path.join(MODE_STATE, f"punish_{MODE_RUN}.txt")).read().split("\n")
    except OSError: return
    for ln in txt:
        parts = ln.strip().split("|")
        if len(parts) < 2 or parts[1] != MODE_TAG: continue
        name = parts[0].encode()
        for who, pv in list(players.items()):
            if pv[2] or now - pv[0] > 1.5: continue
            n = display_name(addr_id(who))
            if not n or n.rstrip(b"_") != name: continue
            hb = bytes.fromhex("47") + struct.pack("<III", who, slot, who) + struct.pack("<H", 0x7d1) + b"\x00\x00" + struct.pack("<H", 1) \
                 + struct.pack("<3f", PUNISH_DMG, 1.0, 0.0) + bytes.fromhex(HIT_TAIL[1][1])
            tid = addr_id(who)
            if tid != 1 and RELAY: relay_msg(2, b"\x00" + hb, [tid])
            elif tid == 1: send_msg(2, b"\x00" + hb)
            print(f"{name.decode(errors='replace')} is still out of the zombies' reach: {PUNISH_DMG:g} damage")

NEUTRAL_KEEP = 60.0


def neutral_spots():
    """where the NEUTRAL players are (Mission 1's piles of presents): the enemies' roaming keeps away from them"""
    now_ = time.time(); out = []
    for who, pv in list(players.items()):
        if now_ - pv[0] > 5.0: continue
        n0 = display_name(addr_id(who))
        if n0 and NEUTRAL.match(n0.rstrip(b"_")): out.append(pv[1])          # (an exploding present too: roaming away from it is no harm)
    return out


# (25 Nov, the user: in Sanctuary the ghosts kept going to one building - "have them venture into other buildings and outside
#  areas just as much") with nobody to fight they walked between the map's STARTPOS points, and 5 of Sanctuary's 14 are in
#  or right by the jail. Now they roam to spots spread evenly over the whole map: a reachable sector middle (nav spots, not
#  up on a roof, not a no-enter sector) in each 30 by 30 square of it.
ROAM_SPOTS = None; ROAM_GRID = 30.0
def roam_spots():
    global ROAM_SPOTS
    if ROAM_SPOTS is None and LVL is not None:
        ROAM_SPOTS = []
        try:
            st_ = startpositions()
            if st_:
                ymax = max(p_[1] for p_ in st_) + 4.0
                ne_ = getattr(LVL, "no_enter", set()) or set()
                cells = {}
                for sp_ in LVL.spots({"x": st_[0][0], "y": st_[0][1], "z": st_[0][2]}):
                    if sp_["index"] in ne_ or sp_["y"] > ymax: continue
                    k_ = (int(sp_["x"] // ROAM_GRID), int(sp_["z"] // ROAM_GRID))
                    if k_ not in cells: cells[k_] = (sp_["x"], sp_["y"], sp_["z"])
                ROAM_SPOTS = list(cells.values())
                print(f"{len(ROAM_SPOTS)} roaming spots spread over {LEVEL_NAME} (one per {ROAM_GRID:.0f} by {ROAM_GRID:.0f} square)")
        except Exception as e:
            print("roaming spots unavailable:", e)
    return ROAM_SPOTS or []

def pick_roam(avoid):
    """a roaming spot at least 25 away, never by a hidden pile of presents; None: use pick_start"""
    import random
    sp_ = [p_ for p_ in roam_spots() if math.hypot(p_[0] - avoid[0], p_[2] - avoid[2]) > 25]
    hid = neutral_spots()
    if hid: sp_ = [p_ for p_ in sp_ if all(math.hypot(p_[0] - q[0], p_[2] - q[2]) > NEUTRAL_KEEP for q in hid)]
    return random.choice(sp_) if sp_ else None


def pick_start(avoid=None, near=None):
    """A STARTPOS far from the host's player (when known) and not where the ghost just was; None if the map has none."""
    import random
    st = [p for p in startpositions() if avoid is None or math.hypot(p[0] - avoid[0], p[2] - avoid[2]) > 20]
    if not st: return None
    # (23 Nov, the user: with the player dead, the enemies hung about a pile of presents and gave it away) never a point near a
    # NEUTRAL player - Mission 1's hidden piles
    hid = neutral_spots()
    if hid:
        st = [p for p in st if all(math.hypot(p[0] - q[0], p[2] - q[2]) > NEUTRAL_KEEP for q in hid)] or st
    # never on top of someone: a point with a player or another ghost within SPAWN_CLEAR is skipped (two bodies in one spot made
    # the awful grinding noise and could hide a ghost inside another player)
    now_ = time.time()
    taken = [pv[1] for pv in list(players.values()) if now_ - pv[0] < 3.0]
    free = [p for p in st if all(math.hypot(p[0] - q[0], p[2] - q[2]) > SPAWN_CLEAR for q in taken)]
    st = free or st
    if GHOST_INDEX:
        # The launcher's ghosts never choose by chance: two that chose in the same instant (they killed each other, or joined
        # together) could not see each other yet and landed on one point, walking off inside each other (measured: Hard 1 and
        # Easy 2 on town_2p, both at 230,331 for 1.7 s). Each takes the point its own number gives, so ghosts with the same
        # view always differ. The first spawn (avoid is None; asked twice, both the same) is ghost n's n-th point of the whole
        # map; a respawn counts through the points that are free and far from the host's player, moving on every 2 s.
        key = lambda p: (p[0], p[2])
        if avoid is None:
            allp = sorted(startpositions(), key=key)
            step = next(k for k in (5, 3, 7, 1) if math.gcd(k, len(allp)) == 1)       # (spread over the map, every ghost a different one)
            ok = set(st)
            for k in range(len(allp)):
                p = allp[((GHOST_INDEX - 1) * step + k) % len(allp)]
                if p in ok: return p
            return allp[(GHOST_INDEX - 1) * step % len(allp)]
        if near is not None and len(st) >= 2 * SPAWN_SPREAD:      # (far from the host's player, while that leaves every ghost a point of its own)
            st = sorted(st, key=lambda p: -math.hypot(p[0] - near[0], p[2] - near[2]))[:(len(st) + 1) // 2]
        st = sorted(st, key=key)
        return st[(GHOST_INDEX - 1 + int(now_ / 2.0) * 3) % len(st)]
    if near is not None: st.sort(key=lambda p: -math.hypot(p[0] - near[0], p[2] - near[2])); st = st[:max(1, (len(st) + 1) // 2)]
    return random.choice(st)
SPAWN_CLEAR = 12.0; SPAWN_SPREAD = 8
GHOST_INDEX = int(os.environ.get("GHOST_INDEX", "0") or 0)
FEED_LOG = os.environ.get("GHOST_FEED", "1" if GHOST_INDEX <= 1 else "0") == "1"     # this ghost logs the kill feed and the players' shots (one per game: livestats.py)
# Ghosts that died in the same instant come back a moment apart (ghost n waits a little longer), so the later one sees the earlier.
RESPAWN_LAG = ((GHOST_INDEX - 1) % 6) * 0.2 if GHOST_INDEX else 0.0

class Walker:
    def __init__(self, sx, sy, sz):
        self.x, self.y, self.z = sx, sy, sz; self.sx, self.sz = sx, sz
        self.k = 0; self.yaw = 0.0; self.pitch = 0; self.pause_until = 0.0; self.last = None; self.moving = False; self.sweep = 1
    def target(self): dx, dz = ROUTE[self.k % len(ROUTE)]; return self.sx + dx, self.sz + dz
    def step(self, now):
        dt = 0.15 if self.last is None else min(now - self.last, 0.5); self.last = now
        if now < self.pause_until:
            self.moving = False
            return make_state(self.x, self.y, self.z, self.yaw, self.pitch, 0.0, 0.0, False), 1.0 if self.pitch == 0 else 0.3
        tx, tz = self.target(); dx, dz = tx - self.x, tz - self.z; d = math.hypot(dx, dz)
        if d < 1.5:                                   # arrived: pause, look up/down a little, go to the next point
            self.k += 1; self.pause_until = now + 2.0; self.sweep = -self.sweep; self.pitch = 900 * self.sweep; self.moving = False
            return make_state(self.x, self.y, self.z, self.yaw, self.pitch, 0.0, 0.0, False), 0.3
        self.pitch = 0; self.moving = True
        ux, uz = dx / d, dz / d; self.yaw = math.atan2(ux, uz)    # forward = (sin yaw, cos yaw) in the (x, z) plane (measured)
        stp = min(SPEED * dt, d); nx, nz = self.x + ux * stp, self.z + uz * stp
        if not valid_pos(nx, self.y, nz):                  # a wall / outside the map: stop here, take the next route point
            self.k += 1; self.pause_until = now + 1.0; self.moving = False
            return make_state(self.x, self.y, self.z, self.yaw, self.pitch, 0.0, 0.0, False), 0.3
        self.x, self.z = nx, nz
        return make_state(self.x, self.y, self.z, self.yaw, self.pitch, ux * SPEED, uz * SPEED, True), 0.15

FIGHT = os.environ.get("GHOST_FIGHT", "1") == "1"                 # fight: chase the host's player, face it, strafe and shoot (needs the map data)
# a game mode can slow its ghosts (GHOST_SPEED_SCALE, e.g. Survival Horde's melee tiers: 0.5 at Easiest ... 1.0 at Hell) and keep them
# from sprinting (GHOST_NO_SPRINT=1: Easiest and Easy only walk); the level flag can change both mid-life ("easy+walk+speed=0.6")
SPEED_SCALE = [float(os.environ.get("GHOST_SPEED_SCALE", "1"))]
NO_SPRINT = [os.environ.get("GHOST_NO_SPRINT", "0") == "1"]
# A fresh run 46.1-46.4 and a walk exactly 31.0 (the user's Dr Death, 11 Nov, GhostLogs\move_rec.jsonl; was 44 / 30)
FIGHT_BASE = float(os.environ.get("GHOST_FIGHT_SPEED", "46")); WALK_BASE = float(os.environ.get("GHOST_WALK_SPEED", "31"))
FIGHT_SPEED = FIGHT_BASE * SPEED_SCALE[0]
DIFFICULTY = os.environ.get("GHOST_DIFFICULTY", "normal").lower()      # easiest / easy / normal / hard / nightmare / hell: the bots' own tiers (brain.DIFFICULTY)
SWIM_SND = os.environ.get("GHOST_SWIMSND", "1") == "1"         # splash / stroke / swim_out sounds (GHOST_SWIMSND=0 silences them)
SHOT_WAV = os.environ.get("GHOST_SHOTSND", START_W["snd"]).encode()

# ---- Doors and windows (decoded from the user's Sanctuary door test, 6 Nov): pressing "use" at a door sends 0x7d6 with
# A = the door's elevator number, B = the player's slot, C = sender address | A, body 2000 0000 a035d128 0000 0000; the host then runs
# the door. The elevator numbers are the map's INF items in order from a base the game counts up to first (Sanctuary 0xb2:
# COURTHOUSEDOOR01 = 0xb2, ..02 = 0xb3, JAILDOOR02 = 0xb5 ...). A window shot out: 0x422 with (u16 sector, u16 wall).
DOOR_BASE = {"town_2p": 0xb2}
BROKEN_EDGES = set()
DOOR_BODY = bytes.fromhex("20000000a035d12800000000")
_INF = {}
def door_id(sec_index):
    """the game's elevator number of the door whose panel is sector sec_index on this map, or None if not known"""
    base = int(os.environ["GHOST_DOOR_BASE"], 0) if os.environ.get("GHOST_DOOR_BASE") else DOOR_BASE.get((LEVEL_NAME or "").lower())
    if base is None or LVL is None: return None
    try:
        if "inf" not in _INF:
            import nav; _INF["inf"] = [e.sector.upper() for e in nav.lvt.load_inf(LEVEL_NAME)]
        nm = (LVL.sectors[sec_index].name or "").upper()
        return base + _INF["inf"].index(nm) if nm in _INF["inf"] else None
    except Exception: return None
# ---- Door state (10 Nov; the user: "they walk through doors instead of opening them ... not walk thru closed doors"). Every door in
# these maps is a two-stop toggle (INF "STOP: 0 HOLD / STOP: 5.875 HOLD"): each "use" (event 32, or 16) sends it to the other stop
# and it stays there. The host passes every player's use on to the others (0x7d6, C = 0x800 | the door's number, event byte 32), and
# reports players walking into / out of a door's sector (events 4 / 8: in the recordings the ghosts walked through closed jail doors
# all game). So each ghost counts the uses: closed at the start, open after one, closed after two ... A door counts as open only
# once it has had the time to get there (its INF distance / SPEED). The ghosts used to "use" a door every 6 s while near it, which
# shut it again in other ghosts' (and the user's) faces.
DOOR_STATE = {}; DOOR_TRAVEL = {}; DOOR_SEEN_BASE = {}; DOOR_GUARD = os.environ.get("GHOST_DOOR_GUARD", "1") == "1"
DOOR_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "door_bases.json")
try:
    with open(DOOR_FILE, encoding="utf-8") as f_: DOOR_BASE.update({k.lower(): int(v) for k, v in json.load(f_).items()})
except (OSError, ValueError): pass
def door_travel(elev):
    """seconds the door takes from one stop to the other (from the map's INF: the stops' distance or angle / SPEED)"""
    if elev not in DOOR_TRAVEL:
        t_ = 1.0
        try:
            base = DOOR_BASE.get((LEVEL_NAME or "").lower()); txt = (nav_lvt().read_from_labs(LEVEL_NAME.lower() + ".inf") or b"").decode("latin-1")
            blocks = re.split(r"ITEM:", txt)[1:]
            blk = blocks[elev - base] if base is not None and 0 <= elev - base < len(blocks) else ""
            sp = re.search(r"SPEED:\s*([-\d.]+)", blk); stops = [float(v) for v in re.findall(r"STOP:\s*([-\d.]+)", blk)]
            if sp and float(sp.group(1)) > 0 and len(stops) >= 2: t_ = max(0.3, (max(stops) - min(stops)) / float(sp.group(1)))
        except Exception: pass
        DOOR_TRAVEL[elev] = min(t_, 4.0)
    return DOOR_TRAVEL[elev]
def nav_lvt():
    import nav; return nav.lvt
def door_used(elev, now, who=""):
    st = DOOR_STATE.setdefault(elev, [False, -99.0]); st[0] = not st[0]; st[1] = now
    print(f"door {elev:#x} used{who}: now {'opening' if st[0] else 'closing'}")
STUCK_DOOR_S = float(os.environ.get("GHOST_STUCK_DOOR", "10"))
GHOST_USE_COUNTS = os.environ.get("GHOST_USE_COUNTS", "0") == "1"
def door_passed(elev, pid, now):
    """the host says a player walked into / out of a door's own sector: for a real game (not a ghost: ghosts walk through anything
    on the other screens) that door must be open - fix our count if it says shut (12 Nov: a count gone wrong - a ghost that joined late,
    a use we missed - left ghosts stopped at open doors and walking through shut ones)"""
    nm = display_name(pid)
    if not nm or nm.rstrip(b"_") == NAME.rstrip(b"_") or PEERS.fullmatch(nm.rstrip(b"_")): return
    st = DOOR_STATE.setdefault(elev, [False, -99.0])
    if not st[0]:
        st[0] = True; st[1] = now - door_travel(elev)
        print(f"door {elev:#x}: {nm.decode(errors='replace')} walked through it, so it is open")
def panel_of(dp):
    return min(LVL.panels, key=lambda q: math.hypot(q["x"] - dp["x"], q["z"] - dp["z"]), default=None) if LVL is not None and dp else None
def door_state(dp):
    """True: open (and done moving), False: closed or still moving, None: not known on this map (its number unknown)"""
    pan = panel_of(dp)
    if pan is None: return None
    did = door_id(pan["sector"])
    if did is None: return None
    if UNLOCKED_AT[0] and time.time() - UNLOCKED_AT[0] > 2.5 and any(math.hypot(dp["x"] - ux, dp["z"] - uz) < 4.0 for ux, uz in UNLOCK):
        return True                    # (17 Nov: the hostage opened these herself - no "use" message ever came, so she thought them shut and couldn't get out)
    st = DOOR_STATE.get(did, [False, -99.0])
    return bool(st[0] and time.time() - st[1] >= door_travel(did))
def door_learn(elev, who, now):
    """a map whose door numbers aren't known yet: a player the host just reported at / walking into door elevator `elev` stands in
    that door's sector, so base = elev - the door's place in the INF list. Two agreeing reports: kept, and saved for the next game."""
    lv = (LEVEL_NAME or "").lower()
    if not lv or lv in DOOR_BASE or LVL is None: return
    pv = players.get(who)
    if not pv or now - pv[0] > 1.0: return
    try:
        if "inf" not in _INF: _INF["inf"] = [e.sector.upper() for e in nav_lvt().load_inf(LEVEL_NAME)]
        pan = min(LVL.panels, key=lambda q: math.hypot(q["x"] - pv[1][0], q["z"] - pv[1][2]), default=None)
        if pan is None or math.hypot(pan["x"] - pv[1][0], pan["z"] - pv[1][2]) > 4.0: return
        nm = (LVL.sectors[pan["sector"]].name or "").upper()
        if nm not in _INF["inf"]: return
        base = elev - _INF["inf"].index(nm)
    except Exception: return
    if DOOR_SEEN_BASE.get(lv) == base:
        DOOR_BASE[lv] = base; print(f"learned this map's door numbers: {lv} starts at {base:#x}")
        try:
            try:
                with open(DOOR_FILE, encoding="utf-8") as f_: saved = json.load(f_)
            except (OSError, ValueError): saved = {}
            saved[lv] = base
            with open(DOOR_FILE, "w", encoding="utf-8") as f_: json.dump(saved, f_, indent=1)
        except OSError: pass
    else: DOOR_SEEN_BASE[lv] = base
USE_Q = {}
LAST_PRESS = {}
USE_REACH = 5.0
def use_step(now):
    """send the queued "use" once the ghost has faced the door for a state or so"""
    if not USE_Q or USE_Q.get("sent") or now < USE_Q.get("at", 0): return
    USE_Q["sent"] = True
    send_msg(2, b"\x00\x47" + struct.pack("<III", 0x800, slot, slot) + struct.pack("<H", 0x40c) + b"\x00\x00" + struct.pack("<If", 0, USE_REACH))
    print(f"used the door {USE_Q.get('name')} (elevator {USE_Q.get('did', 0):#x})")
def use_facing(x, z, now):
    """the yaw to face the queued door, while a press is under way (None: none)"""
    if not USE_Q or now > USE_Q.get("until", 0): return None
    dp = USE_Q["dp"]; return math.atan2(dp["x"] - x, dp["z"] - z)
def open_door(dp, force=False):
    """send the game's "use" on the door whose panel centre is dp"""
    if LVL is None: return
    pan = panel_of(dp)
    if pan is None: return
    did = door_id(pan["sector"])
    if did is None: print(f"door at {dp['x']:.0f},{dp['z']:.0f}: its number on this map is not known (no door message)"); return
    # (12 Nov, the user's own game recorded opening doors: a player's game never sends 0x7d6 - that is the HOST's answer to everyone.
    #  What it sends is "use" itself, 0x40c to the host (A = 0x800, B = C = its slot, body 0, 5.0 - the reach); the host traces
    #  from where that player stands, the way it faces, runs the door it finds and tells everyone (0x7d6, event 32, B = the user).
    #  The ghosts sent the host's answer instead, which the host ignores: their doors never opened. Now: turn to face the door,
    #  let a state with that facing go out, then "use" (use_step). The count changes when the host's 0x7d6 comes back.)
    now_ = time.time()
    if USE_Q and now_ < USE_Q.get("until", 0): return              # (one press at a time)
    # (12 Nov, the user: "press open on them just once - pressed again it could start opening and then shut". One press per door: none
    #  while our own press is waiting for the host's answer or the door is still swinging, from this ghost or anyone else's press.)
    wait_ = door_travel(did) + 1.0
    if now_ - LAST_PRESS.get(did, -99.0) < wait_ + 1.0: return
    if now_ - DOOR_STATE.get(did, [False, -99.0])[1] < wait_: return
    if door_state(dp) and not force: return                           # (open already: a press would shut it)
    LAST_PRESS[did] = now_
    USE_Q.clear(); USE_Q.update(dp=dict(dp), name=LVL.sectors[pan["sector"]].name, did=did, at=now_ + 0.2, until=now_ + 0.7, sent=False)
BROKEN_WALLS = set()
def broken_edges():
    """window edges of the route finder that are shot out (from the (sector, wall) pairs the game reported)"""
    out = set()
    if LVL is None: return out
    for (si, wi) in BROKEN_WALLS:
        try:
            s = LVL.sectors[si]; w = s.walls[wi]; a, b = s.vertices[w.v1], s.vertices[w.v2]; mx, mz = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
            for es in LVL.edges.values():
                for e in es:
                    if e.window and si in e.key[:2] and math.hypot(e.x - mx, e.z - mz) < max(2.0, math.hypot(b[0] - a[0], b[1] - a[1]) / 2 + 1.0):
                        out.add(e.key)
        except Exception: continue
    return out
# ---- The map's items (the host's list: 0x3f8 bundles of creates at join, single 0x3fd creates when one comes back, 0x3ff when taken)
ITEMS = {}; ITEM_SKIP = {}; ARMOR = [0.0]
# boiler plates: gbplate1.itm COUNT 150, gbplate2 100 ("COUNT is 10 * how much damage it can absorb"); pickup sound ricoch3
PLATE_VALUE = {"GBPLATE1": 15.0, "GBPLATE2": 10.0, "GBPLATE3": 5.0, "NBPLATE1": 15.0, "NBPLATE2": 10.0, "NBPLATE3": 5.0}
PLATES_ON = os.environ.get("GHOST_PLATES", "1") == "1"
PLATE_RANGE = float(os.environ.get("GHOST_PLATE_RANGE", "70"))      # goes for a plate this close
PLATE_IGNORE_NEAR = float(os.environ.get("GHOST_PLATE_FIGHT", "20"))  # ...unless an enemy is closer than this
PLATE_MAX = float(os.environ.get("GHOST_PLATE_MAX", "15"))
def item_name(blob):
    m = re.search(rb"([A-Za-z0-9_]+)\.(?:ITM|itm)\x00", blob)
    if m: return m.group(1).decode().upper()
    m = re.search(rb"(GAMBOX[BCS])\.", blob.upper())          # (a dropped ammo box names its picture twice and no .ITM)
    return m.group(1).decode() if m else None
def note_items(p):
    """item creates in a host message: a single 0x3fd, or a 0x3f8 bundle of them"""
    ty = struct.unpack("<H", p[13:15])[0]
    if ty == 0x3fd and len(p) >= 41:
        nm = item_name(p[41:])
        if nm: ITEMS[struct.unpack("<H", p[21:23])[0]] = (nm, struct.unpack("<3f", p[29:41]))
    elif ty == 0x3f8:
        idx = [m.start() for m in re.finditer(rb"\xfd\x03\x00\x40", p)]
        for k, i in enumerate(idx):
            end = idx[k + 1] if k + 1 < len(idx) else len(p)
            if i + 28 > len(p): continue
            nm = item_name(p[i + 28:end])
            if nm: ITEMS[struct.unpack("<H", p[i + 8:i + 10])[0]] = (nm, struct.unpack("<3f", p[i + 16:i + 28]))
# Ammo lying about (the user, 10 Nov: "make the ghosts pick up ammo whenever they walk over it"): the boxes a dying player leaves and
# a knife or stick on the ground. What each gives is its own file's (g<name>.itm: PICKUP, COUNT): a box of bullets 12, cartridges
# (the rifle's) 16, shells 8, a knife or a stick of dynamite 1. A ghost takes what one of its own weapons uses, up to AMMO_CAP x what it
# spawned with; its pistol never runs out, so bullets it always takes (a player low on bullets would).
AMMO_ITEMS = {"GAMBOXB": ("pistol", 12), "GAMBOXC": ("rifle", 16), "GAMBOXS": ("shells", 8), "GKNIFE": ("knife", 1), "GDYNAM": ("dynamite", 1)}
AMMO_ON = os.environ.get("GHOST_AMMO", "1") == "1"; AMMO_REACH = 3.0; AMMO_CAP = 3
# (12 Nov, the user: "I can hear it when the ghosts pickup items ... Only the character picking up that item should hear it". In the game
#  the grab / gulp / plate / med bag sounds are the picker's own; the ghosts sent them to everyone. Off: GHOST_PICKUP_SOUNDS=1 brings them back.)
PICKUP_SOUNDS = os.environ.get("GHOST_PICKUP_SOUNDS", "0") == "1"
def pickup_sound(wav):
    if PICKUP_SOUNDS: send_sound(sound_msg(slot, wav))
def take_item(isl, nm):
    """pick an item up: 0x3ff for it to the host (as the user's own pickup), and its effect on the ghost"""
    ITEMS.pop(isl, None)
    send_msg(2, b"\x00\x47" + struct.pack("<III", 0, NS, isl) + struct.pack("<H", 0x3ff) + b"\x00\x00")
    # (12 Nov evening, Dry Gulch in a hosted game: a ghost took a boiler plate and the user could still take it too. The host doesn't pass a
    #  client's pickup of the map's own items on - while the user WAS the host his game removed it itself. Now every other player is
    #  told, like a real client does; a second "gone" for something already gone does nothing.)
    tell_gone(isl)
    if nm in PLATE_VALUE:
        ARMOR[0] = min(PLATE_MAX, ARMOR[0] + PLATE_VALUE[nm]); pickup_sound(b"ricoch3.wav")
        print(f"picked up the {nm}: armor {ARMOR[0]:.0f}")
SPREAD = {"sgun": 3.0, "dbsgun": 4.0, "stab": 45.0, "dynamite": 45.0}     # degrees added to the target's width: pellets spread; a stab or a blast can't miss by a hair
STAMINA_SHOWN = [False]
class FightWalker(Walker):
    """Same interface as Walker, but the movement and shooting come from fighter.Fighter."""
    def visit(self, now):
        """A mission's director (horde.py) asks for someone to step into a door's sector, which runs the door (its INF: darkitems
        lock_doors): state/visit_<run>.txt "x,y,z,t". The first ghost to claim it (visit_<run>.txt.claim) is there for half a
        second, then back where it was - as the hostage unlocks the jail cells."""
        vis = getattr(self, "vis", None)
        if vis is not None:
            if now < vis[1]: self.x, self.y, self.z = vis[0]; return vis[0]
            self.x, self.y, self.z = vis[2]; self.vis = None; print("visit: back"); return None
        if now < getattr(self, "vis_next", 0.0): return None
        self.vis_next = now + 0.5
        vf_ = os.path.join(MODE_STATE, f"visit_{MODE_RUN}.txt")
        if not MODE_RUN or not os.path.exists(vf_) or now - self.born < 3.0: return None
        try:
            x_, y_, z_, t_ = (float(v) for v in open(vf_).read().split(","))
            if time.time() - t_ > 4.0 or getattr(self, "vis_t", None) == t_: return None
            self.vis_t = t_
            os.close(os.open(vf_ + ".claim", os.O_CREAT | os.O_EXCL | os.O_WRONLY))
        except (OSError, ValueError):
            return None
        self.vis = ((x_, y_, z_), now + 0.5, (self.x, self.y, self.z))
        print(f"visit: stepping into the door at {x_:.0f},{z_:.0f}")
        self.x, self.y, self.z = x_, y_, z_
        return (x_, y_, z_)

    def way_down(self, ne_):
        """the nearest point just outside the no-enter sectors (nav GHOST_NO_ENTER), a little past the opening out of them"""
        L_ = self.F.L
        if getattr(self, "_exits", None) is None:
            ex_ = []
            for a_, es_ in getattr(L_, "edges", {}).items():
                if a_ not in ne_: continue
                for e_ in es_:
                    if e_.to in ne_: continue
                    try:
                        sc_ = L_.sectors[e_.to]; vs_ = sc_.vertices
                        cx_, cz_ = sum(v[0] for v in vs_) / len(vs_), sum(v[1] for v in vs_) / len(vs_)
                        d_ = math.hypot(cx_ - e_.x, cz_ - e_.z) or 1.0
                        px_, pz_ = e_.x + (cx_ - e_.x) / d_ * 4.0, e_.z + (cz_ - e_.z) / d_ * 4.0
                        if not sc_.contains(px_, pz_): px_, pz_ = e_.x, e_.z
                        ex_.append((px_, L_.floor_at(e_.to, px_, pz_), pz_))
                    except Exception:
                        pass
            self._exits = ex_
        if not self._exits: return None
        return min(self._exits, key=lambda p_: math.hypot(p_[0] - self.x, p_[2] - self.z) + abs(p_[1] - self.y))

    def __init__(self, sx, sy, sz):
        Walker.__init__(self, sx, sy, sz)
        self.going_for = None; self.going_since = 0.0; self.strafe0 = None; self.guard_press = {}; self.still_since = None
        from fighter import Fighter
        self.F = Fighter(LVL, difficulty=DIFFICULTY, speed_run=FIGHT_BASE * SPEED_SCALE[0], speed_walk=WALK_BASE * SPEED_SCALE[0], base_gap=float(os.environ.get("GHOST_FIRE_GAP", START_W["gap"])), reach=START_W["reach"],
                         energy=ENERGY if STAMINA_ON else None, energy_max=STAMINA_MAX, energy_resume=STAMINA_RESUME)
        self.F.no_sprint = NO_SPRINT[0]
        self.F.door_state = door_state                               # (closed doors are walls; open ones are walked through)
        if STAMINA_ON and not STAMINA_SHOWN[0]:
            STAMINA_SHOWN[0] = True; E = ENERGY
            print(f"stamina from {ENERGY_SRC}: rest {E['rest']:+g}/s, run {E['move']:+g}/s, jump {E['jump']:+g}, max {STAMINA_MAX:g}"
                  f" -> strafes at a run {STAMINA_MAX / max(-E['move'], 1e-9):.1f} s from full, then walks until {STAMINA_RESUME:.0%} is back ({STAMINA_RESUME * STAMINA_MAX / max(E['rest'], 1e-9):.1f} s)")
        print(f"ghost fights like a {self.F.p['level']} bot (GHOST_DIFFICULTY): aim wobble {self.F.p['aim_error']}, reaction {self.F.p['reaction']} s, turn {self.F.p['turn_speed']:.0f} deg/s, range {self.F.p['max_engage']:.0f}")
        self.fire = None; self.wet = False; self.swim_snd = 0.0; self.water_events = []
        self.born = time.time()                                          # (no attacking for SPAWN_HOLD after this)
        self.unreach = {}; self.roam = None; self.roam_until = 0.0
        self.load = Loadout(); st = STYLES[CHAR]; self.rush_until = 0.0
        if STYLE_ON:
            # the style sets how much this character strafes and sprints compared with the others; the difficulty sets the level
            # (an easiest Mary strafes 15% x her share, a hell one all the time): tier share x style / the average style (0.85 strafe, 0.8 sprint)
            self.F.p.update(keep_distance=st["keep"], retreat=st["retreat"],
                            sprint_frac=min(1.0, self.F.p["sprint_frac"] * st["sprint"] / 0.8), strafe_frac=min(1.0, self.F.p["strafe_frac"] * st["strafe"] / 0.85))
            self.strafe0 = self.F.p["strafe_frac"]
            self.F.see_reach = max(self.F.see_reach, 650.0)
            print(f"strafes {self.F.p['strafe_frac']:.0%} of the time, sprints {self.F.p['sprint_frac']:.0%}")
            print(f"style: {st['note']} (weapons: {', '.join(self.load.arms)}" + (f", {self.load.bags} med bags" if self.load.bags else "") + ")")
    def grab(self, isl, nm, now):
        """take a weapon / canteen from the map (the user's own pickup message), if it is any use"""
        global hp
        if nm in BAG_ITEMS:
            if self.load.bags >= BAG_MAX: return
            take_item(isl, nm); self.load.bags = min(BAG_MAX, self.load.bags + BAG_COUNT); pickup_sound(b"cool.wav"); print(f"picked up med bags ({self.load.bags})")
            return
        if nm in HEAL_ITEMS:
            if hp >= HP: return
            take_item(isl, nm); hp = min(HP, hp + HEAL_ITEMS[nm]); pickup_sound(b"gulp.wav" if nm == "GCANTEEN" else b"elixir.wav"); print(f"picked up {nm}: health {hp:.1f}")
            return
        if nm not in WEAPON_ITEMS: return
        arm, n_ = WEAPON_ITEMS[nm]
        if arm not in LIKED.get(CHAR, []) and arm not in self.load.ammo and not (arm == "knife" and CHAR == "twofeathers"): return
        if not self.load.add(arm, n_): return
        take_item(isl, nm); pickup_sound(b"weapgrab.wav"); print(f"picked up {nm}: {arm} ({self.load.ammo.get(arm)} rounds)")
    def step(self, now):
        global host_pos, target_slot
        if STILL:                                                        # GHOST_STILL: never moves at all (Mission 1's piles of presents)
            if getattr(self, "still_at", None) is None: self.still_at = FIXED_SPAWN or (self.x, self.y, self.z)
            self.x, self.y, self.z = self.still_at; BLASTKNOCK.clear(); LAST_HIT.clear()
            return make_state(self.x, self.y, self.z, self.yaw, 0, 0.0, 0.0, False), 0.25
        if BLASTKNOCK:                                                   # thrown by a blast: in the air until it lands
            v, s_ = knock_step(0.05)
            return make_state(self.x, self.y, self.z, self.yaw, 0, v[0], v[2], True, vy=v[1], sec=s_), 0.05
        # Deathmatch: everyone is a target (the human and the other ghosts), the nearest one we can get to first. An opponent the map's
        # route finder has no way to (and that is not in sight) is skipped for a while: chasing it used to leave the ghost standing still for good.
        cands = []
        for who, (t, pos3, dying) in list(players.items()):
            if now - t > 1.5:
                if now - t > 10: players.pop(who, None)
                continue
            if dying or self.unreach.get(who, 0.0) > now or now - first_seen.get(who, now) < MIN_AGE: continue
            if HOSTAGE:                                                    # (the missions' hostage never fights - until she is armed)
                if not (hostage_armed() and hostage_foe(who)): continue
            elif is_friend(who): continue                                  # a game mode's own side (GHOST_FRIENDS): never a target
            cands.append((math.hypot(pos3[0] - self.x, pos3[2] - self.z), who, pos3))
        cands.sort()
        best = cands[0] if cands else None
        roam = False
        if best is not None:
            target_slot, host_pos = best[1], best[2]; tgt = best[2]; self.roam = None
            crowd = sum(1 for c in cands if math.hypot(c[2][0] - tgt[0], c[2][2] - tgt[2]) < 20.0)     # enemies bunched around the target (dynamite)
            w = self.load.choose(best[0], now, crowd)
            if getattr(self.F, "swimming", False):                  # under the water: guns don't work - the knife, else the fists
                self.load.cur = "stab" if self.load.has("stab") else "fist"; w = WEAPONS[self.load.cur]
            st = STYLES[CHAR]
            keep = st["keep"] if self.load.cur in st["arms"][:1] or CHAR in ("sanchez", "drdeath") else max(st["keep"], 28.0)   # fallback pistol: a bit further back
            if PICKUPS and self.load.cur not in st["arms"][:1]: keep = min(30.0, keep)              # (not its favourite gun yet: the bots' default 30)
            if PICKUPS: keep = min(keep, WEAPONS[self.load.cur]["range"] * 0.6)                      # (and never further than the gun reaches, as the bots)
            if self.load.cur in ("fist", "stab") and (WMODE in ("melee", "tnt") or BOSS_ARMS): keep = MELEE_KEEP                                # fists / knife: up close (not INTO them)
            if STYLE_ON and CHAR == "twofeathers" and self.load.cur == "knife": keep = 26.0      # Chief opens with throws from range...
            if DYNS and not HELD: keep = max(keep, best[0] + 1.0)        # our stick is out there: no walking toward it (the blast hurt the thrower)
            if HELD or any(math.dist(d_["p"], (self.x, self.y, self.z)) < 55.0 for d_ in DYNS):
                keep = 60.0; self.F.p["retreat"] = 50.0       # a lit stick in hand, or ours about to go off: stay out of its blast (the bots' tnt_min 45)
            elif STYLE_ON: self.F.p["retreat"] = 0.0 if self.load.cur in ("fist", "stab") else STYLES[CHAR]["retreat"]
            if STYLE_ON and now < self.rush_until: keep = MELEE_KEEP; self.F.sprinting = True; self.F.sprint_until = now + 0.5     # ...a hit spins them round: rush in for the stab
            if KAMI:                                                  # an exploding present: straight at them, running
                keep = 0.5; self.F.p["retreat"] = 0.0; self.F.p["strafe_frac"] = 0.0; self.F.sprinting = True; self.F.sprint_until = now + 0.5
            # (Chief's 42 is for his throws; a stab or a punch only lands within its own reach - in Melee only the ghost stabbed from 36 away)
            self.F.p.update(max_engage=max(w["range"], 42.0) if (CHAR == "twofeathers" and self.load.cur == "knife") else w["range"], keep_distance=keep if STYLE_ON else self.F.p["keep_distance"])
            self.F.base_gap = w["gap"]; self.F.hold_fire_until = self.load.reloading_until; self.F.spray = self.load.cur == "pistol"
            self.F.weapon = self.load.cur
            self.F.tgt_vel = VEL.get(target_slot, (0.0, 0.0))     # (the aim trails a target that moves sideways: fighter.AIM_LAG)
            self.F.spread = SPREAD.get(self.load.cur, 0.0); self.F.hurt = hp < HP * 0.4
            # the pistol fanned (FAN): the tiers in FAN_LEVELS, within fanning's own range (further: aimed shots, primary fire)
            self.load.fan = self.load.cur == "pistol" and self.F.p.get("level") in FAN_LEVELS and best[0] <= FAN["range"]
            if self.load.fan: self.F.base_gap = FAN["gap"]
            self.F.scatter = FAN["scatter"] if self.load.fan else 0.0
            # fists / a stab: straight at them (strafing round at arm's length, a Melee only Mary circled the user for a while first)
            if self.load.cur in ("fist", "stab"): self.F.p["strafe_frac"] = 0.0
            elif self.strafe0 is not None: self.F.p["strafe_frac"] = self.strafe0
        else:
            target_slot = None                                       # nobody alive we can reach: walk between the map's start points until someone turns up
            hid_ = neutral_spots()                                   # (and never hanging about a hidden pile of presents)
            near_hid = any(math.hypot(q[0] - self.x, q[2] - self.z) < NEUTRAL_KEEP * 0.6 for q in hid_)
            if near_hid and self.roam is not None and any(math.hypot(q[0] - self.roam[0], q[2] - self.roam[2]) < NEUTRAL_KEEP for q in hid_):
                self.roam = None
            if self.roam is None or now > self.roam_until or math.hypot(self.roam[0] - self.x, self.roam[2] - self.z) < 8.0:
                self.roam = pick_roam((self.x, self.y, self.z)) or pick_start(avoid=(self.x, self.y, self.z)); self.roam_until = now + 15.0
            tgt = self.roam; roam = tgt is not None
        v_ = self.visit(now)                                     # (a mission asked for someone to step into a door's sector)
        if v_ is not None:
            tgt, roam = v_, True
        elif HOSTAGE:
            ht_ = hostage_target(self, now)
            # armed, with the player close by and an enemy in reach: she stands and fires from where she is (no walking at them);
            # the player gets further off: she follows again (no shooting on the move)
            if best is not None and hostage_armed() and getattr(self, "h_free", False) and getattr(self, "h_fdist", 99.0) < 14.0 and best[0] < 110.0:
                self.F.p["keep_distance"] = best[0]; self.F.p["retreat"] = 0.0; self.F.p["strafe_frac"] = 0.0
            else:
                tgt, roam = ht_, True
        elif HEALER and ESCORT:
            e_ = escort_target(self, now)
            if e_ is not None: tgt, roam = e_, True
        self.F.broken = BROKEN_EDGES
        # A boiler plate close by: go and get it (unless an enemy is right on top of us). It's the map's own item (the host's list), and
        # taking it is what the user's own pickup sent: 0x3ff for the item. While going for it: no shooting, no stopping to fight.
        plate = None
        if PLATES_ON and ARMOR[0] < PLATE_MAX and (best is None or best[0] > PLATE_IGNORE_NEAR):
            for isl, (nm, ip) in list(ITEMS.items()):
                if nm in PLATE_VALUE and abs(ip[1] - self.y) < 8.0 and math.hypot(ip[0] - self.x, ip[2] - self.z) < PLATE_RANGE \
                        and now >= ITEM_SKIP.get(isl, 0.0) and (plate is None or math.hypot(ip[0] - self.x, ip[2] - self.z) < plate[0]):
                    plate = (math.hypot(ip[0] - self.x, ip[2] - self.z), isl, nm, ip)
        # A weapon it likes and lacks, ammo for one running low, a canteen when hurt: go and get it too, the way the bots do ("going for
        # GRIFLE"), unless an enemy is close. (Walking over any of these picks it up anyway: below.)
        # (11 Nov, 6 bots + 6 ghosts: the ghosts went for items 13-39 times each in 4 minutes and fired a third as much as before;
        #  the bots fight whoever they can see and fetch things when nobody is in reach. Now: only with no enemy within its gun's reach,
        #  or a canteen / elixir / med bag when it is hurt.)
        reach_ = WEAPONS.get(self.load.cur, {}).get("range", 120.0)
        free_ = best is None or best[0] > min(reach_, 120.0)
        if plate is None and PICKUPS and (free_ or (hp < HP * 0.4 and (best is None or best[0] > PLATE_IGNORE_NEAR))):
            for isl, (nm, ip) in list(ITEMS.items()):
                want = (free_ and nm in WEAPON_ITEMS and self.load.wants(WEAPON_ITEMS[nm][0])) or (nm in HEAL_ITEMS and hp < HP * 0.7) \
                    or (free_ and nm in BAG_ITEMS and self.load.bags < BAG_MAX) \
                    or (free_ and nm in AMMO_ITEMS and AMMO_ITEMS[nm][0] in ("rifle", "shells") and any(self.load.wants(a) for a in (("sgun", "dbsgun") if AMMO_ITEMS[nm][0] == "shells" else ("rifle",)) if a in self.load.ammo))
                if want and abs(ip[1] - self.y) < 8.0 and math.hypot(ip[0] - self.x, ip[2] - self.z) < PLATE_RANGE \
                        and now >= ITEM_SKIP.get(isl, 0.0) and (plate is None or math.hypot(ip[0] - self.x, ip[2] - self.z) < plate[0]):
                    plate = (math.hypot(ip[0] - self.x, ip[2] - self.z), isl, nm, ip)
        if HOSTAGE or getattr(self, "esc_on", False): plate = None          # (escorting the boss: no running off for items)
        # (25 Nov, the user: ghosts at Sanctuary's porch edge "just stand there and do nothing") they were going for a canteen
        # they couldn't walk to (195 "going for the GCANTEEN" in a few minutes): no route, so they stood at the nearest edge for
        # the 12 s give-up, then picked it again 30 s later. Now an item is first checked for a walking route (nav), at most
        # half again longer than PLATE_RANGE; one without is left alone for a minute.
        if plate is not None and plate[0] >= 3.0:
            rc_ = self.__dict__.setdefault("item_route", {})
            t_, ok_ = rc_.get(plate[1], (0.0, True))
            if now - t_ > 6.0:
                try:
                    ln_ = self.F.L.route_lengths({"x": self.x, "y": self.y, "z": self.z}, [{"x": plate[3][0], "y": plate[3][1], "z": plate[3][2]}])[0]
                    ok_ = ln_ is not None and ln_ <= PLATE_RANGE * 1.5
                except Exception:
                    ok_ = True
                rc_[plate[1]] = (now, ok_)
            if not ok_:
                ITEM_SKIP[plate[1]] = now + 60.0
                if self.going_for == plate[1]: self.going_for = None
                print(f"no way to walk to the {plate[2]} {plate[0]:.0f} away: leaving it")
                plate = None
        # (20 Nov, the user: enemies still got up on Orleans' big building and kept hopping between its roof levels.) Up in a
        # no-enter sector (nav GHOST_NO_ENTER) it drops everything and walks out the nearest way down; then it fights as usual.
        ne_ = getattr(self.F.L, "no_enter", None)
        if ne_ and self.F.cur_sec in ne_:
            down_ = self.way_down(ne_)
            if down_ is not None:
                if not getattr(self, "down_said", False): self.down_said = True; print(f"up where it may not be (sector {self.F.cur_sec}): coming down")
                tgt = down_; roam = True; plate = None
        else: self.down_said = False
        if v_ is not None: tgt = v_; roam = True; plate = None           # (stepping into a door's sector: nothing else for that half second)
        if plate is not None:
            if plate[0] < 3.0:
                if plate[2] in PLATE_VALUE: take_item(plate[1], plate[2])
                else: self.grab(plate[1], plate[2], now)
            else:
                if self.going_for != plate[1]: self.going_for = plate[1]; self.going_since = now; print(f"going for the {plate[2]} {plate[0]:.0f} away")
                # time spent going for each item, added up (12 Nov: a ghost in Sanctuary's jail swapped between two canteens in other
                # cells, 13 and 15 away, for minutes - each swap restarted the 12 s give-up clock, so it never gave up)
                ct_ = self.__dict__.setdefault("chase_t", {}); lc_ = self.__dict__.get("chase_last", now); self.chase_last = now
                ct_[plate[1]] = ct_.get(plate[1], 0.0) + max(0.0, min(0.5, now - lc_))
                if ct_[plate[1]] > 12.0:
                    ITEM_SKIP[plate[1]] = now + 30.0; ct_.pop(plate[1], None); self.going_for = None
                    print(f"can't get to the {plate[2]}: leaving it for now")
                tgt = plate[3]; roam = True; me_ = self.F.p["max_engage"]; self.F.p["max_engage"] = 0.5
                out = self.F.update(now, (self.x, self.y, self.z), tgt); self.F.p["max_engage"] = me_
        else: self.going_for = None
        if PICKUPS:                                                  # walking over a weapon or a canteen it can use
            for isl, (nm, ip) in list(ITEMS.items()):
                if (nm in WEAPON_ITEMS or nm in HEAL_ITEMS or nm in BAG_ITEMS) and abs(ip[1] - self.y) < 5.0 and math.hypot(ip[0] - self.x, ip[2] - self.z) < AMMO_REACH:
                    self.grab(isl, nm, now)
        if AMMO_ON and STYLE_ON:
            for isl, (nm, ip) in list(ITEMS.items()):
                if nm in AMMO_ITEMS and abs(ip[1] - self.y) < 5.0 and math.hypot(ip[0] - self.x, ip[2] - self.z) < AMMO_REACH:
                    kind, n_ = AMMO_ITEMS[nm]
                    arm = next((a for a in (("sgun", "dbsgun") if kind == "shells" else (kind,)) if a in self.load.ammo), None)
                    if arm is None: continue                                   # (nothing of its own uses it: left for someone who can)
                    have = self.load.ammo[arm]
                    if have is not None:
                        top = (WEAPONS[arm]["ammo"] or n_) * AMMO_CAP
                        if have >= top: continue                               # (carrying all it can)
                        self.load.ammo[arm] = min(top, have + n_)
                    take_item(isl, nm)
                    print(f"picked up {nm} ({'+' + str(n_) + ' for the ' + arm if have is not None else 'bullets'}" + (f": now {self.load.ammo[arm]})" if have is not None else ")"))
        if plate is None or plate[0] < 3.0:
            out = self.F.update(now, (self.x, self.y, self.z), tgt)
        if out.get("door"): open_door(out["door"])
        if roam: out["fire"] = None                                  # (never shoot at a waypoint)
        if roam and HOSTAGE and best is not None and best[0] < 110.0 and hostage_armed() and getattr(self, "h_free", False):
            # (25 Nov, the user: "Mrs. Claus never did seem to fire at the enemies") she shoots while she follows: the player was
            #  always further off than her stand-and-fight distance, so she only ever walked. Now, on the move, she turns to the
            #  nearest enemy she can see and fires at the rifle's own rate (an easy shot: a third of them hit).
            try:
                tg_ = best[2]; sec_ = out.get("sec", self.F.cur_sec)
                if self.F.sees(sec_, (self.x, self.z), (tg_[0], tg_[2]), self.y, tg_[1]):
                    out = dict(out); out["yaw"] = math.atan2(tg_[0] - self.x, tg_[2] - self.z)
                    if now >= getattr(self, "h_next_shot", 0.0):
                        out["fire"] = "hit" if random.random() < 0.34 else "miss"
                        self.h_next_shot = now + max(0.45, WEAPONS.get("rifle", {}).get("gap", 0.5)) + random.random() * 0.4
                        target_slot = best[1]
            except Exception as ex_:
                if now - getattr(self, "h_err_t", 0.0) > 10: self.h_err_t = now; print("hostage shot:", ex_)
        if now - self.born < SPAWN_HOLD: out["fire"] = None          # (just spawned: it can move and aim, not attack yet)
        if out.get("fire") is not None and tgt is not None and tnt_in_the_way((self.x, self.y + 5.0, self.z), tgt, now):
            out["fire"] = None                                       # (someone's lit stick near the line of fire or the target: don't set it off)
            if now - getattr(self, "tnt_said", 0.0) > 5.0: self.tnt_said = now; print("holding fire: lit dynamite in the way")
        ice_ = now - getattr(self.F, "ice_target_t", -99.0) < 1.0 or getattr(self.F, "swimming", False)   # (after someone under the ice: never give up on them)
        if not out["moving"] and self.F.mode == "chase" and not self.F.path and not ice_:
            if best is not None: self.unreach[best[1]] = now + 4.0
            elif roam: self.roam = None
        # (13 Nov, the user: ghosts sometimes stop and stare at a wall for a few seconds. A ghost chasing someone it can't see faces
        #  that someone - through the wall - and when its route keeps failing (an opening it can't get through, a door that won't
        #  open) it stood there, re-planning the same way every 1.5 s. Standing still while chasing for STILL_MAX s now gives up on
        #  that target for a while and on that opening, and the reason goes in the log.)
        if self.F.mode == "chase" and not out["moving"] and not roam and best is not None and not ice_:
            if getattr(self, "chase_still_t", None) is None: self.chase_still_t = now
            elif now - self.chase_still_t > (STILL_MAX + 2.5 if now < self.F.door_wait else STILL_MAX):       # (a door gets longer: it has to swing)
                why = "waiting at a door" if now < self.F.door_wait else ("no route" if not self.F.path else "its route is blocked")
                try: who_ = (display_name(addr_id(best[1])) or b"").decode(errors="replace") or str(best[1])
                except Exception: who_ = str(best[1])
                print(f"stood still {now - self.chase_still_t:.1f} s chasing {who_} at {self.x:.0f},{self.z:.0f} ({why}): trying someone else")
                try: self.F.blame(now)
                except Exception: pass
                self.unreach[best[1]] = now + 6.0; self.F.path = []; self.F.path_t = -99.0; self.chase_still_t = None
                if ACT[0] is not None: ACT[0]["still"] += 1
        else: self.chase_still_t = None
        if SPACING > 0 and not BLASTKNOCK:
            # never step INTO a teammate (bodies 1.5 + 1.5): a step that ends closer than BODY_GAP to one, and closer than it was, isn't taken.
            # Zombies pressed right up against each other made an awful noise in the user's game (no sound file: the clash itself)
            tnow_ = time.time()
            for who_, pv_ in list(players.items()):
                if pv_[2] or tnow_ - pv_[0] > 1.0 or abs(pv_[1][1] - out["y"]) > 6.0 or not is_friend(who_): continue
                fp_ = now_pos(who_, pv_); dn_ = math.hypot(out["x"] - fp_[0], out["z"] - fp_[2])
                if dn_ < BODY_GAP and dn_ < math.hypot(self.x - fp_[0], self.z - fp_[2]):
                    out["x"], out["z"], out["vx"], out["vz"] = self.x, self.z, 0.0, 0.0; self.F.vel = (0.0, 0.0); break
        # never half into a wall (12 Nov, the user): the centre kept WALL_R from walls (fighter.wall_push) - not mid-jump or mid-throw
        if alive and not BLASTKNOCK and not self.F.play and not self.F.cj and not self.F.slide and not getattr(self.F, "swimming", False):
            try:
                wx_, wz_ = self.F.wall_push(out.get("sec", self.F.cur_sec), out["x"], out["y"], out["z"])
                if (wx_, wz_) != (out["x"], out["z"]): out = dict(out); out.update(x=wx_, z=wz_)
            except Exception: pass
        # The last word on shut doors (11 Nov, the user: they "still walk through closed doors"). Whatever moved it this tick (the route,
        # a strafe, a shove, an unstick slide, a recorded jump), a step across a door this ghost counts as shut is not taken - the way the
        # game's own walls stop a bot - and the log says which movement tried it. Leaving a door it stands in is always allowed.
        if self.F.door_state is not None and DOOR_GUARD and (abs(out["x"] - self.x) > 1e-3 or abs(out["z"] - self.z) > 1e-3):
            try: shut = self.F.closed_door_on((self.x, self.z), (out["x"], out["z"]))
            except Exception: shut = False
            if shut:
                how = "slide" if self.F.slide else "jump" if (self.F.play or self.F.cj) else self.F.mode
                if now - getattr(self, "door_said", 0.0) > 3.0: self.door_said = now; print(f"stopped at a shut door ({how}) at {self.x:.0f},{self.z:.0f}")
                # (12 Nov, the user: stuck in Sanctuary's jail cells, stopped at the courthouse door for good. A bot walking into a shut
                #  door presses "use"; so does the ghost now - whatever movement brought it there - then waits for it to open. Three
                #  presses in 20 s at most: a door that still counts as shut after that is left to the route (which goes round it).)
                if isinstance(shut, dict):
                    k_ = (round(shut["x"], 1), round(shut["z"], 1)); gp_ = self.guard_press.get(k_, (0, -99.0))
                    if now - gp_[1] > 20.0: gp_ = (0, -99.0)
                    if gp_[0] < 3 and now - gp_[1] > 2.5:
                        open_door(shut); self.guard_press[k_] = (gp_[0] + 1, now)
                out = dict(out); out.update(x=self.x, z=self.z, y=self.y, vx=0.0, vz=0.0, moving=False); self.F.vel = (0.0, 0.0); self.F.slide = None
        # (12 Nov, the user: "if they get stuck in a jail cell for 10 seconds or so, they automatically open the door") - not got 3
        # units anywhere in 10 s, a door within 6: "use" the nearest one, again every 10 s while it stays stuck (whatever our count of
        # that door says: a count that is wrong is exactly what leaves a ghost shut in)
        if (self.still_since is None or math.hypot(out["x"] - self.still_since[1], out["z"] - self.still_since[2]) > 3.0
                or not getattr(self.F, "want_move", False) or BLASTKNOCK):       # (only while it is trying to get somewhere)
            self.still_since = (now, out["x"], out["z"]); self.stuck_n = 0
        elif now - self.still_since[0] > STUCK_DOOR_S and alive and LVL is not None:
            dq_ = min(LVL.panels or [], key=lambda q: math.hypot(q["x"] - self.x, q["z"] - self.z), default=None)
            if dq_ is not None and math.hypot(dq_["x"] - self.x, dq_["z"] - self.z) < 6.0:
                print(f"stuck {now - self.still_since[0]:.0f} s by a door at {self.x:.0f},{self.z:.0f}: using it")
                open_door(dq_, force=getattr(self, "stuck_n", 0) >= 1)        # (the 2nd time still stuck: even a door counted open)
                self.stuck_n = getattr(self, "stuck_n", 0) + 1
            self.still_since = (now, out["x"], out["z"])
        if getattr(self.F, "unstuck", None):
            u_ = self.F.unstuck; self.F.unstuck = None
            print(f"stuck where no player can stand ({u_[0]},{u_[1]}): back to {u_[2]},{u_[3]}")
        fy_ = use_facing(out["x"], out["z"], now)
        if fy_ is not None: out = dict(out); out["yaw"] = fy_; out["fire"] = None          # (facing the door it is about to use)
        use_step(now)
        self.x, self.y, self.z = out["x"], out["y"], out["z"]
        if out["yaw"] is not None: self.yaw = out["yaw"]
        self.moving = out["moving"]; self.pitch = 0
        if out["fire"]: self.fire = out["fire"]
        # (14 Nov, a player on the server: the ghosts seemed to "give up" about halfway through a match. Once a minute, what this
        #  ghost spent the minute doing - fighting, chasing, roaming, other - its shots, its "stood still" give-ups and whom it went
        #  after, so a match's log shows whether and when that changes.)
        a_ = ACT[0]                                              # (kept across lives: a new walker comes with every respawn)
        if a_ is None: a_ = ACT[0] = {"t": now, "last": now, "eng": 0.0, "chase": 0.0, "roam": 0.0, "other": 0.0, "shots": 0, "who": {}, "still": 0}
        dt_ = min(1.0, max(0.0, now - a_["last"])); a_["last"] = now
        a_["roam" if roam else "eng" if self.F.mode == "engage" else "chase" if self.F.mode == "chase" else "other"] += dt_
        if out["fire"]: a_["shots"] += 1
        if best is not None and not roam: a_["who"][best[1]] = a_["who"].get(best[1], 0.0) + dt_
        # (20 Nov, the user: enemies stuck up on a ledge, "standing there looking lost") GHOST_LOST_LEAVE=s: a mission's ordinary
        # enemy that has found nobody to go after for that long leaves the game - horde.py puts a fresh one in its place
        # (21 Nov: not the ghost that reports everyone's positions - the missions' goals go by them - and only one up high:
        #  with a player inside the shut warehouse every enemy was "lost" on the street and they all kept leaving)
        if LOST_LEAVE and MODE_RUN and MODE_TAG and not FEED_LOG:
            if not roam or abs(self.y) < 8.0: self.lost_since = None     # (up on a ledge, or down where it fell - Buckshotville's creek)
            elif getattr(self, "lost_since", None) is None: self.lost_since = now
            elif now - self.lost_since > LOST_LEAVE and not getattr(self, "lost_left", False):
                self.lost_left = True; print(f"lost: nobody to go after for {LOST_LEAVE:.0f} s - leaving for a fresh start")
                try: open(mode_flag("leave"), "w").close()
                except OSError: pass
        if now - a_["t"] >= 60.0:
            span = max(1.0, now - a_["t"]); pc = lambda k: f"{100.0 * a_[k] / span:.0f}%"
            dead_ = max(0.0, span - a_["eng"] - a_["chase"] - a_["roam"] - a_["other"])
            def nm_(w_):
                try: return (display_name(addr_id(w_)) or b"").decode(errors="replace") or hex(w_)
                except Exception: return str(w_)
            top = sorted(a_["who"].items(), key=lambda kv: -kv[1])[:3]
            print(f"last minute: fighting {pc('eng')}, chasing {pc('chase')}, roaming {pc('roam')}, other {pc('other')}, dead {100.0 * dead_ / span:.0f}%;"
                  f" shots {a_['shots']}; gave up standing still {a_['still']}x; went after " + (", ".join(f"{nm_(w_)} {t_:.0f}s" for w_, t_ in top) or "nobody"))
            ACT[0] = None
        w = out.get("wet", False)                                  # swimming: splash going in, a stroke now and then, swim_out coming out
        if w != self.wet:
            self.water_events.append(b"splash.wav" if w else b"swim_out.wav"); self.wet = w; self.swim_snd = now + 1.0
        elif w and out["moving"] and now >= self.swim_snd:
            self.water_events.append(b"SWIM.wav"); self.swim_snd = now + 1.4
        # The speed sent with the state: what the ghost really covered since its last state when that differs a lot from what the
        # movement code says (pushes, slides, a slow tick): the other games carry it on at the speed sent until the next state, so a
        # speed that matches the ground covered keeps them from overshooting and snapping it back. (11 Nov: a smoothed version of it
        # lagged every turn - 27-33% of states 3+ units off instead of 24-27% - so back to this.)
        vx_, vz_ = out["vx"], out["vz"]; ls_ = getattr(self, "last_sent", None)
        if ls_ is not None and 0.03 < now - ls_[0] < 0.6 and out["moving"]:
            mvx_, mvz_ = (self.x - ls_[1]) / (now - ls_[0]), (self.z - ls_[2]) / (now - ls_[0])
            if math.hypot(mvx_ - vx_, mvz_ - vz_) > 8.0 and math.hypot(mvx_, mvz_) < 90.0: vx_, vz_ = mvx_, mvz_
        self.last_sent = (now, self.x, self.z)
        py_ = getattr(self, "prev_y", self.y); CLIMB[0] = out["moving"] and abs(self.y - py_) > 0.3 and self.F.mode not in ("jump", "cjump", "gjump"); self.prev_y = self.y
        TICKS.append(now)
        return make_state(self.x, self.y, self.z, self.yaw, 0, vx_, vz_, out["moving"], vy=out.get("vy", 0.0), sec=out.get("sec"), crouch=out.get("crouch", False)), \
               (0.05 if self.F.mode in ("engage", "jump", "cjump", "gjump") or CLIMB[0] or STATE_GAP < 0.12 else 0.075)   # (fighting: quicker ticks for the gun's rate; 0.075 elsewhere so a state goes every 0.15 s like a player's, not every 0.2)

TICKS = []; TICK_SAID = [0.0]
STILL_MAX = float(os.environ.get("GHOST_STILL_MAX", "1.5"))
ACT = [None]                                                     # the once-a-minute activity summary's counts (FightWalker.step)
def tick_report(now):
    """once a minute in the log: how often this ghost really got to send its moves (a busy PC makes them jump on the others' screens)"""
    if now - TICK_SAID[0] < 60.0: return
    TICK_SAID[0] = now; t = [b - a for a, b in zip(TICKS, TICKS[1:]) if b - a < 2.0]; del TICKS[:-1]
    if len(t) >= 20:
        t.sort(); print(f"moves sent every {t[len(t) // 2]:.2f} s (90% within {t[int(len(t) * 0.9)]:.2f}, slowest {t[-1]:.2f}); wanted 0.05-0.10")
BLASTS = []; next_bag = 0.0
# ---- Thrown dynamite, ammo boxes, bodies: copied from what the HOST sends for its own (recorded in a real game, decoded with its dictionary):
# lighting creates an entity with the GDYNAM.3DO model (flags 4b01, state tail cb01 in the hand, cf00 flying, cf04 lying), FUSE.wav on it,
# the thrower's pose 15 + THROW.wav, its own states while it flies, 4.5 s after lighting 0x421 "PDYNAM.itm" at its spot (the explosion: every game
# shows it and hurts its own player) and 0x3ff for the stick. A dying player creates GAMBOXB/C/S (bullets / cartridges / shells) where it fell.
try: TT = json.load(open(data_file("throw_templates.json")))
except Exception as e: TT = {}; print("throw_templates.json missing: no dynamite objects / ammo boxes:", e)
EXTRA_IDS = {"proj": 0x80, "box": 0xc0}


def next_life_slot(s):
    """The entity number for the next life. Lives count up from NS|0x02, but NS|0x80..0xff are the thrown sticks' and the ammo
    boxes' (new_id): after life 126 the old count ran into them (a player created on a box's number). Lives skip to NS|0x100
    instead (the namespace is 0x800 wide); past NS|0x7ff they start again at NS|0x02."""
    n = s + 1
    lo = n & 0x7ff
    if 0x80 <= lo < 0x100:
        n = (n & ~0x7ff) | 0x100
    elif lo == 0:
        n = (s & ~0x7ff) | 0x02
    return n
def new_id(kind):
    """an entity number of our own for a thrown stick (NS|0x80..0xbf) or an ammo box (NS|0xc0..0xff); lives use NS|0x02, 0x03..."""
    lo, hi = (0x80, 0xbf) if kind == "proj" else (0xc0, 0xff)
    v = EXTRA_IDS[kind]; EXTRA_IDS[kind] = lo + ((v - lo + 1) % (hi - lo + 1)); return NS | v
def ent_create(tmpl, eslot, x, y, z, sec):
    b = bytearray(bytes.fromhex(tmpl))
    b[1:5] = struct.pack("<I", 0); b[5:9] = struct.pack("<I", NS); b[9:13] = struct.pack("<I", 0)
    b[17:21] = struct.pack("<I", (sec or 0) & 0xFFFF); b[21:23] = struct.pack("<H", eslot); b[29:41] = struct.pack("<3f", x, y, z)
    return b"\x00" + bytes(b).replace(b"sanchez.nwx", MODEL.encode())
def ent_state(tmpl, eslot, x, y, z, sec, v=(0.0, 0.0, 0.0), pitch=0, yaw=None):
    """an object's state; pitch / yaw in the packet's angle units (16384 a turn). A thrown stick tumbles end over end: the host's own
    flying sticks turn their pitch about a turn a second (-2420 units every 0.15 s) and keep the throw's heading as yaw"""
    b = bytearray(bytes.fromhex(tmpl))
    b[33:35] = struct.pack("<h", int(pitch))
    if yaw is not None: b[35:37] = struct.pack("<H", int(round(yaw / (2 * math.pi) * YAW_UNITS)) % int(YAW_UNITS))
    b[1:5] = struct.pack("<I", 0x00200000); b[5:9] = b[9:13] = struct.pack("<I", 0x00200000 | eslot)
    b[17:21] = struct.pack("<I", (sec or 0) & 0xFFFF); b[21:33] = struct.pack("<3f", x, y, z); b[39:51] = struct.pack("<3f", *v)
    return b"\x00" + bytes(b)
def tell_gone(eslot):
    """the 0x3ff for one of our objects, to every OTHER client (the host gets its own from the caller). A real client relays it to each
    of them (recorded: 84 <its id> 01 <the client> 00 03, then 47 0 <its address> <the object> ff 03). The ghosts told only the host,
    which was enough while the user WAS the host. With a host of its own (10 Nov), on the user's game nothing a ghost made ever went
    away: every knife thrown, every body of every life, and every dynamite stick with its LOOPING fuse sound: a loud buzz from where
    each stick had gone off, more of them every minute, until they drowned every other sound and the game ran at 20 frames a second."""
    if not RELAY: return
    body = b"\x00\x47" + struct.pack("<III", 0, NS, eslot) + struct.pack("<H", 0x3ff) + b"\x00\x00"
    for pid in peer_ids(): relay_msg(3, body, [pid])
def ent_destroy(eslot):
    send_msg(3, b"\x00\x47" + struct.pack("<III", 0, NS, eslot) + struct.pack("<H", 0x3ff) + b"\x00\x00")
    tell_gone(eslot)
TNT_SPIN = float(os.environ.get("GHOST_TNT_SPIN", "16100"))      # angle units per second a thrown stick tumbles (measured from the host's)
DYNS = []; TNT_G = 60.0; TNT_FUSE = float(os.environ.get("GHOST_TNT_FUSE", "4.5"))    # (a mission's Santa: a shorter fuse)
TNT_HOSTHITS = os.environ.get("GHOST_TNT_HOSTHITS", "1") == "1"      # the host's game does NOT apply a ghost stick's blast itself (user: no damage next to it): send it      # 1 = also send the host's player blast damage (if the host does not apply its own)
def floor_under(x, z, ytop):
    """(floor, sector) of the highest floor under (x, z) at or below ytop: where something falling from ytop lands (sector_of only
    finds a spot a player stands in, so a fast stick that dropped a few units below the floor in one step was never caught)"""
    if LVL is None: return None, None
    best = (None, None)
    try:
        for s in LVL.sectors:
            if not s.walls or not s.contains(x, z): continue
            f = LVL.floor_at(s.index, x, z)
            if f <= ytop + 0.5 and LVL.ceiling_at(s.index, x, z) > f + 0.5 and (best[0] is None or f > best[0]): best = (f, s.index)
    except Exception: pass
    return best
def floor_at(x, y, z):
    s = sector_of(x, y, z)
    try: return (LVL.floor_at(s, x, z) if (s is not None and LVL is not None) else None), s
    except Exception: return None, s
try:
    import tnt as TNTM                                   # the bots' TNT ballistics (tnt.py, from the exe: speed = power x 60, pitch + 35, gravity 60)
except Exception as e:
    TNTM = None; print("tnt.py unavailable: simple dynamite throws:", e)
HELD = None
TNT_SWITCH = float(os.environ.get("GHOST_TNT_SWITCH", "1.0"))      # seconds to swap weapons around the TNT (the bots' TNT_SWITCH_WAIT: the switch animation)
TNT_LAND_MARGIN, TNT_LAST_CALL, TNT_LEAD, TNT_LEAD_MAX = 0.25, 0.45, 0.8, 1.5      # brain.Brain's own numbers
# (17 Nov, the user: "give Santa a strong arm - throw them hard, far and accurately". GHOST_TNT_ARM: the strongest throw as a multiple
#  of a player's full one (2 = twice as fast: flatter, quicker to land, twice the reach); with it, throws start at full power, not
#  the softest that reaches. GHOST_TNT_SELF=0: his own presents don't hurt him.)
SIDEARM = os.environ.get("GHOST_SIDEARM") if os.environ.get("GHOST_SIDEARM") in WEAPONS else None
SIDE_GAP = float(os.environ.get("GHOST_SIDE_GAP", "1.6")); SIDE_DMG = float(os.environ.get("GHOST_SIDE_DMG", "3.0"))
SIDE_RANGE = float(os.environ.get("GHOST_SIDE_RANGE", "120")); SIDE_NEXT = [0.0]
# (23 Nov, the user: Santa's pistol at a normal Sanchez speed) GHOST_SIDE_MAG shots, then GHOST_SIDE_RELOAD s to reload, like the
# player's own pistol (0 = no reloading, the old slow clock)
SIDE_MAG = int(os.environ.get("GHOST_SIDE_MAG", "0")); SIDE_RELOAD = float(os.environ.get("GHOST_SIDE_RELOAD", "1.6")); SIDE_LEFT = [SIDE_MAG]
TNT_ARM = float(os.environ.get("GHOST_TNT_ARM", "1.0"))
TNT_SELF = os.environ.get("GHOST_TNT_SELF", "1") != "0"
if os.environ.get("GHOST_TNT_RANGE"): WEAPONS["dynamite"]["range"] = float(os.environ["GHOST_TNT_RANGE"])
def hand_pos(w):
    return (w.x + math.sin(w.yaw) * 1.2, w.y + 0.85 * 5.5, w.z + math.cos(w.yaw) * 1.2)
def light_dynamite(w, tgt, now):
    """secondary fire: the stick lights in the hand (an object with flags 4b01 + FUSE.wav, as the host sends for its own); its fuse runs from now"""
    global HELD
    if "tnt_create" not in TT: return False
    x, y, z = hand_pos(w); eslot = new_id("proj"); sec = sector_of(w.x, w.y, w.z) or LAST_SEC[0]
    mk = ent_create(TT["tnt_create"], eslot, x, y, z, sec)
    if TNT_MODEL: mk = mk.replace(b"GDYNAM.3DO", TNT_MODEL)
    to_all(2, mk)
    send_sound(sound_msg(eslot, b"FUSE.wav", fuse=True))
    HELD = dict(slot=eslot, lit=now, tgt=tgt, sec=sec, next=now, planned=None)
    return True
def plan_throw(w, now):
    """(velocity, goal, flight) for a throw now that lands at the target's spot TNT_LAND_MARGIN before the blast, or None"""
    tp = players.get(HELD["tgt"])
    if (tp is None or tp[2] or now - tp[0] > 1.5) and target_slot is not None and target_slot in players:
        HELD["tgt"] = target_slot; tp = players[target_slot]          # the one it was lit for died or is gone: the current target
    if tp is None: return None
    left = HELD["lit"] + TNT_FUSE - now
    tv = VEL.get(HELD["tgt"], (0.0, 0.0))
    lead = min(TNT_LEAD_MAX, max(0.0, left - TNT_LAND_MARGIN)) * TNT_LEAD
    gx, gz = tp[1][0] + tv[0] * lead, tp[1][2] + tv[1] * lead
    # the tier's aim: the throw drifts like its gun aim (a degree of wobble = a degree of heading, and a bit of length)
    off = math.radians(w.F.aim_off if isinstance(w, FightWalker) else 0.0); dx, dz = gx - w.x, gz - w.z
    gx, gz = w.x + dx * math.cos(off) + dz * math.sin(off), w.z - dx * math.sin(off) + dz * math.cos(off)
    gf, _ = floor_at(gx, tp[1][1] + 2.0, gz); gy = gf if gf is not None else tp[1][1]
    # (the thrower's own run is not added: backing off at full speed with the stick, no throw reached and it waited for the last
    #  moment - the sticks went off in the air in the user's game. The ghost plants its feet for the throw.)
    sv = (0.0, 0.0, 0.0)
    best = None
    if TNTM is not None:
        pws = (0.5, 0.6, 0.7, 0.8, 0.9, 1.0) if TNT_ARM <= 1.0 else tuple(round(1.0 + (TNT_ARM - 1.0) * k / 5, 2) for k in range(6))
        for pw in pws:                 # the softest throw that reaches (a strong arm: from full power up - hard and flat)
            try: sol = TNTM.solve(dict(x=w.x, y=w.y, z=w.z, height=5.5), sv, dict(x=gx, y=gy, z=gz), pw, g=TNT_G)
            except Exception: sol = None
            if sol:
                sp = max(TNTM.MIN_SPEED, TNTM.SPEED * pw); L = math.radians(sol["launch"]); yw = math.radians(sol["yaw"])
                v = [sp * math.cos(L) * math.sin(yw) + sv[0], sp * math.sin(L), sp * math.cos(L) * math.cos(yw) + sv[2]]
                best = (v, (gx, gy, gz), sol["flight"], pw); break
    if best is None:                                              # out of reach: as far as it goes toward them
        yw = math.atan2(gx - w.x, gz - w.z); sp = 60.0 * max(1.0, TNT_ARM); L = math.radians(40.0)
        best = ([sp * math.cos(L) * math.sin(yw) + sv[0], sp * math.sin(L), sp * math.cos(L) * math.cos(yw) + sv[2]], (gx, gy, gz), 1.45, 1.0)   # (a full throw flies ~1.45 s)
    return best
def update_held(now):
    """the lit stick in the hand: follows the hand; thrown the moment its flight ends TNT_LAND_MARGIN before the blast (or at the last call)"""
    global HELD
    if HELD is None: return
    w = walker
    if w is None: HELD = None; return
    if not alive:                                                 # killed with it lit: it drops at his feet and still goes off
        x, y, z = w.x, w.y + 0.3, w.z
        DYNS.append(dict(slot=HELD["slot"], p=[x, y + 2.0, z], v=[0.0, 0.0, 0.0], lit=HELD["lit"], next=now, landed=False, sec=HELD["sec"], rest_sent=0.0))
        print("killed holding a lit stick: it drops"); HELD = None; return
    if isinstance(w, FightWalker): w.F.hold_fire_until = max(w.F.hold_fire_until, now + 0.2)
    left = HELD["lit"] + TNT_FUSE - now
    plan = plan_throw(w, now)
    near = plan is not None and math.hypot(plan[1][0] - w.x, plan[1][2] - w.z) < 22.0       # it would land right next to him: wait (backing off)
    due = plan is not None and plan[2] is not None and left - TNT_LAND_MARGIN <= plan[2] + 0.1
    go = left <= TNT_LAST_CALL or (due and not near)
    if plan is None and left > TNT_LAST_CALL: go = False
    if go:
        if plan is None or plan[2] is None or (near and left <= TNT_LAST_CALL):                  # last call: as far as it goes (full power, 40 degrees) toward them / ahead
            tp = players.get(HELD["tgt"]); yw = math.atan2(tp[1][0] - w.x, tp[1][2] - w.z) if tp else w.yaw; L = math.radians(40.0)
            sp_ = 60.0 * max(1.0, TNT_ARM)
            plan = ([sp_ * math.cos(L) * math.sin(yw), sp_ * math.sin(L), sp_ * math.cos(L) * math.cos(yw)], None, None, 1.0)
        v = plan[0]; x, y, z = hand_pos(w)
        throw_pose()
        send_sound(sound_msg(slot, b"THROW.wav"))
        DYNS.append(dict(slot=HELD["slot"], p=[x, y, z], v=list(v), lit=HELD["lit"], next=now, landed=False, sec=HELD["sec"], rest_sent=0.0, goal=plan[1],
                         thrown=now, yaw=math.atan2(v[0], v[2])))
        if isinstance(w, FightWalker):
            w.F.hold_fire_until = max(w.F.hold_fire_until, now + TNT_SWITCH)      # putting the TNT away and drawing the pistol takes a moment
        g = plan[1]
        print(f"threw the dynamite with {left:.1f} s of fuse left" + (f" at {math.hypot(g[0] - w.x, g[2] - w.z):.0f} away, power {plan[3]:.1f}, flight {plan[2]:.2f} s" if g and plan[2] else " (last call)"))
        HELD = None; return
    if now >= HELD["next"]:                                       # in the hand: where the hand is
        HELD["next"] = now + 0.15; x, y, z = hand_pos(w)
        to_all(2, ent_state(TT["tnt_hand"], HELD["slot"], x, y, z, sector_of(w.x, w.y, w.z) or HELD["sec"], yaw=w.yaw))
BLAST_SCALE = float(os.environ.get("GHOST_BLAST_SCALE", "1.875"))
BLAST_MOM = 75.0                # a blast hit's momentum = 75 x its damage (every one the host sent: 24 -> 1800, 13.01 -> 975.7)
def blast_words(bp, vp):
    """direction words of a blast at bp hitting a player standing at vp: heading away from it, and the lift the host's blasts carry
    (about 3.5 units over the distance: 9 degrees at 22 away, 5 at 39; no more than 15)"""
    dx, dz = vp[0] - bp[0], vp[2] - bp[2]; h = math.hypot(dx, dz)
    yw = int(round(math.atan2(dx, dz) / (2 * math.pi) * 16384)) & 0x3FFF
    pw = int(round(min(math.radians(15.0), math.atan2(3.5, max(h, 0.1))) / (2 * math.pi) * 16384))
    return yw, pw
def blast_dmg(d):
    """the game's blast (tnt.py, from the exe): full damage within 12.5, then ((50 - d) / 37.5)^2 of it, none at 50"""
    # full damage 22.5 (pdynam.itm's 12 x 1.875): the user - a direct hit leaves a Mary (takes 0.8 of 20 health) one heart (2), and
    # kills anyone else outright (Chief 0.9 -> 20.25)
    if TNTM is not None: return TNTM.damage(d) * BLAST_SCALE
    return WEAPONS["dynamite"]["dmg"] * DMG_MULT * max(0.0, 1.0 - d / WEAPONS["dynamite"]["blast"])
# ---- Thrown knives: the knife flies as an object, as the user's own throws (recorded 7 Nov): a GKNIFE.3DO entity (flags 4b01) with
# states every 0.15 s (tail cf00, pitch turning ~-32500 units a second: end over end), gravity 60, gone (0x3ff) when it lands or hits.
KNIVES = []; LATER = []; KNIFE_SPEED = 70.0; KNIFE_SPIN = 32500.0
KNIFE_ITEMS = os.environ.get("GHOST_KNIFE_ITEMS", "1") == "1"
KNIFE_RATE, KNIFE_PITCH, KNIFE_Y0, KNIFE_MID = 120.0, math.radians(5.0), 4.5, 3.0   # RATE_1; THROW_PITCH; the hand; a body's middle
KNIFE_WIND_T, KNIFE_FOLLOW = 0.1, 0.3      # the wind-up frame; the follow-through (2 frames) + the end frame before the next can start
KNIFE_WIND = [None]                        # the throw being wound up: dict(at = when it's let go, ev, power, tgt, w)
# How often a thrown knife lands (11 Nov, the user): the aim roll every other gun uses made Chief's knives "deadly accurate" (57% from
# 5 to 19 away on Normal, near every throw on Nightmare). A knife is slow, so from further off they step out of its way: the share
# that lands falls from the tier's close-range rate (within 10) to 79% of it at 15, 53% at 20, 26% at 25, 18% from 30 on - Normal:
# 57 / 45 / 30 / 15 / 10%. Nightmare and Hell no more than 65% even up close. GHOST_KNIFE_CHANCE=0: the old aim roll.
KNIFE_CHANCE_ON = os.environ.get("GHOST_KNIFE_CHANCE", "1") == "1"
# (16:17, the user: too low now - Hell 85% close, each tier a step down; falling off more gently: 85% of it at 15, 65% at 20,
#  45% at 25, 30% from 30 on)
KNIFE_CLOSE = {"easiest": 0.50, "easy": 0.60, "normal": 0.68, "hard": 0.75, "nightmare": 0.80, "hell": 0.85}
KNIFE_FALL = ((10.0, 1.0), (15.0, 0.85), (20.0, 0.65), (25.0, 0.45), (30.0, 0.30))
def knife_hit_chance(d, level):
    base = KNIFE_CLOSE.get(level or "normal", 0.57)
    if d <= KNIFE_FALL[0][0]: return base
    for (d0, f0), (d1, f1) in zip(KNIFE_FALL, KNIFE_FALL[1:]):
        if d <= d1: return base * (f0 + (f1 - f0) * (d - d0) / (d1 - d0))
    return base * KNIFE_FALL[-1][1]
def knife_power(d, dy):
    """the least power (0.5..1.0) that takes a knife thrown straight at a body's middle d away and dy above the hand to that middle:
    aimed at it, the throw leaves 5 degrees above the aim and drops back onto it (1.0: at full power it can't, it lands lower)"""
    th = math.atan2(dy, max(d, 0.1)) + KNIFE_PITCH
    den = 2.0 * math.cos(th) ** 2 * (max(d, 0.1) * math.tan(th) - dy)     # y(d) = d tan th - g d^2 / (2 v^2 cos^2 th) = dy
    if den <= 0: return 1.0
    return min(1.0, max(0.5, math.sqrt(TNT_G * d * d / den) / KNIFE_RATE))
def knife_drop(d, dy, power):
    """how far below the body's middle a knife thrown with this power at it arrives (negative: above it)"""
    th = math.atan2(dy, max(d, 0.1)) + KNIFE_PITCH; v = max(10.0, power * KNIFE_RATE)
    return dy - (d * math.tan(th) - TNT_G * d * d / (2.0 * v * v * math.cos(th) ** 2))
def throw_knife(w, aim, will_hit, now, power=None):
    """the knife object for a throw at aim; returns when it gets there (the hit is delivered then). power: the wound-up throw's
    (speed = power x 120; a miss flies as thrown and falls where it falls); None: the old flat 70"""
    if "knife_create" not in TT or aim is None: return None
    x0, y0, z0 = w.x + math.sin(w.yaw) * 1.2, w.y + KNIFE_Y0, w.z + math.cos(w.yaw) * 1.2
    tx, ty_, tz = aim[0], aim[1] + KNIFE_MID, aim[2]
    if not will_hit:                                         # a miss: a little to the side, and on past
        a = random.uniform(-1, 1) * 0.15; dx, dz = tx - x0, tz - z0
        tx, tz = x0 + dx * math.cos(a) - dz * math.sin(a), z0 + dx * math.sin(a) + dz * math.cos(a)
    d = math.hypot(tx - x0, tz - z0)
    if power is None:
        t = max(0.1, d / KNIFE_SPEED)
        vy = (ty_ - y0) / t + 0.5 * TNT_G * t                 # lands on the aim point after t
        v = [(tx - x0) / t, vy, (tz - z0) / t]
    else:
        sp = max(10.0, power * KNIFE_RATE); th = math.atan2(ty_ - y0, max(d, 0.1)) + KNIFE_PITCH
        t = max(0.05, d / (sp * math.cos(th)))
        if will_hit: v = [(tx - x0) / t, (ty_ - y0) / t + 0.5 * TNT_G * t, (tz - z0) / t]        # (onto the body when it gets there)
        else:
            hx, hz = (tx - x0) / max(d, 0.1), (tz - z0) / max(d, 0.1)
            v = [hx * sp * math.cos(th), sp * math.sin(th), hz * sp * math.cos(th)]           # as thrown: past them, or short of them
    ks = new_id("proj"); sec = sector_of(w.x, w.y, w.z) or LAST_SEC[0]
    to_all(2, ent_create(TT["knife_create"], ks, x0, y0, z0, sec))
    KNIVES.append(dict(slot=ks, p=[x0, y0, z0], v=v, t0=now, next=now, sec=sec, end=(now + t) if will_hit else None, yaw=math.atan2(v[0], v[2]), landed=None))
    return now + t
PROJS = []
def shoot_proj(w, aim, now, hit):
    """a mini-boss's shot made visible: its sprite flies straight from the gun to the target (or just past it on a miss) and is
    gone when it gets there. Only a picture: the hit itself is the gun's, as for any ghost shot."""
    if not PROJ_MODEL or "knife_create" not in TT or aim is None: return None
    eta = None
    for k_ in range(PROJ_N):
        x0, y0, z0 = w.x + math.sin(w.yaw) * 1.5, w.y + 5.2, w.z + math.cos(w.yaw) * 1.5
        tx, ty, tz = aim[0] + random.uniform(-0.6, 0.6) * k_, aim[1] + 4.0 + random.uniform(-0.4, 0.4), aim[2] + random.uniform(-0.6, 0.6) * k_
        if not hit:
            tx += random.uniform(-3, 3); tz += random.uniform(-3, 3)
        d = max(0.5, math.dist((x0, y0, z0), (tx, ty, tz))); t = d / PROJ_SPEED
        v = [(tx - x0) / t, (ty - y0) / t, (tz - z0) / t]
        ps = new_id("proj"); sec = sector_of(w.x, w.y, w.z) or LAST_SEC[0]
        to_all(2, ent_create(TT["knife_create"], ps, x0, y0, z0, sec).replace(b"GKNIFE.3DO", PROJ_MODEL))
        PROJS.append(dict(slot=ps, p=[x0, y0, z0], v=v, t0=now, end=now + t, next=now, sec=sec, yaw=math.atan2(v[0], v[2])))
        eta = max(eta or 0.0, now + t)
    return eta
def update_projs(now):
    for k in list(PROJS):
        if now >= k["end"] or now - k["t0"] > 2.0:
            PROJS.remove(k); ent_destroy(k["slot"]); continue
        if now < k["next"]: continue
        dt = now - k.get("last", k["t0"]); k["last"] = now; k["next"] = now + 0.05
        k["p"] = [k["p"][0] + k["v"][0] * dt, k["p"][1] + k["v"][1] * dt, k["p"][2] + k["v"][2] * dt]
        to_all(2, ent_state(TT["knife_fly"], k["slot"], *k["p"], k["sec"], tuple(k["v"]), pitch=-(int((now - k["t0"]) * 20000) % 16384), yaw=k["yaw"]))
def update_knives(now):
    for b_ in [L_ for L_ in LATER if now >= L_[0]]:
        LATER.remove(b_); _, b, tid_ = b_
        if b[13:15] == b"\xd1\x07" and tid_ != 1:
            if RELAY: relay_msg(2, b"\x00" + b, [tid_])
        elif b[13:15] == b"\xd1\x07": send_msg(2, b"\x00" + b)
        else: to_all(2, b"\x00" + b)
    for k in list(KNIVES):
        if (k["end"] is not None and now >= k["end"]) or (k["landed"] is not None and now - k["landed"] > 0.5) or now - k["t0"] > 4.0:
            KNIVES.remove(k); ent_destroy(k["slot"])
            if k["end"] is None and "knife_item" in TT and KNIFE_ITEMS:
                # a miss lies where it fell as a knife anyone can pick up - what the user's game does with its own missed throws
                # (GKNIFE.ITM, flags 4f04, made the moment the flying one is removed); the ghosts' dropped ammo boxes go the same way
                to_all(2, ent_create(TT["knife_item"], new_id("box"), *k["p"], k["sec"])); print("the knife missed: it lies on the ground")
            continue
        if now < k["next"]: continue
        dt = 0.15; k["next"] = now + dt
        if k["landed"] is None:
            nx, ny, nz = k["p"][0] + k["v"][0] * dt, k["p"][1] + k["v"][1] * dt - 0.5 * TNT_G * dt * dt, k["p"][2] + k["v"][2] * dt
            k["v"][1] -= TNT_G * dt
            if not can_move(k["p"][0], k["p"][1] - 4.0, k["p"][2], nx, nz): nx, nz = k["p"][0], k["p"][2]; k["v"][0] = k["v"][2] = 0.0
            f, s = floor_under(nx, nz, k["p"][1])
            if s is not None: k["sec"] = s
            if f is not None and ny <= f + 0.2: ny = f + 0.2; k["landed"] = now; k["v"] = [0.0, 0.0, 0.0]
            k["p"] = [nx, ny, nz]
        spin = 0 if k["landed"] is not None else -(int((now - k["t0"]) * KNIFE_SPIN) % 16384)
        to_all(2, ent_state(TT["knife_fly"], k["slot"], *k["p"], k["sec"], tuple(k["v"]), pitch=spin, yaw=k["yaw"]))

def kami_blast(now, pos):
    """an exploding present goes off at pos (once a life): the dynamite's explosion, and damage to every player near it, falling off"""
    if now - KAMI_AT[0] < 3.0: return
    KAMI_AT[0] = now
    x, y, z = pos; sec = sector_of(x, y, z) or LAST_SEC[0] or 0
    m = b"\x00\x47" + struct.pack("<III", 0, 0x00180000 | NS, 0) + struct.pack("<H", 0x421) + b"\x00\x00" + struct.pack("<H", sec & 0xFFFF) + struct.pack("<3f", x, y, z) + b"PDYNAM.itm\x00"
    send_msg(2, m)
    if RELAY: relay_msg(2, m, peer_ids())
    BOOMS.append((now, (x, y, z))); del BOOMS[:-8]
    hurt = []
    for who, (t_, p3, dying) in list(players.items()):
        d3 = math.dist((p3[0], p3[1], p3[2]), (x, y, z))
        if dying or now - t_ > 1.5 or d3 > KAMI_R or is_friend(who): continue
        dd = KAMI_DMG if d3 <= KAMI_FULL else KAMI_DMG * ((KAMI_R - d3) / (KAMI_R - KAMI_FULL)) ** 2
        if dd < 0.2: continue
        yw_, pw_ = blast_words((x, y, z), p3)
        hb = bytes.fromhex("47") + struct.pack("<III", who, slot, who) + struct.pack("<H", 0x7d1) + b"\x00\x00" + struct.pack("<H", 4) + struct.pack("<3f", dd, 1.0, BLAST_MOM * dd) \
             + struct.pack("<HH", yw_, pw_) + struct.pack("<3f", *p3[:3]) + struct.pack("<2f", 1.5, 3.0) + bytes.fromhex("30640400")
        if addr_id(who) == 1: send_msg(2, b"\x00" + hb)
        elif RELAY: relay_msg(2, b"\x00" + hb, [addr_id(who)])
        hurt.append(f"{(display_name(addr_id(who)) or b'?').decode(errors='replace')} {dd:.1f} @{d3:.0f}")
    print("the present went off" + (": " + ", ".join(hurt) if hurt else " (nobody close)"))
def update_dynamite(now):
    for dy in list(DYNS):
        if now >= dy["lit"] + TNT_FUSE:                     # boom: the explosion event at its spot, then the stick is gone
            DYNS.remove(dy); x, y, z = dy["p"]; sec = dy["sec"] or 0
            send_msg(2, b"\x00\x47" + struct.pack("<III", 0, 0x00180000 | NS, 0) + struct.pack("<H", 0x421) + b"\x00\x00" + struct.pack("<H", sec & 0xFFFF) + struct.pack("<3f", x, y, z) + b"PDYNAM.itm\x00")
            if RELAY: relay_msg(2, b"\x00\x47" + struct.pack("<III", 0, 0x00180000 | NS, 0) + struct.pack("<H", 0x421) + b"\x00\x00" + struct.pack("<H", sec & 0xFFFF) + struct.pack("<3f", x, y, z) + b"PDYNAM.itm\x00", peer_ids())
            ent_destroy(dy["slot"])
            BOOMS.append((now, (x, y, z))); del BOOMS[:-8]
            chain_blast(now, (x, y, z))
            hurt = []
            if alive and walker is not None and TNT_SELF:     # its own blast hurts the thrower too (killed by it: "self-destructed")
                d3 = math.dist((walker.x, walker.y + 2.5, walker.z), (x, y, z))
                if d3 <= WEAPONS["dynamite"]["blast"]:
                    dd = blast_dmg(d3); hurt.append(f"itself {dd:.1f}")
                    yw_, pw_ = blast_words((x, y, z), (walker.x, walker.y, walker.z))
                    LAST_HIT.update(t=now, mom=BLAST_MOM * dd, f2=1.0, yaw=yw_, pitch=pw_, kind=4, src=slot)
                    KICK[:] = [now, kick_vel(BLAST_MOM * dd, 1.0, yw_, pw_)]
                    take_damage(dd, slot, now, blast=True)
                    if alive: knock_hit(now)
            for who, (t_, p3, dying) in list(players.items()):
                d3 = math.dist((p3[0], p3[1], p3[2]), (x, y, z))
                if dying or now - t_ > 1.5 or d3 > WEAPONS["dynamite"]["blast"]: continue
                if is_friend(who): continue                                       # (a game mode: its own side takes no blast)
                if addr_id(who) == 1 and not TNT_HOSTHITS: hurt.append(f"host player {d3:.0f} away (its own game applies the blast)"); continue
                dd = blast_dmg(d3)
                # a BLAST hit, as the host sends its own dynamite's (decoded 7 Nov): kind 4 (a bullet is 1), damage, 1.0, the direction from
                # the blast (degrees), a word, the victim's position, its radius 1.5 and height 3.0. With kind 1 the user's kill feed said
                # "killed" for a ghost's dynamite; kind 4 is what makes it "blew up".
                # (its momentum and direction as the host's own blasts carry them: 75 x the damage, heading from the blast to the victim
                #  and a slight lift - the ghosts sent the heading in degrees as the momentum and a fixed direction, so the bots were
                #  thrown the wrong way by the ghosts' dynamite)
                yw_, pw_ = blast_words((x, y, z), p3)
                hb = bytes.fromhex("47") + struct.pack("<III", who, slot, who) + struct.pack("<H", 0x7d1) + b"\x00\x00" + struct.pack("<H", 4) + struct.pack("<3f", dd, 1.0, BLAST_MOM * dd) \
                     + struct.pack("<HH", yw_, pw_) + struct.pack("<3f", *p3[:3]) + struct.pack("<2f", 1.5, 3.0) + bytes.fromhex("30640400")
                if addr_id(who) == 1: send_msg(2, b"\x00" + hb)
                elif RELAY: relay_msg(2, b"\x00" + hb, [addr_id(who)])
                hurt.append(f"{(display_name(addr_id(who)) or b'?').decode(errors='replace')} {dd:.1f}")
            gl = dy.get("goal")
            print("dynamite went off" + (f" {math.hypot(x - gl[0], z - gl[2]):.0f} from its aim point (y {y:.1f}, aimed {gl[1]:.1f}, landed {dy['landed']})" if gl else "") + (": " + ", ".join(hurt) if hurt else " (nobody close)"))
            continue
        if now < dy["next"]: continue
        dt = 0.15; dy["next"] = now + dt
        if not dy["landed"]:
            nx, ny, nz = dy["p"][0] + dy["v"][0] * dt, dy["p"][1] + dy["v"][1] * dt - 0.5 * TNT_G * dt * dt, dy["p"][2] + dy["v"][2] * dt      # (exact arc: the solver's)
            dy["v"][1] -= TNT_G * dt
            if not can_move(dy["p"][0], dy["p"][1] - 4.0, dy["p"][2], nx, nz): nx, nz = dy["p"][0], dy["p"][2]; dy["v"][0] = dy["v"][2] = 0.0   # hit a wall: drops
            f, s = floor_under(nx, nz, dy["p"][1])
            if s is not None: dy["sec"] = s
            if f is not None and ny <= f + 0.3:
                ny = f + 0.3
                if abs(dy["v"][1]) > 12.0: dy["v"] = [dy["v"][0] * 0.5, -dy["v"][1] * 0.3, dy["v"][2] * 0.5]     # it bounces (ALLOW_BOUNCE 1)...
                else:
                    dy["landed"] = True; dy["v"] = [0.0, 0.0, 0.0]                                               # ...and settles
                    if dy.get("goal"): print(f"dynamite landed {math.hypot(nx - dy['goal'][0], nz - dy['goal'][2]):.0f} from where it was aimed, {dy['lit'] + TNT_FUSE - now:.2f} s before going off")
            dy["p"] = [nx, ny, nz]
            spin = 0 if dy["landed"] else -(int((now - dy.get("thrown", now)) * TNT_SPIN) % 16384)
            to_all(2, ent_state(TT["tnt_rest" if dy["landed"] else "tnt_fly"], dy["slot"], nx, ny, nz, dy["sec"], tuple(dy["v"]), pitch=spin, yaw=dy.get("yaw")))
        elif now - dy["rest_sent"] > 1.0:
            dy["rest_sent"] = now
            to_all(2, ent_state(TT["tnt_rest"], dy["slot"], *dy["p"], dy["sec"], yaw=dy.get("yaw")))
DYN_ENTS = {}; CHAIN_R = float(os.environ.get("GHOST_TNT_CHAIN", "30"))
# The user (10 Nov): the ghosts "shoot thrown lit TNT way too much". A ghost now holds its fire while someone's lit stick (out of their
# hand: thrown, flying or lying) is near its line of fire or near its target. DYN_SEEN: when each stick was last heard of.
DYN_SEEN = {}; TNT_HOLD = os.environ.get("GHOST_TNT_HOLD", "1") == "1"; TNT_LANE = 6.0; TNT_NEAR_TGT = 10.0
def tnt_in_the_way(g, t, now):
    if not TNT_HOLD: return False
    for es, (ep, in_hand) in list(DYN_ENTS.items()):
        if now - DYN_SEEN.get(es, now) > 6.0: DYN_ENTS.pop(es, None); DYN_SEEN.pop(es, None); continue     # (long gone off)
        if in_hand or es not in DYN_SEEN: continue
        if math.dist(ep, t) < TNT_NEAR_TGT: return True
        dx, dy, dz = t[0] - g[0], t[1] - g[1], t[2] - g[2]; L2 = dx * dx + dy * dy + dz * dz
        if L2 <= 0: continue
        k = max(0.0, min(1.0, ((ep[0] - g[0]) * dx + (ep[1] - g[1]) * dy + (ep[2] - g[2]) * dz) / L2))
        if math.dist(ep, (g[0] + k * dx, g[1] + k * dy, g[2] + k * dz)) < TNT_LANE: return True
    return False
def chain_blast(now, pos):
    """an explosion sets off every stick close to it, lit or not: our own go off at once; the host's get a hit (hitting a stick
    blows it up in the game: the ghosts used to shoot the user's lit dynamite out of his hand)"""
    for dy in DYNS:
        if math.dist(dy["p"], pos) <= CHAIN_R and dy["lit"] + TNT_FUSE > now + 0.2:
            dy["lit"] = now + 0.2 - TNT_FUSE; print(f"our dynamite caught in a blast {math.dist(dy['p'], pos):.0f} away: it goes off too")
    # (25 Nov, the user: "ghosts still steal TNT kills a good bit" - MRBO took his TNT kills several times) every ghost near a
    #  blast gave the user's own sticks lying close by a hit to set them off, and the hit made that ghost the stick's killer
    #  (84 times in a few minutes). The host's sticks are left to the game now: GHOST_TNT_CHAIN_HOST=1 brings the old way back.
    if os.environ.get("GHOST_TNT_CHAIN_HOST", "0") != "1": return
    for es, (ep, in_hand) in list(DYN_ENTS.items()):
        # (a stick still in someone's hand is left alone, as in the original game; the other ghosts' sticks: they chain their own)
        if in_hand or es >> 11 != 1 or math.dist(ep, pos) > CHAIN_R: continue
        hb = bytes.fromhex("47") + struct.pack("<III", es, slot, es) + struct.pack("<H", 0x7d1) + b"\x00\x00" + struct.pack("<H", 1) + struct.pack("<3f", 12.0, 1.0, 0.0) \
             + bytes.fromhex("92281b00") + bytes(4) + struct.pack("<4f", 5.72, 68.3, 0.02, 3.16) + bytes.fromhex("50f70400")
        send_msg(2, b"\x00" + hb); DYN_ENTS.pop(es, None)
        print(f"host dynamite {es:#x} caught in a blast {math.dist(ep, pos):.0f} away: hit it so it goes off")
BOX_KINDS = {"james": ("box_b", "box_c"), "drdeath": ("box_b", "box_c"), "sanchez": ("box_b", "box_c"),
             "mary": ("box_b", "box_s"), "bob": ("box_b", "box_s"), "twofeathers": ("box_b",)}
DROP_BOXES = os.environ.get("GHOST_DROPBOXES", "1") == "1"
# The user (10 Nov): ammo piled up on the ground. A box a ghost drops goes after BOX_LIFE seconds if nobody has taken it.
BOX_LIFE = float(os.environ.get("GHOST_BOX_LIFE", "60")); BOX_BORN = {}; BOX_SWEEP = [0.0]
def sweep_boxes():
    t = time.time()
    if t < BOX_SWEEP[0]: return
    BOX_SWEEP[0] = t + 1.0
    for bid, born in list(BOX_BORN.items()):
        if bid not in ITEMS: BOX_BORN.pop(bid)                         # (picked up: by a ghost, or someone told us it is gone)
        elif BOX_LIFE > 0 and t - born > BOX_LIFE:
            BOX_BORN.pop(bid); ITEMS.pop(bid, None); ent_destroy(bid)
def drop_boxes(x, y, z):
    """what a real dying player creates where it fell: an ammo box per kind of ammo it carried (not dynamite or knives)"""
    if not DROP_BOXES or WMODE == "melee": return                     # (Melee only: nobody has guns, so no ammo comes out of a body)
    sec = sector_of(x, y, z) or LAST_SEC[0]
    for i, k in enumerate(BOX_KINDS.get(CHAR, ("box_b",))):
        if k in TT:
            bid = new_id("box")
            if bid in BOX_BORN: ent_destroy(bid); ITEMS.pop(bid, None)          # (the number came round again: the old box goes first)
            to_all(2, ent_create(TT[k], bid, x + i * 1.0, y, z, sec)); BOX_BORN[bid] = time.time()
            ITEMS[bid] = ({"box_b": "GAMBOXB", "box_c": "GAMBOXC", "box_s": "GAMBOXS"}[k], (x + i * 1.0, y, z))      # (ours: nobody tells us about it)
# 0 (10 Nov, was 4): a ghost's old player entity goes when it respawns, as a real client's does. Kept "bodies" are old player
# entities nobody updates any more; with another PC as host the user saw them standing at the spawn points, dark, with no name, never
# moving ("ghosts that spawned and didn't move"). GHOST_KEEP_BODIES=4 brings them back.
KEEP_BODIES = int(os.environ.get("GHOST_KEEP_BODIES", "0")); BODIES_LEFT = []
last_shooter = None; last_ack_t = 0.0; last_402_t = 0.0; ACK_EVERY = float(os.environ.get("GHOST_ACK_EVERY", "10")); next_ack = None
# OFF by default: with "~ACK" the host stopped processing the ghosts' respawns after its first catch-up transfer (~30 s): no 0x413 for any respawn after
# that, and ghosts stayed invisible while still moving and shooting (real game, 6 min, ~50 respawns ignored). Without it the host just repeats the
# 10-byte end marker once a second, and respawns keep working (earlier games). GHOST_ACK=1 turns it back on for experiments.
ACK_ON = os.environ.get("GHOST_ACK", "0") == "1"

def to_player(shooter_addr, body):
    """send a message to the player owning shooter_addr: straight to the host if it is the host's, else relayed to that client"""
    pid = addr_id(shooter_addr)
    if pid == 1: send_msg(2, body)
    elif RELAY: relay_msg(2, body, [pid])

CONFIRM = os.environ.get("GHOST_CONFIRM", "1") == "1"; KILLMSG = os.environ.get("GHOST_KILLMSG", "1") == "1"; ANSWER402 = os.environ.get("GHOST_ANSWER402", "1") == "1"
def confirm(ty):
    """what a real victim sends its shooter on every hit: 0x7e4 (hit) / 0x7e3 (killed), A = shooter, B = us"""
    if last_shooter is None or not CONFIRM: return
    to_player(last_shooter, b"\x00\x47" + struct.pack("<III", last_shooter, slot, last_shooter) + struct.pack("<H", ty) + b"\x00\x00")

# XP for the user's kills of ghosts (13 Nov, the user: "is the XP counting?" - it was not: kills are counted by a BOT watching the kill
# feed, so a game with ghosts only counted nothing). The victim ghost knows who killed it and its own difficulty: when the killer is the
# player named on the launcher's Stats tab, it records the kill for the character chosen there (xp.record_kill counts a kill once, and
# the launcher still moves it to the character really played if it was switched in the lobby). GHOST_XP=0: off.
XP_ON = os.environ.get("GHOST_XP", "1") == "1"; _XP_WHO = []
def xp_who():
    if not _XP_WHO:
        pl, ch = os.environ.get("BOT_STATS_PLAYER", ""), os.environ.get("BOT_STATS_CHAR", "")
        if not pl or not ch:
            try:
                st_ = json.load(open(data_file("launcher_settings.json"), encoding="utf-8"))
                pl = pl or (st_.get("stats_player") or "").strip(); ch = ch or (st_.get("my_char") or "")
            except Exception: pass
        _XP_WHO[:] = [pl, ch]
    return _XP_WHO
def xp_for_killer(killer):
    if not XP_ON: return
    try:
        pl, ch = xp_who()
        k_ = (killer.decode(errors="replace") if isinstance(killer, bytes) else str(killer)).strip().lower()
        if not pl or pl.strip().lower() not in k_: return
        for d_ in (HERE, UP):
            if d_ not in sys.path: sys.path.insert(0, d_)
        import xp as xp_
        got = xp_.record_kill(pl, NAME.decode(errors="replace"), DIFFICULTY if DIFFICULTY in xp_.LEVEL_XP else "normal", character=ch)
        print(f"XP: {pl} killed this ghost: +{got} for {ch or 'no character'} ({DIFFICULTY})")
    except Exception as e:
        print("XP: could not record the kill:", e)
_DEATH_SEEN = {}
def note_player_death(raw):
    """the first ghost keeps the Stats-tab player's deaths (state\\ghost_deaths.jsonl) so the launcher can make the game's record"""
    try:
        pl, _ch = xp_who()
        if not pl: return
        m_ = re.match(rb"\$\$(\d+)\$\$([^$]*)\$\$(?:([^$]*)\$\$)?", raw)
        if not m_: return
        code, a_, b_ = m_.group(1), m_.group(2).decode(errors="replace"), (m_.group(3) or b"").decode(errors="replace")
        victim, cause, suicide = (b_, "killed by a player", False) if code == b"20042" else (b_, "killed by explosion", False) if code == b"20061" \
            else (a_, "self-destruct", True) if code == b"20059" else (a_, "fall", True) if code == b"20044" else (None, None, False)
        if not victim or pl.strip().lower() not in victim.strip().lower(): return
        now_ = time.time()
        if now_ - _DEATH_SEEN.get(raw, 0) < 3.0: return                  # (the same message twice: once)
        _DEATH_SEEN[raw] = now_
        sd_ = os.path.join(os.path.dirname(HERE) if os.path.basename(HERE).lower() == "netre" else HERE, "state")
        os.makedirs(sd_, exist_ok=True)
        with open(os.path.join(sd_, "ghost_deaths.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps({"t": now_, "player": pl, "cause": cause, "suicide": suicide, "by": a_ if code in (b"20042", b"20061") else ""}) + "\n")
    except Exception as e:
        print("XP: could not note the player's death:", e)
def death_notice(by_tnt=False):
    """The kill message. In the real game the VICTIM announces its own death to everyone: $$20042$$<killer>$$<victim>$$ (0x40a, sender = victim).
    The ghosts never did, so the human's kills of ghosts did not count on the score list, and kills between ghosts would not either."""
    if not KILLMSG: return
    own = last_shooter is not None and (last_shooter & 0xFFFF) >> 11 == NS >> 11
    killer = NAME if own else (display_name(addr_id(last_shooter)) if last_shooter is not None else None)
    if not killer: print("ghost died (killer unknown: no kill message)"); return
    # the game's own lines (olpatch4.lab strings): 20042 "%s killed %s!", 20061 "%s blew up %s!", 20059 "%s self-destructed!"
    if own and FELL[0]: text = b"$$20044$$" + NAME + b"$$"          # 20044 "%s died from a fall!"
    elif own: text = b"$$20059$$" + NAME + b"$$"
    elif by_tnt: text = b"$$20061$$" + killer + b"$$" + NAME + b"$$"
    else: text = b"$$20042$$" + killer + b"$$" + NAME + b"$$"
    b = b"\x00\x47" + struct.pack("<III", 0, NS, 0) + struct.pack("<H", 0x40a) + b"\x00\x00" + text + b"\x00"
    send_msg(2, b)
    if RELAY: relay_msg(2, b, peer_ids())
    # The score: a real victim also sends the HOST (only the host) 0x408 with the killer's slot number (address >> 11: host 1, client k = k+1), -1, 1.
    # Without it the kill text showed but no one's score went up (measured: bots' death bundles in a real 4-player game).
    # The middle value is -1 in a free-for-all; in a team game it is the KILLER's team (1 red, 2 blue, 0 none) - Team Play captures: a bot
    # killed by the user's red sent 1, the user killed by a blue bot 2, killed by the team-less ghost 0. With -1 the user's kills of ghost
    # zombies never reached the Survivors' team score (his own score did).
    kteam = -1
    if TEAM_GAME[0]:
        kt_ = MY_TEAM[0] if own else {b"SERVER_TEAM_RED": "red", b"SERVER_TEAM_BLUE": "blue"}.get(TEAMS.get(addr_id(last_shooter)) if last_shooter is not None else None)
        kteam = 1 if kt_ == "red" else 2 if kt_ == "blue" else 0
    send_msg(2, b"\x00\x47" + struct.pack("<III", 0x0800, NS, 0) + struct.pack("<H", 0x408) + b"\x00\x00" + struct.pack("<IiI", (last_shooter & 0xFFFF) >> 11, kteam, 1))
    print("kill message sent: " + text.decode(errors='replace'))
    print(f"FEED {time.time():.2f} " + text.decode(errors='replace'))
    if not own: xp_for_killer(killer)
    if MODE_RUN:                                                    # the game mode reads its zombies' deaths like a bot's
        k_ = killer.rstrip(b"_").decode(errors="replace")
        print("FMT: G " + (f"{NAME.rstrip(b'_').decode(errors='replace')} " + ("died from a fall!" if FELL[0] else "self-destructed!") if own else f"{k_} blew you up!" if by_tnt else f"{k_} killed you!"), flush=True)

DEATH_PEND = [None]; FELL = [False]; RELOAD_SND = []; MODE_POLL = [0.0]     # (MODE_POLL: the game mode flags, every 0.5 s; lost in an edit, put back 15 Nov)
# ---- Fall damage: the game's own rule (player hit handler, 0x1400bac88; the player defaults at 0x1400b27c4): landing faster than 45
# units/s hurts (speed - 45) x 0.2 (health 10). With gravity ~61 that is a drop of ~17 units for the first scratch; 24 units ~1.7; a
# full health is gone at 95 a second (~74 units). A death from it reads "<name> died from a fall!" (20044) and counts as a suicide.
FALL_SAFE = float(os.environ.get("GHOST_FALL_SAFE", "45"))
FALL_HURT = float(os.environ.get("GHOST_FALL_HURT", "0.2"))
FALL_DMG_ON = os.environ.get("GHOST_FALL_DMG", "1") == "1"
# (15 Nov, Bunkers and Simms at Night: the first ghost of a game joined, fought, was named on the scoreboard - and nobody could
#  see it. The host had never taken its body: it never asked for it (a seen body is asked for within a second of its create)
#  and nobody ever hit it. It showed up only after it next died and respawned. Now a body with no sign of the host having it
#  UNSEEN_AFTER s after its create is given up: the ghost "dies" quietly and respawns, which makes a new body. At most
#  UNSEEN_MAX times a game. GHOST_UNSEEN_AFTER=0: off.)
UNSEEN_AFTER = float(os.environ.get("GHOST_UNSEEN_AFTER", "20")); UNSEEN_MAX = 3
UNSEEN = {"ask": 0.0, "n": 0, "life": None, "late": 0.0, "first": None, "refreshed": False}; UNSEEN_EARLY = 30.0; SHOT_HIT_T = [0.0]; QUIET_DEATH = [False]; LAST_SHOT_T = [0.0]; UNSEEN_FIGHT = 15.0; FIRST_REFRESH = float(os.environ.get("GHOST_FIRST_REFRESH", "3"))


# (23 Nov, the user: "Enemies still spawn in jail cells". The host's own map list can still have the cell points (a game that was
#  already running when the mission's map files went in), and the host names the spawn point. A body put on one of the
#  GHOST_NO_STARTS points is taken away quietly a moment later and made again: the host then names its next point.)
try:
    NO_STARTS = [tuple(float(v) for v in p_.split(",")) for p_ in os.environ.get("GHOST_NO_STARTS", "").split(";") if p_.strip()]
except ValueError:
    NO_STARTS = []
BAD_SPAWN = {"at": 0.0, "n": 0}; BAD_SPAWN_MAX = 6


# (25 Nov, the user: "the Mary ghost ran and shot once and vanished and appeared on the roof - ghosts tend to teleport") the
# quiet rebuilds (the first body's, FIRST_REFRESH s in, and the watchdog's) made the new body wherever the host named next - a
# jump across the map. A rebuild now makes it again where it stood.
KEEP_POS = [None]
def keep_spot():
    try: KEEP_POS[0] = (walker.x, walker.y, walker.z)
    except Exception: KEEP_POS[0] = None

# (25 Nov, the user: in every ghost game, not just the missions, never spawn in Sanctuary's jail cells) the cells' STARTPOS
# points by map, for when GHOST_NO_STARTS is not set (horde.py sets it from the missions' MAP_TWEAKS)
MAP_NO_STARTS = {"town_2p": [(251.99, 366.13), (250.75, 329.5)]}
def no_starts():
    if NO_STARTS: return NO_STARTS
    if os.environ.get("GHOST_NO_STARTS"): return []
    return MAP_NO_STARTS.get((LEVEL_NAME or "").lower(), [])

def avoid_blocked(pos):
    """the host named a blocked spawn point (a jail cell): spawn at another of the map's STARTPOS points instead - straight
    there, no body made and taken away"""
    ns_ = no_starts()
    if not ns_ or not any(math.hypot(pos[0] - q[0], pos[2] - q[1]) < 6.0 for q in ns_):
        return pos
    ok_ = [p_ for p_ in startpositions() if all(math.hypot(p_[0] - q[0], p_[2] - q[1]) > 6.0 for q in ns_)]
    if not ok_:
        return pos
    np_ = random.choice(ok_)
    print(f"that spawn point ({pos[0]:.0f},{pos[2]:.0f}) is a blocked one (a jail cell): spawning at {np_[0]:.0f},{np_[2]:.0f} instead")
    return np_


def bad_spawn_mark(pos, now):
    """after the host names a spawn point: one of the no-start points means a quiet redo in a moment"""
    if NO_STARTS and any(math.hypot(pos[0] - q[0], pos[2] - q[1]) < 6.0 for q in NO_STARTS):
        if BAD_SPAWN["n"] < BAD_SPAWN_MAX:
            BAD_SPAWN["at"] = now + 0.8; BAD_SPAWN["n"] += 1
            print(f"that spawn point ({pos[0]:.0f},{pos[2]:.0f}) is a blocked one: the body is redone in a moment")
    else:
        BAD_SPAWN["n"] = 0


def bad_spawn_check(now):
    global alive, died_at, respawn_req
    if not BAD_SPAWN["at"] or now < BAD_SPAWN["at"]: return
    BAD_SPAWN["at"] = 0.0
    if not alive: return
    UNSEEN["refreshed"] = True                                   # (this redo is a respawn too: it registers the ghost the same way)
    try: ent_destroy(slot); print(f"its body {slot:#x} taken away at once (no corpse), to spawn somewhere else")
    except Exception as ex_: print("could not take the body away:", ex_)
    alive = False; died_at = now - DEAD_TIME + 0.3; respawn_req = None; QUIET_DEATH[0] = True


def unseen_check(now):
    global alive, died_at, respawn_req
    c = CREATED_AT[0]
    # (16 Nov 16:42, the user on Orleans: "Player 3 connected", but the elf never got a name or a team in his game and was not on the
    #  scoreboard, for 4 minutes, while it fought him (none of its hits hurt). The host had asked for its FIRST body 0.2 s after the
    #  create and the ghost, as it must, did not send it twice; the user's game kept a half-made player. It showed up the moment the elf
    #  died (his TNT) and respawned. Now a first body the host asked for after its create is rebuilt once, FIRST_REFRESH s in (before it
    #  has reached anyone): taken away quietly and made again, like that respawn. GHOST_FIRST_REFRESH=0: off.)
    # (16 Nov 16:53, Buckshotville: "Player 3" again, nameless, and this time the host never asked for the body at all; the old
    #  watchdog rebuilt it after 53 s and "Elf 1" appeared at once. Only the respawn path registers the ghost as a player in every
    #  game, so now EVERY first body is rebuilt once, FIRST_REFRESH s in, ask or no ask.)
    if UNSEEN["first"] is None and c: UNSEEN["first"] = c
    if FIRST_REFRESH > 0 and not UNSEEN["refreshed"] and c and c == UNSEEN["first"] and now - c >= FIRST_REFRESH:
        UNSEEN["refreshed"] = True
        print(f"rebuilding the first body once ({now - c:.0f} s in), so every game registers it as a player")
        keep_spot()
        try: ent_destroy(slot); print(f"its body {slot:#x} taken away at once (no corpse)")
        except Exception as ex_: print("could not take the body away:", ex_)
        alive = False; died_at = now - DEAD_TIME + 0.5; respawn_req = None; QUIET_DEATH[0] = True
        return
    if UNSEEN_AFTER <= 0 or UNSEEN["n"] >= UNSEEN_MAX or not c or now - c < UNSEEN_AFTER or UNSEEN["life"] == c:
        return
    # (16 Nov, the user: "lots of bodies that aren't the actual ghosts - nameless, don't move, can't be hurt". The watchdog fired on
    #  a third of the ghosts 20 s into their first life: the host had asked for the body BEFORE our create (answered with it), so the
    #  ask counted as missing. The "dead" ghost's body was left standing in the other games and its respawn made a standing corpse of
    #  it. Now an ask from up to UNSEEN_EARLY s before the create counts too, any shot it fired that hit counts, and when it does fire
    #  the old body is taken away at once (no death message, no corpse).)
    if UNSEEN["ask"] >= c - UNSEEN_EARLY or last_hit_t >= c or SHOT_HIT_T[0] >= c:
        UNSEEN["life"] = c; return                              # the host has it: nothing to do for this body
    # (16 Nov, the user: an elf came after him under water, got close, "made a grinding noise and vanished", then came back and
    #  killed him: five stabs under water, all misses, and the watchdog took the body away mid-fight. A ghost that is attacking
    #  someone is left alone: the check waits until it has not swung or fired for UNSEEN_FIGHT s (a hit by then settles it).)
    if now - LAST_SHOT_T[0] < UNSEEN_FIGHT:
        return
    UNSEEN["life"] = c; UNSEEN["n"] += 1
    print(f"no sign the host has this body {now - c:.0f} s after its create (never asked for, never hit): respawning to make a new one")
    keep_spot()
    try: ent_destroy(slot); print(f"its body {slot:#x} taken away at once (no corpse)")
    except Exception as ex_: print("could not take the body away:", ex_)
    alive = False; died_at = now; respawn_req = None; QUIET_DEATH[0] = True


def fall_check(now):
    """after a move: any landing since the last one hard enough to hurt"""
    land = list(FALL_HIT); FALL_HIT.clear()
    F = getattr(walker, "F", None)
    if F is not None and getattr(F, "impacts", None): land += F.impacts; F.impacts = []
    if not land or not FALL_DMG_ON or not alive: return
    v = max(land)
    if v <= FALL_SAFE: return
    dmg = (v - FALL_SAFE) * FALL_HURT
    print(f"landed at {v:.0f} a second: fall damage {dmg * TAKE_MULT:.2f}")
    KICK[:] = []; LAST_HIT.clear()
    if HIT_WAV and hp - dmg * TAKE_MULT > 0: send_sound(sound_msg(slot, b"LAND.WAV"))
    take_damage(dmg, slot, now, fall=True)
# (18 Nov, the user: Santa fell into Thud Tower's pit, lived through the landing (200 health) and was stuck down there. GHOST_PIT_SAFE=1
#  (Mission 4's Santa only): a ghost falling more than PIT_DROP below the map's lowest spawn point is put back in the map's main
#  area before it lands - the pit neither kills nor hurts it.)
PIT_SAFE = os.environ.get("GHOST_PIT_SAFE") == "1"
PIT_DROP = float(os.environ.get("GHOST_PIT_DROP", "60"))
def pit_return(now):
    global walker
    if not PIT_SAFE or walker is None or not alive: return
    S = startpositions()
    if not S or walker.y >= min(q[1] for q in S) - PIT_DROP: return
    hub = main_area() or S[0]
    x, y, z = settle(*hub)
    print(f"fell into a pit (height {walker.y:.0f} at {walker.x:.0f},{walker.z:.0f}): back up in the main area at {x:.0f},{z:.0f}")
    walker.x, walker.y, walker.z = x, y, z
    F = getattr(walker, "F", None)
    if F is not None:
        F.fall_vy = 0.0; F.impacts = []; F.vel = (0.0, 0.0); F.path = []
        try: F.cur_sec = sector_of(x, y, z)
        except Exception: pass
    FALL_HIT.clear(); BLASTKNOCK.clear(); LAST_SEC[0] = sector_of(x, y, z)
def door_sectors():
    """the doors' own sectors on this map (thin strips a door slides or swings in)"""
    try: return {q["sector"] for q in (LVL.panels or []) if q.get("sector") is not None} if LVL is not None else set()
    except Exception: return set()
def in_door(x, y, z):
    if LVL is None: return False
    try:
        from fighter import door_at
        q = door_at(LVL, x, z)
        return q is not None and abs(LVL.floor_at(q["sector"], q["x"], q["z"]) - y) <= 4.0
    except Exception: return False
def body_out_of_door():
    """A ghost killed while it is in a door's own sector falls beside the door, not in it: a body lying in a door blocks it, and the
    user's game buzzes loudly and stops drawing it (town_2p: Normal 1's body in JAILDOOR05, 10 Nov). True if it was moved."""
    if walker is None or not in_door(walker.x, walker.y, walker.z): return False
    try:
        sl = walker.F.door_exit(time.time(), dict(x=walker.x, y=walker.y, z=walker.z), None)
    except Exception: sl = None
    if sl is None: print("died in a doorway and found no spot beside it: the body is taken away when the ghost comes back"); return False
    walker.x, walker.y, walker.z = sl["x1"], sl["y1"], sl["z1"]; LAST_SEC[0] = sl["sec"]
    print(f"died in a doorway: the body falls beside it, at {walker.x:.0f},{walker.z:.0f}")
    return True
def death_pending(now):
    if DEATH_PEND[0] is not None and now >= DEATH_PEND[0]:
        DEATH_PEND[0] = None; death_notice(boom_near(now))
def take_damage(dmg, shooter, now, blast=False, fall=False):
    """a hit on the ghost (someone's 0x7d1, the blast of its own dynamite: shooter = its own slot, or a fall: shooter = its own slot)"""
    global hp, last_shooter, hit_fx, last_hit_t, alive, died_at, respawn_req
    if not alive or walker is None: return
    dmg *= TAKE_MULT * (BLAST_TAKE if blast else 1.0)
    FELL[0] = fall
    if ARMOR[0] > 0 and dmg > 0:                                  # a boiler plate takes the hit first
        ab = min(ARMOR[0], dmg); ARMOR[0] -= ab; dmg -= ab
        send_sound(sound_msg(slot, random.choice((b"ARMOR1.WAV", b"armor2.wav", b"ARMOR3.WAV"))))
        print(f"the plate took {ab:.1f} (armor left {ARMOR[0]:.1f})")
    hp -= dmg; last_shooter = shooter
    own = (shooter & 0xFFFF) >> 11 == NS >> 11
    who_n = NAME if own else display_name(addr_id(shooter))
    far = ""
    if not own and walker is not None:                            # (how far the shot came from: the match summary's best shot)
        try:
            pv = players.get(shooter) or next((v for k, v in players.items() if addr_id(k) == addr_id(shooter)), None)
            if pv: far = f" @{math.dist(pv[1], (walker.x, walker.y, walker.z)):.0f}"
        except Exception: far = ""
    print(f"hit by {who_n.decode(errors='replace') if who_n else hex(shooter)}! damage {dmg:.2f}, health {max(hp, 0):.1f}/{HP:.0f}{far}")
    hit_fx = "blast" if blast else True; last_hit_t = now
    if not own: confirm(0x7e4 if hp > 0 else 0x7e3)
    if hp <= 0:
        alive = False; died_at = now; respawn_req = None; print("ghost died" + (" from a fall" if fall else ""))
        if KAMI:
            try: kami_blast(now, (walker.x, walker.y + 2.5, walker.z))
            except Exception as e_: print("present blast:", e_)
        body_out_of_door()
        if MODE_RUN: print("died", flush=True)
        drop_boxes(walker.x, walker.y, walker.z)
        # the body flies with the kick of the hit that killed it, exactly as a real player's (the game keeps its velocity; a blast's
        # kick is the blast's own, from where it went off) - plus whatever it was already flying with
        kv = KICK[1] if KICK and now - KICK[0] < 0.5 else None
        if BLASTKNOCK: bv = BLASTKNOCK["v"]; kv = (bv[0] + (kv[0] if kv else 0.0), bv[1] + (kv[1] if kv else 0.0), bv[2] + (kv[2] if kv else 0.0)) if kv else tuple(bv)
        BLASTKNOCK.clear(); FLY.clear()
        if kv is not None and (math.hypot(kv[0], kv[2]) > 1.0 or kv[1] > 1.0):
            FLY.update(v=[kv[0], max(0.0, kv[1]), kv[2]], landed=False, floor=walker.y, t0=now, x0=walker.x, y0=walker.y, z0=walker.z)
            print(f"the body is thrown: {math.hypot(kv[0], kv[2]):.0f} sideways, {max(0.0, kv[1]):.0f} up")
        if fall: death_notice()
        elif blast or boom_near(now): death_notice(True)
        else: DEATH_PEND[0] = now + 0.25        # the kill text a moment later: the explosion message can come just after the hit it caused
        if DIE_WAV: send_sound(sound_msg(slot, DIE_WAV))             # the death cry the moment health reaches zero
        if BODIES:
            for bm in body_msgs(walker.x, walker.y, walker.z): send_msg(2, bm)

# ---- GHOST_GUESTS: the guest, a second player on this ghost's connection (split-screen style; test 2) ----
# It joins with the same recorded messages as the main ghost, under its own id, address, name and character, gets a body next to
# the main ghost and walks a small square. Its moves go out relayed with ITS id as the sender (84 <guest id> 1 <host id> ...).
# No fighting, health or respawns yet: the question is only whether the user's game shows two players from one connection.
GUEST_CHAR = os.environ.get("GHOST_GUEST_CHAR", "bob").lower()
GUEST_MODEL = {"mary": "mary.nwx", "bob": "bobgrahm.nwx", "james": "james.nwx", "drdeath": "drdeath.nwx", "sanchez": "sanchez.nwx",
               "twofeathers": "twofeath.nwx"}.get(GUEST_CHAR, "bobgrahm.nwx")
GUEST_SIZE = float(os.environ.get("GHOST_GUEST_SQUARE", "10"))       # half the side of the square it walks
GUEST = {"t0": None, "hi": 0, "spawned": None, "pos": None, "home": None, "k": 0, "sec": None, "chor": None, "next": 0.0,
         "spawn407": None, "rx": {}, "hits": 0, "answered402": 0}

def guest_addr(gid): return 0x1800 if NS_OFF else 0x800 * (gid + 1)
def guest_slot(gid): return guest_addr(gid) | 0x02

class as_player:
    """For a moment the module's identity (CID, NS, slot, MODEL) is another local player's, so the same helpers build its messages."""
    def __init__(self, cid, model=None): self.cid, self.model = cid, model
    def __enter__(self):
        global CID, NS, slot, MODEL
        self.saved = (CID, NS, slot, MODEL)
        CID = self.cid; NS = guest_addr(self.cid); slot = NS | 0x02
        if self.model: MODEL = self.model
        return self
    def __exit__(self, *a):
        global CID, NS, slot, MODEL
        CID, NS, slot, MODEL = self.saved

def guest_send(gid, fl, body):
    """a guest's game message, relayed with the guest as the sender (the way real clients send theirs)"""
    send_msg(fl, b"\x84" + bytes([gid & 0xFF, 1, HOST_ID & 0xFF]) + b"\x00" + bytes([fl]) + (body[1:] if body[:1] == b"\x00" else body))

def guest_rx(p, src, dsts):
    """a message the host addressed to our guest only"""
    ty = struct.unpack("<H", p[13:15])[0] if p[:1] == b"\x47" and len(p) >= 15 else None
    k_ = f"{ty:#x}" if ty is not None else p[:1].hex() + "?"
    GUEST["rx"][k_] = GUEST["rx"].get(k_, 0) + 1
    if GUEST["rx"][k_] <= 2: print(f"GUEST TEST: for the guest only ({src} -> {dsts}): {k_} {p[:48].hex()}")
    if not GUEST_IDS: return
    gs = guest_slot(GUEST_IDS[0])
    if ty == 0x407 and len(p) >= 33 and GUEST["spawn407"] is None:
        GUEST["spawn407"] = struct.unpack("<3f", p[21:33]); print("GUEST TEST: the host gave the guest a spawn point:", tuple(round(v, 1) for v in GUEST["spawn407"]))
    if ty == 0x7d1 and len(p) >= 23 and struct.unpack("<H", p[1:3])[0] == gs:
        GUEST["hits"] += 1; print(f"GUEST TEST: the guest was hit for {struct.unpack('<f', p[19:23])[0]:.1f} (it has no health yet)")
    if ty == 0x402 and len(p) >= 17 and struct.unpack("<H", p[9:11])[0] == gs and GUEST["pos"] is not None:
        with as_player(GUEST_IDS[0], GUEST_MODEL):                   # "send me entity <slot>": answer with its create, alive (like the main ghost)
            cb = bytearray(make_create(*GUEST["pos"], 0, gs)); cb[26] = 0xef; cb[2:6] = p[5:9]
        send_msg(2, bytes(cb)); GUEST["answered402"] += 1

def guest_state(gid, x, y, z, yaw, moving, vx, vz):
    gs = guest_slot(gid)
    b = bytearray(TEMPLATE)
    b[6:10] = b[10:14] = struct.pack("<I", 0x00200000 | gs)
    sec = sector_of(x, y, z, prefer=GUEST["sec"])
    if sec is not None: GUEST["sec"] = sec
    chor = 1 if moving else 0
    b[18:22] = struct.pack("<I", (chor << 16) | ((GUEST["sec"] or 0) & 0xFFFF))
    b[22:26] = struct.pack("<f", x); b[26:30] = struct.pack("<f", y); b[30:34] = struct.pack("<f", z)
    b[34:36] = struct.pack("<h", 0); b[36:38] = struct.pack("<H", int(round(yaw / (2 * math.pi) * YAW_UNITS)) % int(YAW_UNITS))
    b[40:44] = struct.pack("<f", vx); b[44:48] = struct.pack("<f", 0.0); b[48:52] = struct.pack("<f", vz)
    return bytes(b), chor

GUEST_STEP_UP = 2.5          # the most the floor may rise or fall in one step (stairs yes, ledges and pits no)
def guest_move(x, y, z, nx, nz):
    """the guest's own wall check (test 2, 7 Nov: on MLTSIMMS the host spawned Bob on a raised spot whose square corners were all in the
    sector 12 units below, and the old 'is the point in any sector' check let him walk through the walls there at ledge height):
    the straight line must cross open sector borders only, and the floor may change by a step at most. Returns the new (y, sector) or None."""
    if LVL is None: return (y, GUEST["sec"])                            # no level data: cannot tell
    sec = GUEST["sec"] if GUEST["sec"] is not None else sector_of(x, y, z)
    if sec is None: return None
    try:
        from fighter import stand_locate
        dest = None
        for dy in (0.0, 0.5, 1.0, 2.0, GUEST_STEP_UP):
            dest = stand_locate(LVL, nx, y + dy, nz, sec)
            if dest is not None: break
        if dest is None: return None
        path = LVL._march(sec, (x, z), (nx, nz))
        if path is None or dest not in path: return None
        f = LVL.floor_at(dest, nx, nz)
        if abs(f - y) > GUEST_STEP_UP: return None
        return (f, dest)
    except Exception: return None

def guest_tick(now, main_spawn):
    """join, spawn and walk the guest; called every loop once the main ghost has finished its own join"""
    if not GUEST_IDS: return
    gid = GUEST_IDS[0]
    if GUEST["t0"] is None: GUEST["t0"] = now; print(f"GUEST TEST: the guest (id {gid}, slot {guest_slot(gid):#x}, {GUEST_CHAR}) joins")
    el = now - GUEST["t0"]
    with as_player(gid, GUEST_MODEL):
        while GUEST["hi"] < len(hand) and hand[GUEST["hi"]]["t"] <= el:
            i_ = GUEST["hi"]; GUEST["hi"] += 1
            if i_ == 1: continue                                       # its name went to the session list as "fd 01" already
            hb = bytearray(ns_fix(with_cid(with_model(bytes.fromhex(hand[i_]["b"])).replace(b"GhostBot_01", GUEST_NAMES[0]))))
            if i_ == 8: hb[22:24] = struct.pack("<H", slot - 1)
            send_msg(hand[i_]["f"], bytes(hb))
        if GUEST["hi"] < len(hand) or main_spawn is None: return
        if GUEST["spawned"] is None:
            if GUEST["spawn407"]: pos = GUEST["spawn407"]
            else:
                pos = main_spawn
                for dx, dz in ((8, 0), (-8, 0), (0, 8), (0, -8), (4, 0), (-4, 0), (0, 4), (0, -4)):
                    mv = guest_move(main_spawn[0], main_spawn[1], main_spawn[2], main_spawn[0] + dx, main_spawn[2] + dz)
                    if mv: pos = (main_spawn[0] + dx, mv[0], main_spawn[2] + dz); break
            GUEST["sec"] = sector_of(*pos)
            for x_ in D["spawn"][:2]:
                mb = bytearray(ns_fix(bytes.fromhex(x_["b"])))
                if x_ is D["spawn"][0]: mb[10:12] = struct.pack("<H", slot - 1)
                send_msg(x_["f"], bytes(mb))
            send_msg(2, make_create(*pos, 0, slot))
            NOT_PLAYERS.add(slot); players.pop(slot, None)              # the main ghost never takes its own guest for a target
            GUEST["spawned"] = now; GUEST["pos"] = pos; GUEST["home"] = pos; GUEST["next"] = now + 0.3
            print(f"GUEST TEST: the guest's body created at {pos[0]:.0f},{pos[2]:.0f}" + (" (the host's spawn point)" if GUEST["spawn407"] else " (next to the ghost)"))
            return
    if now < GUEST["next"]: return
    x, y, z = GUEST["pos"]; hx, hy, hz = GUEST["home"]
    sz = GUEST.setdefault("size", GUEST_SIZE)
    corners = ((-sz, -sz), (sz, -sz), (sz, sz), (-sz, sz))
    tx, tz = hx + corners[GUEST["k"] % 4][0], hz + corners[GUEST["k"] % 4][1]
    dx, dz = tx - x, tz - z; d = math.hypot(dx, dz); step = SPEED * 0.15
    mv = None
    if d >= 1.0:
        nx, nz = x + dx / d * min(step, d), z + dz / d * min(step, d)
        mv = guest_move(x, y, z, nx, nz)
    if mv is None:
        if d >= 1.0:                                                   # a wall, ledge or pit on the way: next corner; boxed in: a smaller square
            GUEST["blocked"] = GUEST.get("blocked", 0) + 1
            if GUEST["blocked"] >= 4 and sz > 1.5:
                GUEST["size"] = sz / 2; GUEST["blocked"] = 0; print(f"GUEST TEST: the square does not fit here: half the size ({sz / 2:.1f})")
        else: GUEST["blocked"] = 0
        GUEST["k"] += 1; st, chor = guest_state(gid, x, y, z, math.atan2(dx, dz) if d > 0 else 0.0, False, 0.0, 0.0)
    else:
        ux, uz = dx / d, dz / d; x, z = nx, nz; y, GUEST["sec"] = mv; GUEST["pos"] = (x, y, z); GUEST["blocked"] = 0
        st, chor = guest_state(gid, x, y, z, math.atan2(ux, uz), True, ux * SPEED, uz * SPEED)
    guest_send(gid, 2, st)
    if chor != GUEST["chor"]:                                          # pose change, like the main ghost's 0x403
        GUEST["chor"] = chor; ga = guest_addr(gid); gs = guest_slot(gid)
        guest_send(gid, 2, b"\x00\x47" + struct.pack("<III", gs - ga, ga, gs) + struct.pack("<H", 0x403) + b"\x00\x00" + struct.pack("<H", chor))
    GUEST["next"] = now + 0.15

def settle(x, y, z):
    """the spot a player put down at (x, y, z) really stands on: the floor of the sector a standing player there is in. A STARTPOS's
    height can be a roof's or a sign's (Dry Gulch: 16.2 where a standing player only fits on the ground below): the ghost was CREATED up
    there (sector 167) and its first move had it on the ground (sector 122) - the user's game kept it dark, nameless and unhittable."""
    if LVL is None: return (x, y, z)
    try:
        from fighter import stand_locate
        sec = stand_locate(LVL, x, y, z)
        if sec is not None:
            fy = LVL.floor_at(sec, x, z)
            if abs(fy - y) > 0.5: print(f"spawn point {x:.0f},{z:.0f}: height {y:.1f} is not standing room - on the floor below/above at {fy:.1f} (sector {sec})")
            return (x, fy, z)
    except Exception as e: print("could not settle the spawn point:", e)
    return (x, y, z)

def new_walker(x, y, z):
    if FIGHT and LVL is not None:
        try: return FightWalker(x, y, z)
        except Exception as e: print("fight mode unavailable:", e)
    return Walker(x, y, z)


while True:
    try: data, addr = s.recvfrom(65535)
    except socket.timeout: data = None
    except ConnectionResetError: print("host refused / not listening"); break
    except OSError as e:                                         # (14 Nov, a ghost on a hosted game left mid-match: Windows error
        if getattr(e, "winerror", None) != 10040: raise          #  10040, a message bigger than the old 4096-byte buffer. Skip one.)
        print("a message from the host was too big to read: skipped"); data = None
    now = time.time()
    if data:
        last_rx = now; n_rx += 1; log_rx("rx", data)
        got_rel = False
        for fl, m in split(data):
            if fl == 0 and m[2:3] == b"\x85" and not accepted:
                print(f"the host REFUSED this player (85 {m[3:4].hex()}): the game is full - Outlaws takes 14 players at most"); sys.exit(0)
            if fl == 0 and b"CRANTIME" in m and not accepted:
                accepted = True; send_t0 = now; print("host accepted the connection")
                if GUESTS:
                    GT["accept_hex"] = m.hex(); GT["accept_ids"] = list(m[m.index(b"CRANTIME") + 8:])
                    print("GUEST TEST: accept packet", m.hex(), "-> bytes after CRANTIME:", GT["accept_ids"])
                    raw_ = GT["accept_ids"]; X_, lst_ = (raw_[0], raw_[1:]) if raw_ else (0, [])
                    if 0 < X_ < len(lst_):
                        HOST_ID = lst_[0]; GUEST_IDS = lst_[X_ + 1:X_ + 1 + GUESTS]
                        if not os.environ.get("GHOST_CID"): set_identity(lst_[X_])
                        print(f"GUEST TEST: host is id {HOST_ID}, this ghost id {CID} (address {NS:#x}, slot {slot:#x}), guest id(s) {GUEST_IDS}")
                    else: print("GUEST TEST: the accept packet does not fit 'position + id list'; keeping the old rule")
                try:
                    ids = list(m[m.index(b"CRANTIME") + 9:])               # the player ids in the game, ours is the last one
                    # (25 Nov: the 23 Nov rule that sent a ghost given an id past 30 away at once is gone - the 24/7 host game
                    #  runs for hours, hands out ids like 37, and its ghosts play fine with them; with the rule none got in.
                    #  The missions keep their ids low another way: a new host game when the kept one is running out.)
                    if ids and not os.environ.get("GHOST_CID") and not GUEST_IDS and 2 <= ids[-1] <= 30:
                        set_identity(ids[-1]); print(f"the host made this ghost player id {CID} (sender address {NS:#x}, slot {slot:#x})")
                except Exception as e: print("could not read the player id from the accept packet:", e)
            if fl == 0 and len(m) > 20 and m[2] == 0x83:
                s.sendto(hdr(11, 0) + b"\x83" + m[3:11][::-1], dst)       # ping: echo the 8 timestamp bytes reversed
            elif GUESTS and fl == 0 and b"CRANTIME" not in m and m[2:3] != b"\x82" and len(GT["control"]) < 20:
                GT["control"].append(m.hex()); print("GUEST TEST: control message from the host:", m.hex(), m[2:].decode("latin-1")[:60])
            if fl == 3 and len(m) >= 6:
                rel = struct.unpack(">H", m[4:6])[0]
                if rel > host_rel: host_rel = rel; got_rel = True
            if fl == 3 and m[6:8] == b"\xfd\x00" and len(m) > 12:          # the host's session list: fd 00 <index> <key> <value>; index k is player id k+1
                try:
                    h = m[6:]; kl = h[3]; key = h[4:4 + kl]; vl = h[4 + kl]
                    if key == b"playername":
                        names[h[2] + HOST_ID] = h[5 + kl:5 + kl + vl]; SESS_NAME[h[2]] = h[5 + kl:5 + kl + vl]; remap_names()      # index 0 is the host
                    if key == b"team":
                        tv_ = h[5 + kl:5 + kl + vl]
                        if not TEAM_GAME[0]:
                            print("a team game: every player has to pick a team")
                            if spawned_at is None and (slot & 0xFF) == 0x02:
                                # every real player in a team game (red and blue) has its lobby object at ..1f and its player at ..20 (..01 / ..02
                                # in other modes); with ..02 the user's game drew the ghost but never put it on its team
                                slot = (slot & 0xFF00) | 0x20; print(f"team game: the ghost's player is {slot:#x} (lobby object {slot - 1:#x})")
                        TEAM_GAME[0] = True
                        if TEAMS.get(h[2] + HOST_ID) != tv_: print(f"session list: {(names.get(h[2] + HOST_ID) or b'player ' + str(h[2]).encode()).decode(errors='replace')} is on {tv_.decode(errors='replace')}")
                        TEAMS[h[2] + HOST_ID] = tv_; SESS_TEAM[h[2]] = tv_; remap_names()
                    if GUESTS:
                        val = h[5 + kl:5 + kl + vl]; sk = f"{h[2]}: {key.decode(errors='replace')}"
                        if GT["session"].get(sk) != val.decode(errors="replace"):
                            GT["session"][sk] = val.decode(errors="replace"); print(f"GUEST TEST: session list  {sk} = {val!r}")
                        if key == b"playername" and val in (NAME, HOSTNAME) and GT["our_index_from_session"] is None:
                            GT["our_index_from_session"] = h[2]; print(f"GUEST TEST: our name is at index {h[2]} (player id {h[2] + HOST_ID}; the accept made us {CID})")
                except IndexError: pass
            elif GUESTS and fl == 3 and m[6:7] == b"\xfd":
                print("GUEST TEST: other session list form:", m[6:].hex(), m[6:].decode("latin-1")[:60]); GT["control"].append("fd:" + m[6:].hex())
            if fl in (2, 3) and m[6:8] == b"\x7e\x01" and len(m) >= 16:
                # the host's catch-up transfer (7e01 <offset> <total> + a chunk of everything it sent since our last ~ACK). Real clients send "~ACK" on
                # their own every half minute and never get one; ours never did, so from ~30 s on the host re-sent the end of it every second for the rest of the game.
                off, tot = struct.unpack("<II", m[8:16])
                if ACK_ON and off >= tot and now - last_ack_t > 0.5:
                    send_msg(2, b"~ACK"); last_ack_t = now
            if fl in (2, 3):
                bodies = []
                p0 = plain_of(m)
                if p0: bodies.append((p0, None))
                if LEVEL_NAME is None and m[6:22] == b"\xffOLCurrentLevel\\":     # the lobby's server info names the map too (no 0x406 came in the guest test)
                    LEVEL_NAME = m[22:].split(b"\x00")[0].decode(errors="replace") or None
                    if LEVEL_NAME: print("map (from the lobby info):", LEVEL_NAME)
                elif m[6:7] == b"\x84":                                       # a message another client sent us through the host
                    rb = relay_body(m[6:])
                    if rb and GUEST_IDS:
                        rdst = list(m[6:][3:3 + m[8]])
                        if CID not in rdst:                                      # addressed to our guest(s) only: not the main ghost's business
                            guest_rx(rb[0], rb[1], rdst); continue
                        if rb[1] == HOST_ID: rb = (rb[0], None)                 # the host's own messages, addressed to our players (not another client's)
                    if rb: bodies.append(rb); rb[1] is not None and relay_ids.add(rb[1])
                for p, rsrc in bodies:
                    if PENDING_CREATE and rsrc is None and p[:1] == b"\x47" and len(p) >= 17 and struct.unpack("<H", p[13:15])[0] == 0x402 \
                            and struct.unpack("<H", p[9:11])[0] == slot:
                        # the host asks for the new body before we sent it: answer, like a real client (see RESPAWN_WAIT)
                        body_, _dl, revive_ = PENDING_CREATE; PENDING_CREATE.clear()
                        cb = bytearray(body_); cb[26] = 0xef; cb[2:6] = p[5:9]
                        CREATED_AT[0] = time.time(); send_msg(2, bytes(cb)); ANSWERED402.add((None, slot)); last_402_t = now
                        if RELAY and os.environ.get("GHOST_CREATE_RELAY", "1") == "1" and peer_ids(): relay_msg(2, body_, peer_ids())
                        to_all(2, revive_); next_state = now + 0.3
                        UNSEEN["ask"] = time.time(); print("the host asked for this body before its create: answered it (one create, like a real player)")
                        continue
                    if ANSWER402 and p[:1] == b"\x47" and len(p) >= 17 and struct.unpack("<H", p[13:15])[0] == 0x402 and walker is not None and alive \
                            and struct.unpack("<H", p[9:11])[0] == slot and now - last_402_t > 0.3 and ASK402_WAIT > 0 and (time.time() - CREATED_AT[0] < ASK402_WAIT or (rsrc, slot) in ANSWERED402):
                        # (12 Nov, the user's own game recorded: every dark, nameless, frozen ghost at a spawn point was one of these answers.
                        #  The host asks right after a respawn while our create for the same body is on its way; it then got BOTH and made
                        #  two bodies - the one our moves don't drive stood at the spawn point, unlit and unnamed, until that body was
                        #  removed at the next respawn. Asked within 3 s of sending the create: not answered again.)
                        # (12 Nov evening, a hosted game: still dark bodies at spawn points, now that the user plays as a CLIENT there. A client's
                        #  ask comes the long way round (through the host) and can come after 3 s, while our create to it is still on its
                        #  way: two bodies again. Now: no answer for 10 s after the create, and each asker gets at most one per life.)
                        last_402_t = now
                        UNSEEN["ask"] = time.time(); UNSEEN["late"] = time.time() if rsrc is None else UNSEEN["late"]; print(f"{'the host' if rsrc is None else 'player ' + str(rsrc)} asked for this body {time.time() - CREATED_AT[0]:.1f} s after its create: not sent twice")
                    elif ANSWER402 and p[:1] == b"\x47" and len(p) >= 17 and struct.unpack("<H", p[13:15])[0] == 0x402 and walker is not None and alive \
                            and struct.unpack("<H", p[9:11])[0] == slot and now - last_402_t > 0.3:
                        # "send me entity <slot>": the host asks right after a respawn. A real client answers at once with the entity's create (alive flag ef).
                        last_402_t = now
                        cb = bytearray(make_create(walker.x, walker.y, walker.z, GID & 0xFFFF, slot)); cb[26] = 0xef
                        cb[2:6] = p[5:9]                                         # addressed to whoever asked
                        ANSWERED402.add((rsrc, slot))
                        UNSEEN["ask"] = time.time(); print(f"{'the host' if rsrc is None else 'player ' + str(rsrc)} asked for this body {time.time() - CREATED_AT[0]:.1f} s after its create: sent it")
                        if rsrc is None: send_msg(2, bytes(cb))
                        else: relay_msg(2, bytes(cb), [rsrc])
                    if p[:1] == b"\x47" and len(p) >= 30 and struct.unpack("<H", p[13:15])[0] == 0x3fd and (p[25] in (0x4b, 0x4f) or b".nwx" not in p.lower()):
                        # a created OBJECT, not a player (lit dynamite in someone's hand, a thrown stick, an ammo box): never a target
                        NOT_PLAYERS.add(struct.unpack("<H", p[21:23])[0])
                    if p[:1] == b"\x47" and len(p) >= 31 and struct.unpack("<H", p[13:15])[0] == 0x421 and b"DYNAM" in p.upper():
                        BOOMS.append((now, struct.unpack("<3f", p[19:31])))       # a dynamite explosion (anyone's): blows a body it kills away
                        del BOOMS[:-8]; chain_blast(now, BOOMS[-1][1])
                    if p[:1] == b"\x47" and len(p) >= 41 and struct.unpack("<H", p[13:15])[0] == 0x3fd and b"DYNAM" in p.upper():
                        # someone's dynamite: lit in a hand (created with flags 4b01: the in-hand stick), or lying on the map
                        DYN_ENTS[struct.unpack("<H", p[21:23])[0]] = (struct.unpack("<3f", p[29:41]), p[25:27] == b"\x4b\x01"); DYN_SEEN[struct.unpack("<H", p[21:23])[0]] = now
                    if p[:1] == b"\x47" and len(p) >= 57 and struct.unpack("<H", p[13:15])[0] == 0x418 and p[-4:] == b"\x20\x04\x00\x00":
                        DYN_ENTS[struct.unpack("<I", p[5:9])[0] & 0xFFFF] = (struct.unpack("<3f", p[21:33]), p[-8:-6] == b"\xcb\x01")   # (state tail cb01 = still in the hand)
                        if (struct.unpack("<I", p[5:9])[0] & 0xFFFF) in DYN_SEEN: DYN_SEEN[struct.unpack("<I", p[5:9])[0] & 0xFFFF] = now   # (a stick we know: still alive)
                    if p[:1] == b"\x47" and len(p) >= 15 and struct.unpack("<H", p[13:15])[0] in (0x3fd, 0x3f8): note_items(p)
                    if p[:1] == b"\x47" and len(p) >= 21 and struct.unpack("<H", p[13:15])[0] == 0x422:
                        BROKEN_WALLS.add(struct.unpack("<HH", p[17:21])); BROKEN_EDGES.clear(); BROKEN_EDGES.update(broken_edges())
                        print(f"window shot out: sector {struct.unpack('<H', p[17:19])[0]} wall {struct.unpack('<H', p[19:21])[0]} ({len(BROKEN_EDGES)} open windows)")
                    if p[:1] == b"\x47" and len(p) >= 17 and struct.unpack("<H", p[13:15])[0] == 0x3ff:
                        # an entity is gone (a player's old body after respawning, thrown dynamite): not a target any more
                        gone = struct.unpack("<H", p[9:11])[0]
                        if FEED_LOG and MODE_RUN and gone in DYN_ENTS and not DYN_ENTS[gone][1]:      # a thrown stick went off (co-op missions: the vault)
                            try:
                                bp_ = DYN_ENTS[gone][0]; print(f"BLAST {bp_[0]:.1f} {bp_[1]:.1f} {bp_[2]:.1f}")
                                with open(os.path.join(MODE_STATE, f"blast_{MODE_RUN}.txt"), "a") as f_: f_.write(f"{time.time():.2f}|{bp_[0]:.1f}|{bp_[1]:.1f}|{bp_[2]:.1f}\n")
                            except (OSError, Exception): pass
                        players.pop(gone, None); first_seen.pop(gone, None); DYN_ENTS.pop(gone, None); ITEMS.pop(gone, None)
                    if p[:1] == b"\x47" and len(p) >= 19 and p[13:15] == b"\x0a\x04":       # someone's kill message: its sender is the victim
                        km_ = re.match(rb"\$\$\d+\$\$([^$]*)\$\$([^$]*)\$\$", p[17:])
                        if FEED_LOG: print(f"FEED {now:.2f} " + p[17:].split(b"\x00")[0].decode(errors="replace"))   # the kill feed, for the live scoreboard
                        if XP_ON and GHOST_INDEX <= 1: note_player_death(p[17:])
                        if km_ and km_.group(1).rstrip(b"_") == NAME.rstrip(b"_") and km_.group(2) != NAME: taunt_killed(now)
                        if km_ and km_.group(2):
                            vid_ = addr_id(struct.unpack("<I", p[5:9])[0])
                            if vid_ != CID and LEARNED.get(vid_) != km_.group(2):
                                LEARNED[vid_] = km_.group(2); remap_names(); print(f"player id {vid_} is {km_.group(2).decode(errors='replace')} (from their own kill message)")
                    if FEED_LOG and p[:1] == b"\x47" and len(p) >= 19 and p[13:15] == b"\x03\x04":
                        # a player's pose change: 10 = firing, 15 = a punch, stab or throw. Counted as that player's shots (the live
                        # scoreboard's accuracy; a pose is only sent when it changes, so a held trigger counts once: roughly)
                        try:
                            pw_ = struct.unpack("<I", p[5:9])[0] & 0xFFFF; pc_ = struct.unpack("<H", p[17:19])[0]
                            if pw_ != slot and pc_ in (10, 15):
                                pn_ = display_name(addr_id(pw_))
                                if pn_: print(f"PSHOT {now:.2f} " + pn_.decode(errors="replace"))
                        except Exception: pass
                    if p[:1] == b"\x47" and len(p) >= 19 and p[13:15] == b"\xd6\x07":
                        dA_, dB_, dC_ = struct.unpack("<III", p[1:13])
                        if (dC_ >> 11) == 1 and (dC_ & 0x7ff) == dA_:   # the host's door event (someone's use - ours too: it runs our "use" and answers)
                            if p[17] in (16, 32): door_used(dA_, now, " by this ghost" if (dB_ & 0xFFFF) == slot else f" by {display_name((dB_ >> 11) - 1).decode(errors='replace') if display_name((dB_ >> 11) - 1) else hex(dB_)}")
                            elif p[17] in (4, 8):
                                door_learn(dA_, dB_ & 0xFFFF, now)
                                door_passed(dA_, (dB_ >> 11) - 1, now)
                    if p and p[:1] == b"\x47" and len(p) >= 33:
                        ty = struct.unpack("<H", p[13:15])[0]
                        if ty == 0x418 and len(p) >= 57:
                            who = struct.unpack("<I", p[5:9])[0] & 0xFFFF            # the sender slot of the state
                            pos3 = struct.unpack("<3f", p[21:33])
                            if isinstance(rsrc, int) and rsrc > 1 and (who >> 11) > 1 and NS_OWNER.get(who >> 11) != rsrc:
                                if (who >> 11) - 1 != rsrc: print(f"player {rsrc}'s bodies are numbered {who & 0xF800:#x}.. (not the usual {0x800 * (rsrc + 1):#x}): hits go to player {rsrc}")
                                NS_OWNER[who >> 11] = rsrc
                            if who in NOT_PLAYERS or p[-4:] == b"\x20\x04\x00\x00":     # an object's state (dynamite: tail 20040000), not a player's
                                NOT_PLAYERS.add(who); players.pop(who, None); continue
                            if who != slot and abs(pos3[1]) < 1000.0:
                                pv = players.get(who)
                                if pv and 0.05 < now - pv[0] < 1.5:                       # its velocity (for leading a dynamite throw)
                                    nv = ((pos3[0] - pv[1][0]) / (now - pv[0]), (pos3[2] - pv[1][2]) / (now - pv[0])); ov = VEL.get(who, nv)
                                    VEL[who] = (ov[0] * 0.5 + nv[0] * 0.5, ov[1] * 0.5 + nv[1] * 0.5)
                                players[who] = (now, pos3, p[56] == 0x41)             # (time, position, dying)
                                if len(p) >= 51:                                        # its own velocity (states are 0.15 s apart now: better than the difference)
                                    rv_ = struct.unpack("<3f", p[39:51])
                                    if all(abs(v_) < 200.0 for v_ in rv_): VEL[who] = (rv_[0], rv_[2])
                                ch_ = (struct.unpack("<I", p[17:21])[0] >> 16) & 0xFF
                                if ch_ in (0, 1, 3): POSE[who] = ch_                    # stand / walk / crouch (a shot's pose 10 keeps the last one)
                                first_seen.setdefault(who, now)
                                if addr_id(who) not in SEEN_IDS: SEEN_IDS.add(addr_id(who)); remap_names()
                            if who != slot and rsrc is None:                      # (another ghost's moves come relayed: they are targets, not "the host")
                                host_pos = pos3
                                if seen_host is None: seen_host = host_pos; seen_host_t = now
                        if ty == 0x3fd and len(p) >= 23 and host_slot_seen is None:
                            host_slot_seen = struct.unpack("<H", p[21:23])[0]; host_slot = host_slot_seen
                        if ty == 0x3f7 and welcome_id is None and now - (send_t0 or now) < 3.0:
                            mw = re.search(rb"([A-Za-z0-9+/]{11}=)\x00", p)
                            if mw:
                                try: wid = struct.unpack("<Q", base64.b64decode(mw.group(1)))[0]
                                except Exception: wid = None
                                if wid == CID: welcome_id = CID; print(f"the host welcomed the ghost as player id {wid}"); gid_write()
                        if ty == 0x406 and LEVEL_NAME is None:
                            mm = re.search(rb"([A-Za-z0-9_]+)\.RCM", p)
                            if mm: LEVEL_NAME = mm.group(1).decode()
                        if ty == 0x407:
                            last_spawn = struct.unpack("<3f", p[21:33])
                            if SPAWN_PEND and not HOST407: HOST407[:] = list(last_spawn)
                            if spawned_at is not None and not host_acked: host_acked = True; print("the host answered the ghost's spawn: it is registered as a player")
                            if spawn_pos is None: spawn_pos = last_spawn; print("host spawn point:", spawn_pos)
                        if ty == 0x413:
                            # The respawn order is BROADCAST to every client (real game, netcap: all three bots got each one, only the dead player answered). It carries the dead player's model
                            # name, so it is ours only if the model matches. It also fires when the HOST player dies (the user): the ghosts used to "die" and respawn over and over.
                            if MODEL.upper().encode() in p[17:].upper():
                                respawn_req = p[17:]                             # spawn info + model name for our respawn echo
                                # (0x413 is the host's answer to a respawn, not an order: off unless GHOST_413DEATH=1)
                                if os.environ.get("GHOST_413DEATH", "0") == "1" and alive and walker is not None and hp <= HP * 0.35 and now - last_hit_t < 6.0:      # the host counted the ghost dead a moment before our own tally did: it vanished for everyone, stop shooting
                                    alive = False; died_at = now - 2.0; print("the host says the ghost is dead (respawn order for its model, health nearly gone)")
                                    death_notice()
                                    if DIE_WAV: send_sound(sound_msg(slot, DIE_WAV))
                                    if BODIES:
                                        for bm in body_msgs(walker.x, walker.y, walker.z): send_msg(2, bm)
                        if ty == 0x7d1 and len(p) >= 59 and alive and walker is not None and struct.unpack("<H", p[1:3])[0] == slot:
                            kind_ = struct.unpack("<H", p[17:19])[0]
                            # its kick (the game's rule, kick_vel): momentum, the 1.0, and the direction words - for every kind (a blast's
                            # direction is from where it went off)
                            mom_, f2_ = struct.unpack("<f", p[27:31])[0], struct.unpack("<f", p[23:27])[0]
                            yw_, pw_ = struct.unpack("<HH", p[31:35])
                            if not (0.0 <= mom_ < 100000.0): mom_ = 0.0
                            if not (0.0 <= f2_ <= 10.0): f2_ = 1.0
                            LAST_HIT.update(t=now, mom=mom_, f2=f2_, yaw=yw_, pitch=pw_, kind=kind_, src=struct.unpack("<H", p[5:7])[0])
                            KICK[:] = [now, kick_vel(mom_, f2_, yw_, pw_)] if mom_ > 0 else []
                            take_damage(struct.unpack("<f", p[19:23])[0], struct.unpack("<H", p[5:7])[0], now, blast=(kind_ == 4))
        if got_rel: ack()
    if GUESTS and accepted and not GT_DONE[0] and now - send_t0 > GUEST_REPORT_AT: guest_report(f"{GUEST_REPORT_AT:.0f} s after the accept")
    if accepted:
        el = now - send_t0
        if next_ack is None: next_ack = now + ACK_EVERY
        elif ACK_ON and now >= next_ack:                     # "~ACK": real clients send it every half minute or so; without it the host keeps re-sending everything (see 7e01 above)
            send_msg(2, b"~ACK"); last_ack_t = now; next_ack = now + ACK_EVERY
        while hi < len(hand) and hand[hi]["t"] <= el:
            hb = bytearray(ns_fix(with_cid(with_model(bytes.fromhex(hand[hi]["b"])).replace(b"\x0bGhostBot_01", bytes([len(NAME)]) + NAME).replace(b"GhostBot_01", NAME), welcome_id if (hi >= 3 and welcome_id) else None)))
            if hi == 8: hb[22:24] = struct.pack("<H", slot - 1)                                  # this message names the player's slot (-1): the recording's 0x1801 made every ghost "slot 1"
            send_msg(hand[hi]["f"], bytes(hb)); hi += 1      # the recorded handshake carries the player name too (the host takes it from there)
            if RELAY and len(hb) >= 16 and hb[:2] == b"\x00\x47" and struct.unpack("<H", hb[14:16])[0] == 0x3f7 and peer_ids():
                relay_msg(hand[hi - 1]["f"], bytes(hb), peer_ids())                # player info: real clients relay it to every other client too
            if hi == 2 and GUESTS and GUEST_FD in ("a", "b"):   # just after our own "fd 00 playername <name>": one per guest (the form with the local index is a guess)
                for k_, g_ in enumerate(GUEST_NAMES, 1):
                    send_msg(3, (bytes([0xfd, k_]) if GUEST_FD == "a" else bytes([0xfd, 0, k_])) + b"\x0aplayername" + bytes([len(g_)]) + g_)
                print(f"GUEST TEST: sent the guests' session-list names (form {GUEST_FD})")
        if hi >= len(hand):
            if GUEST_IDS: guest_tick(now, spawn_pos if spawned_at is not None else None)
            if spawn_wait_from is None: spawn_wait_from = now
            if spawned_at is None and spawn_pos is None and now - spawn_wait_from > (1.0 if WAIT_HOST else 10) and (not WAIT_HOST or seen_host is not None):
                sp0 = pick_start(near=seen_host) if USE_START else None
                if sp0: spawn_pos = sp0; print("no spawn message; using one of the map's STARTPOS points")
                elif seen_host is not None and math.hypot(seen_host[0] - REC_SPAWN[0], seen_host[2] - REC_SPAWN[1]) < 250:
                    spawn_pos = (REC_SPAWN[0], -0.5, REC_SPAWN[1]); print("no spawn message; map matches the recording, using the recorded spawn point")
                elif now - spawn_wait_from > 40 and not WAIT_HOST:
                    print("no spawn message and the host's player is far from the recorded spawn (different map?); not creating the ghost"); break
            if spawned_at is None and spawn_pos is not None and not SPAWN_PEND and (WAIT_HOST is False or seen_host_t is None or now - seen_host_t >= STAGGER):
                sp1 = pick_start(near=seen_host) if (USE_START and not os.environ.get("GHOST_SPAWN")) else None
                if sp1: spawn_pos = sp1; print(f"ghost spawns at a STARTPOS: {sp1[0]:.1f}, {sp1[2]:.1f}")
                if os.environ.get("GHOST_SPAWN"):                  # GHOST_SPAWN=x,y,z: start somewhere else on the map (e.g. one of the host's own spawn points)
                    spawn_pos = tuple(float(v) for v in os.environ["GHOST_SPAWN"].split(","))
                sector_of(*spawn_pos)                      # load the map data now (may take a moment) before the ghost appears
                if TEAM_GAME[0] and MY_TEAM[0] is None:            # a team game: pick a team first (the user's game and the bots do it here)
                    MY_TEAM[0] = pick_team(); tv_ = b"SERVER_TEAM_" + MY_TEAM[0].upper().encode()
                    send_msg(3, b"\xfd\x00\x04team" + bytes([len(tv_)]) + tv_)
                    print(f"picked the {MY_TEAM[0]} team")
                for x in D["spawn"][:2]:
                    mb = bytearray(ns_fix(bytes.fromhex(x["b"])))
                    if x is D["spawn"][0]:
                        mb[10:12] = struct.pack("<H", slot - 1)      # the handshake carries slot-1
                        if TEAM_GAME[0]: mb[10] = 0x1f               # (a team game's lobby object)
                    if x is D["spawn"][1]: mb[-1] = team_byte()
                    send_msg(x["f"], bytes(mb))
                    if TEAM_GAME[0] and x is D["spawn"][0] and RELAY: relay_msg(x["f"], bytes(mb), peer_ids())   # (real clients relay this one to the others too)
                HOST407.clear(); SPAWN_PEND[:] = ["join", now]
            if spawned_at is None and SPAWN_PEND and SPAWN_PEND[0] == "join" and (WAIT407 <= 0 or HOST407 or now - SPAWN_PEND[1] > WAIT407):
                if FIXED_SPAWN: spawn_pos = FIXED_SPAWN; print(f"the ghost's own spawn point (GHOST_SPAWN): {spawn_pos[0]:.0f},{spawn_pos[2]:.0f}")
                elif HOST407: spawn_pos = tuple(HOST407); print(f"the host chose the spawn point: {spawn_pos[0]:.0f},{spawn_pos[2]:.0f}"); spawn_pos = avoid_blocked(spawn_pos)
                elif WAIT407 > 0: print(f"no spawn point from the host within {WAIT407:.1f} s: the ghost's own pick")
                SPAWN_PEND.clear(); HOST407.clear()
                spawn_pos = settle(*spawn_pos)
                REDELETES.extend((now + d_, slot - 1) for d_ in JOIN_REDELETE)   # (the handshake's stand-in body: see JOIN_REDELETE)
                send_create(make_create(*spawn_pos, slot=slot))
                walker = new_walker(*spawn_pos); next_state = now; spawned_at = now
                print(f"ghost entity {GID:#x} created at {spawn_pos[0]:.0f},{spawn_pos[2]:.0f}; walking the route {ROUTE}")
            if spawned_at is not None:
                if now >= next_state and not PENDING_CREATE and not SPAWN_PEND:     # (nothing while a respawn is under way)
                    if alive and waiting_for_player():         # nobody to play with yet: stand still, do nothing
                        st = make_state(walker.x, walker.y, walker.z, walker.yaw, 0, 0.0, 0.0, False); next_state = now + 1.0
                    elif alive:
                        st, gap = walker.step(now); next_state = now + gap
                        fall_check(now)
                        pit_return(now)
                        unseen_check(now)
                        if HOSTAGE: arm_check(now)
                        bad_spawn_check(now)
                        if isinstance(walker, FightWalker): st = lag_state(now, st)
                    else:                                       # dying: stand still with the "dying" flag set
                        # like a real client: the dying states quickly while it falls (0.75 s), then once a second
                        flying = bool(FLY) and not FLY.get("landed")
                        dt = 0.08 if flying else (0.15 if now - died_at < 0.75 else 1.0)
                        fv = fly_step(dt) if flying else (0.0, 0.0, 0.0)
                        st = make_state(walker.x, walker.y, walker.z, walker.yaw, 0, fv[0], fv[2], False, dying=True, vy=fv[1]); next_state = now + dt
                    if st is not None: send_state(st)
                    if THROW_RESET[0] is not None and time.time() >= THROW_RESET[0]:
                        THROW_RESET[0] = None
                        if LAST_CHOR[0] is not None: CHOR_MSGS.append(LAST_CHOR[0])          # the throw is over: back to standing / walking
                    for c in CHOR_MSGS:                         # the pose change, the way real clients send it (0x403, A = slot - address, code = choreography)
                        to_all(2, b"\x00\x47" + struct.pack("<III", slot - NS, NS, slot) + struct.pack("<H", 0x403) + b"\x00\x00" + struct.pack("<H", c))
                    CHOR_MSGS.clear()      # real clients send their moves to every other client too (through the host): the other ghosts see and fight this one
                if alive and isinstance(walker, FightWalker) and walker.F.tired_snd:
                    walker.F.tired_snd = False; print(f"out of breath: walking until {STAMINA_RESUME:.0%} of the stamina is back")
                    if TIRED_WAV: send_sound(sound_msg(slot, TIRED_WAV))
                if SPACING > 0 and alive and isinstance(walker, FightWalker) and now >= SPACE_T[0]:
                    SPACE_T[0] = now + 0.15
                    for who_, pv_ in list(players.items()):
                        if pv_[2] or now - pv_[0] > 1.0 or not is_friend(who_): continue
                        fp_ = now_pos(who_, pv_); dx_, dz_ = walker.x - fp_[0], walker.z - fp_[2]; d_ = math.hypot(dx_, dz_)
                        if d_ < SPACING and abs(walker.y - pv_[1][1]) < 6.0:
                            if d_ < 0.05: dx_, dz_ = random.uniform(-1, 1), random.uniform(-1, 1)
                            walker.F.push(dx_, dz_, 0.9 * walker.F.walk * (1.0 - d_ / SPACING))      # (in step with its own speed: a slow walker isn't shoved along fast)
                    if host_pos is not None and abs(walker.y - host_pos[1]) < 6.0:   # (and never run INTO the one it is punching: body radius 1.5 each)
                        dx_, dz_ = walker.x - host_pos[0], walker.z - host_pos[2]; d_ = math.hypot(dx_, dz_)
                        if d_ < 3.5: walker.F.push(dx_ or 0.1, dz_, 0.9 * walker.F.walk * (1.0 - d_ / 3.5))
                if spawned_at is not None:
                    WALKER_REF[0] = walker; pos_report(now)
                if MODE_RUN and spawned_at is not None:
                    reach_report(now); punish_step(now); heal_step(now, walker)
                if MOANS and alive and now >= NEXT_MOAN[0]:
                    mw_ = random.choice([m_ for m_ in MOANS if m_ != LAST_MOAN[0]] or MOANS); LAST_MOAN[0] = mw_
                    NEXT_MOAN[0] = now + random.uniform(*MOAN_GAP)
                    send_sound(sound_msg(slot, mw_))      # the plain player-sound form (plays once): the 01 form (fuse) LOOPS - every groan kept going and they piled into a roar
                if alive and isinstance(walker, FightWalker) and walker.water_events and SWIM_SND:
                    for wv in walker.water_events: send_sound(sound_msg(slot, wv))
                    walker.water_events = []
                # The knife is wound up before it's thrown (KNIFE_WINDUP): the decision to throw starts the wind-up, held as long as the
                # throw's distance needs (knife_power), and the throw itself goes when it's let go - at whoever it was for, as far as the
                # hold takes it (they ran out of its reach meanwhile: it falls short). Died, switched weapons or lost them: no throw.
                knife_power_now = None; knife_short = False
                if KNIFE_WIND[0] is not None:
                    kw = KNIFE_WIND[0]
                    if not alive or walker is not kw["w"] or walker.load.cur != "knife" or host_pos is None or target_slot != kw["tgt"]:
                        KNIFE_WIND[0] = None
                    elif now >= kw["at"]:
                        KNIFE_WIND[0] = None; walker.fire = kw["ev"]; knife_power_now = kw["power"]
                        kd_ = math.hypot(host_pos[0] - walker.x, host_pos[2] - walker.z); kdy_ = host_pos[1] + KNIFE_MID - walker.y - KNIFE_Y0
                        if knife_drop(kd_, kdy_, knife_power_now) > KNIFE_MID - 0.5: knife_short = True                  # (they ran out of its reach)
                        if walker.fire == "hit" and knife_short: walker.fire = "miss"
                    else: walker.fire = None                         # (still winding up: nothing else fires)
                elif KNIFE_WINDUP and alive and isinstance(walker, FightWalker) and walker.fire and host_pos is not None and walker.load.cur == "knife":
                    kd_ = math.hypot(host_pos[0] - walker.x, host_pos[2] - walker.z); kdy_ = host_pos[1] + KNIFE_MID - walker.y - KNIFE_Y0
                    kp_ = knife_power(kd_, kdy_)
                    hold_ = 0.0 if kp_ <= 0.5 else min(1.0, kp_ + random.uniform(0.0, 0.08))   # (a tap gives 0.5; a little over what's needed)
                    KNIFE_WIND[0] = dict(at=now + KNIFE_WIND_T + hold_, ev=walker.fire, power=max(0.5, hold_), tgt=target_slot, w=walker)
                    walker.F.next_fire = max(walker.F.next_fire, KNIFE_WIND[0]["at"] + KNIFE_FOLLOW)
                    walker.fire = None
                if KAMI and alive and walker is not None and host_pos is not None and math.hypot(host_pos[0] - walker.x, host_pos[2] - walker.z) <= KAMI_TRIGGER \
                        and abs(host_pos[1] - walker.y) < 8.0:
                    print("the present goes off next to its target"); take_damage(9999.0, slot, now, blast=True)
                if KAMI and walker is not None: walker.fire = None                # (a present has no weapon)
                # (17 Nov, the user: "have Santa throw presents and shoot a slow style pistol at the same time - he needs to feel tougher".
                #  GHOST_SIDEARM: a second gun on its own slow clock, fired whenever the target's in sight, presents or not.)
                if SIDEARM and alive and not PENDING_CREATE and isinstance(walker, FightWalker) and host_pos is not None and now >= SIDE_NEXT[0] \
                        and getattr(walker.F, "los_cache", False):
                    sd_ = math.hypot(host_pos[0] - walker.x, host_pos[2] - walker.z)
                    if sd_ <= SIDE_RANGE:
                        SIDE_NEXT[0] = now + SIDE_GAP * (random.uniform(0.95, 1.1) if SIDE_MAG else random.uniform(0.85, 1.2))
                        if SIDE_MAG:
                            SIDE_LEFT[0] -= 1
                            if SIDE_LEFT[0] <= 0:
                                SIDE_LEFT[0] = SIDE_MAG; SIDE_NEXT[0] = now + SIDE_RELOAD
                                try: send_sound(sound_msg(slot, WEAPONS[SIDEARM].get("rsnd", "PRELOAD.wav").encode()))
                                except Exception: pass
                        stgt = target_slot if target_slot is not None else host_slot; stid = addr_id(stgt)
                        shit = random.random() < max(0.3, 0.85 - sd_ / 220.0)          # (a steady hand: most shots land up close)
                        sdmg = SIDE_DMG * DMG_MULT
                        SHOOT_UNTIL[0] = time.time() + 0.4
                        for b in fire_burst(slot, stgt, host_pos, sector_of(*host_pos) or 0, hit_it=shit, dmg=sdmg, kind=HIT_KIND.get(SIDEARM, 1),
                                            f3_override=hit_momentum(SIDEARM, sdmg)):
                            if b[13:15] == b"\xd1\x07" and stid != 1:
                                if RELAY: relay_msg(2, b"\x00" + b, [stid])
                            elif b[13:15] == b"\xd1\x07": send_msg(2, b"\x00" + b)
                            else: to_all(2, b"\x00" + b)
                        send_sound(sound_msg(slot, WEAPONS[SIDEARM]["snd"].encode()))
                        shots += 1; print(f"sidearm shot ({SIDEARM}): {'hit' if shit else 'miss'} @{sd_:.0f}")
                if alive and not PENDING_CREATE and isinstance(walker, FightWalker) and walker.fire and host_pos is not None:
                    ev, walker.fire = walker.fire, None
                    if walker.load.cur not in SWING + ("dynamite", "snowball") and not NOFLASH: SHOOT_UNTIL[0] = time.time() + 0.5      # (throws: the throw pose, not the gun's)
                    tgt = target_slot if target_slot is not None else host_slot; tid = addr_id(tgt)
                    wpn = WEAPONS[walker.load.cur]; wdist = math.hypot(host_pos[0] - walker.x, host_pos[2] - walker.z)
                    wdmg = wpn["dmg"] * DMG_MULT
                    if walker.load.cur == "pistol" and walker.load.fan: wdmg = FAN["dmg"] * DMG_MULT          # (DAMAGE_2)
                    if walker.load.cur == "stab": wdmg = WEAPONS["stab"]["dmg"] * random.uniform(0.97, 1.03)     # (the user's Chief stabbed for 11.8-12.2: no character factor)
                    if walker.load.cur == "fist":
                        # punches, measured on the user's own Mary (7 Nov): the slow punch (middle button) did 11.9-12.2 = her DAMAGE_1 4.0
                        # x 3, the rapid one 6.4-6.8 = DAMAGE_2 2.3 x 3 (one glancing 2.5). Every character's own fist file x 3.
                        slow = random.random() < 0.5
                        d1, d2 = FIST_DMG.get(CHAR, (1.0, 0.3))
                        wdmg = (d1 if slow else d2) * 3.0 * random.uniform(0.95, 1.05)
                        walker.F.base_gap = 0.6 if slow else 0.2              # (slow punches 0.6 s apart; the held button 0.2 s, as measured)
                    if wpn.get("falloff"): wdmg *= max(0.3, 1.0 - wdist / wpn["range"])        # shotguns: the pellets spread with distance
                    if walker.load.cur == "dynamite":
                        # lit now, cooked in the hand and thrown so it lands where the target will be just before it goes off (update_held)
                        if not HELD and now - walker.load.cur_since < TNT_SWITCH:
                            walker.F.next_fire = now + 0.1                       # still drawing the TNT: light it as soon as it's out
                        elif not HELD and light_dynamite(walker, tgt, now):
                            rs = walker.load.fired(now); shots += 1; print(f"ghost lit dynamite for {display_name(tid).decode(errors='replace') if display_name(tid) else hex(tgt)} @{wdist:.0f} ({walker.load.ammo['dynamite']} left)")
                        continue_fire = False
                    else: continue_fire = True
                    # (a stab is already deadly: the user's own stabs did 10.8-13.1, thrown knives 3.7-4.4 - itknife.itm says 4.0 for both,
                    #  the game makes the stab about three times that)
                    if walker.load.cur in ("fist", "stab") and ev == "hit" and (abs(host_pos[1] - walker.y) > MELEE_DY or math.dist(host_pos, (walker.x, walker.y, walker.z)) > wpn["range"] + 1.0):
                        ev = "miss"                                         # a punch / stab only reaches someone at about its own height (it hit the user standing well above its head)
                    if walker.load.cur == "knife" and ev in ("hit", "miss") and KNIFE_CHANCE_ON and not knife_short:
                        ev = "hit" if random.random() < knife_hit_chance(wdist, walker.F.p.get("level")) else "miss"
                    if walker.load.cur == "knife" and ev == "hit": walker.rush_until = now + 3.0       # it spun them round: close the gap for the stab
                    knife_eta = throw_knife(walker, host_pos, ev == "hit", now, power=knife_power_now) if (continue_fire and walker.load.cur == "knife") else None
                    if continue_fire and walker.load.cur == "snowball" and PROJ_MODEL:          # the snowball's hit lands when the snowball gets there
                        try: knife_eta = shoot_proj(walker, host_pos, now, ev == "hit")
                        except Exception as e_: print("snowball:", e_)
                    for b in (fire_burst(slot, tgt, host_pos, sector_of(*host_pos) or 0, hit_it=(ev == "hit"), dmg=wdmg, spin=wpn.get("spin"),
                                         pose=(0x0f if THROWPOSE else 0x0a) if (walker.load.cur in SWING + ("snowball",) or NOFLASH) else 0x0a, kind=HIT_KIND.get(walker.load.cur, 1),
                                         # a punch's third value follows its damage (the user's: 12.2 -> 540, 6.4 -> 270, 2.5 -> 90)
                                         f3_override=(max(90.0, math.floor(wdmg / 2.0) * 90.0) if walker.load.cur == "fist" else hit_momentum(walker.load.cur, wdmg))) if continue_fire else []):      # (15: punches, stabs, throws)
                        if walker.load.cur in SWING + ("snowball",) and b[13:15] == b"\x03\x04" and THROWPOSE: THROW_RESET[0] = time.time() + 0.3
                        if knife_eta is not None and b[13:15] != b"\x03\x04":
                            LATER.append((knife_eta, b, tid)); continue      # a thrown knife's hit and mark land when the knife gets there
                        if b[13:15] == b"\xd1\x07" and tid != 1:
                            if RELAY: relay_msg(2, b"\x00" + b, [tid])           # a hit on another client goes to that client only (real game: 84 <shooter> 01 <victim>, A = victim's slot)
                        elif b[13:15] == b"\xd1\x07": send_msg(2, b"\x00" + b)     # a hit on the host's player: straight to the host (real clients too)
                        else: to_all(2, b"\x00" + b)                                # the pose (0x403) and the impact mark (0x40e): to everyone
                    if continue_fire:
                        send_sound(sound_msg(slot, (wpn["snd"] if walker.load.cur in ("stab", "fist") else (os.environ.get("GHOST_SHOTSND") or wpn["snd"])).encode()))
                        if PROJ_MODEL and walker.load.cur in BOSS_ARMS and walker.load.cur not in ("dynamite", "snowball", "stab", "fist"):
                            try: shoot_proj(walker, host_pos, now, ev == "hit")
                            except Exception as e_: print("projectile:", e_)
                        if ev == "hit" and walker.load.cur in ("fist", "stab"):
                            # the blow landing: a punch CONNECT.wav (the user's own punches: THROW.wav swing, CONNECT.wav on the hit);
                            # a stab jab.wav (the user: fists CONNECT, knife stabs jab)
                            send_sound(sound_msg(slot, b"CONNECT.wav" if walker.load.cur == "fist" else b"jab.wav"))
                        rs = walker.load.fired(now)
                        if rs:   # reloading: the game's own sounds, one per round loaded (WEAPONS: clicks)
                            c0, c_gap, c_n = WEAPONS.get(walker.load.cur, {}).get("clicks", (0.4, 0.2, 1))
                            if walker.load.cur == "pistol" and walker.load.fan: c0 -= _P_FIRE - FAN["fire"]
                            RELOAD_SND[:] = [[time.time() + c0 + c_gap * k, rs] for k in range(max(1, c_n))]
                        tn = display_name(tid)
                        shots += 1; LAST_SHOT_T[0] = now; print(f"ghost shot {shots} ({walker.load.cur}{' fanned' if walker.load.cur == 'pistol' and walker.load.fan else ''}) at {tn.decode(errors='replace') if tn else hex(tgt)}: {ev} @{wdist:.0f}" + (" (reloading)" if rs else ""))
                update_held(now); update_dynamite(now); update_knives(now); update_projs(now); death_pending(now)
                while RELOAD_SND and now >= RELOAD_SND[0][0]:
                    send_sound(sound_msg(slot, RELOAD_SND[0][1].encode())); RELOAD_SND.pop(0)
                if alive and isinstance(walker, FightWalker) and walker.load.bags > 0 and hp <= HP * 0.4 and now >= next_bag:
                    walker.load.bags -= 1; hp = min(HP, hp + MEDBAG_HEAL); next_bag = now + 3.0
                    pickup_sound(b"cool.wav")
                    print(f"used a med bag: health {hp:.1f}/{HP:.0f} ({walker.load.bags} left)")
                if FIRE and not FIGHT and alive and host_pos is not None and now >= next_fire and now - spawned_at > 5:
                    for b in fire_burst(slot, host_slot, host_pos, sector_of(*host_pos) or 0): send_msg(2, b"\x00" + b)
                    shots += 1; next_fire = now + FIRE_GAP; print(f"ghost fired shot {shots} at the host's player")
                if not alive and DROP and not dropped:
                    dropped = True                                       # real clients announce the item they drop where they die: 0x421 + "PDYNAM.itm"
                    d_sec = sector_of(walker.x, walker.y, walker.z) or 0
                    send_msg(2, b"\x00" + bytes.fromhex("47") + struct.pack("<III", 0, 0x00180000 | NS, 0) + struct.pack("<H", 0x421) + b"\x00\x00" + struct.pack("<H", d_sec & 0xFFFF) + struct.pack("<3f", walker.x, walker.y + 25.0, walker.z) + b"PDYNAM.itm\x00")
                    print("ghost dropped an item where it died")
                if hit_fx:
                    hit_fx_kind = hit_fx; hit_fx = False
                    if HITFX and alive:                                  # hit but alive: what a real victim's game sends: blood where it was hit, a flinch, and it is pushed back a little
                        wsec = sector_of(walker.x, walker.y, walker.z) or 0
                        to_all(2, b"\x00\x47" + struct.pack("<III", 0, NS, NS) + struct.pack("<H", 0x40e) + b"\x00\x00\x00\x00" + struct.pack("<H", wsec & 0xFFFF) + b"\x01\x00" + struct.pack("<3f", walker.x, walker.y + 6.5, walker.z))
                        # (no 0x403 here: it sent choreography 15, which no character has - the game drew NOTHING for the ghost, and it could not be
                        #  hit, until its next shot changed the pose again. Real clients' 0x403 only ever carry 0, 1, 3, 10, 21.)
                        blast = any(now - t < 0.6 and math.dist(bp, (walker.x, walker.y + 2.5, walker.z)) <= 60.0 for t, bp in BOOMS)
                        if hit_fx_kind == "blast": blast = True
                        if HIT_WAV and not blast: send_sound(sound_msg(slot, HIT_WAV))      # the bullet / blade hit sound (not for a blast)
                        shooter = players.get(last_shooter)
                        src_pos = shooter[1] if shooter else host_pos             # pushed away from whoever fired
                        crouch_src = POSE.get(last_shooter) == 3
                        if isinstance(walker, FightWalker):
                            knock_hit(now)                                       # the hit's own kick, the game's rule (none when it carried no momentum)
                        elif src_pos is not None:
                            dx, dz = walker.x - src_pos[0], walker.z - src_pos[2]; dd = math.hypot(dx, dz) or 1.0
                            for fr in (1.0, 0.5, 0.25):
                                kx, kz = walker.x + dx / dd * KNOCK * fr, walker.z + dz / dd * KNOCK * fr
                                if can_move(walker.x, walker.y, walker.z, kx, kz):
                                    walker.x, walker.z = kx, kz
                                    ks = sector_of(kx, walker.y, kz, prefer=LAST_SEC[0])
                                    if ks is not None and LVL is not None: walker.y = LVL.floor_at(ks, kx, kz)      # (on a slope the floor height changes)
                                    break
                            rx, rz = ROUTE[walker.k % len(ROUTE)]; walker.sx = walker.x - rx; walker.sz = walker.z - rz   # the route now starts from where it was pushed, so it stays there
                            walker.pause_until = max(walker.pause_until, now + 1.5)
                if not alive and QUIET_DEATH[0]: death_snd = True                  # (the watchdog's quiet respawn: no death message)
                if not alive and DEATHSND and not death_snd and now - died_at > 0.75:
                    death_snd = True                                      # what real clients send 0.77 s after dying (0x40c, value 0x51): the others' games play the death from it (guess, from the captures)
                    # (12 Nov, a hosted game: this is the same 0x40c "use" message, reach 5.0 - the host traced it from the body and swung the
                    #  saloon door shut each time a ghost died by it. Near a door it is not sent.)
                    near_door = LVL is not None and walker is not None and any(math.hypot(q["x"] - walker.x, q["z"] - walker.z) < 8.0 for q in (LVL.panels or []))
                    if near_door: print("ghost died by a door: no death message (the game would take it as a door press)")
                    else:
                        send_msg(2, b"\x00\x47" + struct.pack("<III", 0x800, slot, slot) + struct.pack("<H", 0x40c) + bytes.fromhex("0000510000000000a040"))
                        print("ghost sent its death message")
                if alive: dropped = False; death_snd = False; QUIET_DEATH[0] = False
                if not alive and not SPAWN_PEND and now - died_at > dead_time(now) + RESPAWN_LAG:     # (DEAD_TIME: see there)
                    lives += 1; prev_slot = slot; slot = next_life_slot(slot)
                    pos = (pick_start(avoid=(walker.x, walker.y, walker.z), near=host_pos or seen_host) if USE_START else None) or last_spawn or spawn_pos
                    t6 = bytearray(ns_fix(with_model(bytes.fromhex(RESP["out_3f6"][1])))); t6[10:12] = struct.pack("<H", slot if TEAM_GAME[0] else prev_slot)
                    # where we respawn: (choreography 21 << 16 | sector), x, y, z, our model - a real client sends its own spawn point here and the
                    # host echoes it to everyone (0x413). The ghosts sent the recording's (sector 75 at 457, 3, 404) for every respawn.
                    # (13 Nov 12:45, counted in the user's game: every standing corpse was at a point named in one of these requests, and
                    #  every point named often had several. The game leaves the old body's corpse at the point in the request. So the
                    #  request now names where the body really lies (as it fell); the spawn point comes from the host anyway (WAIT407).
                    #  GHOST_REQ_AT_SPAWN=1: the old way, the spawn point.)
                    cpos = pos if os.environ.get("GHOST_REQ_AT_SPAWN") == "1" else (walker.x, walker.y, walker.z)
                    # (16 Nov, the user: "more than 2 of these extra ghost bodies but only 2 were in the game ... can you just remove the
                    #  ghost dead bodies from the game entirely". The nameless standing elves are the corpses the other games make at the
                    #  point in this request (no network number: nothing can take them away later). Now that point is CORPSE_DROP units
                    #  under the floor where the ghost died, out of sight. The ghost's own body still falls and goes 0.3 s after this
                    #  request. GHOST_CORPSE_DROP=0: the old way.)
                    rs = sector_of(*cpos)                               # (the sector where it really lies)
                    if CORPSE_DROP > 0: cpos = (cpos[0], cpos[1] - CORPSE_DROP, cpos[2])
                    t6 = t6[:18] + struct.pack("<I", (0x15 << 16) | ((rs if rs is not None else 0) & 0xFFFF)) + struct.pack("<3f", *cpos) + MODEL.upper().encode() + b"\x00"
                    # the body stays: the old player entity is no longer deleted at once (a real client deletes it; then the body vanished as the
                    # ghost respawned 3 s later). Only the oldest beyond GHOST_KEEP_BODIES bodies is removed.
                    BODIES_LEFT.append(prev_slot)
                    # (13 Nov 20:05, the user's screenshot from the server: the corpses now stood where the ghosts died - but STANDING.
                    #  The game makes the corpse from the old body named in the respawn request; with the old body already removed it had no
                    #  dead pose to copy and drew the figure upright. So the old body now stays until the request is handled and is removed
                    #  REMOVE_AFTER_REQ s later (a real client's order: request first; one we recorded never removed it at all).)
                    rm_after_ = REMOVE_AFTER_REQ_TEAM if TEAM_GAME[0] else REMOVE_AFTER_REQ
                    if in_door(walker.x, walker.y, walker.z):          # (a body that still lies in a door, e.g. thrown there by a blast: not kept)
                        gone_ = BODIES_LEFT.pop()
                        REDELETES.extend((now + rm_after_ + d_, gone_) for d_ in [0.0] + REDELETE_AFTER)
                        print("the body lay in a doorway: taken away")
                    while len(BODIES_LEFT) > KEEP_BODIES:
                        gone_ = BODIES_LEFT.pop(0)
                        REDELETES.extend((now + rm_after_ + d_, gone_) for d_ in [0.0] + REDELETE_AFTER)
                    # (13 Nov 12:36, found in the user's game itself (bodydump): the frozen ghosts are the game's CORPSES ("misc_CorpseDispatch",
                    #  no network number), each standing exactly on a spawn point. The respawn request named the old body with the new spawn
                    #  point, so the game moved the old body there, standing, and our removal of it a moment later left a corpse right there.
                    #  The old body is now removed BEFORE the respawn request (REQ_AFTER_DELETE s before it, so the removal, which goes on
                    #  another channel, is surely handled first): the game makes its corpse where the ghost really died. GHOST_REQ_DELAY=0: old order.)
                    SPAWN_PEND[:] = ["req", now, pos, bytes(t6)]
                if not alive and SPAWN_PEND and SPAWN_PEND[0] == "req" and now - SPAWN_PEND[1] >= REQ_AFTER_DELETE:
                    pos, t6 = SPAWN_PEND[2], SPAWN_PEND[3]
                    send_msg(2, t6); print(f"[{time.time():.2f}] respawn request sent (old body {struct.unpack('<H', t6[10:12])[0]:#x})")
                    send_msg(2, ns_fix(bytes.fromhex(RESP["out_3f1"][1]))[:-1] + bytes([team_byte()])); p37_ = ns_fix(with_cid(bytes.fromhex(RESP["out_3f7"][1]), welcome_id)); send_msg(2, p37_)
                    if RELAY and peer_ids(): relay_msg(2, p37_, peer_ids())
                    HOST407.clear(); SPAWN_PEND[:] = ["respawn", now, pos]          # (the body is made when the host names the spawn point: WAIT407)
                if not alive and SPAWN_PEND and SPAWN_PEND[0] == "respawn" and (WAIT407 <= 0 or HOST407 or now - SPAWN_PEND[1] > WAIT407):
                    pos = SPAWN_PEND[2]
                    if FIXED_SPAWN: pos = FIXED_SPAWN; print(f"the ghost's own spawn point (GHOST_SPAWN): {pos[0]:.0f},{pos[2]:.0f}")
                    elif KEEP_POS[0] is not None: pos = KEEP_POS[0]; print(f"made again where it stood: {pos[0]:.0f},{pos[2]:.0f} (a quiet rebuild, no jump)")
                    elif HOST407: pos = tuple(HOST407); print(f"the host chose the spawn point: {pos[0]:.0f},{pos[2]:.0f}"); pos = avoid_blocked(pos)
                    elif WAIT407 > 0: print(f"no spawn point from the host within {WAIT407:.1f} s: the ghost's own pick")
                    KEEP_POS[0] = None
                    SPAWN_PEND.clear(); HOST407.clear()
                    gid = 0x00150000 | (GID & 0xFFFF)
                    pos = settle(*pos)
                    body_ = make_create(pos[0], pos[1], pos[2], gid, slot)
                    GID = gid; walker = new_walker(*pos); hp = HP; ARMOR[0] = 0.0; alive = True; respawn_req = None; next_state = now + 0.3
                    revive_ = make_state(pos[0], pos[1], pos[2], walker.yaw, 0, 0.0, 0.0, False, revive=True)   # real client: first state after respawn has tail 6f and id word 0x15
                    if RESPAWN_WAIT > 0:
                        PENDING_CREATE[:] = [body_, now + RESPAWN_WAIT, revive_]   # (sent when the host asks, or at the deadline: see RESPAWN_WAIT)
                    else:
                        send_create(body_); to_all(2, revive_)
                    print(f"ghost respawned (life {lives + 1}) at {pos[0]:.0f},{pos[2]:.0f}")
                if REDELETES and any(t_ <= now for t_, _ in REDELETES):
                    due_ = [g_ for t_, g_ in REDELETES if t_ <= now]; REDELETES[:] = [(t_, g_) for t_, g_ in REDELETES if t_ > now]
                    for gone_ in due_:
                        if gone_ == slot: continue                                      # (never our live body)
                        if gone_ not in REMOVED_ONCE: REMOVED_ONCE.add(gone_); print(f"[{time.time():.2f}] old body {gone_:#x} removed")
                        t3 = bytearray(ns_fix(bytes.fromhex(RESP["out_3ff"][1]))); t3[10:12] = struct.pack("<H", gone_); send_msg(3, bytes(t3)); tell_gone(gone_)
                if PENDING_CREATE and now >= PENDING_CREATE[1]:
                    body_, _dl, revive_ = PENDING_CREATE; PENDING_CREATE.clear()
                    send_create(body_); to_all(2, revive_); next_state = now + 0.3
                    print(f"no ask from the host within {RESPAWN_WAIT:.1f} s: sent the body's create")
                sweep_boxes()
                if now >= REMAP_T[0]: REMAP_T[0] = now + 5.0; remap_names(); report_players(now)
                taunt_step(now)
                tick_report(now)
                if now - spawned_at > STAY: print("done, rx packets:", n_rx); break
                if MODE_RUN and now >= MODE_POLL[0]:
                    MODE_POLL[0] = now + 0.5
                    if os.path.exists(mode_flag("leave")) or os.path.exists(os.path.join(MODE_STATE, f"stop_{MODE_RUN}")):
                        print("the game mode asked this ghost to leave"); break
                    try: tok_ = open(mode_flag("level")).read().strip().lower().split("+")
                    except OSError: tok_ = []
                    lv_ = tok_[0] if tok_ else None
                    if tok_:
                        sc_ = next((float(t_[6:]) for t_ in tok_ if t_.startswith("speed=")), 1.0); ns_ = "walk" in tok_
                        if (sc_, ns_) != (SPEED_SCALE[0], NO_SPRINT[0]):
                            SPEED_SCALE[0], NO_SPRINT[0] = sc_, ns_
                            if isinstance(walker, FightWalker):
                                walker.F.run, walker.F.walk, walker.F.no_sprint = FIGHT_BASE * sc_, WALK_BASE * sc_, ns_
                            print(f"the game mode set the speed: {sc_:.0%} of a player's" + (", walking only" if ns_ else ", sprinting allowed"))
                    if lv_ and lv_ != DIFFICULTY:
                        DIFFICULTY = lv_                                  # the next life starts at it; this one changes now
                        if isinstance(walker, FightWalker):
                            try:
                                from fighter import profile          # aim, reaction and turning now; the character's strafing/sprint style stays until the next life
                                walker.F.p.update({k: v for k, v in profile(lv_).items() if k not in ("keep_distance", "retreat", "sprint_frac", "strafe_frac")})
                            except Exception as ex_: print("could not change the difficulty:", ex_)
                        print(f"the horde became stronger: now fights like a {lv_} bot")
    elif now - t0 > 5:
        print("no answer from the host within 5 s (is a LAN game running, and is it on port", PORT, "?)"); break
    if now - last_rx > 10 and accepted:
        print("host went silent for 10 s (crashed or closed the connection?)"); break
guest_report("the ghost stopped")
if accepted:
    leave()                                                                      # the clean leave message real clients send (seen in captures)
    print("sent the disconnect message")
print("log: GhostLogs\\" + os.path.basename(log.name))
