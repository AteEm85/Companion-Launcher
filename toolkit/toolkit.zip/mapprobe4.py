"""Next-map probe, round 4 (mapprobe4.cmd): what the Host screens do before Start. hostnext2 showed that when you host
from the menu, the multiplayer manager (exe+0x1355420) already has a session object (+0x110) in state 2 (+0x4c) and the
flag exe+0xf0d710 has bit 2 set when the host request comes; after a match they are cleared, so a bare host request is
refused. This round watches who writes those three (hardware watchpoints 1-3), with the calls that led there.

Next-map probe (mapprobe.cmd): how the Steam build of the game starts a multiplayer map, so the bots can do it themselves.

Why: on the Steam build the host bot can't start the next map from inside the game ("the host can't start the next map
in-game"), so a map rotation or the next Co-op Mission closes every game copy and starts it all again. To change maps the
way a normal host does (everyone stays connected), we need to know which code of the game does it.

Attaches to YOUR game copy only (the one without -userpath; the bots' copies are left alone) and only watches - nothing in
the game is changed. It notes:
  - every change of the game's state (menu / lobby / loading / playing), with the code that made it and the calls that led
    there (a hardware watchpoint on the state value);
  - every game file opened (maps, archives), with the calls that led there;
  - every formatted text that names a map, a level or the lobby, with the calls that led there.
Writes state\\mapprobe4.txt.

  python mapprobe.py [seconds]      (default 900, 15 minutes)
"""
import json
import subprocess
import sys
import time
from pathlib import Path

import frida

HERE = Path(__file__).resolve().parent
OUT = HERE / "state" / "mapprobe4.txt"
SECS = float(sys.argv[1]) if len(sys.argv) > 1 else 900.0

JS = r"""
const exe = Process.mainModule;
const stamp = exe.base.add(exe.base.add(0x3c).readU32() + 8).readU32();
const BUILDS = {
  0x6a39ed68: { name: 'Steam', gameState: 0xf0d714, gameMode: 0xf0d724, lobbyPick: 0x1357934, sprintf: 0x329480 },
  0x6a39efd0: { name: 'GOG', gameState: 0xf07194, gameMode: 0xf071a4, lobbyPick: 0x1351310, sprintf: null },
};
const build = BUILDS[stamp];
if (!build) send({ kind: 'error', message: 'unknown game build 0x' + stamp.toString(16) });
function rva(p) { try { return '0x' + p.sub(exe.base).toString(16); } catch (e) { return String(p); } }
function inExe(p) { return p.compare(exe.base) >= 0 && p.compare(exe.base.add(exe.size)) < 0; }
function bt(ctx, n) { try { return Thread.backtrace(ctx, Backtracer.FUZZY).filter(inExe).slice(0, n || 14).map(rva).join(' < '); } catch (e) { return '?'; } }
const STATE = exe.base.add(build.gameState), MODE = exe.base.add(build.gameMode), PICK = exe.base.add(build.lobbyPick);
let lastState = STATE.readS32();
const seen = new Set();
function once(key) { if (seen.has(key) || seen.size > 4000) return false; seen.add(key); return true; }

// 1. the state value: who writes it (watchpoint 0 on every thread; threads started later are armed by the timer below)
const armedThreads = new Set();
const MGR = exe.base.add(0x1355420).readPointer();
const FLAGS = exe.base.add(0xf0d710);
const W = [['mgr+0x4c', MGR.add(0x4c), 4, p => p.readS32()], ['mgr+0x110', MGR.add(0x110), 8, p => p.readPointer().toString()],
           ['flags f0d710', FLAGS, 4, p => p.readS32()]];
const lastW = W.map(x => { try { return x[3](x[1]); } catch (e) { return null; } });
send({ kind: 'info', message: 'multiplayer manager ' + MGR + ': ' + W.map((x, i) => x[0] + '=' + lastW[i]).join(', ') });
function arm() {
  for (const t of Process.enumerateThreads()) {
    if (armedThreads.has(t.id)) continue;
    try {
      t.setHardwareWatchpoint(0, STATE, 4, 'w');
      for (let i = 0; i < W.length; i++) t.setHardwareWatchpoint(i + 1, W[i][1], W[i][2], 'w');
      armedThreads.add(t.id);
    } catch (e) {}
  }
}
Process.setExceptionHandler(function (d) {
  if (d.type !== 'single-step') return false;
  try {
    const v = STATE.readS32();
    if (v !== lastState) {
      send({ kind: 'state', from: lastState, to: v, mode: MODE.readS32(), pc: rva(d.context.pc), calls: bt(d.context, 16) });
      lastState = v;
    }
    for (let i = 0; i < W.length; i++) {
      const nv = W[i][3](W[i][1]);
      if (nv !== lastW[i]) {
        send({ kind: 'info', message: 'WRITE ' + W[i][0] + ': ' + lastW[i] + ' -> ' + nv + ' at ' + rva(d.context.pc) + ' (state ' + STATE.readS32() + ')\n        calls: ' + bt(d.context, 16) });
        lastW[i] = nv;
      }
    }
  } catch (e) {}
  return true;
});
arm();

// 2. files opened
const FILES = /\.(lvt|lvb|obt|inf|itm|lab|zip|pak|pal|cmp|msc|lst|ini|cfg|json)$/i;
for (const [mod, fn, wide] of [['kernel32.dll', 'CreateFileW', true], ['kernel32.dll', 'CreateFileA', false], ['kernelbase.dll', 'CreateFileW', true]]) {
  let a = null;
  try { a = Process.getModuleByName(mod).getExportByName(fn); } catch (e) { continue; }
  Interceptor.attach(a, {
    onEnter(args) {
      let p = null;
      try { p = wide ? args[0].readUtf16String() : args[0].readCString(); } catch (e) { return; }
      if (!p || !FILES.test(p)) return;
      const calls = bt(this.context, 12);
      if (once('F' + p + calls)) send({ kind: 'file', path: p, state: STATE.readS32(), calls: calls });
    }
  });
}

// 3. formatted text naming a map, level, lobby or host (the game's own sprintf)
const WORDS = /(\.lv[bt]|\.obt|\.inf|level|lobby|host|map|mission|loading|server|session|match|start)/i;
if (build.sprintf) {
  const sp = exe.base.add(build.sprintf);
  Interceptor.attach(sp, {
    onEnter(args) { this.out = args[0]; try { this.fmt = args[1].readCString(); } catch (e) { this.fmt = null; } this.ctx = this.context; },
    onLeave() {
      if (!this.fmt) return;
      let text = '';
      try { text = this.out.readCString(200); } catch (e) { return; }
      if (!WORDS.test(this.fmt) && !WORDS.test(text)) return;
      const calls = bt(this.ctx, 10);
      if (once('T' + this.fmt + calls)) send({ kind: 'text', fmt: this.fmt, text: text, state: STATE.readS32(), calls: calls });
    }
  });
}

setInterval(function () {
  arm();
  let pick = null;
  try { pick = PICK.readS32(); } catch (e) {}
  send({ kind: 'tick', state: STATE.readS32(), mode: MODE.readS32(), pick: pick });
}, 1000);
send({ kind: 'ready', build: build ? build.name : '?' });
"""

NAMES = {0: "main menu?", 2: "playing", 8: "lobby"}


def own_game_pid():
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='OutlawsAHOM.exe'\" | "
          "ForEach-Object { '{0}|{1}' -f $_.ProcessId, $_.CommandLine }")
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True, timeout=30)
    mine = [int(l.split("|", 1)[0]) for l in r.stdout.splitlines() if l.strip() and "-userpath" not in l]
    return mine[0] if mine else None


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    print("waiting for your own game (start Outlaws; stay in the main menu for now)...")
    pid = None
    for _ in range(300):
        pid = own_game_pid()
        if pid:
            break
        time.sleep(2)
    if not pid:
        print("your game was not found")
        return
    print(f"watching your game (pid {pid}) for {SECS / 60:.0f} minutes. Now:")
    print("  1. Host a multiplayer LAN game yourself from the game's menu (any map, Deathmatch, time limit 1 minute).")
    print("  2. Play until the match ends.")
    print("  3. Back in the main menu, host once more on a different map (slowly: one menu screen at a time).")
    print("When it says 'done', tell Claude. Everything is written to state\\mapprobe4.txt.")
    log = open(OUT, "w", encoding="utf-8")
    t0 = time.time()
    last = [None]

    def w(line):
        log.write(f"{time.strftime('%H:%M:%S')} +{time.time() - t0:6.1f}s  {line}\n")
        log.flush()

    def on_msg(msg, data):
        if msg.get("type") == "error":
            print("script error:", msg.get("description"))
            w("script error: %s" % msg.get("description"))
            return
        pl = msg.get("payload") or {}
        k = pl.get("kind")
        if k == "tick":
            cur = (pl.get("state"), pl.get("mode"), pl.get("pick"))
            if cur != last[0]:
                last[0] = cur
                s = pl.get("state")
                print(f"game state {s} ({NAMES.get(s, '?')}), mode {pl.get('mode')}, lobby pick {pl.get('pick')}")
                w(f"TICK state {s} ({NAMES.get(s, '?')}) mode {pl.get('mode')} pick {pl.get('pick')}")
        elif k == "state":
            w(f"STATE {pl['from']} -> {pl['to']} (mode {pl['mode']}) written at {pl['pc']}\n        calls: {pl['calls']}")
        elif k == "file":
            w(f"FILE  [{pl['state']}] {pl['path']}\n        calls: {pl['calls']}")
        elif k == "text":
            w(f"TEXT  [{pl['state']}] {pl['fmt']!r} => {pl['text']!r}\n        calls: {pl['calls']}")
        elif k == "info":
            print(pl.get("message", "")[:160])
            w(pl.get("message", ""))
        else:
            print(k, {x: y for x, y in pl.items() if x != "kind"})
            w(json.dumps(pl))

    s = frida.get_local_device().attach(pid)
    sc = s.create_script(JS)
    sc.on("message", on_msg)
    sc.load()
    t_end = time.time() + SECS
    try:
        while time.time() < t_end:
            time.sleep(1)
            if int(time.time() - t0) % 15 == 0 and own_game_pid() != pid:
                w("your game closed")
                break
    except KeyboardInterrupt:
        pass
    try:
        sc.unload()
        s.detach()
    except Exception:
        pass
    log.close()
    print(f"done: {OUT}")


if __name__ == "__main__":
    main()
