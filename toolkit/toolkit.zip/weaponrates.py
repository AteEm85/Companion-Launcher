"""The weapons' own timing, read from the game files: python weaponrates.py   (run in botctl, next to the game)

A weapon's .itm (olweap.lab and the olpatch labs) names its animation (.nwx) and the choreography of each action: FIRE_CHOR_1
(primary), FIRE_CHOR_2 (secondary), RELOAD_CHOR. The .nwx is a WAXF file; its CHOT section holds, per choreography, a record of
u32 size, then 6 u32 (1.0, 1.0 as 16.16, frames per second, 0, views (32), words per view) and, per view, that many int16:
frame numbers, with "-5, a, b" where the action happens (the shot; each round loaded) and "-1 / -2, ..." ending it.

How frames turn into time, checked against the user's own Sanchez pistol in a ghost recording (264 shots, 36 reloads):
  holding fire: a shot every (frames - 1) / fps        (measured 0.23 s; 4 / 18 = 0.222)
  the magazine's last shot to the reload's first sound: frames / fps + the reload's first frame   (measured 0.40; 0.278 + 0.1)
  reload sounds: the frames between them / fps          (measured 0.200; 2 / 10)
  the last reload sound to the next shot: (reload frames - 1 - its frame) / fps   (measured 0.19; 0.2)
netre/ghost.py's WEAPONS table uses these.
"""
import os, re, struct, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lvt

LABS = ["olweap.lab", "olpatch1.lab", "olpatch2.lab", "olpatch3.lab", "olpatch4.lab", "olpatch5.lab", "Olpatch6.lab"]
def get(nm):
    for lab in reversed(LABS):
        try:
            d = lvt.read_from_labs(nm, [lab])
            if d is not None: return d, lab
        except Exception: pass
    return None, None
def chors(d):
    o2 = struct.unpack_from("<I", d, 0x1c)[0]; c = d[o2:]
    assert c[:4] == b"CHOT", c[:4]
    n = struct.unpack_from("<I", c, 4)[0]; off = 16; out = []
    for i in range(n):
        size = struct.unpack_from("<I", c, off)[0]
        hdr = struct.unpack_from("<6I", c, off + 4)
        nview, cnt = hdr[4], hdr[5]
        body = c[off + 28:off + 4 + size]
        views = [list(struct.unpack_from(f"<{cnt}h", body, v * cnt * 2)) for v in range(nview)] if len(body) >= nview * cnt * 2 else []
        out.append(dict(hdr=hdr, views=views, raw=c[off:off + 32]))
        off += 4 + size
    return out

def script(v):
    """view script -> (frames before the first event, total frames, number of events, end opcode, raw)"""
    frames = 0; first = None; events = []; i = 0; end = None
    while i < len(v):
        t = v[i]
        if t >= 0: frames += 1; i += 1
        elif t == -5: events.append(frames); i += 3
        else: end = t; break
    return frames, events, end
d = lvt.lab_directory(os.path.join(lvt.GAME_DIR, "olweap.lab"))
names = sorted(d) if isinstance(d, dict) else [x[0] if isinstance(x, (tuple, list)) else x for x in d]
rows = []
for n in names:
    if not str(n).lower().endswith(".itm"): continue
    t, lab = get(n); t = t.decode("latin1") if isinstance(t, bytes) else (t or "")
    f = dict((m.group(2), m.group(3)) for m in re.finditer(r"^\s*(INT|FLOAT|STR)\s+(\S+)\s+(\S+)", t, re.M))
    anim = re.search(r"^ANIM\s+(\S+)", t, re.M)
    if not anim or "FIRE_CHOR_1" not in f: continue
    a, alab = get(anim.group(1).lower())
    if a is None: rows.append((n, anim.group(1), "animation file not found")); continue
    cs = chors(a)
    def one(key):
        k = f.get(key)
        if k is None or int(k) >= len(cs): return None
        c = cs[int(k)]; fr, ev, end = script(c["views"][0]); fps = c["hdr"][2]
        return dict(chor=int(k), frames=fr, events=ev, end=end, fps=fps, secs=fr / fps, raw=c["views"][0])
    rows.append((n, anim.group(1), lab, alab, f, {k: one(k) for k in ("FIRE_CHOR_1", "FIRE_CHOR_2", "RELOAD_CHOR", "NO_AMMO_CHOR_1")}))
for r in rows:
    if len(r) == 3: print(r); continue
    n, an, lab, alab, f, c = r
    def s(x):
        if x is None: return "-"
        return f"chor {x['chor']}: {x['frames']} frames @ {x['fps']} fps = {x['secs']:.1f} s, events at frames {x['events']}, ends with {x['end']}"
    print(f"{n:14} anim {an:13} ({alab}) cap {f.get('SHOT_CAPACITY','-'):>2} dmg {f.get('DAMAGE_1','-'):>5}/{f.get('DAMAGE_2','-'):<5} snd {f.get('FIRE_SOUND_1','-')}")
    print(f"      primary   {s(c['FIRE_CHOR_1'])}   {c['FIRE_CHOR_1']['raw'] if c['FIRE_CHOR_1'] else ''}")
    print(f"      secondary {s(c['FIRE_CHOR_2'])}   {c['FIRE_CHOR_2']['raw'] if c['FIRE_CHOR_2'] else ''}")
    print(f"      reload    {s(c['RELOAD_CHOR'])}")

print("\n\nCOMPACT")
who = {"b": "bob", "d": "drdeath", "j": "james", "m": "mary", "s": "sanchez", "t": "twofeathers", "f": "f?", "": "generic"}
out = {}
for r in rows:
    if len(r) == 3: continue
    n, an, lab, alab, f, c = r
    m = re.match(r"i([bdjmstf]?)(pistol|rifle|sgun|dbsgun|sawgun|knife|fist|dynam|gatgun)\.itm", n)
    if not m: continue
    p, s2, rl = c["FIRE_CHOR_1"], c["FIRE_CHOR_2"], c["RELOAD_CHOR"]
    def cyc(x): return None if not x else (x["frames"], x["fps"], round((x["frames"] - 1) / x["fps"], 3), round(x["frames"] / x["fps"], 3))
    ev = rl["events"] if rl else []
    per = (ev[1] - ev[0]) / rl["fps"] if rl and len(ev) > 1 else None
    print(f"{who[m.group(1)]:11} {m.group(2):7} primary {cyc(p)} secondary {cyc(s2)} reload {('%d frames @%d = %.1fs, %d sounds %s apart' % (rl['frames'], rl['fps'], rl['frames'] / rl['fps'], len(ev), per)) if rl else '-'} cap {f.get('SHOT_CAPACITY')} x{f.get('SHOT_MULTIPLES')} dmg {f.get('DAMAGE_1')}/{f.get('DAMAGE_2')} effrange {f.get('EFFRANGE_1')}/{f.get('EFFRANGE_2')} var {f.get('VARIANCE_1')}/{f.get('VARIANCE_2')}")
