@echo off
rem Gold Gatling: copies the game's Gatling gun sprite (GGATGUN.SPX, about 0.6 MB) out of olremaster1.lab into botctl\extract\. The archive itself is not changed.
cd /d "%~dp0"
.venv\Scripts\python.exe labextract.py olremaster1.lab GGATGUN.SPX
pause
