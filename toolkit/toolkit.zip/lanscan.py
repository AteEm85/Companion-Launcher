"""Finds the LAN games on the home network and ZeroTier: the same question the game's Multiplayer > LAN screen asks.
(25 Nov, from a capture of that screen.) The game sends, to UDP 5069:
    [u16 BE len<<4] 81 08 "CRANTIME" <len> "Outlaws + Handful of Missions: Remaster" "@" <7 bytes of its own>
to the multicast group 224.69.69.69 (and to hosts it has heard from before), and every host answers with
    <len> <host name> "@" <the same 7 bytes> <players> <max players> ... then <len>key <len>value pairs
    (OLCurrentLevel, OLMultiGameClass, OLKillsToEnd, OLTimeToEnd, TeamChat, UUID ...).
The multicast does not always cross ZeroTier, which is why the game's own list sometimes comes up empty: this asks
the multicast group AND every network's broadcast address AND any addresses it is given. A host PC running the
launcher also answers modserver.py's "OUTLAWS?" (UDP 8766) with what kind of game it is and how many of its
players are bots or ghosts, so only real players are counted.
Usage (a test): python lanscan.py [extra address ...]"""
import ipaddress
import json
import os
import socket
import struct
import subprocess
import sys
import time

GAME_NAME = b"Outlaws + Handful of Missions: Remaster"
PORT, MCAST, DISCOVER_PORT = 5069, "224.69.69.69", 8766
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
GAME_CLASS = {1: "Capture the Flag", 2: "Tag", 3: "Chicken", 4: "Doc", 5: "Team Play", 6: "Death Match"}


def query(nonce):
    body = b"\x81\x08CRANTIME" + bytes([len(GAME_NAME)]) + GAME_NAME + b"@" + nonce
    return struct.pack(">H", (len(body) + 2) << 4) + body


def parse(data):
    """A host's answer -> {name, players, max, vars}, or None"""
    try:
        n = data[0]
        name = data[1:1 + n].decode("utf-8", errors="replace")
        i = 1 + n
        if data[i:i + 1] != b"@":
            return None
        rest = data[i + 8:]
        players, maxp = rest[0], rest[1]
        for start in range(2, 10):                      # (a few header bytes, then length-prefixed key / value pairs)
            kv, j, ok = {}, start, True
            while j < len(rest):
                kl = rest[j]; k = rest[j + 1:j + 1 + kl]; j += 1 + kl
                if j >= len(rest) or kl == 0 or not all(32 <= c < 127 for c in k):
                    ok = False; break
                vl = rest[j]; v = rest[j + 1:j + 1 + vl]; j += 1 + vl
                if j > len(rest):
                    ok = False; break
                kv[k.decode()] = v.decode("utf-8", errors="replace")
            if ok and kv:
                return {"name": name, "players": players, "max": maxp, "vars": kv}
        return {"name": name, "players": players, "max": maxp, "vars": {}}
    except (IndexError, ValueError):
        return None


def networks():
    """[(this PC's IPv4 address, its network's broadcast address)] for every adapter that is up"""
    out = []
    ps = ("Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | "
          "ForEach-Object { $_.IPAddress + '/' + $_.PrefixLength }")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=20, creationflags=NO_WINDOW)
        for line in (r.stdout or "").split():
            try:
                itf = ipaddress.ip_interface(line.strip())
                out.append((str(itf.ip), str(itf.network.broadcast_address)))
            except ValueError:
                pass
    except (OSError, subprocess.SubprocessError):
        pass
    return out


def scan(extra=(), timeout=2.5, only=None):
    """{host address: {name, players, max, vars, info}} - info is the launcher's own answer (modserver) or {}.
    only: ask just that one address (the check before joining)."""
    nonce = os.urandom(7)
    pkt = query(nonce)
    found = {}
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    s.bind(("0.0.0.0", 0))
    targets = set([only] if only else list(extra))
    nets = [] if only else networks()
    if not only:
        targets |= {b for _ip, b in nets} | {"255.255.255.255"}
    def send_all():
        for t in targets:
            try: s.sendto(pkt, (t, PORT))
            except OSError: pass
        if not only:
            for ip, _b in nets:                         # the game's own multicast, out of every adapter
                try:
                    s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(ip))
                    s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 4)
                    s.sendto(pkt, (MCAST, PORT))
                except OSError:
                    pass
    end, again = time.time() + timeout, time.time()
    while time.time() < end:
        if time.time() >= again:
            send_all(); again = time.time() + 0.8          # (asked a few times: a lost packet is common over ZeroTier)
        s.settimeout(0.2)
        try:
            data, a = s.recvfrom(2048)
        except (socket.timeout, OSError):
            continue
        if nonce in data[:80]:
            g = parse(data)
            if g:
                found[a[0]] = g
    s.close()
    # one game seen at two addresses (the hosting PC on the home network AND on ZeroTier): kept once, by the game's UUID,
    # at the address that answered first (the faster way there)
    uniq, seen = {}, set()
    for ip, g in found.items():
        u = (g.get("vars") or {}).get("UUID") or ip
        if u in seen: continue
        seen.add(u); uniq[ip] = g
    found = uniq
    for ip, g in found.items():
        g["info"] = launcher_info(ip)
    return found


def launcher_info(ip, timeout=1.2):
    """the host PC's launcher (modserver.py): {mode, map, christmas, bots, mission ...}, or {} (no launcher there)"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.settimeout(timeout)
        s.sendto(b"OUTLAWS?", (ip, DISCOVER_PORT))
        data, _a = s.recvfrom(4096)
        return json.loads(data.decode("utf-8", errors="replace"))
    except (OSError, ValueError):
        return {}
    finally:
        s.close()


def describe(g, map_label=lambda k: k):
    """-> (title, map, real players, room for one more?, the most players)"""
    info, v = g.get("info") or {}, g.get("vars") or {}
    mp = v.get("OLCurrentLevel") or info.get("map") or "?"     # (the game's own: the launcher's is the map it started on - a rotation moves on)
    ms = info.get("mission") or {}
    if ms:
        title = ms.get("label") or "Christmas Mission"
    elif info.get("mode") == "horde":
        title = "Christmas Horde" if info.get("christmas") else ("Melee Zombies" if info.get("melee") else "Survival Horde")
    elif info.get("mode") == "dark":
        title = "Dark Mode Horde"
    else:
        try: title = GAME_CLASS.get(int(v.get("OLMultiGameClass", "0")), "LAN game")
        except ValueError: title = "LAN game"
    bots = int(info.get("bots") or 0)
    total, most = int(g.get("players") or 0), int(g.get("max") or 0)
    real = max(0, total - bots) if info else total
    cap = int(ms.get("max_humans") or 0) if ms else 0
    room = (most == 0 or total < most) and (not cap or real < cap)
    return title, map_label(mp), real, room, (cap or (most - bots if info and most else most))


if __name__ == "__main__":
    for ip, g in scan(sys.argv[1:]).items():
        print(ip, g["name"], f"{g['players']}/{g['max']}", g["vars"].get("OLCurrentLevel"), describe(g), g["info"])
