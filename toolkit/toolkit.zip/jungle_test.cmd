@echo off
rem One map on its own: jungle.
cd /d "%~dp0"
".venv\Scripts\python.exe" -u mapbatch.py --only jungle_only.txt --lanes 1 --limit 1
exit
