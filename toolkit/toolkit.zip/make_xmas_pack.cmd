@echo off
rem Packs the Christmas Missions' files for new players into botctl\_xmas_pack (see make_xmas_pack.py).
rem (No ( ) blocks: a game folder under "Program Files (x86)" has a ")" in its path.)
cd /d "%~dp0"
if not exist "%~dp0.venv\Scripts\python.exe" goto nopy
"%~dp0.venv\Scripts\python.exe" make_xmas_pack.py
goto done
:nopy
py -3 make_xmas_pack.py
:done
echo.
pause
