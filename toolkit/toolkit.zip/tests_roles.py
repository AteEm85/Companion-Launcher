"""Offline checks for Relay, Juggernaut, Infection and Hot Potato (no game needed): python tests_roles.py
Each mode needs its own environment (roles.MODE is read at import), so the checks run in child processes."""
import json, os, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))

CHECKS = {}

CHECKS["relay"] = ({"BOT_GG_RELAY": "1", "BOT_GG_LAUNCH": "t_relay", "BOT_GG_ORDER": "5,4,3,8"}, '''
import gungame as g
g.relay_reset()
assert g.relay_get(1) == 0 and g.relay_get(2) == 0
assert g.relay_move(1, 1) == 1 and g.relay_move(1, 1) == 2 and g.relay_get(2) == 0
assert g.relay_move(2, -1) == 0                      # never below the bottom
assert g.relay_move(1, 1) == 3 and g.relay_move(1, 1) == 4      # past the last rung (4 rungs): the caller wins the round
g.relay_reset(); assert g.relay_get(1) == 0
print("relay ok")
''')

CHECKS["jug"] = ({"BOT_ROLE": "jug", "BOT_ROLE_LAUNCH": "t_jug", "BOT_STATS_PLAYER": "Human"}, '''
import roles, time
r = roles.Referee(); r.me = "HOST"
r.kill("A", "B");  assert roles.read()["jug"] == "A"                 # first blood
r.kill("C", "D");  assert roles.read()["jug"] == "A"                 # a kill that is not of the Juggernaut changes nothing
r.kill("C", "A");  assert roles.read()["jug"] == "C"                 # killing him takes over
r.kill("C", "C");  assert roles.read()["jug"] == "C"                 # a suicide does not
r.tick(time.time() + 1); assert roles.read()["held"]["C"] > 0
# the loadout is handed out once with armour and bags, then only topped up
inv_full = {"armor": 150, "weapons": [{"slot": s} for s in range(1, 10)], "carried": {"IDYNAM": 7, "IKNIFE": 6, "IDOCBAG": 6}}
assert roles.jug_short(inv_full, True) and not roles.jug_short(inv_full, False)
inv_low = dict(inv_full, carried={"IDYNAM": 1, "IKNIFE": 6, "IDOCBAG": 6}); assert not roles.jug_short(inv_low, False)   # no ammo or TNT refills
class Api:
    def __init__(s): s.gave, s.counts = [], {}
    def give(s, l): s.gave.append(list(l)); return {"ok": True}
    def set_count(s, i, n): s.counts[i] = n
a = Api(); roles.jug_give(a, True)
assert "IBPLATE" in a.gave[0] and a.gave[0].count("IDOCBAG") == 2 and a.gave[0].count("IDYNAM") == 7 and a.gave[0].count("IKNIFE") == 6
assert a.counts["IBPLATE"] == 150 and a.counts["IDOCBAG"] == 6 and a.counts["IDYNAM"] == 7 and a.counts["IKNIFE"] == 6
b = Api(); roles.jug_give(b, False)
assert "IBPLATE" not in b.gave[0] and "IDOCBAG" not in b.gave[0] and "IBPLATE" not in b.counts and "IDOCBAG" not in b.counts
print("jug ok")
''')

CHECKS["jugsilver"] = ({"BOT_ROLE": "jug", "BOT_ROLE_LAUNCH": "t_jugs", "BOT_JUG_GATLING": "1", "BOT_STATS_PLAYER": "Human"}, '''
import roles, time, struct, darkitems, silvergat
r = roles.Referee(); r.me = "HOST"
r.kill("A", "B"); assert roles.read() is None or roles.read()["jug"] is None      # a kill alone starts nothing
assert not roles.has_gatling({"weapons": [{"slot": 2}, {"slot": 8}]}) and roles.has_gatling({"weapons": [{"slot": 9}]})
assert roles.claim("Bot3") and not roles.claim("Bot5") and roles.claimed() == "Bot3"     # first come, first served
r.tick(time.time()); assert roles.read()["jug"] == "Bot3"
r.kill("A", "B"); assert roles.read()["jug"] == "Bot3"
r.kill("D", "Bot3"); assert roles.read()["jug"] == "D"                              # killing him takes over
# fallback: nobody found it in time
import os; os.remove(roles.CLAIM_FILE)
r2 = roles.Referee(); r2.s["jug"] = None; r2.t0 = time.time() - roles.GATLING_WAIT - 1; r2.kill("E", "F"); assert r2.s["jug"] == "E"
# the map patch: one Gatling left, renamed; counts and layout stay consistent
t = open(os.path.join("..", "maps", "hargrove.obt"), "rb").read() if os.path.exists(os.path.join("..", "maps", "hargrove.obt")) else None
if t:
    n, c, k = darkitems._jug_text(t, 0.3); assert n.count(b"GGATGUN") == 1 and n.count(b"NGATGUN") == 0 and k == 1
if t:
    n2, c2, k2 = darkitems._jug_text(t, 0.3, keep_one=False); assert b"GATGUN" not in n2 and c2 == c
    import re, random
    lv = open(os.path.join("..", "maps", "hargrove.lvt"), "rb").read() if os.path.exists(os.path.join("..", "maps", "hargrove.lvt")) else None
    if lv:
        sp = darkitems._random_spot("hargrove", lv, t.decode("latin-1"), [(409.81, 380.62)], random.Random(1))
        assert sp and ((sp[1] - 409.81) ** 2 + (sp[3] - 380.62) ** 2) ** 0.5 >= 60
rec = lambda nm: b"\\x03\\x00\\x00\\x00\\x0b" + nm + b"\\x00" + bytes(40)
data = b"HDR!" + struct.pack("<I", 4) + rec(b"NKNIFE1") + rec(b"NGATGUN") + rec(b"GGATGUN") + rec(b"NSGUN1") + b"TAIL"
out, c, k = darkitems._jug_binary(data, 0.9)
assert c == 2 and struct.unpack_from("<I", out, 4)[0] == 3 and [m.group(1) for m in darkitems._REC.finditer(out)] == [b"NKNIFE1", b"GGATGUN", b"NSGUN1"]
# the gold sprite is the same size as the game's and starts like it
sp = open(os.path.join(os.path.dirname(roles.__file__), "silver", "GGATGUN.SPX"), "rb").read(); assert sp[:4] == b"SPRX" and len(sp) == 581216
ip = open(os.path.join(os.path.dirname(roles.__file__), "silver", "IGATGUN.SPX"), "rb").read(); assert ip[:4] == b"SPRX" and len(ip) == 22468568
print("jugsilver ok")
''')

CHECKS["jugnative"] = ({"BOT_ROLE": "jug", "BOT_ROLE_LAUNCH": "t_jugn", "BOT_ROLE_NATIVE": "1", "BOT_STATS_PLAYER": "Human"}, '''
import roles, time
assert roles.NATIVE
r = roles.Referee(); r.me = "HOST"
roles.publish(111, "Bot2", {"x": 50.0, "z": 50.0, "y": 0})
players = [{"addr": "a", "x": 0, "z": 0, "local": True, "team": 2}, {"addr": "b", "x": 50.5, "z": 49.0, "team": 2},
           {"addr": "c", "x": 200, "z": 200, "team": 2}]
r.native(players, "HOST"); assert roles.read() is None or roles.read()["jug"] is None      # nobody is red yet
players[1]["team"] = 1; r.native(players, "HOST"); assert roles.read()["jug"] == "Bot2"       # a bot's actor is the holder
players[1]["team"] = 2; players[2]["team"] = 1; r.native(players, "HOST"); assert roles.read()["jug"] == "Human"   # nobody near: the human
players[2]["team"] = 2; players[0]["team"] = 1; r.native(players, "HOST"); assert roles.read()["jug"] == "HOST"      # our own actor
r.kill("X", "HOST"); assert roles.read()["jug"] == "HOST"                  # the feed no longer decides
print("jugnative ok")
''')

CHECKS["inf"] = ({"BOT_ROLE": "inf", "BOT_ROLE_LAUNCH": "t_inf", "BOT_STATS_PLAYER": "Human"}, '''
import roles, time
r = roles.Referee(); r.me = "HOST"
for n in ("HOST", "Bot2", "Bot3"):
    roles.publish(abs(hash(n)) % 100000, n, {"x": 0, "z": 0, "y": 0})
r.tick(time.time() + 30)
st = roles.read(); a = st["alpha"]; assert a in ("HOST", "Bot2", "Bot3") and st["infected"] == [a]
r.kill("Human", "Bot2");  assert "Bot2" not in roles.read()["infected"] or a == "Bot2"     # a survivor kills: nothing
r.kill(a, "Human");       assert "Human" in roles.read()["infected"]                        # an infected kills: infected
assert roles.is_infected(roles.read(), "Human") and not roles.is_infected(roles.read(), "nobody")
for n in ("HOST", "Bot2", "Bot3"):
    r.kill("Human", n)
r.tick(time.time() + 31)
assert roles.read()["over"], "everyone infected must end the game"
import dataclasses
@dataclasses.dataclass
class S:
    favorite: int = 3; lean: object = None; prefer_close: list = None; prefer_far: list = None; prefer_long: list = None
    far_long: object = None; tnt: bool = True; melee_only: bool = False; knife_first: bool = False
    keep_distance: float = 10.0; back_off: float = 5.0; knife_keep: float = 15.0; speed_mult: float = 1.0
k = roles.knife_skill(S()); assert k.melee_only and k.favorite == 8 and not k.tnt
print("inf ok")
''')

CHECKS["pot"] = ({"BOT_ROLE": "pot", "BOT_ROLE_LAUNCH": "t_pot", "BOT_STATS_PLAYER": "Human"}, '''
import roles, time
r = roles.Referee(); r.me = "HOST"
for n in ("Bot2", "Bot3"):
    roles.publish(abs(hash(n)) % 100000, n, {"x": 0, "z": 0, "y": 0})
r.tick(time.time() + 1); assert r.s["holder"] is None                       # too early
r.tick(time.time() + 30); st = roles.read(); h = st["holder"]; assert h in ("HOST", "Bot2", "Bot3", "Human")
assert abs(st["fuse_at"] - time.time() - roles.POTATO_FUSE) < 2
other = next(n for n in ("HOST", "Bot2", "Bot3", "Human") if n != h)
r.kill("X", "Y");        assert roles.read()["holder"] == h              # nothing to do with the holder
r.kill(h, other);        assert roles.read()["holder"] == other          # the holder kills: the victim has it
r.kill("Z", other);      assert roles.read()["holder"] == "Z"             # someone kills the holder: the killer has it
before = roles.read()["boom"]
r.s["fuse_at"] = time.time() - 1; r.tick(time.time() + 40)                # the fuse is out
st = roles.read(); assert st["boom"] == before + 1 and st["boom_name"] == "Z" and st["holder"] != "Z"
assert st["booms"]["Z"] == 1 and st["fuse_at"] > time.time() + roles.POTATO_FUSE
print("pot ok")
''')


def main():
    only = sys.argv[1:] or list(CHECKS)
    bad = 0
    for name in only:
        env, code = CHECKS[name]
        state = os.path.join(HERE, "state")
        for f in ("roles.json", "gg_relay.json", "gg_banner.json", "jug_claim.json"):
            try: os.remove(os.path.join(state, f))
            except OSError: pass
        e = dict(os.environ, **env)
        p = subprocess.run([sys.executable, "-c", code], cwd=HERE, env=e, capture_output=True, text=True)
        out = (p.stdout + p.stderr).strip().splitlines()
        ok = p.returncode == 0
        print(("PASS " if ok else "FAIL ") + name + ("" if ok else ": " + " | ".join(out[-4:])))
        bad += (not ok)
    for f in os.listdir(os.path.join(HERE, "state")) if os.path.isdir(os.path.join(HERE, "state")) else ():
        if f.startswith(("pos_", "name_")) and f.endswith(".txt"):
            try: os.remove(os.path.join(HERE, "state", f))
            except OSError: pass
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
