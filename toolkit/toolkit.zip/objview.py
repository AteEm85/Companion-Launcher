"""A Co-op Mission's objective on screen (tierhud.py on the host, the companion app for friends): big letters with a thick
black outline, the mission's name in Christmas red and the objective in Christmas green, wrapped back to the left before it
reaches the middle of the screen. Standard library only.

    objview.size(screen_w, screen_h)            -> (window width, window height)
    objview.draw(canvas, text, screen_h, width) -> draws "TITLE\\nobjective\\n..." into the canvas"""
RED, GREEN = "#ff3b30", "#36e06a"
FACES = ("Segoe UI Black", "Arial Black", "Impact", "Segoe UI")


def size(sw, sh):
    return int(sw * 0.30), int(sh * 0.42)          # (wraps well before the middle: the user, 17 Nov)


def _face(cv):
    try:
        from tkinter import font as tkfont
        fams = {f.lower(): f for f in tkfont.families(cv)}
        return next((fams[f.lower()] for f in FACES if f.lower() in fams), "Arial")
    except Exception:
        return "Arial"


def draw(cv, text, sh, width):
    cv.delete("all")
    if not text:
        return
    face = _face(cv)
    big, small = max(11, sh // 74), max(12, sh // 60)          # (the objective lines a little smaller than the red name; both smaller, 17 Nov)
    y = 6
    for i, line in enumerate(l for l in text.split("\n") if l.strip()):
        title = i == 0 and "\n" in text
        f = (face, small if title else big, "bold")
        col = RED if title else GREEN
        t = max(2, (small if title else big) // 9)
        for dx in range(-t, t + 1, max(1, t)):
            for dy in range(-t, t + 1, max(1, t)):
                if dx or dy:
                    cv.create_text(10 + dx, y + dy, text=line, font=f, fill="black", anchor="nw", width=width - 24)
        tid = cv.create_text(10, y, text=line, font=f, fill=col, anchor="nw", width=width - 24)
        bb = cv.bbox(tid)
        y = (bb[3] if bb else y + big) + 6
