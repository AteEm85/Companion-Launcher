@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe labextract.py
pause
