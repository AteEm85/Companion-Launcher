"""King of the Hill: free-for-all; the hill is the best armor plate on the map. Every second a bot stands on it is a
point; first to --target points wins (else the most points when the time is up) and the game ends.

  python koth.py --map drygulch --bots 4 --levels nightmare,hard,easy,easiest [--target 60] [--minutes 12]
Logs: koth_logs\\<map>_<name>.log, result in koth_logs\\result.txt
"""
import argparse
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

from horde import CHARS, NOWIN, kill, pump

HERE = Path(__file__).resolve().parent
LOGS = HERE / "koth_logs"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--map", default="drygulch")
    ap.add_argument("--bots", type=int, default=4)
    ap.add_argument("--levels", default="nightmare,hard,easy,easiest")
    ap.add_argument("--target", type=int, default=60)
    ap.add_argument("--radius", default="14")
    ap.add_argument("--minutes", type=float, default=10)
    ap.add_argument("--fps", default="60")
    ap.add_argument("--window-mode", default=os.environ.get("HORDE_WINDOWS", "hidden"))
    ap.add_argument("--users", type=int, default=0)
    a = ap.parse_args()
    LOGS.mkdir(exist_ok=True)
    levels = [x for x in a.levels.split(",") if x] or ["easy"]
    procs, logs, names = [], [], []

    def start(i, host=False):
        name = f"lm{i + 1}"
        level = levels[i % len(levels)]
        spec = ":".join([name, CHARS[i % len(CHARS)], "lv_" + level] + (["nightmare"] if level in ("nightmare", "hell") else []))
        log = LOGS / f"{a.map}_{name}.log"
        cmd = [sys.executable, "-u", str(HERE / "botctl.py"), spec, "--slot", str(i), "--fps", a.fps, "--size", "320x180",
               "--fight", "--no-taunts", "--window-mode", a.window_mode, "--no-bench"]
        cmd += ["--host", "--map", a.map, "--mode", "dm", "--wait-for", str(a.users), "--maxplayers", "8"] if host \
            else ["--join", "127.0.0.1"]
        p = subprocess.Popen(cmd, cwd=str(HERE), env=dict(os.environ, PYTHONUNBUFFERED="1", BOT_TAG=name, BOT_KOTH=str(a.radius)),
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace", creationflags=NOWIN)
        threading.Thread(target=pump, args=(p, log), daemon=True).start()
        procs.append(p); logs.append(log); names.append(name)
        print(f"{time.strftime('%H:%M:%S')} started {name} ({level})", flush=True)
        return p, log

    result = "no winner before the time ran out"
    try:
        host, hlog = start(0, True)
        end = time.time() + 150
        while time.time() < end and host.poll() is None:
            time.sleep(2)
            try:
                if "attached to" in hlog.read_text(errors="replace"):
                    break
            except OSError:
                pass
        if host.poll() is not None:
            print("the host bot exited early"); return
        print("lobby up", flush=True)
        time.sleep(12)
        for i in range(1, a.bots):
            start(i)
            time.sleep(8)
        t_end = time.time() + a.minutes * 60
        while time.time() < t_end:
            time.sleep(3)
            scores = {}
            for n, lg in zip(names, logs):
                try:
                    hits = re.findall(r"KOTH: \+1 \((\d+)\)", lg.read_text(errors="replace"))
                    scores[n] = int(hits[-1]) if hits else 0
                except OSError:
                    scores[n] = 0
            top = max(scores, key=scores.get)
            if scores[top] >= a.target:
                result = f"{top} wins with {scores[top]} points ({levels[names.index(top) % len(levels)]}); scores {scores}"
                break
        else:
            top = max(scores, key=scores.get) if scores else None
            result = f"time up: {top} leads; scores {scores}"
        print(result, flush=True)
        (LOGS / "result.txt").write_text(result + "\n")
        time.sleep(3)
    finally:
        kill(procs, logs)


if __name__ == "__main__":
    main()
