"""Give the human player boiler-plate armor in their own running game (Survival rewards).

  python giveplates.py <amount> [--pid N] [--exclude pid,pid,...]

Attaches the bot agent to the one OutlawsAHOM.exe that isn't a bot (or --pid), calls the game's own pickup function for
IBPLATE until the armor reaches <amount> (light 50, medium 100, heavy 150; the game caps it at 150), then lets go.
Log: botctl\\giveplates_log.txt"""
import argparse
import subprocess
import sys
import time
from pathlib import Path

import frida

HERE = Path(__file__).resolve().parent
LOG = HERE / "giveplates_log.txt"
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def log(msg):
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    try:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def play_pickup_sound(amount=None):
    """Play the sound the game plays when you pick up a boiler plate (the plates' PICKUP_SOUND is ricoch3, read from the
    game's own archives: olpatch5.lab first, else olsfx.lab) so you know you got one."""
    try:
        import struct
        import winsound
        want = "ricoch3.wav"
        cache = HERE / "sounds" / want
        if not cache.exists():
            for lab in ("olpatch5.lab", "olsfx.lab"):
                path = HERE.parent / lab
                if not path.exists():
                    continue
                with path.open("rb") as f:
                    head = f.read(16)
                    n, = struct.unpack_from("<I", head, 8)
                    ent = f.read(16 * n)
                    tab = 16 + 16 * n
                    f.seek(tab)
                    names = f.read(struct.unpack_from("<I", head, 12)[0])
                    for i in range(n):
                        no, off, size, _t = struct.unpack_from("<IIII", ent, 16 * i)
                        if names[no:names.index(b"\0", no)].decode("latin1").lower() == want:
                            f.seek(off)
                            cache.parent.mkdir(exist_ok=True)
                            cache.write_bytes(f.read(size))
                            break
                if cache.exists():
                    break
        play = cache
        try:
            quiet = cache.with_name("ricoch3_half.wav")           # the same sound at half volume (it was very loud)
            if not quiet.exists() or quiet.stat().st_mtime < cache.stat().st_mtime:
                import wave, array
                with wave.open(str(cache), "rb") as src:
                    prm, frames = src.getparams(), src.readframes(src.getnframes())
                if prm.sampwidth == 2:
                    a = array.array("h"); a.frombytes(frames); a = array.array("h", (int(x * 0.5) for x in a)); frames = a.tobytes()
                elif prm.sampwidth == 1:
                    frames = bytes(128 + int((x - 128) * 0.5) for x in frames)
                with wave.open(str(quiet), "wb") as dst:
                    dst.setparams(prm); dst.writeframes(frames)
            play = quiet
        except Exception as e:
            log(f"could not lower the sound volume: {e}")
        winsound.PlaySound(str(play), winsound.SND_FILENAME)
    except Exception as e:
        log(f"could not play the pickup sound: {e}")


def human_pid(exclude):
    dev = frida.get_local_device()
    pids = [p.pid for p in dev.enumerate_processes() if p.name.lower() == "outlawsahom.exe" and str(p.pid) not in exclude]
    return pids[0] if len(pids) == 1 else None


def armor(api):
    try:
        w = api.world()
        if not w.get("ok"):                      # no live player actor (menu, dead, loading): giving then asserts "Bad Actor"
            return None
        return int(((w.get("self") or {}).get("inventory") or {}).get("armor") or 0)
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("amount", type=int)
    ap.add_argument("--pid", type=int)
    ap.add_argument("--exclude", default="")
    ap.add_argument("--name", help="pickup item name to use (default: IBPLATE, then GBPLATE3)")
    a = ap.parse_args()
    target = max(0, min(150, a.amount))
    pid = a.pid or human_pid(set(a.exclude.split(",")))
    if not pid:
        log("no single non-bot game window found; nothing given")
        return 1
    dev = frida.get_local_device()
    session = dev.attach(pid)
    script = session.create_script((HERE / "input_agent.js").read_text())
    script.on("message", lambda m, d: None)
    script.load()
    api = script.exports_sync
    try:
        now = None
        for _ in range(20):                       # the agent needs a moment before it sees the player
            now = armor(api)
            if now is not None:
                break
            time.sleep(0.5)
        log(f"pid {pid}: armor {now}, want {target}")
        if now is None:
            return 1
        r = api.give(["IBPLATE"])                     # makes the item (count 0) in the first free slot, or finds it
        time.sleep(0.3)
        log(f"give IBPLATE -> {r}")
        new = max(now, target)
        r = api.setCount("IBPLATE", min(150, new))    # armor is the item's count
        time.sleep(0.3)
        got = armor(api)
        log(f"set count -> {r}; armor now {got}")
        now = got if got is not None else now
        if r.get("ok"):
            play_pickup_sound(target)
        log(f"done: armor {now}")
    finally:
        try:
            api.shutdown()
            time.sleep(0.5)
        except Exception:
            pass
        try:
            session.detach()
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
