"""Your own game follows the host to the next match: python follow.py <game pid | auto> [red|blue|-] [log file]

When a match ends the game shuts the LAN session down and everyone sits on the score screen. Whatever hosts the next
match (rotation.py, or horde.py going on to the next Co-op Mission) writes state/next_lobby.json once the new lobby
is up: {"t": time, "address": "127.0.0.1", "map": ..., "team": "red"}. This script, attached to YOUR game the way
autojoin.py is, then presses Continue on the score screen (again every 2 seconds: the score screen may hold for a few
seconds first), joins the new lobby from the main menu, and picks the team (if one is named) once the lobby shows.
It never does anything else: if you are already somewhere else (playing, in a menu with a lobby up) it waits.
It runs until your game closes."""
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
NEXT = HERE / "state" / "next_lobby.json"
LOBBY_STATE, PLAYING, MENU = 8, 2, 0
PICK = {"red": 3, "blue": 4}
RETURN_KEY = (40, 0x0D)                       # SDL scancode, keycode (botctl.KEYS["return"])


def log(msg, path=None):
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    try:
        if path:
            with open(path, "a") as f:
                f.write(line + "\n")
    except OSError:
        pass


def in_front(pid):
    """is the window in front (the one with the keyboard) the game's own?"""
    try:
        import ctypes
        u = ctypes.windll.user32
        out = ctypes.c_ulong(0)
        u.GetWindowThreadProcessId(u.GetForegroundWindow(), ctypes.byref(out))
        return out.value == pid
    except Exception:
        return True


def own_game_pid(wait=120):
    """your own copy of the game (the one without -userpath: the bots' copies have it)"""
    import subprocess
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='OutlawsAHOM.exe'\" | "
          "ForEach-Object { '{0}|{1}' -f $_.ProcessId, $_.CommandLine }")
    end = time.time() + wait
    while time.time() < end:
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True, timeout=30)
            mine = [int(l.split("|", 1)[0]) for l in r.stdout.splitlines() if l.strip() and "-userpath" not in l]
            if mine:
                return mine[0]
        except Exception:
            pass
        time.sleep(2)
    return None


def joined_mark():
    """state/follow_in.txt: your game is in the next match (horde.py starts the music and the steps on screen then)"""
    try: (HERE / "state" / "follow_in.txt").write_text(str(time.time()))
    except OSError: pass


def main():
    pid = own_game_pid() if sys.argv[1] == "auto" else int(sys.argv[1])
    if pid is None:
        log("follow: your game is not running")
        return 1
    team = (sys.argv[2] if len(sys.argv) > 2 else "-").lower()
    logf = sys.argv[3] if len(sys.argv) > 3 else None
    # autojoin.py (the launcher's, for the first lobby's team) is attached for the first minutes: two copies of the agent
    # doing lobby steps at once is asking for trouble, so this one waits until autojoin is done (4 minutes at most)
    import subprocess
    end = time.time() + 240
    while time.time() < end:
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                                "@(Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | Where-Object { $_.CommandLine -match 'autojoin\\.py' }).Count"],
                               capture_output=True, text=True, timeout=30)
            if r.stdout.strip() in ("", "0"):
                break
        except Exception:
            break
        time.sleep(5)
    import frida
    dev = frida.get_local_device()
    session = None
    end = time.time() + 150
    while time.time() < end:                  # the game may still be starting
        try:
            session = dev.attach(pid)
            break
        except Exception:
            time.sleep(1.0)
    if session is None:
        log("follow: could not attach to your game", logf)
        return 1
    gone = [False]
    session.on("detached", lambda *a: gone.__setitem__(0, True))
    script = session.create_script((HERE / "input_agent.js").read_text())
    said = []                                 # the agent's answers ("join 127.0.0.1: on its way" / "...: failed" / "not at the main menu")
    script.on("message", lambda m, d: said.append(str((m.get("payload") or {}).get("message", "")) if isinstance(m, dict) else ""))
    script.load()
    api = script.exports_sync
    started = time.time()
    done_t = 0.0                              # the next_lobby.json we have followed already
    job = None                                # the one we are following: {t, address, map, team}
    last_press = last_join = 0.0
    presses = joins = team_presses = 0
    log(f"follow: watching your game (pid {pid})", logf)
    try:
        while not gone[0]:
            time.sleep(0.5)
            try:
                lob = api.lobby() or {}
                mp = api.max_players() or {}
            except Exception:
                continue
            state, has_lobby = lob.get("state"), bool(mp.get("lobby"))
            if job is None:
                try:
                    j = json.loads(NEXT.read_text())
                    if float(j.get("t", 0)) > max(done_t, started) and time.time() - float(j["t"]) < 300:
                        job, presses, joins, team_presses = j, 0, 0, 0
                        log(f"follow: the next match is up ({j.get('map') or '?'}): taking your game there", logf)
                except (OSError, ValueError, KeyError, TypeError):
                    pass
            if job is None:
                continue
            now = time.time()
            if now - float(job["t"]) > 180:
                log("follow: gave up on this one (3 minutes): join it by hand", logf)
                done_t, job = float(job["t"]), None
                continue
            if state == PLAYING and not has_lobby:          # the score screen: Continue (it may hold a few seconds)
                if now - last_press > 2.0 and presses < 40:
                    # (19 Nov: a window over the game - it ignores keys without the focus: it gets the focus for the press)
                    fake = not in_front(pid)        # (only then: the agent's fake focus also holds the mouse back)
                    if fake:
                        try: api.set_fake_focus(True)
                        except Exception: fake = False
                        time.sleep(0.2)
                    api.key(*RETURN_KEY, True); time.sleep(0.1); api.key(*RETURN_KEY, False)
                    if fake:
                        time.sleep(0.2)
                        try: api.set_fake_focus(False)
                        except Exception: pass
                    last_press, presses = now, presses + 1
                    if presses in (1, 10, 25): log(f"follow: Continue on the score screen (press {presses})", logf)
            elif state == MENU and not has_lobby:           # the main menu: join the new lobby
                # (23 Nov, the user: once the game sat at the main menu and never joined - five tries, each "on its way", none
                #  answered: the game only does it on its own frame, and a window over it can hold that back.) Keep trying every
                #  4 s for the whole 3 minutes, giving the game the focus for each try (the agent loads the main menu itself).
                if now - last_join > 4.0:
                    fake = not in_front(pid)
                    if fake:
                        try: api.set_fake_focus(True)
                        except Exception: fake = False
                    said.clear()
                    ok = api.join_lobby(str(job.get("address") or "127.0.0.1"))
                    time.sleep(1.0)
                    if fake:
                        try: api.set_fake_focus(False)
                        except Exception: pass
                    last_join, joins = time.time(), joins + 1
                    ans = next((x for x in said if "join" in x or "menu" in x), "no answer yet")
                    log(f"follow: joining {job.get('address') or '127.0.0.1'} (try {joins}): {ans if ok else 'refused'}", logf)
            elif state == LOBBY_STATE and has_lobby:        # in the new lobby: the team, if one is named
                t_ = (job.get("team") or team or "-").lower()
                if t_ in PICK and lob.get("pick") == 0 and now - last_press > 3.0 and team_presses < 10:
                    api.lobby_join(PICK[t_])
                    last_press, team_presses = now, team_presses + 1
                    log(f"follow: joined the {t_} team", logf)
                elif t_ not in PICK or lob.get("pick") != 0:
                    log("follow: you are in the next match's lobby", logf)
                    joined_mark()
                    done_t, job = float(job["t"]), None
            elif state == PLAYING and has_lobby and joins:  # straight into the match
                log("follow: you are in the next match", logf)
                joined_mark()
                done_t, job = float(job["t"]), None
    finally:
        try:
            script.unload()
            session.detach()
        except Exception:
            pass
    log("follow: your game closed", logf)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print("follow:", e)
        sys.exit(1)
