@echo off
cd /d "%~dp0"
set HORDE_WINDOWS=visible
".venv\Scripts\python.exe" -u horde.py --map drygulch --minutes 6 --ramp 12
exit
