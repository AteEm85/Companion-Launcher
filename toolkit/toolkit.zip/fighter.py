"""Fighting brain for the ghost player (no game, no sockets: pure logic, testable offline).

Each tick the ghost tells the Fighter where it stands and where the human is; the Fighter answers with where to move,
which way to face and whether to shoot. It uses the map data in nav.py (the same data the launcher's bots use):
  - no line of sight (or beyond the engage range): chase along a route of portal waypoints (Level.route),
  - line of sight and in range: face the target (turning at the tier's turn speed), keep the tier's fighting distance,
    strafe, and shoot after the tier's reaction time.

The difficulty is the bots' own: the same table brain.DIFFICULTY (easiest .. hell) sets the aim wobble, reaction time,
turn speed, sprint and strafe shares, engage range and shot time. A shot hits while the aim wobble is inside the body
width; the ghost has no mouse, so each shot simply lands with the hit rate brain.py's table is tuned for
(~100% nightmare, 80% hard, 70% normal, 60% easy, 35% easiest; hell never misses its aim).
"""
import math
import os
import random

SWIM_SPEED = float(os.environ.get("GHOST_SWIM_SPEED", "0.55"))     # share of the walking pace in the water (the bots' swimming is slow too)

LEVELS = ("easiest", "easy", "normal", "hard", "nightmare", "hell")

# the same numbers as brain.DIFFICULTY (used when brain.py can't be imported next to the ghost)
FALLBACK = {
    "easiest": {'aim_error': 6.0, 'aim_mult': 2.0, 'shot_mult': 1.4, 'recheck': 0.60, 'reaction': 0.25, 'sight_memory': 1.5, 'turn_speed': 160.0, 'sprint': False, 'sprint_frac': 0.0, 'strafe_frac': 0.15},
    "easy": {'aim_error': 4.5, 'aim_mult': 1.5, 'shot_mult': 1.15, 'recheck': 0.45, 'reaction': 0.25, 'sight_memory': 1.5, 'turn_speed': 240.0, 'sprint': True, 'sprint_frac': 0.45, 'strafe_frac': 0.2},
    "normal": {'aim_error': 4.0, 'aim_mult': 1.35, 'shot_mult': 1.07, 'recheck': 0.40, 'reaction': 0.25, 'sight_memory': 1.5, 'turn_speed': 285.0, 'sprint': True, 'sprint_frac': 0.68, 'strafe_frac': 0.52},
    "hard": {'max_engage': 170.0, 'aim_error': 3.6, 'aim_mult': 1.2, 'shot_mult': 1.0, 'recheck': 0.35, 'reaction': 0.25, 'sight_memory': 1.5, 'turn_speed': 330.0, 'sprint': True, 'sprint_frac': 0.9, 'strafe_frac': 0.85},
    "nightmare": {'max_engage': 220.0, 'aim_error': 0.35, 'reaction': 0.1, 'turn_speed': 420.0, 'sprint': True, 'sprint_frac': 1.0, 'strafe_frac': 1.0},
    "hell": {'max_engage': 300.0, 'aim_error': 0.0, 'reaction': 0.0, 'turn_speed': 600.0, 'sprint': True, 'sprint_frac': 1.0, 'strafe_frac': 1.0, 'keep_distance': 18.0, 'respawn_delay': 0.3},
}
DEFAULTS = dict(max_engage=120.0, keep_distance=30.0, shot_mult=1.0, aim_mult=None, sight_memory=1.0, reaction=0.25, recheck=0.0,
                turn_speed=240.0, sprint=True, sprint_frac=1.0, strafe_frac=1.0, aim_error=4.0, respawn_delay=1.5)
# How often a shot lands, per tier: the hit rates brain.py's aim table is tuned for (its comment: about 100% nightmare, 80% hard,
# 70% normal, 60% easy and 35% easiest of nightmare's; hell never misses its aim). The ghost has no mouse, so it rolls them directly.
HIT_RATE = {"easiest": 0.35, "easy": 0.60, "normal": 0.70, "hard": 0.80, "nightmare": 1.0, "hell": 1.0}
# Measured against the bots themselves (11 Nov, Normal, 3 bots + 3 ghosts on town_2p): the aim model landed 65% of a ghost's pistol
# shots on bots (81% under 20 units), the bots about 40% of theirs; a game's bot also misses a target that strafes and its bullets
# take the real path, which the model leaves out. Each shot the model calls a hit now lands with this chance (Easiest .. Hard; the
# Nightmare / Hell bots hardly miss). GHOST_HIT_SCALE=1: as before.
# 11 Nov, 6 bots + 6 ghosts (Normal, with weapon pickups on both sides): bots 133 kills, ghosts 82; at 0.6 the ghosts died as often
# as the bots but killed 40% less. Raised: easiest .55, easy .65, normal .75, hard .85.
TIER_HIT = {"easiest": 0.42, "easy": 0.50, "normal": 0.56, "hard": 0.64,
            "nightmare": 0.62, "hell": 0.70}        # (15 Nov, the user: Nightmare ghosts killed far faster than Nightmare bots; the model's
                                                   #  shots landed every time, the bots' real bullets miss a strafing player now and then)
if os.environ.get("GHOST_HIT_SCALE") == "1": TIER_HIT = {}
# 16 Nov (the user: the ghosts are far tougher than the bots; on Nightmare they kill within 2-3 s of a respawn, against Nightmare
# bots the user gets several kills first). Measured from deathwatch_log.txt and horde_logs\events.txt:
#   8-10 Nightmare BOTS (15 Nov 19:31): the user died every ~16 s;  10 Nightmare GHOSTS (16 Nov 04:19): every ~7 s (22 deaths in
#   171 s). Less the 3-4 s of dying and respawning: ~12 s alive against ~3.5.  Easiest .. Hard: 1 death in 10 kills against bots,
#   4 in 16 against ghosts. So about three times too deadly on every tier.
# The tables are the same; the difference is that a bot plays through the game. Every 0.05 s it turns its view to where the target
# was when it last read the game, and its bullets leave along that view until the next turn: the view trails a target that moves
# sideways, and its trigger waits while the view is off the body. A player who keeps strafing is hard for a real bot to hit at any
# range; one who stands, runs straight at it or turns back is not. The ghost has no view: its shots landed whenever the tier's
# wobble allowed, strafing or not.
# Now each shot is also off by the target's sideways speed (across the line from the ghost) x AIM_LAG. In the 16 Nov recording
# that leaves the aim on the user's body about 40% of the time at 0.10 s (49% at 0.07, 65% at 0.05); pellets still forgive by
# their spread. A rifle or a shotgun waits for the aim as a bot's trigger does (the error inside the body + 1 degree + the
# spread) for up to LAG_HOLD s, then fires anyway. The same for every tier, so the tiers keep their order.
# Offline (a target strafing 60% of the time) that takes a third to a half of the hits; the measured gap is about three times, so
# the flat cuts above (TIER_HIT) came down by a quarter as well: together a bit over half the hits gone on every tier.
# GHOST_AIM_LAG=0: off (the old ghosts). Raise it to make every ghost miss a moving player more.
AIM_LAG = float(os.environ.get("GHOST_AIM_LAG", "0.10")); LAG_HOLD = 1.2
# The aim itself, like brain.Brain.aim: the aim drifts a random walk either side of the target (steps of 0.3 x the wobble, never more
# than the wobble). Easiest .. hard: 3 degrees x aim_mult, + 15 x aim_mult x (turning speed / turn speed) while moving, + 7 when hurt;
# nightmare 0.35 degrees, hell none. A shot lands when the drift is inside the target's width at that distance (+ a shotgun's spread):
# so the higher the tier the deadlier, close up nearly every tier hits, and far away only the sharp ones. GHOST_AIM=flat: the old flat rates.
AIM_MODEL = os.environ.get("GHOST_AIM", "wobble")
# The bots' bursts (brain.Brain.shot_gate; 11 Nov, the user: Normal ghosts "way too difficult", match the bots). Easiest .. Hard bots
# fire 1 to 4 shots (a shotgun 1) at the gun's own rate, then wait SHOT_TIME x the tier's shot_mult (Normal: pistol 1.5 s, rifle 1.7 s,
# shotgun 1.9 s) before the next burst. The ghosts kept firing at the gun's rate the whole magazine. Nightmare and Hell bots have no
# such wait (no shot_mult), nor do the ghosts. GHOST_BURSTS=0: no bursts.
BURSTS = os.environ.get("GHOST_BURSTS", "1") == "1"
WALL_R = float(os.environ.get("GHOST_WALL_R", "1.3"))     # (how near a wall a ghost's centre may come: wall_push)
DOOR_REACH = float(os.environ.get("GHOST_DOOR_REACH", "4.0"))   # (stop and "use" a door this near its middle: the game's use reaches 5)
SHOT_TIME = {"pistol": 1.4, "rifle": 1.6, "sgun": 1.8, "dbsgun": 2.0}; PUMPS = ("sgun", "dbsgun")
BURST_LEVELS = ("easiest", "easy", "normal", "hard")
# The longest tick the movement keeps up with (was 0.2 s). On the host PC the ghosts' ticks were 0.2 s apart on average and up to 0.7 s
# (10 Nov recordings): with the 0.2 cap a ghost covered less ground than the speed it reported, so the other games ran it ahead and pulled
# it back with every update - the "teleporting" the user saw.
DT_MAX = float(os.environ.get("GHOST_DT_MAX", "0.5"))
DOOR_TRIES, DOOR_RETRY = 3, 1.6        # the bots' (brain.DOOR_TRIES / DOOR_RETRY): nudges at one door, seconds between them
SMOOTH_ACCEL = float(os.environ.get("GHOST_SMOOTH", "0"))   # momentum on every walk (route following too), units/s per s; 0 = off
DOOR_BACK = float(os.environ.get("GHOST_DOOR_BACK", "4.0")); DOOR_BACK_T = 0.6; DOOR_USE_T = 0.35     # after "use": this far back from the door, in this long
DOOR_WAIT = float(os.environ.get("GHOST_DOOR_WAIT", "1.2"))     # seconds a ghost waits for a door it opened
DOOR_STAND = float(os.environ.get("GHOST_DOOR_STAND", "0.5"))   # seconds a ghost may stand still inside a door's own sector before it steps out
DROP_MAX = float(os.environ.get("GHOST_DROP_MAX", "40"))       # furthest a ghost steps down off a ledge into a neighbouring sector
JUMP_UP = float(os.environ.get("GHOST_JUMP_UP", "5.0"))        # highest ledge a ghost jumps onto (the bots' jump clears about 4.4 + the step)
TURN_TERM = float(os.environ.get("GHOST_TURN_TERM", "0.33"))
BODY_HALF = float(os.environ.get("GHOST_BODY_HALF", "1.5"))      # half a player's width (units)
# Crouching (decoded from the user's crouch recording, 7 Nov 2026, GhostLogs\crouch_rec.jsonl / tools\crouch_states.py): pose 3, sent as a
# 0x403 when it starts and carried in every state while crouched, walking too (nothing else in the state changes: the position stays the
# feet). Crouch-walk 16 a second. A crouch-jump is the plain jump (up at 29.9, apex 7.35 above the floor) with pose 3 held, and it only
# works crouch FIRST, then jump (user: crouching after take-off doesn't get you through). Out of Simms' lit windows the user stood ~2.3
# from the wall, crouched, jumped straight up and moved through ~0.15 s later at 17-21 a second, landing in the street a second after.
CROUCH = os.environ.get("GHOST_CROUCH", "1") == "1"             # 0: ghosts never crouch (crouch-only openings are routes of last resort)
CROUCH_SPEED = float(os.environ.get("GHOST_CROUCH_SPEED", "16"))
CROUCH_AHEAD = 4.0                                               # crouch this far before a crouch-only waypoint
CROUCH_FIRST = 0.15                                              # seconds crouched before a crouch-jump takes off
LEAP_AT = 2.0; JUMP_UP_LEAP = 6.0
HOP_FLY = float(os.environ.get("GHOST_HOP_FLY", "5.5"))   # a hop up higher than this is flown (straight up, then over), not one tick
SWIM_REACH = 6.0                      # underwater: close enough for a stab or a punch
RIM_STEP = 4.0                        # climbing out of a hole: only from this close to its rim
HOLE_BERTH = 1.0                      # walking keeps this far outside a hole's rim
SWIM_STUCK = 2.0                      # on the way out of the water and stuck this long: straight out through the nearest hole
def _ice_holes(level):
    """[(x, z, radius, surface y)] of the holes in this map's frozen pools (icewater.HOLES), when the level has them (the Christmas
    Horde's ice map: the hole sectors are water surfaces), else []"""
    if os.environ.get("GHOST_ICE_SWIM", "1") != "1": return []
    try:
        import icewater
        name = (getattr(level, "name", None) or os.environ.get("GHOST_LEVEL", "")).lower()
        out = []
        for pool, cx, cz, r in icewater.HOLES.get(name, []):
            y = level.floor_at(pool, cx, cz)
            if level.water_at(cx, y - 1.0, cz) is None: continue          # (no water below: not the ice map)
            out.append((cx, cz, r, y))
        return out
    except Exception:
        return []
JUMP_VY = 29.9; GRAVITY = 60.7                                   # (29.9^2 / (2 x 60.7) = the measured 7.35 apex)
CJ_AT = 3.0                                                      # take off this close to the opening (the user: 2.3)
CJ_DELAY = 0.12; CJ_SPEED = 19.0                                 # straight up first, then forward at this pace until landing
FALL_G = float(os.environ.get("GHOST_FALL_G", "60"))
FALL_MIN = float(os.environ.get("GHOST_FALL_MIN", "4"))           # a floor this much lower in one step is a ledge: fall to it             # gravity for a fall off a ledge (the jump's measured 60)
STEP = 2.0                                                       # (nav's STEP_UP: a floor further below than this is a drop)
GAP_AT = 2.0                                                     # take off for a jump across a gap (nav GAPS) this close to its spot
try:
    import nav as _nav; HIGH_JUMP_UP = _nav.HIGH_JUMP_UP
except Exception: HIGH_JUMP_UP = 8.5


def profile(level):
    """The bots' numbers for this difficulty (brain.DIFFICULTY when it can be imported, else the copy above)."""
    level = {"average": "easy"}.get((level or "normal").lower(), (level or "normal").lower())
    if level not in LEVELS: level = "normal"
    table = None
    try:
        import brain
        table = brain.DIFFICULTY
    except Exception:
        table = None
    row = (table or FALLBACK).get(level) or FALLBACK[level]
    p = dict(DEFAULTS); p.update({k: v for k, v in row.items() if k in DEFAULTS}); p["level"] = level
    return p


def wrap_pi(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


try:
    from nav import PLAYER_HEIGHT
except Exception:
    PLAYER_HEIGHT = 5.6
EYE = 5.0                                                # eye height above the feet for the line of sight
# 150 (11 Nov, was 260): with 260 a third of the ghosts' states landed 3+ units from where the other games, carrying on the last
# speed sent, had them (the jumpy look; a human's 8-23%); offline with 150: 4%. 0 to full run in 0.3 s, a reversal in 0.6.
ACCEL = float(os.environ.get("GHOST_ACCEL", "150"))      # units/s^2: 0 to full run (44) in ~0.17 s, a full reversal in ~0.35 s
# Measured on the user's own Dr Death (11 Nov, GhostLogs\move_rec.jsonl: 6 minutes of running, strafing, stops and starts, 1615 states).
# A key held pushes hard: from a standstill 0.5 -> 39.1 -> 46.1 in two states at a run (~260 units/s^2), 0.3 -> 22.0 -> 31.0 at a walk
# (~145). Let go and the player GLIDES to a stop: exactly 12.0 less every 0.15 s state, at any speed (80 units/s^2): ~0.57 s and
# ~13 units from a run. The ghosts sped up at 150 and braked at 150 (half the slide).
# The push stays at 150 for now: offline (3 Dr Death ghosts, Simms, 85 s each) the measured 260 / 145 put 16% of the ghosts' states 3+
# units from where the other games had them (150: 7-8%; the user 6.1%) and doubled their turning (p50 91 deg/s; the user 60). A ghost
# changes the way it wants to go far more often than a player (strafe flips, advance / strafe at the fighting distance's edge), and the
# softer push smooths that over. With the glide only: 7.0%, turning p50 69. GHOST_ACCEL_MODEL=0: the old single ACCEL both ways.
ACCEL_MODEL = os.environ.get("GHOST_ACCEL_MODEL", "1") == "1"
ACCEL_RUN = float(os.environ.get("GHOST_ACCEL_RUN", str(ACCEL)))    # a key held, toward a run (a player: ~260)
ACCEL_WALK = float(os.environ.get("GHOST_ACCEL_WALK", str(ACCEL)))  # a key held, toward a walk and slower (a player: ~145)
GLIDE = float(os.environ.get("GHOST_GLIDE", "80"))              # no key held: slowing to a stop
STRAFE_FB = float(os.environ.get("GHOST_STRAFE_FB", "0.7"))      # strafing at the fighting distance: up to this much forward / back with the side step (0 = straight sideways); 0.7 = up to 41 degrees off sideways
UNSTICK_SPEED = 30.0                                     # a stuck ghost steps out at walking pace (it used to jump the 3 units in one state)
STAND_ROOM = float(os.environ.get("GHOST_STAND_ROOM", PLAYER_HEIGHT - 0.1))      # headroom a standing player needs


def _seg_dist(p, a, b):
    """distance from point p to the segment a-b (all (x, z))"""
    ax, az = a; bx, bz = b; dx, dz = bx - ax, bz - az; L2 = dx * dx + dz * dz
    t = 0.0 if L2 <= 0 else max(0.0, min(1.0, ((p[0] - ax) * dx + (p[1] - az) * dz) / L2))
    return math.hypot(p[0] - ax - t * dx, p[1] - az - t * dz)


def stand_locate(L, x, y, z, prefer=None, room=None):
    """The sector a STANDING player at (x, y, z) is in. Like nav's locate (the floor just below y), but
    - sectors a standing player does not fit in are skipped: the crawl spaces under Hargrove's stairs (ceilings 1.9-3.9) were
      taken as floor, so ghosts walked INSIDE the staircase, where the game cannot show them or let them be hit (the "vanishing");
    - `prefer` (the sector we are in) is kept while the point is still in it at that height, like the game itself does (a player only
      changes sector by crossing a wall); a tie went to the lower sector number, e.g. the closed room 41 inside the roof sector 70."""
    need = STAND_ROOM if room is None else room
    def gap_in(i):
        s = L.sectors[i]
        if not s.walls or not s.contains(x, z): return None
        f = L.floor_at(i, x, z); c = L.ceiling_at(i, x, z)
        if c - f < need or y < f - 1.0 or y > c + 1.0: return None
        return y - f
    try:
        if prefer is not None:
            g = gap_in(prefer)
            if g is not None and g < 2.5: return prefer
        best, bg = None, None
        for s in L.sectors:
            g = gap_in(s.index)
            if g is not None and (bg is None or g < bg): best, bg = s.index, g
        if best is None:                                   # nav's fallback (a door panel's spot, a seam), if a player fits there
            r = L.locate(x, y, z)
            if r is not None and L.ceiling_at(r, x, z) - L.floor_at(r, x, z) >= need: best = r
        return best
    except Exception:
        return None

def doors_at(level, x, z, margin=0.8):
    """every door panel whose line passes within margin of (x, z)"""
    out = []
    for q in (getattr(level, "panels", None) or []):
        a, b = q.get("a"), q.get("b")
        if not a or not b:
            if math.hypot(q["x"] - x, q["z"] - z) <= margin + 0.7: out.append(q)
            continue
        dx, dz = b[0] - a[0], b[1] - a[1]; ll = dx * dx + dz * dz
        t = 0.0 if ll <= 0 else max(0.0, min(1.0, ((x - a[0]) * dx + (z - a[1]) * dz) / ll))
        if math.hypot(x - (a[0] + dx * t), z - (a[1] + dz * t)) <= margin: out.append(q)
    return out
def door_at(level, x, z, margin=0.8):
    """the door panel (nav's dict) whose line passes within `margin` of (x, z), or None. By the panel's line, not by its sector's
    outline: a barred jail door's sector is drawn bar by bar, and a point between two bars is in no sector at all."""
    for q in (getattr(level, "panels", None) or []):
        a, b = q.get("a"), q.get("b")
        if not a or not b:
            if math.hypot(q["x"] - x, q["z"] - z) <= margin + 0.7: return q
            continue
        dx, dz = b[0] - a[0], b[1] - a[1]; ll = dx * dx + dz * dz
        t = 0.0 if ll <= 0 else max(0.0, min(1.0, ((x - a[0]) * dx + (z - a[1]) * dz) / ll))
        if math.hypot(x - (a[0] + dx * t), z - (a[1] + dz * t)) <= margin: return q
    return None

class Fighter:
    def __init__(self, level, difficulty="normal", speed_run=44.0, speed_walk=30.0, rng=None, base_gap=1.2, see_reach=400.0, hit_scale=1.0, reach=None,
                 energy=None, energy_max=100.0, energy_resume=0.25):
        self.L = level
        self.p = profile(difficulty)
        if reach:                                             # a short-range weapon (shotgun, knife): only fight, and close in, within its reach
            self.p['max_engage'] = min(self.p['max_engage'], reach); self.p['keep_distance'] = min(self.p['keep_distance'], reach * 0.4)
        self.rng = rng or random.Random()
        self.run, self.walk = speed_run, speed_walk
        self.no_sprint = False                                    # (Survival Horde's slow melee tiers: never sprints)
        self.fall_vy = 0.0                                        # falling off a ledge (units/s, down is negative)
        self.impacts = []                                         # landing speeds (units/s down) since the ghost last looked: fall damage
        self.base_gap, self.see_reach, self.hit_scale = base_gap, see_reach, hit_scale
        self.path = []; self.path_goal = None; self.path_t = -99.0
        self.strafe = 1; self.strafe_until = 0.0; self.strafing = True; self.strafe_blocked_until = 0.0
        self.sprinting = True; self.sprint_until = 0.0
        # stamina (the character file's E_REST / E_MOVE per second, E_JUMP per jump, see ghost.char_energy): running sideways drains it (a straight
        # run is free: players tap W / S), anything else refills it; at zero no more running (and a tired pant, tired_snd) until energy_resume of the maximum is back. energy=None: no stamina.
        self.energy_use = energy; self.energy_max = energy_max; self.energy = energy_max; self.energy_resume = energy_resume
        self.tired = False; self.tired_snd = False; self.jumps = 0; self.dt = 0.15
        self.next_fire = 0.0; self.hold_fire_until = 0.0              # (reloading)
        self.last_shot = -99.0; self.spray = False
        self.weapon = None; self.burst_w = None; self.burst_n = 0; self.burst_len = 1; self.burst_wait = 0.0      # (the bots' bursts)
        self.seen_since = None; self.lost_at = None          # for the reaction time / sight memory
        self.yaw = None; self.turn_rate = 0.0
        self.aim_off = 0.0; self.pitch_off = 0.0; self.spread = 0.0; self.weapon_aim = 1.0; self.hurt = False; self.moving_now = False
        self.tgt_vel = (0.0, 0.0); self.lag_wait = None     # the target's velocity (set by the ghost), since when a shot waits for the aim
        self.scatter = 0.0      # degrees each shot strays at random on top of the aim (fanning a pistol)
        self.y_off = None                                     # the spawn height minus the floor (kept for the whole life)
        self.mode = "idle"; self.last = None; self.cur_y = 0.0; self.cur_sec = None; self.vel = (0.0, 0.0)
        self.los_cache = False; self.los_until = 0.0; self.los_tgt = None
        # Jump moves recorded from the user's own player (jump_macros_<map>.json, made from a ghost log of a jumps-only game): run-ups
        # and jumps onto crates, porch roofs and rooftops the map's route finder knows no way onto. Played back exactly as recorded.
        self.broken = set()                                  # edge keys of windows shot out (filled by the ghost from the game's 0x422)
        # GHOST_CROUCH=0: ghosts never crouch, so openings only a crouching player fits through (Simms' small lit windows, 5 high with a
        # 4-high sill) are routes of last resort. Simms (7 Nov): before ghosts could crouch, the way out of the west building's upstairs
        # room went through the window at (42, 248); the ghosts walked up to it and stood there for good, the doorway right beside them.
        # With crouching on, the ghosts use crouch openings walked through (a low doorway, a gap) and window crouch-jumps; a crouched LEAP up onto
        # a low ledge (Hargrove's crate-to-stairs jump at (416, 434): 8 up, more than a jump) stays a route of last resort like before.
        try:
            ce = [e for es in level.edges.values() for e in es if e.crouch]
            self.crouch_ok = {e.key for e in ce if not e.jump or e.crouch_jump or getattr(e, "leap", None)} if CROUCH else set()   # (a LEAP: leap_step)
            self.no_crouch = {e.key for e in ce if e.key not in self.crouch_ok}
        except Exception: self.no_crouch = set(); self.crouch_ok = set()
        self.crouch = False; self.crouch_since = 0.0; self.cj = None; self.bridge = None     # crouched; a crouch-jump in the air; a strip walked over
        self.swimming = False; self.holes = _ice_holes(level)                      # under the ice (Orleans' frozen pools): see swim_step
        self.pool_water = set(getattr(level, "water", ())) if self.holes else set()     # (the Christmas Orleans: every pool is iced over)
        # The highest ledge a ghost hops onto when the route's next point is up there: JUMP_UP, or the map's own jump where the bots'
        # is longer (Bill's Homestead, Dookes: maps built from 8-high crates; plus the 0.5 JUMP_UP has over the bots' 4.5), and the
        # longer HIGH_JUMPS ones on their own edges. Only into the sector the route goes to next: a ghost brushing past a crate stays down.
        try: self.climb = max(JUMP_UP, float(getattr(level, "jump_up", 0.0)) + 0.5)
        except Exception: self.climb = JUMP_UP
        try: self.high_jumps = set(getattr(level, "high_jumps", ()))
        except Exception: self.high_jumps = set()
        try: self.crouch_room = float(getattr(level, "crouch_height", 3.0))
        except Exception: self.crouch_room = 3.0
        # Crawl spaces: sectors with real floor room (not just a window's or a doorway's thickness) and nowhere to stand up, e.g. the spaces under
        # Hargrove's stairs (ceiling 3.0). Off limits even crouched (GHOST_CRAWL=1 lets them in): a ghost inside the stairs was the "vanishing".
        self.crawl = set()
        if CROUCH and os.environ.get("GHOST_CRAWL", "0") != "1":
            for s in level.sectors:
                try:
                    if not s.walls or len(s.vertices) < 3: continue
                    xs = [v[0] for v in s.vertices]; zs = [v[1] for v in s.vertices]
                    if min(max(xs) - min(xs), max(zs) - min(zs)) < 2.5: continue
                    hs = [level.ceiling_at(s.index, *v) - level.floor_at(s.index, *v) for v in s.vertices]
                    if max(hs) >= STAND_ROOM: continue
                    # (14 Nov: Dry Gulch's mine tunnel (sector 120, 3.75 high) is a real passage players crouch through, between two
                    #  rooms. The routes went through it, the fighter wouldn't, and every ghost ended up stuck at its mouth. A crawl
                    #  space with room to spare (3.5+) that joins two places to stand is a passage: walked through crouched. The
                    #  spaces under Hargrove's stairs are 3.0 high and stay off limits.)
                    if min(hs) >= 3.5:
                        nb = set()
                        for w in s.walls:
                            a_ = w.adjoin
                            if a_ is None or a_ < 0: continue
                            A = level.sectors[a_]
                            if abs(A.floor - s.floor) <= 2.5 and A.ceiling - A.floor >= STAND_ROOM: nb.add(a_)
                        if len(nb) >= 2: continue
                    self.crawl.add(s.index)
                except Exception: pass
            try: self.no_crouch |= {e.key for es in level.edges.values() for e in es if e.key[1] in self.crawl}
            except Exception: pass
        self.bad_edges = {}                                  # edge key -> until when: openings we got stuck at, routed round for a while
        self.door_wait = 0.0; self.door_open = {}; self.stuck_at = None             # door panel (x, z) -> when we asked it open
        self.door_state = None          # set by ghost.py: panel -> True open / False closed (or still moving) / None not known
        self.door_tries = {}            # door panel -> (nudges, when the last was)
        # The doors' own sectors (Sanctuary's jail doors are strips 1 unit thick): walked through, never stood in. A ghost that
        # stops inside one blocks the door, which the user's game answers with a loud buzzing and by not drawing the ghost.
        self.door_secs = {q["sector"] for q in (getattr(level, "panels", None) or []) if q.get("sector") is not None}
        self.in_door = None                                                         # (x, z, since) while standing in one
        self.want_move = True; self.slide = None; self.strafe_fb = 0.0             # (the stuck check; a step out when stuck; a strafe's forward / back share)
        self.macro_cost = None; self.macros = []; self.play = None; self.macro_next = None; self.macro_check = 0.0
        try:
            import json as _j
            mp = os.environ.get("GHOST_MACROS") or os.path.join(os.path.dirname(os.path.abspath(__file__)), f"jump_macros_{(getattr(level, 'name_key', '') or getattr(level, 'name', '') or '').lower()}.json")
            if os.path.exists(mp): self.macros = _j.load(open(mp))
        except Exception: self.macros = []

    # ----- map helpers
    def room(self, crouched=None):
        """the headroom we need: a standing player's, or a crouching one's"""
        return self.crouch_room if (self.crouch if crouched is None else crouched) else STAND_ROOM

    def can_stand(self, x, y, z):
        """room to stand up here: the headroom over our feet in the sector we stand in (the highest floor under us), not just anywhere at
        this spot (in a window sill the street far below has room to spare)"""
        best = None
        for s in self.L.sectors:
            if not s.walls or not s.contains(x, z): continue
            try: f = self.L.floor_at(s.index, x, z); c = self.L.ceiling_at(s.index, x, z)
            except Exception: continue
            if f <= y + 0.5 and c > y and (best is None or f > best[0]): best = (f, c)
        return best is None or best[1] - max(best[0], y) >= STAND_ROOM

    def floor_below(self, x, z, ytop):
        """(floor, sector): the highest floor at (x, z) no higher than ytop with room for a crouching player above it, or None"""
        best = None
        for s in self.L.sectors:
            if not s.walls or not s.contains(x, z): continue
            try: f = self.L.floor_at(s.index, x, z); c = self.L.ceiling_at(s.index, x, z)
            except Exception: continue
            if f <= ytop and c - f >= self.crouch_room and (best is None or f > best[0]): best = (f, s.index)
        return best

    def sector(self, x, y, z, prefer=None):
        """Sector a standing player at the point is in (a crouching one while we crouch); the height is tried a little higher too (on stairs
        and slopes the point can sit just under the next floor). None in a crawl space (see self.crawl): we don't go in."""
        r = self._sector(x, y, z, prefer)
        if r is None or r in self.crawl: return None
        if self.crouch:
            # crouched, no dropping down to where we couldn't stand: under a staircase's overhang (Hargrove, the stairs at (418, 435): a crouching
            # ghost stepped off them onto the ground UNDER them - the "vanishing" again)
            try:
                f = self.L.floor_at(r, x, z)
                if f < y - 1.0 and self.L.ceiling_at(r, x, z) - f < STAND_ROOM: return None
            except Exception: return None
        return r

    def _sector(self, x, y, z, prefer=None):
        rm = self.room()
        blocked = set()
        # First the sector we are in and its neighbours (walking up a ramp, the next step's floor is a few units higher: at the old height
        # the first match was the ground UNDER the ramp, and the ghosts dropped through every ramp and stairway - 0 of 21 roofs reached)
        if prefer is not None:
            near = [prefer]
            # (21 Nov, the user: enemies walked through an invisible wall and fell into the creek below Buckshotville) never
            # through a wall flagged impassable (0x800: the map's invisible walls, fences, bars) unless it is breakable glass
            blocked = set()
            try:
                for w in self.L.sectors[prefer].walls:
                    if w.adjoin is None or w.adjoin < 0: continue
                    if w.flags & 0x800 and not w.flags & 0x4000: blocked.add(w.adjoin)
                    elif w.adjoin not in near: near.append(w.adjoin)
                blocked -= set(near)                  # (also joined by an open wall: fine)
            except Exception: pass
            ne_ = getattr(self.L, "no_enter", None)     # (20 Nov: the sectors nobody may step or hop into - Orleans' big building's roof:
            if ne_ and prefer not in ne_:               #  a clone strafing into its wall hopped up there anyway, off the route)
                near = [c for c in near if c not in ne_]
            nxt = self.path[0][3] if self.path else None
            for dy in (0.0, 0.5, 1.0, 2.0, 3.0, 4.0, JUMP_UP):    # (the last: a jump up onto a neighbouring ledge or crate)
                for cand in near:
                    # (21 Nov, the user: "only when needed to get to a player will they jump high" - a hop higher than the
                    #  ordinary jump only onto the sector the route goes to next, never by walking or strafing into a wall)
                    if dy > 5.0 and cand != nxt: continue
                    if stand_locate(self.L, x, y + dy, z, cand, room=rm) == cand: return cand
            lim = self.hop_limit(prefer, nxt)
            if nxt is not None and nxt in near and lim > JUMP_UP and stand_locate(self.L, x, y + lim, z, nxt, room=rm) == nxt: return nxt
        for dy in (0.0, 0.5, 1.0, 2.0, 4.0):
            sec = stand_locate(self.L, x, y + dy, z, prefer, room=rm)
            if sec is not None and prefer is not None and sec in blocked: continue      # (not through the invisible wall)
            if sec is not None: return sec
        # stepping DOWN off a ledge / out of a window opening into a neighbouring room or the street: the highest neighbouring floor
        # below us there (the checks above only look up to a few units; a ghost in a window sill 3 above the floor could never leave it)
        if prefer is not None:
            best = None
            for cand in near:
                try:
                    if not self.L.sectors[cand].contains(x, z): continue
                    fl = self.L.floor_at(cand, x, z); cl = self.L.ceiling_at(cand, x, z)
                except Exception: continue
                if y - DROP_MAX <= fl <= y + 0.5 and cl - fl >= rm and (best is None or fl > best[0]): best = (fl, cand)
            if best is not None: return best[1]
        return None

    def hop_limit(self, frm, to):
        """the highest ledge we hop up onto going from sector frm to sector to (see self.climb)"""
        return max(self.climb, HIGH_JUMP_UP + 0.5) if (frm, to) in self.high_jumps else self.climb

    def floor(self, sec, x, z):
        try: return self.L.floor_at(sec, x, z)
        except Exception: return None

    def sees(self, sec, a, b, ya=None, yb=None):
        """An open line from a to b (x, z): no wall in between (the map's flat check), and - with the heights given - the line from eye to eye
        stays in open air all the way: not through a floor or a ceiling (a ghost on the ground shot the human upstairs through the floor)."""
        try:
            if not self.L.sees({"index": sec, "x": a[0], "z": a[1]}, {"x": b[0], "z": b[1]}, reach=self.see_reach): return False
        except Exception: return False
        if ya is None or yb is None: return True
        # (19 Nov, the user: a ghost shot and killed him at the bottom of the water in the well) one under the water and the other
        # out of it: no sight through the surface
        try:
            if bool(self.L.in_water(a[0], ya, a[1])) != bool(self.L.in_water(b[0], yb, b[1])): return False
        except Exception: pass
        ea, eb = ya + EYE, yb + EYE
        d = math.hypot(b[0] - a[0], b[1] - a[1]); n = max(2, int(d / 2.0), int(abs(eb - ea) / 0.5))     # (steep lines: sample by height too)
        for i in range(1, n):
            f = i / n; px, pz, h = a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, ea + (eb - ea) * f
            ok = None
            for s in self.L.sectors:
                if not s.walls or not s.contains(px, pz): continue
                try:
                    if self.L.floor_at(s.index, px, pz) < h < self.L.ceiling_at(s.index, px, pz): ok = True; break
                except Exception: continue
                ok = False if ok is None else ok
            if ok is False: return False                       # inside the solid between floors (or under a ceiling) at this point
        return True

    def wall_push(self, sec, x, y, z, r=None):
        """(x, z) moved out to r from any wall nearby (12 Nov, the user: ghosts' bodies half into walls - in the jail, in the church).
        The route and the step checks follow the centre of the body only, and the other games draw a ghost where it says it is: a
        real player's body (about 1.5 across the middle) never gets that close to a wall. Walls: the sector's own and its neighbours'
        solid ones, and openings onto floor too high to step up on or a ceiling too low to stand under. Not door panels (the shut-door
        guard handles those). Only a push that lands on floor of the same height is kept."""
        r = WALL_R if r is None else r
        if sec is None or r <= 0: return x, z
        L = self.L
        if not hasattr(self, "_door_secs"):
            self._door_secs = {q.get("sector") for q in (getattr(L, "panels", None) or [])}
        try: S0 = L.sectors[sec]
        except Exception: return x, z
        secs = {sec} | {w.adjoin for w in S0.walls if w.adjoin is not None and w.adjoin >= 0}
        nx, nz = x, z
        for _ in range(2):
            moved = False
            for si in secs:
                try: S = L.sectors[si]
                except Exception: continue
                for w in S.walls:
                    if w.adjoin is not None and w.adjoin >= 0:
                        if w.adjoin in self._door_secs or si in self._door_secs: continue
                        try:
                            A = L.sectors[w.adjoin]
                            if A.floor <= y + 2.0 and A.ceiling >= y + 5.5: continue          # (an opening it can walk through)
                        except Exception: continue
                    try: a, b = S.vertices[w.v1], S.vertices[w.v2]
                    except Exception: continue
                    dx, dz = b[0] - a[0], b[1] - a[1]; ll = dx * dx + dz * dz
                    if ll <= 1e-9: continue
                    t = max(0.0, min(1.0, ((nx - a[0]) * dx + (nz - a[1]) * dz) / ll))
                    cx, cz = a[0] + dx * t, a[1] + dz * t; d = math.hypot(nx - cx, nz - cz)
                    if 1e-6 < d < r:
                        k = (r - d) / d; nx += (nx - cx) * k; nz += (nz - cz) * k; moved = True
            if not moved: break
        if (nx, nz) == (x, z): return x, z
        s2 = self.sector(nx, y, nz, prefer=sec)
        if s2 is None: return x, z
        f2 = self.floor(s2, nx, nz)
        if f2 is None or abs(f2 - y) > 1.0: return x, z
        try:
            if s2 != sec and self.L._march(sec, (x, z), (nx, nz)) is None: return x, z
        except Exception: return x, z
        return nx, nz

    def can_step(self, sec, a, b):
        """a straight step from a to b (x, z) that stays on open floor of the map: no wall in between, and it ends in a sector the line
        actually walks into (not one stacked above or below it, or a room with no open way in) where a standing player fits."""
        dest = self.sector(b[0], self.cur_y, b[1], prefer=sec)
        if dest is None: return False
        if self.door_state is not None and self.closed_door_on(a, b): return False      # (a shut door is a wall)
        try: path = self.L._march(sec, a, b)
        except Exception: return False
        if path is None and dest != sec:
            # standing IN a window opening (its walls carry the glass flag, and the map keeps them "impassable" even once the glass is
            # shot out): the ways out of the sill are those walls - the ghosts stood there until a shot shoved them off
            try:
                W = self.L.sectors[sec].walls
                if any(w.adjoin == dest and (w.flags & 0x4000 or w.flags & 0x800) for w in W) and any(w.flags & 0x4000 for w in W):
                    return self.L.sectors[dest].contains(*b)
            except Exception: pass
        if path is None and dest != sec and any(p[3] == dest for p in self.path[:2]):
            # a jump the route asks for (onto a crate, a ledge, a porch): the walking check never passes such a portal
            try: ok = self.L.sectors[dest].contains(*b) and any(w.adjoin == dest for w in self.L.sectors[sec].walls)
            except Exception: ok = False
            return ok
        if path is None or dest not in path: return False
        try: return dest != sec or self.L.clear_line(sec, {"x": a[0], "z": a[1]}, {"x": b[0], "z": b[1]})       # (body width inside the room: posts, frames)
        except Exception: return True

    def smooth(self, me, out):
        """Momentum (11 Nov, the user: the ghosts' movement "still so jumpy"). The other games draw a player where its last state
        said, carried on at the speed it sent; a ghost that changed course or speed between two states (every 0.15 s) was pulled to
        a new spot each time: a third of its states landed 3+ units from where the other games had it, a human's 8-23%. Like a
        player's, its speed now changes by at most ACCEL a second, on open floor (same room, a clear step); anywhere else (stairs,
        ledges, doors, jumps) it moves as before."""
        dt = self.dt; sv = getattr(self, "sv", (0.0, 0.0))
        want = (out["vx"], out["vz"]) if out.get("moving") else (0.0, 0.0)
        ok_mode = self.mode in ("chase", "engage", "idle") and self.play is None and self.cj is None and self.slide is None and abs(out.get("vy", 0.0)) < 0.5
        if SMOOTH_ACCEL <= 0 or not ok_mode or abs(out["y"] - me[1]) > 0.3:
            self.sv = want; return out
        dv = (want[0] - sv[0], want[1] - sv[1]); m = math.hypot(*dv); lim = SMOOTH_ACCEL * dt
        if m <= lim:
            self.sv = want; return out
        nv = (sv[0] + dv[0] * lim / m, sv[1] + dv[1] * lim / m)
        cx, cz = me[0] + nv[0] * dt, me[2] + nv[1] * dt
        sec = self.cur_sec
        try:
            f = self.floor(sec, cx, cz) if sec is not None and self.L.sectors[sec].contains(cx, cz) else None
            ok = f is not None and abs(f - me[1]) < 0.3 and self.can_step(sec, (me[0], me[2]), (cx, cz))
        except Exception: ok = False
        if not ok:
            self.sv = want; return out
        self.sv = nv
        out = dict(out); out.update(x=cx, z=cz, y=f, vx=nv[0], vz=nv[1], moving=math.hypot(*nv) > 0.5)
        return out

    def closed_door_on(self, a, b):
        """a closed door's panel this step would touch or cross (ones the ghost is already in are let out of). EVERY panel near each
        point counts (12 Nov: the saloon's double door is two panels meeting in the middle - the check took the first one near, the
        open half, and the ghost walked through the shut half)."""
        here = {id(q) for q in doors_at(self.L, a[0], a[1], 0.9)}
        d = math.hypot(b[0] - a[0], b[1] - a[1]); n = max(1, int(d / 0.4))
        for i in range(1, n + 1):
            for q in doors_at(self.L, a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n, 0.9):
                if id(q) in here: continue
                try: st = self.door_state(q)
                except Exception: st = None
                if st is False: return q                      # (the door itself: the ghost can "use" it)
        return None

    # ----- routing
    def repath(self, now, me, tgt):
        goal = {"x": tgt[0], "y": tgt[1], "z": tgt[2]}
        start = {"x": me[0], "y": me[1], "z": me[2]}
        self.bad_edges = {k: t for k, t in self.bad_edges.items() if t > now}
        avoid = self.no_crouch | set(self.bad_edges)         # (soft: used only when nothing else gets there)
        try: r = self.L.route(start, goal, avoid=avoid)
        except Exception: r = None
        # Unbroken windows: the route finder plans through breakable glass (the bots shoot it out first); a ghost can't, so a
        # route through a window that isn't broken yet (the game's 0x422 says which are) is tried again avoiding it, and else dropped.
        def shut(rr): return [w.get("edge") for w in (rr or []) if w.get("window") and w.get("edge") not in self.broken]
        bad = shut(r)
        if bad:
            try: r = self.L.route(start, goal, avoid=avoid | set(bad))
            except Exception: r = None
            if shut(r): r = None
        # (x, z, floor height, sector, door panel, edge key, bridge, crouch, crouch-jump, gap: (take-off x, z, its floor height))
        self.path = [(w["x"], w["z"], w.get("y"), w.get("sector"), w.get("door"), w.get("edge"), w.get("bridge"),
                      bool(w.get("crouch")) and CROUCH and w.get("edge") not in self.no_crouch,
                      bool(w.get("crouch_jump")) and CROUCH and w.get("edge") not in self.no_crouch,
                      (w["gap"][0], w["gap"][1], w.get("gap_y")) if w.get("gap") else None,
                      tuple(w["leap"]) if w.get("leap") else None) for w in (r or [])]
        self.path_goal = (tgt[0], tgt[2]); self.path_t = now

    def blame(self, now, hold=15.0):
        """stuck on the way: the opening we were heading for (the first one on the path) is routed round for `hold` seconds
        (the re-plan used to give the very same route back, and the ghost walked straight back to the spot it was stuck at)"""
        for p in self.path[:3]:
            if len(p) > 5 and p[5] is not None:
                self.bad_edges[p[5]] = now + hold; return

    def follow(self, me, step, sec=None):
        """Walk along the path; returns (x, z, ux, uz, moving)."""
        x, z = me[0], me[2]
        while self.path and math.hypot(self.path[0][0] - x, self.path[0][1] - z) < 2.0 and (self.path[0][2] is None or abs(self.path[0][2] - self.cur_y) <= 1.0):
            self.path.pop(0)                                   # (a waypoint up on a ledge counts only once we're up there)
        # A fresh route often starts with a point the ghost has already passed (the line-up point in front of a doorway, a corner):
        # it turned back for it, re-planned, turned forward again... and in the game it bounced between two spots every tenth of a second.
        # Skip any first waypoint when the next one can be walked to in a straight line (a ledge or a drop never can, so those are kept).
        while sec is not None and len(self.path) >= 2:
            # never skip a waypoint at another height (a stair, a ledge, a roof): in plan view the ground under a roof is "straight ahead",
            # and the ghosts walked to the spot UNDER the roof they wanted, skipping the stairs (offline test: 0 of 21 raised spots reached)
            lvl = lambda p: p[2] is None or abs(p[2] - self.cur_y) <= 1.0
            if not (lvl(self.path[0]) and lvl(self.path[1])): break
            try: straight = self.L._march(sec, (x, z), self.path[1][:2]) is not None and \
                            self.L.clear_line(sec, {"x": x, "z": z}, {"x": self.path[1][0], "z": self.path[1][1]})     # (body width: not grazing a post or a window frame)
            except Exception: straight = False
            if not straight: break
            self.path.pop(0)
        if not self.path: return x, z, 0.0, 0.0, False
        tx, tz = self.path[0][:2]; dx, dz = tx - x, tz - z; d = math.hypot(dx, dz)
        if d < 0.6 and len(self.path) >= 2:                    # right under a ledge waypoint: lean on toward the one after it (onto the ledge)
            # (also when standing exactly on it: the "or 1.0" against a zero distance used to skip this, and a ghost that stopped on the
            # midpoint of a crate's edge - Dookes, the 24 crate below the 32 one - stood there for good)
            tx, tz = self.path[1][:2]; dx, dz = tx - x, tz - z; d = math.hypot(dx, dz)
        d = d or 1.0
        ux, uz = dx / d, dz / d; stp = min(step, max(d, 0.5))
        return x + ux * stp, z + uz * stp, ux, uz, True

    def wobble(self, moving):
        """the aim wobble now, degrees (brain.Brain.aim's formula)"""
        P = self.p
        if P.get("aim_mult"):
            err = 3.0 * P["aim_mult"]
            # (the bots' turning term counted whole: a ghost strafing round its target turns fast all the time, and the strafing tiers
            # (hard) then aimed worse than the standing ones (easiest). A ghost turns by numbers, not a mouse: a third of it)
            if moving: err += TURN_TERM * 15.0 * P["aim_mult"] * min(1.0, self.turn_rate / max(1.0, P["turn_speed"]))
            if self.hurt: err += 7.0
        else: err = P["aim_error"]
        return err * self.weapon_aim
    # ----- recorded jump moves
    def pick_macro(self, me, tgt):
        """the first recorded jump move of the best chain (up to 4 moves, walking between them on the same level) that brings us
        up toward a target above us: Dijkstra over the moves, cost = walking + what is left to the target at the end"""
        import heapq
        here = math.dist(me, tgt); best = None
        heap = [(0.0, 0, tuple(me), None)]; seen = {}
        n = 0
        while heap:
            c, depth, pos, first = heapq.heappop(heap); n += 1
            if n > 400: break
            if first is not None:
                left = math.dist(pos, tgt)
                if left < here - 5.0 and (best is None or c + left < best[0]): best = (c + left, first)
            if depth >= 4: continue
            for i, m in enumerate(self.macros):
                s, e_ = m["start"], m["end"]
                if abs(s[1] - pos[1]) > 1.5 or e_[1] < pos[1] + 3.0 or e_[1] > tgt[1] + 8.0: continue
                nc = c + math.hypot(s[0] - pos[0], s[2] - pos[2]) + 5.0
                if seen.get(i, 1e18) <= nc: continue
                seen[i] = nc
                heapq.heappush(heap, (nc, depth + 1, tuple(e_), first if first is not None else m))
        self.macro_cost = best[0] if best else None
        return best[1] if best else None
    def play_step(self, now, out):
        m, t0, off = self.play["m"], self.play["t0"], self.play["off"]
        fr = m["frames"]; el = now - t0
        if el >= fr[-1][0]:
            self.count_takeoffs(fr, len(fr) - 1)
            if self.play.get("min_vy", 0.0) < -1.0: self.impacts.append(-self.play["min_vy"])     # (a recorded drop: it landed at that speed)
            f = fr[-1]; self.play = None; self.path = []; self.path_t = -99.0
            self.cur_y, self.cur_sec = f[2], (self.sector(f[1], f[2], f[3], prefer=f[7]) or f[7]); self.vel = (0.0, 0.0)
            out.update(x=f[1], y=f[2], z=f[3], vx=0.0, vz=0.0, vy=0.0, moving=False, sec=self.cur_sec)
            return out
        k = 0
        while k + 1 < len(fr) - 1 and fr[k + 1][0] <= el: k += 1
        self.count_takeoffs(fr, k)
        a, b = fr[k], fr[min(k + 1, len(fr) - 1)]
        u = 0.0 if b[0] <= a[0] else max(0.0, min(1.0, (el - a[0]) / (b[0] - a[0])))
        fade = max(0.0, 1.0 - el / 0.3)                                      # (we started a little off the recorded spot: blend it away)
        x = a[1] + (b[1] - a[1]) * u + off[0] * fade; y = a[2] + (b[2] - a[2]) * u; z = a[3] + (b[3] - a[3]) * u + off[1] * fade
        vx, vy, vz = a[4] + (b[4] - a[4]) * u, a[5] + (b[5] - a[5]) * u, a[6] + (b[6] - a[6]) * u
        if math.hypot(vx, vz) > 2.0: self.yaw = math.atan2(vx, vz)
        self.vel = (vx, vz); self.cur_y = y; self.play["min_vy"] = min(self.play.get("min_vy", 0.0), vy)
        out.update(x=x, y=y, z=z, vx=vx, vz=vz, vy=vy, moving=True, yaw=self.yaw, sec=a[7], fire=None)
        return out
    # ----- one tick
    def update(self, now, me, tgt):
        """me, tgt = (x, y, z); tgt None when the human's position is unknown.
        Returns dict(x, y, z, yaw, vx, vz, moving, fire) with fire in (None, 'hit', 'miss')."""
        if self.slide is not None:
            out = self.slide_step(now); self.breathe(out); return out
        out = self._update(now, me, tgt)
        out = self.smooth(me, out)
        self.breathe(out)
        # Stuck: hasn't moved for 1 s while it wants to (user: a ghost standing in a window opening didn't move until it was shot -
        # the shot's shove got it off the sill). Give itself the same shove, toward where it is going.
        # Only while it is trying to move: standing to shoot counted as stuck too, and a fighting ghost jumped 3 units toward its target
        # every second it stood (offline, Hargrove: 364.3 -> 361.3 -> 358.3 -> 355.3, zero velocity in every state).
        if self.mode in ("chase", "engage") and self.want_move and now >= self.door_wait and self.play is None:
            if self.stuck_at is None or math.hypot(out["x"] - self.stuck_at[0], out["z"] - self.stuck_at[1]) > 0.5 or abs(out["y"] - self.stuck_at[2]) > 0.5:
                self.stuck_at = (out["x"], out["z"], out["y"], now)
            elif now - self.stuck_at[3] > 1.0:
                # step out sideways: the first of 16 directions (nearest to where it's going first) with a place to stand 3 units away
                # (in a window opening the only ways out are the two sides; the shove alone took a long while)
                x0, y0, z0 = out["x"], out["y"], out["z"]; sec0 = self.cur_sec
                gx, gz = (self.path[0][0], self.path[0][1]) if self.path else ((tgt[0], tgt[2]) if tgt else (x0 + 1.0, z0))
                want = math.atan2(gx - x0, gz - z0); moved = False
                for k in sorted(range(16), key=lambda k: abs(((k * math.pi / 8 - want) + math.pi) % (2 * math.pi) - math.pi)):
                    a = k * math.pi / 8
                    for dd in (3.0, 5.0):
                        bx, bz = x0 + math.sin(a) * dd, z0 + math.cos(a) * dd
                        s2 = self.sector(bx, y0, bz, prefer=sec0)
                        if s2 is None or s2 in self.door_secs: continue      # (never INTO a door: no route starts there, and it stood in it for good)
                        f2 = self.floor(s2, bx, bz)
                        if f2 is None or f2 > y0 + 4.0: continue
                        try:
                            mp = self.L._march(sec0, (x0, z0), (bx, bz))      # no walking through a wall to get out
                            ok = mp is not None and s2 in mp
                        except Exception: ok = False
                        if not ok: continue
                        # walk there over a few states with the velocity that goes with it (the game draws a jump in one state as a teleport)
                        self.slide = dict(t0=now, x0=x0, y0=y0, z0=z0, x1=bx, y1=f2, z1=bz, sec=s2, dur=max(dd / UNSTICK_SPEED, 0.12))
                        out = self.slide_step(now); moved = True; break
                    if moved: break
                if not moved and getattr(self, "unstick_fails", 0) >= 1:
                    # wedged where no step is a legal walk (11 Nov: a ghost stood 80 s in town_2p's jail bars - a 1-unit strip
                    # of posts, sector 27 - just outside its outline, so every walk out "went through a wall"): out to the nearest spot
                    # with floor to stand on in another sector, at walking pace
                    for dd in (2.0, 3.0, 5.0):
                        for k in sorted(range(16), key=lambda k: abs(((k * math.pi / 8 - want) + math.pi) % (2 * math.pi) - math.pi)):
                            a = k * math.pi / 8; bx, bz = x0 + math.sin(a) * dd, z0 + math.cos(a) * dd
                            s2 = self.sector(bx, y0, bz, prefer=sec0)
                            if s2 is None or s2 == sec0 or s2 in self.door_secs: continue
                            f2 = self.floor(s2, bx, bz)
                            if f2 is None or abs(f2 - y0) > 2.5: continue
                            self.slide = dict(t0=now, x0=x0, y0=y0, z0=z0, x1=bx, y1=f2, z1=bz, sec=s2, dur=max(dd / UNSTICK_SPEED, 0.12))
                            out = self.slide_step(now); moved = True; break
                        if moved: break
                self.unstick_fails = 0 if moved else getattr(self, "unstick_fails", 0) + 1
                if not moved: self.push(gx - x0, gz - z0, 35.0)
                self.blame(now)
                self.path_t = -99.0; self.path = []
                self.stuck_at = (out["x"], out["z"], out["y"], now)
        else: self.stuck_at = None
        # Standing in a door's own sector (pushed there, stopped to shoot in the doorway, or left there by a route that ended): step out
        # of it at once. Measured on town_2p: a ghost stood in JAILDOOR02 for 34 s, until it was shot, with no route out (the route finder
        # has no start inside a door) and the unstick step blocked by the door's own walls.
        if (self.cur_sec in self.door_secs or door_at(self.L, out["x"], out["z"]) is not None) and self.play is None and self.cj is None and self.slide is None:
            if self.in_door is None or math.hypot(out["x"] - self.in_door[0], out["z"] - self.in_door[1]) > 0.4:
                self.in_door = (out["x"], out["z"], now)
            elif now - self.in_door[2] > DOOR_STAND:
                sl = self.door_exit(now, out, tgt)
                if sl is not None:
                    self.slide = sl; self.in_door = None; self.stuck_at = None; self.path = []; self.path_t = -99.0
                    out = self.slide_step(now)
        else: self.in_door = None
        return out

    def door_exit(self, now, out, tgt):
        """the unstick step for a ghost standing in a door's sector: a spot beside the door (not in any door, floor at about this
        height, nothing but this door between here and there), the side toward where it is going first; None if there is none"""
        x0, y0, z0 = out["x"], out["y"], out["z"]; sec0 = self.cur_sec
        gx, gz = (self.path[0][0], self.path[0][1]) if self.path else ((tgt[0], tgt[2]) if tgt else (x0 + 1.0, z0))
        want = math.atan2(gx - x0, gz - z0)
        for k in sorted(range(16), key=lambda k: abs(((k * math.pi / 8 - want) + math.pi) % (2 * math.pi) - math.pi)):
            a = k * math.pi / 8
            for dd in (2.5, 3.5, 5.0):
                bx, bz = x0 + math.sin(a) * dd, z0 + math.cos(a) * dd
                s2 = None
                for yy in (y0, y0 - 1.0):                             # (a door's sill is a little above the floors either side)
                    s2 = stand_locate(self.L, bx, yy, bz, None, self.room())
                    if s2 is not None: break
                if s2 is None or s2 in self.door_secs or door_at(self.L, bx, bz, 1.3) is not None: continue
                f2 = self.floor(s2, bx, bz)
                if f2 is None or abs(f2 - y0) > 2.0: continue
                ok = True
                for i in range(1, int(dd / 0.5)):                       # only the door itself on the way: no wall, no other room
                    px, pz = x0 + math.sin(a) * i * 0.5, z0 + math.cos(a) * i * 0.5
                    if door_at(self.L, px, pz, 1.0) is not None: continue
                    try: inside = self.L.sectors[s2].contains(px, pz)
                    except Exception: inside = False
                    if not inside: ok = False; break
                if not ok: continue
                return dict(t0=now, x0=x0, y0=y0, z0=z0, x1=bx, y1=f2, z1=bz, sec=s2, dur=max(dd / UNSTICK_SPEED, 0.12))
        return None

    def slide_step(self, now):
        """one tick of a stuck ghost stepping out (see update): straight to the free spot found, at UNSTICK_SPEED"""
        s = self.slide; u = min(1.0, (now - s["t0"]) / s["dur"])
        x, z = s["x0"] + (s["x1"] - s["x0"]) * u, s["z0"] + (s["z1"] - s["z0"]) * u
        y = s["y0"] + (s["y1"] - s["y0"]) * u
        # the velocity sent: what is left of the step over about one state's time (0.1 s), never more than the step's pace - the game
        # carries a player on at the last velocity until the next state, and a full-pace last state ran it 2 units past the spot and back
        k = min(1.0 / s["dur"], 1.0 / 0.1) * (1.0 - u)
        vx, vz = (s["x1"] - s["x0"]) * k, (s["z1"] - s["z0"]) * k
        self.dt = 0.15 if self.last is None else min(max(now - self.last, 0.02), DT_MAX); self.last = now
        if u >= 1.0: self.slide = None; self.cur_sec = s["sec"]; self.cur_y = s["y1"]
        self.vel = (vx, vz)                                      # (carried on: the next steps turn it toward the route at ACCEL)
        return dict(x=x, y=y, z=z, yaw=self.yaw, vx=vx, vz=vz, moving=True, fire=None, wet=False, crouch=self.crouch,
                    sec=s["sec"] if u >= 0.5 else None)

    def count_takeoffs(self, fr, k):
        """the recorded jump's take-offs reached by frame k (each costs E_JUMP): a frame where the upward speed kicks up by more than 5 -
        gravity only ever slows it, so that is a jump, even one straight off a landing in the middle of a chain (vy 3.7 -> 27.5, 21.3 -> 28.2)"""
        done = self.play.get("seen", -1)
        for i in range(done + 1, k + 1):
            if fr[i][5] > 5.0 and (i == 0 or fr[i][5] - fr[i - 1][5] > 5.0): self.jumps += 1
        self.play["seen"] = max(done, k)

    def breathe(self, out):
        """this tick's stamina: E_MOVE a second while running sideways (on the ground, faster than halfway from the walk to the run, and more than
        30 degrees off the way it faces: a strafe or a diagonal), E_REST a second otherwise, E_JUMP for each take-off (every kick in a recorded jump
        move, see count_takeoffs, or a hop onto a crate / ledge). Running straight forward or back costs nothing: players tap W / S to keep it free.
        (E_TURN, Two Feathers' -2 a second for turning, was patched out of the game: not used.)"""
        E = self.energy_use
        if not E: return
        vx, vz = out.get("vx", 0.0), out.get("vz", 0.0); sp = math.hypot(vx, vz); yw = out.get("yaw") if out.get("yaw") is not None else self.yaw
        side = abs(vx * math.cos(yw) - vz * math.sin(yw)) if yw is not None else 0.0      # across the facing (forward = (sin yaw, cos yaw))
        strafe_run = out.get("moving") and not out.get("wet") and self.mode != "jump" and sp > (self.walk + self.run) / 2 and side > 0.5 * sp
        rate = E["move"] if strafe_run else E["rest"]
        self.energy = max(0.0, min(self.energy_max, self.energy + rate * self.dt + E["jump"] * self.jumps)); self.jumps = 0
        if self.energy <= 0.0 and not self.tired: self.tired = True; self.tired_snd = True
        elif self.tired and self.energy >= self.energy_resume * self.energy_max: self.tired = False

    def back_off(self, now, x, z, dp):
        """(16 Nov, the user: "when ghosts go to open doors, have them use the use key and then back up to help the door open - they
        are in the way of the doors sometimes, too close") - after the "use", a few steps straight back from the door's middle while
        it swings (DOOR_BACK units in DOOR_BACK_T s), facing it"""
        ax, az = x - dp["x"], z - dp["z"]; d = math.hypot(ax, az)
        if d < 1e-3: ax, az, d = -math.sin(self.yaw or 0.0), -math.cos(self.yaw or 0.0), 1.0
        self.backing = (now + DOOR_USE_T + DOOR_BACK_T, ax / d, az / d, math.atan2(-ax, -az), now + DOOR_USE_T)   # (still first: the "use" goes out 0.2 s later and reaches 5)

    def _update(self, now, me, tgt):
        P = self.p
        dt = 0.15 if self.last is None else min(max(now - self.last, 0.02), DT_MAX); self.last = now; self.dt = dt
        x, y, z = me
        out = dict(x=x, y=y, z=z, yaw=self.yaw, vx=0.0, vz=0.0, moving=False, fire=None, wet=False, crouch=False)
        self.want_move = True                                   # (cleared when it stands on purpose: shooting, at a door, crouching first)
        if self.cj is not None:
            self.mode = "cjump" if self.cj.get("crouch", True) else "gjump"; return self.cj_step(now, out)     # (a jump across a gap flies standing)
        bk = getattr(self, "backing", None)
        if bk is not None:
            if now >= bk[0]: self.backing = None
            elif now < bk[4]:
                self.yaw = bk[3]; self.mode = "door"; self.vel = (0.0, 0.0); out.update(yaw=self.yaw); return out
            else:
                sec_ = self.sector(x, y, z, prefer=self.cur_sec); st_ = DOOR_BACK / DOOR_BACK_T * dt
                cx_, cz_ = x + bk[1] * st_, z + bk[2] * st_
                self.yaw = bk[3]; self.mode = "door"; self.vel = (bk[1] * DOOR_BACK / DOOR_BACK_T, bk[2] * DOOR_BACK / DOOR_BACK_T)
                if sec_ is not None and self.can_step(sec_, (x, z), (cx_, cz_)):
                    f_ = self.floor(self.sector(cx_, y, cz_, prefer=sec_) or sec_, cx_, cz_)
                    out.update(x=cx_, z=cz_, y=(f_ + self.y_off) if f_ is not None and self.y_off is not None else y, vx=self.vel[0], vz=self.vel[1], moving=True, yaw=self.yaw)
                else: self.backing = None; out.update(yaw=self.yaw)
                return out
        if self.holes:
            r_ = self.ice_plan(now, me, tgt, out)
            if r_ is not None:
                if r_ is out: return out                                 # swimming this tick
                tgt = r_; self._ice_walk = now                           # on the ice: make for the hole nearest the one we follow
        sec = self.sector(x, y, z, prefer=self.cur_sec)
        if sec is None and CROUCH and not self.crouch:
            self.crouch = True; self.crouch_since = now                  # somewhere only a crouching player fits (a window sill we landed on)
            sec = self.sector(x, y, z, prefer=self.cur_sec)
            if sec is None: self.crouch = False
        # (14 Nov, Dry Gulch on a hosted game: every ghost ended up crammed in the low mine tunnel at (108, 295) - a crawl space we never
        #  walk into (self.crawl), so once in, no sector was ours, the fighter stood "idle" and the ghost stayed there for minutes.
        #  Out of every sector we may stand in for 1 s - not mid-jump - back to the last spot we stood on properly.)
        if sec is not None:
            self.lost_t = None
            try:
                if self.L.sectors[sec].contains(x, z): self.good = (x, y, z, sec)      # (really inside it: not kept on by `prefer`)
            except Exception: pass
        elif self.play is None and getattr(self, "good", None) is not None:
            if getattr(self, "lost_t", None) is None: self.lost_t = now
            elif now - self.lost_t > 1.0:
                gx, gy, gz, sec = self.good; self.lost_t = None; self.crouch = False
                self.unstuck = (round(x, 1), round(z, 1), round(gx, 1), round(gz, 1)); self.path = []; self.vel = (0.0, 0.0)
                x, y, z = gx, gy, gz; out.update(x=x, y=y, z=z)
        self.cur_y = y; self.cur_sec = sec
        try: wet = bool(self.L.in_water(x, y, z))                  # feet in the water or treading on it: no guns, slow
        except Exception: wet = False
        out["wet"] = wet
        if self.play is not None:
            self.crouch = False; self.mode = "jump"; return self.play_step(now, out)
        if sec is None or tgt is None:
            self.mode = "idle"; self.vel = (0.0, 0.0); out["crouch"] = self.crouch; return out
        if self.y_off is None:
            # Real players stand exactly on the floor (their states: y = the sector's floor). This used to keep the spawn height minus the floor, and the spawns
            # were half a unit low, so every ghost walked 0.5 inside the floor all game. GHOST_Y_OFF overrides it.
            self.y_off = float(os.environ.get("GHOST_Y_OFF", "0"))
        dx, dz = tgt[0] - x, tgt[2] - z; dist = math.hypot(dx, dz)
        aim = math.atan2(dx, dz)                         # forward = (sin yaw, cos yaw) in the (x, z) plane (measured)
        if self.yaw is None: self.yaw = aim
        if now >= self.los_until or self.los_tgt is None or math.hypot(self.los_tgt[0] - tgt[0], self.los_tgt[2] - tgt[2]) > 3.0:
            self.los_cache = dist < min(self.see_reach, P["max_engage"] * 1.5) and self.sees(sec, (x, z), (tgt[0], tgt[2]), y, tgt[1])
            self.los_until = now + 0.2; self.los_tgt = tgt
        los = self.los_cache
        # reaction time and sight memory (a target out of sight for less than sight_memory keeps the reaction already made)
        if los:
            if self.seen_since is None: self.seen_since = now
            self.lost_at = None
        elif self.seen_since is not None:
            if self.lost_at is None: self.lost_at = now
            elif now - self.lost_at > P["sight_memory"]: self.seen_since = None; self.lost_at = None
        engaged = los and dist <= P["max_engage"] and getattr(self, "_ice_walk", -1.0) != now     # (walking to a hole is no fight)
        # sprint share (re-rolled every few seconds)
        if now >= self.sprint_until:
            self.sprinting = bool(P["sprint"]) and self.rng.random() < P["sprint_frac"]; self.sprint_until = now + self.rng.uniform(2.0, 4.0)
        speed = self.run if (self.sprinting and not self.tired and not self.no_sprint) else self.walk          # out of breath: walk (no_sprint: a game mode's walkers)
        if wet: speed = self.walk * SWIM_SPEED
        if CROUCH:
            # crouch: coming up to a crouch-only opening (or a crouch-jump), or where there's no room to stand; stand up once there is
            p0 = self.path[0] if self.path else None
            near0 = (not engaged) and p0 is not None and len(p0) > 8 and (p0[7] or p0[8]) and math.hypot(p0[0] - x, p0[1] - z) < CROUCH_AHEAD
            want_c = bool(near0) or not self.can_stand(x, y, z)
            if want_c != self.crouch: self.crouch = want_c; self.crouch_since = now
            if self.crouch and not wet: speed = CROUCH_SPEED
        nx, nz, ux, uz, moving = x, z, 0.0, 0.0, False
        want = aim
        if engaged:
            self.mode = "engage"
            if now >= self.strafe_until:                 # strafe share: the rest of the time stand and shoot
                self.strafe = self.rng.choice((-1, 1)); self.strafe_until = now + self.rng.uniform(0.8, 2.0)
                self.strafing = self.rng.random() < P["strafe_frac"]
                # Inside the fighting distance the strafe was purely sideways (90 degrees off the facing in 493 of 545 moving states, offline):
                # with the game's walk pose a remote player then crab-slid. Players hold W or S with the side key: a diagonal, forward or
                # back for each strafe (back when it's got too close)
                self.strafe_fb = self.rng.uniform(-STRAFE_FB, STRAFE_FB)
                if dist < P["keep_distance"] * 0.6: self.strafe_fb = -abs(self.strafe_fb)
            fx, fz = dx / (dist or 1.0), dz / (dist or 1.0)
            mx = mz = 0.0
            if dist > P["keep_distance"]: mx, mz = fx, fz                   # advance until the fighting distance
            elif P.get("retreat") and dist < P["retreat"]: mx, mz = -fx, -fz      # a long-range fighter backs off when someone gets close
            elif self.strafing: mx, mz = fx * self.strafe_fb / 0.6, fz * self.strafe_fb / 0.6
            if self.strafing: mx, mz = mx * 0.6 + (-fz) * self.strafe * 0.8, mz * 0.6 + fx * self.strafe * 0.8
            m = math.hypot(mx, mz)
            self.want_move = m > 0.01                                       # (standing to shoot is not being stuck)
            if m > 0.01:
                ux, uz = mx / m, mz / m; stp = speed * dt
                cx, cz = x + ux * stp, z + uz * stp
                if self.can_step(sec, (x, z), (cx, cz)): nx, nz, moving = cx, cz, True
                elif now >= self.strafe_blocked_until:
                    # a wall: strafe the other way, but at most every 0.6 s (in a corner it used to flip every tick and jitter on the spot)
                    self.strafe = -self.strafe; self.strafe_until = now + 1.0; self.strafe_blocked_until = now + 0.6
        else:
            self.mode = "chase"
            if self.macros and tgt[1] > y + 4.0 and now >= self.macro_check:
                self.macro_check = now + 1.0
                if not self.path or self.path_goal is None or math.hypot(self.path_goal[0] - tgt[0], self.path_goal[1] - tgt[2]) > 10.0:
                    self.repath(now, me, tgt)                    # (what walking would take, to compare with)
                pend = self.path[-1][2] if self.path and self.path[-1][2] is not None else None
                walk = None
                if self.path and pend is not None and tgt[1] - pend <= 3.0:
                    walk = math.hypot(self.path[0][0] - x, self.path[0][1] - z) + sum(math.hypot(self.path[i + 1][0] - self.path[i][0], self.path[i + 1][1] - self.path[i][1]) for i in range(len(self.path) - 1))
                m = self.pick_macro(me, tgt)
                # the recorded jumps when walking has no way up, or when they're the shorter way (user: next to the crate he jumps from,
                # the ghost walked round and in through the building instead of jumping up onto the roof)
                self.macro_next = m if (m is not None and (walk is None or self.macro_cost + 10.0 < walk)) else None
            if self.macro_next is not None:
                s = self.macro_next["start"]
                if math.hypot(s[0] - x, s[2] - z) < 3.0 and abs(s[1] - y) < 1.5:
                    self.play = dict(m=self.macro_next, t0=now, off=(x - s[0], z - s[2])); self.macro_next = None
                    self.mode = "jump"; return self.play_step(now, out)
                if (not self.path) or now - self.path_t > 1.5 or self.path_goal != (s[0], s[2]):
                    self.repath(now, me, (s[0], s[1], s[2]))
            elif (not self.path) or now - self.path_t > 1.5 or (self.path_goal and math.hypot(self.path_goal[0] - tgt[0], self.path_goal[1] - tgt[2]) > 10.0):
                self.repath(now, me, tgt)
            # a door on the way (a panel across the next leg): stop short of it, ask it open (the ghost sends the game's own "use"
            # message, out["door"]), and wait for it to swing / slide open, like the bots' nudge
            dp = self.path[0][4] if self.path and len(self.path[0]) > 4 else None
            if dp is not None and math.hypot(dp["x"] - x, dp["z"] - z) < DOOR_REACH:
                k = (round(dp["x"], 1), round(dp["z"], 1))
                try: dst = self.door_state(dp) if self.door_state is not None else None
                except Exception: dst = None
                if dst is None:                                          # (a door whose number isn't known: as before)
                    if now - self.door_open.get(k, -99.0) > 6.0:
                        self.door_open[k] = now; self.door_wait = now + DOOR_WAIT; out["door"] = dp; self.back_off(now, x, z, dp)
                elif dst is False:                                       # shut (or still swinging): open it once, then wait for it
                    # Like the bots (brain.handle_obstacles): a nudge, DOOR_RETRY to let it swing, at most DOOR_TRIES nudges; then
                    # the route goes round that door for a while (a door that won't open, or one our count has wrong).
                    tr = self.door_tries.get(k, (0, -99.0))
                    if now - tr[1] > 20.0: tr = (0, -99.0)
                    if tr[0] >= DOOR_TRIES:
                        self.blame(now, hold=30.0); self.path = []; self.path_t = -99.0; self.door_tries.pop(k, None)
                    elif now - self.door_open.get(k, -99.0) > DOOR_RETRY:
                        self.door_open[k] = now; out["door"] = dp; self.door_tries[k] = (tr[0] + 1, now); self.back_off(now, x, z, dp)
                    self.door_wait = max(self.door_wait, now + 0.25)
                # (open: walk on; "using" it again would shut it)
            # a jump across a gap (nav GAPS: off a crate onto a ledge or a crate beyond): at its spot, up there, jump at the landing point
            # (cj_step flies us, standing: high enough to clear the far side, fast enough to be over it by the time we come down to it)
            gw = next((p for p in self.path[:2] if len(p) > 9 and p[9] is not None), None)
            if gw is not None and now >= self.door_wait:
                gx, gz, gy = gw[9]
                if math.hypot(gx - x, gz - z) <= GAP_AT and (gy is None or y >= gy - 1.0):
                    ax, az = gw[0] - x, gw[1] - z; da = math.hypot(ax, az) or 1.0
                    h = (gw[2] - y) if gw[2] is not None else 0.0
                    vy = max(JUMP_VY, math.sqrt(2.0 * GRAVITY * max(h + 0.6, 0.0)))
                    t_land = (vy + math.sqrt(max(vy * vy - 2.0 * GRAVITY * max(h, 0.0), 0.0))) / GRAVITY
                    self.cj = dict(t=0.0, vy=vy, ux=ax / da, uz=az / da, sec=sec, sec0=sec, edge=gw[5], crouch=False, delay=0.0,
                                   speed=min(self.run, max(CJ_SPEED, (da + 1.0) / max(t_land, 0.2))))
                    self.jumps += 1; self.crouch = False
                    self.yaw = math.atan2(ax / da, az / da); self.vel = (0.0, 0.0); self.mode = "gjump"
                    return self.cj_step(now, out)
            # a LEAP (nav.LEAPS: Orleans' attic, a hole in the roof; 16 Nov, the user: the elves crowded under it and never got up): under
            # the hole, crouch, jump straight up high enough for the roof beside it and move on to the landing (cj_step flies us)
            lw = next((p for p in self.path[:2] if len(p) > 10 and p[10] is not None), None); leap_wait = False
            if lw is not None and now >= self.door_wait and math.hypot(lw[10][0] - x, lw[10][1] - z) <= LEAP_AT:
                if not self.crouch: self.crouch = True; self.crouch_since = now
                if now - self.crouch_since >= CROUCH_FIRST:
                    h = (lw[2] - y) if lw[2] is not None else JUMP_UP_LEAP
                    vy = max(JUMP_VY, math.sqrt(2.0 * GRAVITY * max(h + 1.2, 0.0)))
                    disc = max(vy * vy - 2.0 * GRAVITY * (h + 0.6), 0.0)
                    delay = (vy - math.sqrt(disc)) / GRAVITY                    # up past the roof's height first, then over it
                    ax, az = lw[0] - x, lw[1] - z; da = math.hypot(ax, az) or 1.0
                    self.cj = dict(t=0.0, vy=vy, ux=ax / da, uz=az / da, sec=sec, sec0=sec, edge=lw[5], crouch=True, delay=delay, speed=CJ_SPEED)
                    self.jumps += 1; self.yaw = math.atan2(ax / da, az / da); self.vel = (0.0, 0.0); self.mode = "cjump"
                    return self.cj_step(now, out)
                leap_wait = True
            # a crouch-jump (a window above a sill): close to the opening, crouch first, then jump (cj_step flies us through)
            p0 = self.path[0] if self.path else None; cj_wait = False
            if p0 is not None and len(p0) > 8 and p0[8] and now >= self.door_wait and math.hypot(p0[0] - x, p0[1] - z) <= CJ_AT:
                if not self.crouch: self.crouch = True; self.crouch_since = now
                # the way through: at the opening, or after a jump that came down short against it, from it on to the next point
                d0 = math.hypot(p0[0] - x, p0[1] - z)
                if d0 < 1.0 and len(self.path) > 1: ax, az = self.path[1][0] - p0[0], self.path[1][1] - p0[1]
                else: ax, az = p0[0] - x, p0[1] - z
                da = math.hypot(ax, az) or 1.0; ux0, uz0 = ax / da, az / da
                if now - self.crouch_since >= CROUCH_FIRST:
                    self.cj = dict(t=0.0, vy=JUMP_VY, ux=ux0, uz=uz0, sec=sec, sec0=sec, edge=p0[5] if len(p0) > 5 else None); self.jumps += 1
                    self.yaw = math.atan2(ux0, uz0); self.vel = (0.0, 0.0); self.mode = "cjump"
                    return self.cj_step(now, out)
                cj_wait = True; want = math.atan2(ux0, uz0)
            if now < self.door_wait or cj_wait or leap_wait:
                nx, nz, ux, uz, moving = x, z, 0.0, 0.0, False; self.want_move = False
            else:
                nx, nz, ux, uz, moving = self.follow(me, speed * dt, sec)
            if moving and self.sector(nx, y, nz, prefer=sec) is None:
                self.blame(now)                                         # the route squeezes through somewhere a standing player does not fit: give up on it
                nx, nz, moving = x, z, False; self.path = []
            if moving: want = math.atan2(ux, uz)
        if self.crouch: engaged = False                                     # (no shooting crouched: nothing recorded for it yet)
        # turn at the tier's turn speed
        dyaw = wrap_pi(want - self.yaw); step = math.radians(P["turn_speed"]) * dt
        turn = max(-step, min(step, dyaw)); self.yaw = wrap_pi(self.yaw + turn); self.turn_rate = abs(math.degrees(turn)) / dt
        out["yaw"] = self.yaw
        err = self.wobble(moving)
        self.aim_off = max(-err, min(err, self.aim_off + self.rng.uniform(-1, 1) * err * 0.3))
        self.pitch_off = max(-err / 2, min(err / 2, self.pitch_off + self.rng.uniform(-1, 1) * err * 0.15))
        # On target (within 6 degrees), or keeping the button down: a weapon the ghost may spray (self.spray: the pistol, which has all
        # the bullets it wants; not the rifle or a shotgun, whose few shots are aimed) that has just fired goes on firing while the
        # target is in sight, like a player holding primary fire, and those shots miss until the aim is back on.
        # (The user, 10 Nov: ghosts with pistols fired a shot, waited a second or two, fired again. Each shot waited for the aim.)
        on_aim = abs(math.degrees(wrap_pi(aim - self.yaw))) < 6.0
        held = self.spray and now - self.last_shot < max(0.6, self.base_gap * 3.0)
        # the bots' sight re-check: the further the target, the longer before it opens fire (half the tier's s per 25 units, at most 1.5)
        recheck = min(1.5, 0.5 * P.get("recheck", 0.0) * dist / 25.0)
        if self.weapon != self.burst_w:
            self.burst_w = self.weapon; self.burst_n = 0; self.burst_len = 1 if self.weapon in PUMPS else self.rng.randint(1, 4)
        # how far the view trails the target (degrees, signed): its sideways speed relative to us x the bots' delay
        lag_deg = 0.0
        if AIM_LAG > 0 and dist > 0.5:
            rvx, rvz = self.tgt_vel                                              # (the target's own speed only: every tier alike, strafing or not)
            side = (rvx * dz - rvz * dx) / dist                                  # units a second across the line of sight
            lag_deg = math.degrees(math.atan2(max(-60.0, min(60.0, side)) * AIM_LAG, max(dist, 1.0)))
        can_fire = engaged and not wet and self.seen_since is not None and now - self.seen_since >= P["reaction"] + recheck and now >= self.next_fire \
            and now >= self.hold_fire_until and now >= self.burst_wait and (on_aim or held)
        if can_fire and on_aim and not self.spray and lag_deg:
            # a bot's trigger: an aimed gun waits until the view is on the body (+ a degree and the spread), a while at most
            if abs(lag_deg) > math.degrees(math.atan2(BODY_HALF, max(dist, 1.0))) + 1.0 + self.spread:
                if self.lag_wait is None: self.lag_wait = now
                if now - self.lag_wait < LAG_HOLD: can_fire = False
            else: self.lag_wait = None
        if can_fire:
            self.last_shot = now; self.lag_wait = None
            if not on_aim: out["fire"] = "miss"
            elif AIM_MODEL == "flat": out["fire"] = "hit" if self.rng.random() < HIT_RATE[P["level"]] * self.hit_scale * TIER_HIT.get(P["level"], 1.0) else "miss"
            else:
                d3 = math.hypot(dist, tgt[1] - y)
                half_w = math.degrees(math.atan2(BODY_HALF, max(d3, 1.0))) + self.spread
                half_h = math.degrees(math.atan2(2.8, max(d3, 1.0))) + self.spread
                hs = self.hit_scale * TIER_HIT.get(P["level"], 1.0)
                sc = self.scatter
                ao = self.aim_off + lag_deg + (self.rng.uniform(-sc, sc) if sc else 0.0); po = self.pitch_off + (self.rng.uniform(-sc, sc) if sc else 0.0)
                ok = abs(ao) <= half_w and abs(po) <= half_h and (hs >= 1.0 or self.rng.random() < hs)
                out["fire"] = "hit" if ok else "miss"; out["aim"] = (round(self.aim_off, 2), round(half_w, 2))
            # The next shot: at the gun's own rate (base_gap, from the game's files), counted from when this one was due rather than from
            # this tick, so a held trigger keeps the real rate (11 Nov: the pistols fired every 0.5 s, not 0.4; it was x shot_mult x 1..1.2
            # from the tick). The tier's slowness is in the pause between bursts, as for the bots.
            due = self.next_fire if 0.0 <= now - self.next_fire < 0.12 else now
            self.next_fire = due + self.base_gap
            if BURSTS and P["level"] in BURST_LEVELS and self.weapon in SHOT_TIME:
                self.burst_n += 1
                if self.burst_n >= self.burst_len:
                    self.burst_wait = now + SHOT_TIME[self.weapon] * P["shot_mult"]
                    self.burst_n = 0; self.burst_len = 1 if self.weapon in PUMPS else self.rng.randint(1, 4)
        # Momentum: the velocity turns toward the wanted one at ACCEL units/s^2 instead of jumping to it. Real players accelerate, so their
        # moves reverse through a standstill (1% of their updates are reversals); the ghosts flipped from full speed one way to full speed
        # the other (14%), which the game, extrapolating each update's velocity, showed as stutter and snapping back.
        want_v = (ux * speed, uz * speed) if moving else (0.0, 0.0)
        if self.fall_vy < 0 and math.hypot(*self.vel) > 0.5:
            want_v = self.vel; moving = True                            # in the air: carries on the way it went off the edge (no turning back mid-fall)
        dvx, dvz = want_v[0] - self.vel[0], want_v[1] - self.vel[1]; dv = math.hypot(dvx, dvz); lim = ACCEL * dt if ACCEL > 0 else 1e9     # (GHOST_ACCEL=0: no momentum)
        if ACCEL_MODEL and ACCEL > 0:
            if math.hypot(*want_v) < 0.5: lim = GLIDE * dt                                   # nothing held: the glide to a stop
            else: lim = (ACCEL_RUN if speed > (self.walk + self.run) / 2 else ACCEL_WALK) * dt    # a key held: the push
        if dv > lim: dvx, dvz = dvx / dv * lim, dvz / dv * lim
        vx, vz = self.vel[0] + dvx, self.vel[1] + dvz
        if math.hypot(vx, vz) > 0.5:
            cx, cz = x + vx * dt, z + vz * dt
            # (16 Nov, the user: a ghost walking at him across the ice "teleported" over a hole - it walked into the water and was put
            #  out on the far side. Walking never steps into a hole: the step slides round its rim instead; going in on purpose
            #  (after someone under the ice) is ice_plan's own move.)
            for h_ in self.holes:
                dh_ = math.hypot(cx - h_[0], cz - h_[1])
                if dh_ < h_[2] + HOLE_BERTH and abs(y - h_[3]) < 3.0:
                    k_ = (h_[2] + HOLE_BERTH) / (dh_ or 1e-3); cx, cz = h_[0] + (cx - h_[0]) * k_, h_[1] + (cz - h_[1]) * k_
            if self.can_step(sec, (x, z), (cx, cz)): nx, nz, moving = cx, cz, True
            elif moving: vx, vz = want_v                                # the smoothed step would clip a wall: take the planned one
            else: vx = vz = 0.0
        else:
            vx = vz = 0.0
            if moving: nx, nz = x, z; moving = False                     # (just starting: no step yet)
        self.vel = (vx, vz)
        if moving:
            nsec = self.sector(nx, y, nz, prefer=sec) or sec
            # the route's next waypoint is up on a crate / ledge / roof edge (a "jump" portal: a sector inside the one we stand in,
            # its floor up to a jump higher): stepping into its outline means jumping onto it (the plan-view lookup kept us on the floor below)
            if self.path and self.path[0][3] is not None and self.path[0][3] != nsec:
                ws = self.path[0][3]
                try:
                    wf = self.L.floor_at(ws, nx, nz); cf = self.floor(nsec, nx, nz)
                    if self.L.sectors[ws].contains(nx, nz) and cf is not None and 0.5 < wf - cf <= self.hop_limit(nsec, ws) and stand_locate(self.L, nx, wf, nz, ws) == ws:
                        if wf - y > HOP_FLY and self.cj is None:
                            # (25 Nov, the user: the gingerbread men "blink out for a moment... go thru the floor of the ledge then appear
                            #  back in front of me") a hop higher than a real jump (the missions' 13-high ledges, GHOST_JUMP_UP) was one
                            #  tick: up 15 at once, the other games drew the body sliding up through the ledge. Now it is flown: straight
                            #  up past the ledge's edge first, then over onto it (cj_step), like a LEAP.
                            h_ = wf - y
                            vy_ = max(JUMP_VY, math.sqrt(2.0 * GRAVITY * (h_ + 1.2)))
                            delay_ = (vy_ - math.sqrt(max(vy_ * vy_ - 2.0 * GRAVITY * (h_ + 0.6), 0.0))) / GRAVITY
                            ax_, az_ = nx - x, nz - z; da_ = math.hypot(ax_, az_)
                            if da_ < 1e-3: ax_, az_ = self.path[0][0] - x, self.path[0][1] - z; da_ = math.hypot(ax_, az_) or 1.0
                            self.cj = dict(t=0.0, vy=vy_, ux=ax_ / da_, uz=az_ / da_, sec=sec, sec0=sec, edge=None, crouch=False, delay=delay_, speed=CJ_SPEED)
                            self.jumps += 1; self.yaw = math.atan2(ax_ / da_, az_ / da_); self.vel = (0.0, 0.0); self.mode = "hjump"
                            out.update(x=x, y=y, z=z)
                            return self.cj_step(now, out)
                        if y < wf - 0.5: self.jumps += 1                 # (the hop up costs a jump)
                        nsec = ws
                except Exception: pass
            self.cur_sec = nsec
            f = self.floor(nsec, nx, nz)
            # a strip narrower than a player across a drop (nav WALKS): the game keeps a player up at the floor height either side
            br = (self.path[0][6] if self.path and len(self.path[0]) > 6 else None) or self.bridge
            if br is not None and f is not None and f < y - STEP and _seg_dist((nx, nz), br[0], br[1]) < 2.5:
                f = br[2] - self.y_off; self.bridge = br
            else: self.bridge = None
            # In the air (falling off a ledge) the side of a higher floor is a wall. A ghost that had stepped off a roof and dropped 5 units
            # drifted over the next roof and was back up on it in one update (town_2p, 24 -> 19.2 -> 24): a jerk at the edge in the user's
            # game. It stops against the higher floor and falls on where it is.
            if self.fall_vy < 0 and f is not None and f + self.y_off > y + STEP:
                nx, nz, nsec = x, z, sec; vx = vz = 0.0; self.vel = (0.0, 0.0); self.cur_sec = sec
                f = self.floor(sec, x, z)
            out.update(x=nx, z=nz, y=(f + self.y_off) if f is not None else y, vx=vx, vz=vz, moving=True)
        elif sec is not None:
            f0 = self.floor(sec, x, z)                                   # standing still in the air (mid-fall): keep falling
            if f0 is not None and f0 + self.y_off < y - 0.6: out["y"] = f0 + self.y_off
        # Off a ledge: FALL to the floor below (gravity 60, as measured) instead of being on it the next tick. A ghost that walked off a
        # 16-high roof was on the ground 0.08 s later; the user's game kept it in the roof's sector - dark, no name, could not be hit.
        fl_ = out["y"]
        if fl_ < y - (0.6 if self.fall_vy < 0 else FALL_MIN):            # (stairs and ramps, a few units a step, still just walk down)
            self.fall_vy -= FALL_G * dt
            ny = max(fl_, y + self.fall_vy * dt)
            if ny > fl_ + 0.01: out["y"] = ny; out["vy"] = self.fall_vy
            else: self.impacts.append(-self.fall_vy); self.fall_vy = 0.0     # (landed: the ghost checks it for fall damage)
        else:
            if self.fall_vy < -1.0: self.impacts.append(-self.fall_vy)
            self.fall_vy = 0.0
        out["crouch"] = self.crouch
        if self.crouch: out["sec"] = self.cur_sec                           # (the ghost's own lookup only knows standing players)
        return out

    # ---- Under the ice (16 Nov, the user: "make the ghosts know to go in water when the user does, know where the holes are and how
    # to get out of the water"). Orleans' pools are frozen in the Christmas Horde (icewater.py): ice to walk on, the water under it
    # reached only through a round hole in each pool. The route finder treats water only at its surface, so here: someone we chase is
    # in the water under a pool -> walk to the hole (of the pools, the one nearest them), drop in and swim to them (straight, in 3D,
    # staying in the water); they come out, or we are in the water with no one there -> swim back to the nearest hole, up, and out
    # onto the ice. GHOST_ICE_SWIM=0: off.
    def ice_plan(self, now, me, tgt, out):
        x, y, z = me
        try:
            wa = self.L.water_at(x, y, z); in_w = wa is not None and wa in self.pool_water
            t_w = tgt is not None and self.L.water_at(tgt[0], tgt[1] + 0.3, tgt[2]) in self.pool_water
            pool = getattr(self.L, "pool", None)
            # (16 Nov, the user: Orleans' west building - the pool inside it, reached only by swimming under the building - "the ghosts
            #  aren't following me up the water into the underpart of this building". Its rooms are the route finder's pool zone.)
            t_zone = bool(pool) and tgt is not None and not t_w and self.zone_of(tgt) in pool["zone"]
            me_zone = bool(pool) and not in_w and self.zone_of(me) in pool["zone"]
        except Exception: return None
        if self.swimming or in_w:
            self.swimming = True
            return self.swim_step(now, out, ("to", tgt) if t_w else ("pool" if t_zone else None))
        if me_zone:
            if tgt is not None and not t_zone:                            # someone outside: back out through the pool
                return self.pool_dive(now, me, out)
            return None
        if not t_w and not t_zone:
            for h in self.holes:                                        # treading water in a hole with no one below: out onto the ice
                if math.hypot(h[0] - x, h[1] - z) <= h[2] - 0.5 and abs(y - h[3]) < 1.5 and getattr(self, "hole_out_t", 0.0) < now - 2.0:
                    if math.hypot(h[0] - x, h[1] - z) < h[2] - RIM_STEP:          # (out in the middle: swim to the near rim first)
                        self.swimming = True; return self.swim_step(now, out, None)
                    self.hole_out_t = now
                    return self.climb_out(h, out)
            return None
        aim = tgt if t_w else (pool["inside"][0], 0.0, pool["inside"][1])
        h = min(self.holes, key=lambda q: math.hypot(q[0] - aim[0], q[1] - aim[2]))
        dh = math.hypot(h[0] - x, h[1] - z)
        if dh <= h[2] - 1.0 and abs(y - h[3]) < 2.0:
            self.swimming = True; self.path = []; self.swim_path = None   # at the hole: in we go
            return self.swim_step(now, out, ("to", tgt) if t_w else "pool")
        self.ice_target_t = now
        if dh <= h[2] + 10.0 and abs(y - h[3]) < 1.5:
            # next to it, on the ice: straight in (the route finder stops short of open water)
            st = min(dh, self.walk * self.dt); ux, uz = (h[0] - x) / (dh or 1.0), (h[1] - z) / (dh or 1.0)
            self.yaw = math.atan2(ux, uz); self.mode = "chase"; self.vel = (ux * self.walk, uz * self.walk)
            out.update(x=x + ux * st, z=z + uz * st, y=h[3], vx=self.vel[0], vz=self.vel[1], moving=True, yaw=self.yaw)
            return out
        # far off: walk to a spot on the ice beside the hole (the route finder plans to ice, not to open water), then straight in
        ax, az = x - h[0], z - h[1]
        for k in range(16):
            a = math.atan2(ax, az) + (k + 1) // 2 * (1 if k % 2 else -1) * math.pi / 8
            px, pz = h[0] + math.sin(a) * (h[2] + 4.0), h[1] + math.cos(a) * (h[2] + 4.0)
            try: ok = self.sector(px, h[3], pz) is not None
            except Exception: ok = False
            if ok: return (px, h[3], pz)
        return (h[0], h[3], h[1])

    def zone_of(self, p):
        try: return self.L.locate(p[0], p[1] + 0.5, p[2])
        except Exception: return None

    def pool_info(self):
        """(pool surface point (x, y, z), the spot to climb out onto (x, y, z)) of the map's inside pool (nav.POOLS)"""
        pl = self.L.pool; s = pl["surface"]
        sy = self.L.floor_at(s, pl["inside"][0], pl["inside"][1])
        ex = pl["exit"]; es = self.L.locate(ex[0], sy + 3.0, ex[1]); ey = self.L.floor_at(es, ex[0], ex[1]) if es is not None else sy + 1.0
        return (pl["inside"][0], sy, pl["inside"][1]), (ex[0], ey, ex[1])

    def pool_dive(self, now, me, out):
        """in the pool's rooms, chasing someone outside them: walk to the pool's edge and drop in"""
        P, E = self.pool_info(); x, y, z = me
        if math.hypot(E[0] - x, E[2] - z) <= 2.0 and abs(y - E[1]) < 2.0:
            self.swimming = True; self.path = []; self.swim_path = None
            out.update(x=P[0], y=P[1] - 1.0, z=P[2], moving=True, wet=True); self.cur_y = P[1] - 1.0
            return out
        self.ice_target_t = now
        return E

    def climb_out(self, h, out, toward=None):
        """from the hole (at the surface) up onto the ice: a step out past its rim (16 Nov, the user: ghosts in the water stuck at the
        edge of the hole, unable to get out), towards `toward` (x, z) when given, else straight on from where we face"""
        x, z = out["x"], out["z"]
        if toward is not None: ax, az = toward[0] - h[0], toward[1] - h[1]
        elif math.hypot(x - h[0], z - h[1]) > 0.5: ax, az = x - h[0], z - h[1]      # (the nearest bit of rim, not across the hole)
        else: ax, az = math.sin(self.yaw or 0.0), math.cos(self.yaw or 0.0)
        best = None
        for k in range(16):                                            # the direction wanted first, then the others round the rim
            a = math.atan2(ax, az) + (k + 1) // 2 * (1 if k % 2 else -1) * math.pi / 8
            px, pz = h[0] + math.sin(a) * (h[2] + 2.0), h[1] + math.cos(a) * (h[2] + 2.0)
            try: sec = self.sector(px, h[3], pz)
            except Exception: sec = None
            if sec is not None and abs(self.L.floor_at(sec, px, pz) - h[3]) < 1.0: best = (px, pz, sec); break
        self.swimming = False; self.path = []; self.path_t = -99.0; self.mode = "chase"
        if best is None: out.update(y=h[3]); self.cur_y = h[3]; return out
        px, pz, sec = best; self.yaw = math.atan2(px - x, pz - z)
        out.update(x=px, y=h[3], z=pz, moving=True, yaw=self.yaw, wet=False); self.cur_y = h[3]; self.cur_sec = sec
        return out

    def swim_nodes(self):
        """the underwater points routes go through: under each hole, and (Orleans) the way under the west building to its pool"""
        if getattr(self, "_swim_nodes", None) is None:
            n = [(h[0], h[3] - 8.0, h[1]) for h in self.holes]
            pl = getattr(self.L, "pool", None)
            if pl:
                P, _E = self.pool_info()
                n += [(pl["mouth"][0], P[1] - 16.0, pl["mouth"][1]), (pl["south"][0], P[1] - 16.0, pl["south"][1]),
                      (P[0], P[1] - 11.0, P[2]), (P[0], P[1] - 1.0, P[2])]
            self._swim_nodes = n
        return self._swim_nodes

    def wet_ok(self, cx, cy, cz):
        if self.L.water_at(cx, cy, cz) is not None: return True
        if any(math.hypot(h[0] - cx, h[1] - cz) <= h[2] - 0.5 and cy <= h[3] + 0.1 for h in self.holes): return True
        return False

    def clear_swim(self, a, b):
        d = math.dist(a, b); n = max(1, int(d / 1.5))
        return all(self.wet_ok(a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n, a[2] + (b[2] - a[2]) * k / n) for k in range(1, n + 1))

    def plan_swim(self, a, b):
        """the shortest chain of straight swims a -> b through swim_nodes (Dijkstra); [b] when there is none"""
        pts = [a] + self.swim_nodes() + [b]; n = len(pts); dist = [1e18] * n; prev = [None] * n; dist[0] = 0.0; done = set()
        while True:
            i = min((k for k in range(n) if k not in done), key=lambda k: dist[k], default=None)
            if i is None or dist[i] >= 1e18 or i == n - 1: break
            done.add(i)
            for j in range(n):
                if j in done or j == i: continue
                dd = dist[i] + math.dist(pts[i], pts[j])
                if dd < dist[j] and self.clear_swim(pts[i], pts[j]): dist[j] = dd; prev[j] = i
        if dist[n - 1] >= 1e18: return [b]
        path = []; k = n - 1
        while k is not None and k != 0: path.append(pts[k]); k = prev[k]
        return path[::-1]

    def swim_step(self, now, out, goal):
        """one tick in the water: goal ("to", (x, y, z)) someone we chase; "pool" up into the west building's pool and out at its edge;
        None back up through the nearest hole and out onto the ice"""
        x, y, z = out["x"], out["y"], out["z"]; dt = self.dt
        if goal is None:
            h = min(self.holes, key=lambda q: math.hypot(q[0] - x, q[1] - z) + abs(q[3] - 8.0 - y))
            flat = math.hypot(h[0] - x, h[1] - z)
            if flat <= h[2] - 1.5 and y >= h[3] - 2.0:                   # up in the hole: out onto the ice beside it
                if flat >= h[2] - RIM_STEP: return self.climb_out(h, out)
                # (16 Nov: a step out from the middle of a 12-wide hole was a jump right across it) - swim to the rim first
                ux_, uz_ = ((x - h[0]) / flat, (z - h[1]) / flat) if flat > 0.5 else (math.sin(self.yaw or 0.0), math.cos(self.yaw or 0.0))
                final = (h[0] + ux_ * (h[2] - 1.0), h[3] - 0.5, h[1] + uz_ * (h[2] - 1.0)); near = 0.3
            else:
                final = (h[0], h[3], h[1]); near = 0.3                    # (16 Nov: it stopped 1.4 under the surface, "close enough", and sat there)
        elif goal == "pool":
            P, E = self.pool_info()
            if math.hypot(P[0] - x, P[2] - z) <= 2.5 and y >= P[1] - 2.0:      # up in the pool: out at its edge
                self.swimming = False; self.path = []; self.path_t = -99.0; self.mode = "chase"; self.swim_path = None
                self.yaw = math.atan2(E[0] - x, E[2] - z)
                out.update(x=E[0], y=E[1], z=E[2], moving=True, yaw=self.yaw, wet=False); self.cur_y = E[1]
                return out
            final = (P[0], P[1] - 0.8, P[2]); near = 0.3                  # (just under the pool's surface: the water ends there)
        else:
            final = goal[1]; near = 1.5
        # the way there: straight when it can be swum straight, else through the swim nodes (re-planned now and then)
        sp = getattr(self, "swim_path", None)
        if sp is None or now - getattr(self, "swim_path_t", -99.0) > 1.0 or math.dist(sp[-1], final) > 3.0:
            sp = self.swim_path = [final] if self.clear_swim((x, y, z), final) else self.plan_swim((x, y, z), final); self.swim_path_t = now
        while len(sp) > 1 and math.dist((x, y, z), sp[0]) < 1.0: sp.pop(0)
        gx, gy, gz = sp[0] if len(sp) > 1 else final
        dx, dy, dz = gx - x, gy - y, gz - z; d = math.sqrt(dx * dx + dy * dy + dz * dz)
        spd = self.walk * SWIM_SPEED; nx, ny, nz = x, y, z; moving = False
        if d > (near if len(sp) <= 1 else 0.2):
            st = min(d, spd * dt)
            for fx, fy, fz in ((dx, dy, dz), (dx, 0.0, dz), (0.0, dy, 0.0)):      # straight; else level; else just up / down
                m = math.sqrt(fx * fx + fy * fy + fz * fz)
                if m < 1e-6: continue
                cx, cy, cz = x + fx / m * st, y + fy / m * st, z + fz / m * st
                if self.wet_ok(cx, cy, cz): nx, ny, nz, moving = cx, cy, cz, True; break
        if moving: self.yaw = math.atan2(nx - x, nz - z)
        # (16 Nov, the user: "have ghosts exit the water asap instead of sitting there floating until the player gets close, after the
        #  player has exited the water") - on the way out (goal None) and not getting anywhere for SWIM_STUCK s: say so, and go
        #  straight up into the nearest hole's water and out onto the ice from there.
        if goal is None:
            sl_ = getattr(self, "_swim_last", None)
            if sl_ is None or math.dist(sl_[0], (nx, ny, nz)) > 0.5: self._swim_last = ((nx, ny, nz), now)
            elif now - sl_[1] > SWIM_STUCK:
                h = min(self.holes, key=lambda q: math.hypot(q[0] - nx, q[1] - nz))
                print(f"in the water, not getting out ({nx:.0f},{ny:.0f},{nz:.0f}, {len(sp)} swim points): out through the hole at {h[0]:.0f},{h[1]:.0f}", flush=True)
                self._swim_last = None; self.swim_path = None
                out.update(x=nx, y=h[3], z=nz)
                return self.climb_out(h, out)
        else: self._swim_last = None
        fire = None
        if goal is not None and goal != "pool" and goal[1] is not None:
            # (16 Nov, the user: "when underwater have ghosts attack with knives first, if no knives, then fists") - the ghost picks
            # the stab or the fists for itself (ghost.py); here: up close and facing them, a swing at the gun's own rate
            t_ = goal[1]; d3 = math.dist((nx, ny, nz), t_)
            if d3 <= SWIM_REACH:
                self.yaw = math.atan2(t_[0] - nx, t_[2] - nz)
                if now >= self.next_fire and now >= self.hold_fire_until:
                    hs = self.hit_scale * TIER_HIT.get(self.p.get("level"), 1.0)
                    fire = "hit" if self.rng.random() < min(1.0, hs * 1.3) else "miss"
                    self.next_fire = now + self.base_gap; self.last_shot = now
        self.mode = "swim"; self.vel = ((nx - x) / dt, (nz - z) / dt) if dt else (0.0, 0.0); self.cur_y = ny
        try: self.cur_sec = self.L.water_at(nx, ny, nz)
        except Exception: pass
        out.update(x=nx, y=ny, z=nz, vx=self.vel[0], vz=self.vel[1], moving=moving, yaw=self.yaw, wet=True, fire=fire, crouch=False)
        return out

    def air_move(self, sec, p, q, y):
        """the sector a crouching player in the air (feet at y) ends up in going straight p -> q from `sec`, crossing any wall with a sector
        behind it that has room for them at that height (the floor at or below the feet, the ceiling a crouch above); None if blocked"""
        L = self.L; cur = sec; dx, dz = q[0] - p[0], q[1] - p[1]; t0 = 0.0
        for _ in range(16):
            best_t, best = None, None
            for w in L._outline(cur)["walls"]:
                x1, z1, x2, z2 = w[:4]; sx, sz = x2 - x1, z2 - z1; den = dx * sz - dz * sx
                if -1e-9 < den < 1e-9: continue
                wx, wz = x1 - p[0], z1 - p[1]; u = (wx * dz - wz * dx) / den
                if u < -1e-6 or u > 1 + 1e-6: continue
                t = (wx * sz - wz * sx) / den
                if t0 + 1e-4 < t < 1 + 1e-4 and (best_t is None or t < best_t): best_t, best = t, w
            if best is None: return cur
            nb = best[9]
            if nb is None or not (0 <= nb < len(L.sectors)): return None
            mx, mz = p[0] + dx * best_t, p[1] + dz * best_t
            try: f = L.floor_at(nb, mx, mz); c = L.ceiling_at(nb, mx, mz)
            except Exception: return None
            if f > y + 0.3 or c < max(y, f) + self.crouch_room: return None
            cur, t0 = nb, best_t
        return None

    def cj_step(self, now, out):
        """one tick of a crouch-jump in the air: the plain jump's arc (up at JUMP_VY, GRAVITY), straight up for CJ_DELAY, then forward at
        CJ_SPEED until we come down on a floor; crouched all the way. Walls stop the forward move (the host doesn't check a ghost's moves:
        it would fly through them)."""
        c = self.cj; dt = 0.0 if c["t"] == 0.0 else self.dt; c["t"] += max(dt, 1e-6)
        x, y, z = out["x"], out["y"], out["z"]
        vy0 = c["vy"]; vy = vy0 - GRAVITY * dt; ny = y + (vy0 + vy) / 2 * dt; c["vy"] = vy
        nx, nz, vx, vz = x, z, 0.0, 0.0
        crouched = c.get("crouch", True); spd = c.get("speed", CJ_SPEED)        # (a jump across a gap: standing, at its own pace)
        if c["t"] > c.get("delay", CJ_DELAY):
            # forward, unless that runs into a wall or an opening we don't fit through at this height (then just up / down this tick:
            # sliding up the wall under a window until we clear the sill)
            cx, cz = x + c["ux"] * spd * dt, z + c["uz"] * spd * dt
            s2 = self.air_move(c["sec"], (x, z), (cx, cz), min(y, ny))
            if s2 is not None: nx, nz, vx, vz = cx, cz, c["ux"] * spd, c["uz"] * spd; c["sec"] = s2
        try: top = self.L.ceiling_at(c["sec"], nx, nz) - (self.crouch_room if crouched else STAND_ROOM)     # the head bumps the ceiling (a window's top)
        except Exception: top = None
        if top is not None and ny > top: ny = top; vy = min(vy, 0.0); c["vy"] = vy
        fb = self.floor_below(nx, nz, max(y, ny) + 0.5)
        if (vy < 0 and fb is not None and ny <= fb[0]) or c["t"] > 2.5:
            # down: on whatever floor is under us (the street, or the sill if we came up short); the route is planned again from there
            if fb is not None: ny = fb[0]; c["sec"] = fb[1]
            if vy < -1.0: self.impacts.append(-vy)
            if c["sec"] == c["sec0"]:                                       # came down where we jumped from: twice, and that opening is routed round
                self.cj_fails = getattr(self, "cj_fails", 0) + 1
                if self.cj_fails >= 2 and c.get("edge") is not None: self.bad_edges[c["edge"]] = now + 15.0; self.cj_fails = 0
            else: self.cj_fails = 0
            self.cj = None; self.path = []; self.path_t = -99.0; vy = 0.0
            self.crouch_since = now
        self.vel = (vx, vz); self.cur_y = ny; self.cur_sec = c["sec"]; self.crouch = crouched
        out.update(x=nx, y=ny, z=nz, vx=vx, vz=vz, vy=vy, moving=True, yaw=self.yaw, sec=c["sec"], fire=None, crouch=crouched)
        return out

    def push(self, dx, dz, speed):
        """being shot: a shove away from the shooter, added to the velocity (it slides and slows down instead of jumping)"""
        d = math.hypot(dx, dz) or 1.0
        self.vel = (self.vel[0] + dx / d * speed, self.vel[1] + dz / d * speed)
