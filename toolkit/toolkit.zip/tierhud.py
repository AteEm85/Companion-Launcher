"""Small tier label in a corner of the screen: python tierhud.py <run id> <horde.py pid>
Shows "HORDE: NORMAL" (small letters, left edge, middle of the screen) while you are in the game, updated whenever horde.py changes the tier
(state/tier_<run>.txt). No focus, click-through, see-through background. Stops when the match ends.
It also holds the big banner ("Horde Becomes Stronger"): a see-through window made once when the match starts and only
drawn into after that (state/banner_<run>.txt: "<seq>|<seconds>|0|<text>"), because opening a new window in the middle of
the match makes the game let go of the keys you are holding."""
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
KEY = "#010101"
COLORS = {"easiest": "#c9c2a8", "easy": "#d6c36a", "normal": "#e0993a", "hard": "#d9602b", "nightmare": "#d02a1f", "hell": "#ff2a1a"}


def main():
    run = sys.argv[1] if len(sys.argv) > 1 else ""
    parent = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    import ambient
    st = HERE / "state"
    stop, over, human, tier = st / f"stop_{run}", st / f"music_stop_{run}", st / f"human_{run}.flag", st / f"tier_{run}.txt"

    def done():
        return stop.exists() or over.exists() or (parent and not ambient.alive(parent))
    while not human.exists():
        if done():
            return
        time.sleep(0.5)
    import ctypes
    u = ctypes.windll.user32
    fg0 = u.GetForegroundWindow()
    import tkinter as tk
    root = tk.Tk()
    root.withdraw()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.configure(bg=KEY)
    try:
        root.attributes("-transparentcolor", KEY)
    except tk.TclError:
        pass
    W, H = 260, 24
    cv = tk.Canvas(root, width=W, height=H, bg=KEY, highlightthickness=0)
    cv.pack()
    root.geometry(f"{W}x{H}+14+{max(0, (root.winfo_screenheight() - H) // 2)}")   # left edge, middle of the screen
    font = ("Consolas", 11, "bold")
    items = []

    def draw(text, color):
        for i in items:
            cv.delete(i)
        items.clear()
        for dx, dy in ((-1, 1), (1, 1), (0, 2), (-1, -1), (1, -1)):
            items.append(cv.create_text(6 + dx, H // 2 + dy, text=text, font=font, fill="black", anchor="w"))
        items.append(cv.create_text(6, H // 2, text=text, font=font, fill=color, anchor="w"))
    shown = [None]

    def tick():
        if done():
            root.destroy()
            return
        try:
            t = tier.read_text().strip().lower()
        except OSError:
            t = ""
        if t and t != shown[0]:
            shown[0] = t
            draw(f"HORDE: {t.upper()}", COLORS.get(t, "#d6c36a"))
        try:
            if fg0 and u.GetForegroundWindow() != fg0:
                u.SetForegroundWindow(fg0)
        except Exception:
            pass
        root.after(500, tick)
    try:
        root.attributes("-alpha", 0.85)
    except tk.TclError:
        pass
    try:
        root.update()
        hwnd = u.GetParent(root.winfo_id()) or root.winfo_id()
        style = u.GetWindowLongW(hwnd, -20)
        u.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x80 | 0x20 | 0x80000)
        u.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)
        u.ShowWindow(hwnd, 4)
        if fg0 and u.GetForegroundWindow() != fg0:
            u.SetForegroundWindow(fg0)
    except Exception:
        root.deiconify()
    # the banner: a full-width see-through strip near the top, empty until horde.py asks for a banner
    from tkinter import font as tkfont
    bw = tk.Toplevel(root)
    bw.overrideredirect(True)
    bw.attributes("-topmost", True)
    bw.configure(bg=KEY)
    try:
        bw.attributes("-transparentcolor", KEY)
        bw.attributes("-alpha", 0.93)
    except tk.TclError:
        pass
    SW, BH = root.winfo_screenwidth(), 110
    bc = tk.Canvas(bw, width=SW, height=BH, bg=KEY, highlightthickness=0)
    bc.pack()
    bw.geometry(f"{SW}x{BH}+0+{int(root.winfo_screenheight() * 0.08)}")
    bfont = tkfont.Font(family="Impact", size=34, weight="bold")
    bfile = st / f"banner_{run}.txt"
    try:
        bseen = [bfile.read_text().split("|", 1)[0]]          # (one left from before this HUD started is not shown)
    except OSError:
        bseen = [None]
    bclear = [None]

    def btick():
        try:
            seq, secs, _style, text = bfile.read_text().split("|", 3)
        except (OSError, ValueError):
            seq = None
        if seq is not None and seq != bseen[0]:
            bseen[0] = seq
            bc.delete("all")
            bg = "#d9d2c3"
            tw = bfont.measure(text.upper()) + 72
            x0 = (SW - tw) // 2
            y0, y1 = 18, 18 + 74
            bc.create_rectangle(x0, y0, x0 + tw, y1, fill=bg, outline=bg)
            bc.create_text(SW // 2, (y0 + y1) // 2, text=text.upper(), font=bfont, fill="#7a0a0a")
            if bclear[0]:
                root.after_cancel(bclear[0])
            bclear[0] = root.after(int(float(secs or 3.5) * 1000), lambda: bc.delete("all"))
        root.after(120, btick)
    try:
        bw.update()
        bh = u.GetParent(bw.winfo_id()) or bw.winfo_id()
        u.SetWindowLongW(bh, -20, u.GetWindowLongW(bh, -20) | 0x08000000 | 0x80 | 0x20 | 0x80000)
        u.SetWindowPos(bh, -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)
        u.ShowWindow(bh, 4)
        if fg0 and u.GetForegroundWindow() != fg0:
            u.SetForegroundWindow(fg0)
    except Exception:
        pass
    tick()
    btick()
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
