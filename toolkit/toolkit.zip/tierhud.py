"""Small tier label in a corner of the screen: python tierhud.py <run id> <horde.py pid>
Shows "HORDE: NORMAL" (small letters, left edge, middle of the screen) while you are in the game, updated whenever horde.py changes the tier
(state/tier_<run>.txt). No focus, click-through, see-through background. Stops when the match ends.
It also holds the big banner ("Elves Grow Restless", "Horde Becomes Stronger", "Santa Is Coming!"): a see-through window
made once when the match starts and only drawn into after that (state/banner_<run>.txt: "<seq>|<seconds>|<xmas 0/1>|<text>"),
because opening a new window in the middle of the match makes the game let go of the keys you are holding."""
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
KEY = "#010101"
COLORS = {"easiest": "#c9c2a8", "easy": "#d6c36a", "normal": "#e0993a", "hard": "#d9602b", "nightmare": "#d02a1f", "hell": "#ff2a1a", "santa": "#ff3b3b", "bob graham": "#ff7a1a", "headless demon": "#ff7a1a"}


def _paths(run):
    st = HERE / "state"
    return st, st / f"stop_{run}", st / f"music_stop_{run}", st / f"human_{run}.flag", st / f"tier_{run}.txt"


def _done(run, parent):
    import ambient
    st, stop, over, human, tier = _paths(run)
    return stop.exists() or over.exists() or (parent and not ambient.alive(parent))


def main():
    run = sys.argv[1] if len(sys.argv) > 1 else ""
    parent = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    st, stop, over, human, tier = _paths(run)
    while not human.exists():
        if _done(run, parent):
            return
        time.sleep(0.5)
    build(run, parent)


def in_launcher(master, run, parent):
    """(24 Nov, the user: a friend running the missions saw no step text and no banners - his bots' Python (.venv) has no
    tkinter, so this file could not open its windows. horde.py then asks the launcher, whose own Tk always works, to
    show them: state/hud_request_<run>.txt, picked up by launchertools.) The same windows, as Toplevels of the launcher;
    waits for you to be in the game without blocking it."""
    st, stop, over, human, tier = _paths(run)

    def wait():
        if _done(run, parent):
            return
        if not human.exists():
            master.after(500, wait); return
        build(run, parent, master)
    wait()


def build(run, parent, master=None):
    st, stop, over, human, tier = _paths(run)

    def done():
        return _done(run, parent)
    import ctypes
    u = ctypes.windll.user32
    fg0 = u.GetForegroundWindow()
    import tkinter as tk
    root = tk.Toplevel(master) if master is not None else tk.Tk()
    root.withdraw()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.configure(bg=KEY)
    try:
        root.attributes("-transparentcolor", KEY)
    except tk.TclError:
        pass
    obj = st / f"obj_{run}.txt"                             # a Co-op Mission's objective (horde.py): shown instead of the tier
    import objview
    SW_, SH_ = root.winfo_screenwidth(), root.winfo_screenheight()
    W, H = objview.size(SW_, SH_)                           # (room for a mission's objective; the tier label uses the top)
    cv = tk.Canvas(root, width=W, height=H, bg=KEY, highlightthickness=0)
    cv.pack()
    root.geometry(f"{W}x{H}+14+{max(0, SH_ // 2 - 40)}")   # left edge, from the middle of the screen down
    font = ("Consolas", 11, "bold")
    items = []

    def draw(text, color):
        for i in items:
            cv.delete(i)
        items.clear()
        for i, line in enumerate(text.split("\n")[:4]):
            y = 12 + i * 20
            f_ = font if i else (font if len(text.split("\n")) == 1 else ("Consolas", 11, "bold"))
            c_ = color if (i == 0 or len(text.split("\n")) == 1) else "#ff6a4a"     # (the bosses' health: red-orange)
            if i: f_ = ("Consolas", 13, "bold"); y = 14 + i * 22
            for dx, dy in ((-1, 1), (1, 1), (0, 2), (-1, -1), (1, -1)):
                items.append(cv.create_text(6 + dx, y + dy, text=line, font=f_, fill="black", anchor="w"))
            items.append(cv.create_text(6, y, text=line, font=f_, fill=c_, anchor="w"))
    shown = [None]

    def tick():
        if done():
            root.destroy()
            return
        try:
            t = tier.read_text().strip().lower()
        except OSError:
            t = ""
        try:
            o = obj.read_text().strip()
        except OSError:
            o = ""
        if o:
            if ("obj", o) != shown[0]:
                shown[0] = ("obj", o)
                items.clear()
                objview.draw(cv, o, SH_, W)
        else:
            try:                                        # the end bosses' health under the tier (horde.py: state/bosshp_<run>.txt)
                hp = (st / f"bosshp_{run}.txt").read_text().strip()
            except OSError:
                hp = ""
            if t and (t, hp) != shown[0]:
                shown[0] = (t, hp)
                draw(f"HORDE: {t.upper()}" + (("\n" + hp) if hp else ""), COLORS.get(t, "#d6c36a"))
        try:
            if fg0 and u.GetForegroundWindow() != fg0:
                u.SetForegroundWindow(fg0)
        except Exception:
            pass
        root.after(500, tick)
    try:
        root.attributes("-alpha", 0.85)
    except tk.TclError:
        pass
    try:
        root.update()
        hwnd = u.GetParent(root.winfo_id()) or root.winfo_id()
        style = u.GetWindowLongW(hwnd, -20)
        u.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x80 | 0x20 | 0x80000)
        u.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)
        u.ShowWindow(hwnd, 4)
        if fg0 and u.GetForegroundWindow() != fg0:
            u.SetForegroundWindow(fg0)
    except Exception:
        root.deiconify()
    # the banner: a full-width see-through strip near the top, empty until horde.py asks for a banner
    from tkinter import font as tkfont
    bw = tk.Toplevel(root)
    bw.overrideredirect(True)
    bw.attributes("-topmost", True)
    bw.configure(bg=KEY)
    try:
        bw.attributes("-transparentcolor", KEY)
        bw.attributes("-alpha", 0.93)
    except tk.TclError:
        pass
    SW, BH = root.winfo_screenwidth(), 110
    bc = tk.Canvas(bw, width=SW, height=BH, bg=KEY, highlightthickness=0)
    bc.pack()
    bw.geometry(f"{SW}x{BH}+0+{int(root.winfo_screenheight() * 0.08)}")
    bfont = tkfont.Font(family="Impact", size=34, weight="bold")
    bfile = st / f"banner_{run}.txt"
    try:
        bseen = [bfile.read_text().split("|", 1)[0]]          # (one left from before this HUD started is not shown)
    except OSError:
        bseen = [None]
    bclear = [None]

    def btick():
        try:
            if not root.winfo_exists(): return              # (gone with the match: in the launcher, nothing else stops this)
        except tk.TclError:
            return
        try:
            seq, secs, xmas, text = bfile.read_text().split("|", 3)
        except (OSError, ValueError):
            seq = None
        if seq is not None and seq != bseen[0]:
            bseen[0] = seq
            xm = xmas.strip() == "1"
            bc.delete("all")
            bg = "#f2f5fa" if xm else "#d9d2c3"
            tw = bfont.measure(text.upper()) + 72
            x0 = (SW - tw) // 2
            y0, y1 = 18, 18 + 74
            bc.create_rectangle(x0, y0, x0 + tw, y1, fill=bg, outline=bg)
            if xm:
                bc.create_rectangle(x0, y0, x0 + tw, y0 + 6, fill="#1f9a3a", outline="#1f9a3a")
                bc.create_rectangle(x0, y1 - 6, x0 + tw, y1, fill="#1f9a3a", outline="#1f9a3a")
            bc.create_text(SW // 2, (y0 + y1) // 2, text=text.upper(), font=bfont, fill="#b01818" if xm else "#7a0a0a")
            if bclear[0]:
                root.after_cancel(bclear[0])
            bclear[0] = root.after(int(float(secs or 3.5) * 1000), lambda: bc.delete("all"))
        root.after(120, btick)
    try:
        bw.update()
        bh = u.GetParent(bw.winfo_id()) or bw.winfo_id()
        u.SetWindowLongW(bh, -20, u.GetWindowLongW(bh, -20) | 0x08000000 | 0x80 | 0x20 | 0x80000)
        u.SetWindowPos(bh, -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)
        u.ShowWindow(bh, 4)
        if fg0 and u.GetForegroundWindow() != fg0:
            u.SetForegroundWindow(fg0)
    except Exception:
        pass
    tick()
    btick()
    if master is None:
        root.mainloop()


def loading_notice(master, finished, text="Loading the next mission - please don't exit the game"):
    """(25 Nov, the user: after the boss is beaten, a message like "Loading next mission, please don't exit the game") a
    see-through, click-through strip low on the screen, in the banners' look, over the score screen and the loading in
    between; the launcher (launchertools.mission_chain) opens it and it closes itself once finished() says so."""
    import ctypes
    import tkinter as tk
    from tkinter import font as tkfont
    u = ctypes.windll.user32
    fg0 = u.GetForegroundWindow()
    w = tk.Toplevel(master)
    w.withdraw()
    w.overrideredirect(True)
    w.attributes("-topmost", True)
    w.configure(bg=KEY)
    try:
        w.attributes("-transparentcolor", KEY)
        w.attributes("-alpha", 0.93)
    except tk.TclError:
        pass
    SW, SH, BH = w.winfo_screenwidth(), w.winfo_screenheight(), 130
    c = tk.Canvas(w, width=SW, height=BH, bg=KEY, highlightthickness=0)
    c.pack()
    w.geometry(f"{SW}x{BH}+0+{int(SH * 0.70)}")
    f1 = tkfont.Font(family="Impact", size=30, weight="bold")
    f2 = tkfont.Font(family="Impact", size=18)
    t1, t2 = (text.split(" - ", 1) + [""])[:2]
    t1, t2 = t1.upper() + "...", t2.upper()
    tw = max(f1.measure(t1), f2.measure(t2)) + 80
    x0, y0, y1 = (SW - tw) // 2, 10, 118
    c.create_rectangle(x0, y0, x0 + tw, y1, fill="#f2f5fa", outline="#f2f5fa")
    c.create_rectangle(x0, y0, x0 + tw, y0 + 6, fill="#1f9a3a", outline="#1f9a3a")
    c.create_rectangle(x0, y1 - 6, x0 + tw, y1, fill="#1f9a3a", outline="#1f9a3a")
    c.create_text(SW // 2, y0 + 40, text=t1, font=f1, fill="#b01818")
    c.create_text(SW // 2, y0 + 80, text=t2, font=f2, fill="#1f6a2a")
    try:
        w.update()
        h = u.GetParent(w.winfo_id()) or w.winfo_id()
        u.SetWindowLongW(h, -20, u.GetWindowLongW(h, -20) | 0x08000000 | 0x80 | 0x20 | 0x80000)
        u.SetWindowPos(h, -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)
        u.ShowWindow(h, 4)
        if fg0 and u.GetForegroundWindow() != fg0:
            u.SetForegroundWindow(fg0)
    except Exception:
        w.deiconify()

    def tick():
        try:
            if finished():
                w.destroy(); return
            u.SetWindowPos(u.GetParent(w.winfo_id()) or w.winfo_id(), -1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10 | 0x40)   # (on top of a new game window too)
        except Exception:
            try: w.destroy()
            except Exception: pass
            return
        w.after(500, tick)
    tick()
    return w


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
