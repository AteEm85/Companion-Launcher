"""Mod server: lets the Outlaws Companion app (friends' PCs) fetch the files a hosted game needs.
The launcher (and companionhost.py) call start(mode, map_key) when a game is hosted; the companion asks
  GET /manifest.json   which mods this game needs (name, size, sha256, url of each file)
  GET /f/<path>        one of those files
  GET /toolkit.zip     the bot toolkit (scripts only), for friends who want to host games themselves
Only files named in the manifest (and the toolkit zip) are ever served; nothing else on this PC is reachable.
Usage: python modserver.py [mode] [map]   (runs until closed; for testing)"""
import os, sys, json, hashlib, threading, zipfile, io, socket, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

HERE = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))
GAME = os.path.dirname(HERE)
PORT = 8765
DISCOVER_PORT = 8766
BUILTIN_MAPS = {"civpow2", "drygulch", "fort", "granary", "hargrove", "lilbatl", "mltsimms", "orleans",
                "thudtowr", "town_2p", "wilderns"}
MAP_EXT = (".lab", ".rcm")      # (Dark Mode adds .obt / .obb above)
TOOLKIT_EXT = (".py", ".js", ".cmd", ".txt")
TOOLKIT_JSON = ("maps_data.json", "maps_extra.json", "mapbatch_assets.json", "teamcolors_game.zip")   # + the game's own sprite shaders (teamcolors.py)
TOOLKIT_SKIP = ("online_settings", "launcher_settings", "bot_presets")
TOOLKIT_DIRS = {"zombie": (".spx", ".wav"), "sounds": (".wav",)}     # the Horde's zombie skins and its music / sound effects
MUSIC = ("sounds", "horde_ambient.wav")                         # joiners play this themselves while in a Horde game
INFO = {"mode": "", "map": "", "melee": False, "humans_team": None}
STARTED = [0.0]                                                 # when this game was hosted (older state files are a past game's)
_srv = None
_cache = {}


def _sha(path):
    st = os.stat(path); key = (path, st.st_size, st.st_mtime)
    if key not in _cache:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for blk in iter(lambda: f.read(1 << 20), b""): h.update(blk)
        _cache[key] = h.hexdigest()
    return _cache[key]


def _file(path, dest, url):
    return {"dest": dest, "size": os.path.getsize(path), "sha256": _sha(path), "url": url}


def mods():
    """[{id, title, files:[{dest,size,sha256,url}], paths:{url: local path}}] for the game being hosted."""
    mode, mp = INFO["mode"], INFO["map"].lower()
    out = []
    if mode in ("horde", "dark"):
        zdir = os.path.join(HERE, "zombie")
        fl = sorted(n for n in (os.listdir(zdir) if os.path.isdir(zdir) else []) if n.upper().endswith((".SPX", ".WAV")))
        if fl:
            out.append({"id": "zombie_skins", "title": "Zombie skins and death sounds",
                        "items": [(os.path.join(zdir, n), n, "/f/zombie/" + n) for n in fl]})
    if (mode == "dark" or INFO.get("melee")) and mp:   # Dark Mode / Melee Zombies: the map's swapped item lists (darkitems.py wrote them)
        items = [(os.path.join(GAME, n), n, "/f/map/" + n) for n in sorted(os.listdir(GAME))
                 if os.path.splitext(n)[0].lower() == mp and os.path.splitext(n)[1].lower() in (".obt", ".obb")]
        if items:
            out.append({"id": "items_" + mp, "title": ("Melee Zombies map items (%s)" if INFO.get("melee") else "Dark Mode map items (%s)") % INFO["map"], "items": items})
    if mp and mp not in BUILTIN_MAPS or (mode in ("horde", "dark", "team") and mp == "town_2p"):   # Sanctuary: its Team Play .rcm
        items = []
        try:
            for n in sorted(os.listdir(GAME)):
                b, e = os.path.splitext(n)
                if b.lower() == mp and e.lower() in MAP_EXT:
                    items.append((os.path.join(GAME, n), n, "/f/map/" + n))
        except OSError:
            pass
        if items:
            out.append({"id": "map_" + mp, "title": "Map files (%s)" % INFO["map"], "items": items})
    res = []
    for m in out:
        res.append({"id": m["id"], "title": m["title"], "_items": m["items"],
                    "files": [_file(p, d, u) for p, d, u in m["items"]]})
    return res


def music():
    """(local path, entry) of the Horde music for joiners, or (None, None)."""
    p = os.path.join(HERE, *MUSIC)
    if INFO["mode"] not in ("horde", "dark") or not os.path.isfile(p): return None, None
    return p, _file(p, MUSIC[1], "/f/sounds/" + MUSIC[1])


def horde_state():
    """The running Survival game, for joiners' on-screen overlays: its current tier and whether the match is over."""
    st = os.path.join(HERE, "state")
    best = None
    try:
        for n in os.listdir(st):
            if n.startswith("tier_") and n.endswith(".txt"):
                p = os.path.join(st, n); mt = os.path.getmtime(p)
                if mt >= STARTED[0] - 5 and (best is None or mt > best[0]): best = (mt, n[5:-4], p)
    except OSError:
        pass
    if not best: return {"mode": INFO["mode"], "run": None, "tier": None, "over": False}
    _mt, run, p = best
    try: tier = open(p).read().strip().lower()
    except OSError: tier = None
    over = any(os.path.exists(os.path.join(st, f % run)) for f in ("stop_%s", "music_stop_%s"))
    return {"mode": INFO["mode"], "run": run, "tier": tier, "over": over}


def manifest():
    ms = mods()
    m = {"v": 1, "name": socket.gethostname(), "mode": INFO["mode"], "map": INFO["map"], "melee": bool(INFO.get("melee")),
         "humans_team": INFO.get("humans_team"),
         "mods": [{k: v for k, v in m.items() if k != "_items"} for m in ms],
         "toolkit": {"url": "/toolkit.zip"}}
    _p, mu = music()
    if mu: m["music"] = mu
    return m


_toolkit_cache = {}


def toolkit_zip():
    """The bot toolkit for a friend's companion: scripts, map data and the Horde's assets (~80 MB, built once per game)."""
    if "zip" in _toolkit_cache: return _toolkit_cache["zip"]
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(os.listdir(HERE)):
            p = os.path.join(HERE, n)
            if not os.path.isfile(p) or any(s in n for s in TOOLKIT_SKIP): continue
            if n.lower().endswith(TOOLKIT_EXT) or n in TOOLKIT_JSON:
                z.write(p, n)
        for d, exts in TOOLKIT_DIRS.items():                 # the Horde's assets: a friend's own hosted game needs them too
            dp = os.path.join(HERE, d)
            for n in sorted(os.listdir(dp)) if os.path.isdir(dp) else []:
                if n.lower().endswith(exts):
                    z.write(os.path.join(dp, n), d + "/" + n)
    _toolkit_cache["zip"] = bio.getvalue()
    return _toolkit_cache["zip"]


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _send(self, data, ctype):
        self.send_response(200); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data))); self.end_headers()
        try: self.wfile.write(data)
        except OSError: pass

    def do_GET(self):
        try:
            import ipaddress
            if not ipaddress.ip_address(self.client_address[0]).is_private and not ipaddress.ip_address(self.client_address[0]).is_loopback:
                return self.send_error(403)         # LAN / ZeroTier only
            p = self.path.split("?")[0]
            if p == "/manifest.json":
                return self._send(json.dumps(manifest()).encode(), "application/json")
            if p == "/horde.json":
                return self._send(json.dumps(horde_state()).encode(), "application/json")
            if p == "/toolkit.zip":
                return self._send(toolkit_zip(), "application/zip")
            if p.startswith("/f/"):
                mp, mu = music()
                if mu and p == mu["url"]:
                    with open(mp, "rb") as f: return self._send(f.read(), "audio/wav")
                for m in mods():
                    for path, _d, url in m["_items"]:
                        if url == p:
                            with open(path, "rb") as f: return self._send(f.read(), "application/octet-stream")
            self.send_error(404)
        except Exception:
            try: self.send_error(500)
            except OSError: pass


def _discovery():
    """Answer the companion's broadcast ("OUTLAWS?") with this game's name, mode and map (private addresses only)."""
    import ipaddress
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", DISCOVER_PORT))
    except OSError:
        return
    while True:
        try:
            data, a = s.recvfrom(256)
            ip = ipaddress.ip_address(a[0])
            if data.startswith(b"OUTLAWS?") and (ip.is_private or ip.is_loopback):
                s.sendto(json.dumps({"name": socket.gethostname(), "mode": INFO["mode"], "map": INFO["map"], "port": PORT}).encode(), a)
        except OSError:
            time.sleep(1)


def _warm():
    try: mods()
    except Exception: pass


def start(mode="", map_key="", melee=False, humans_team=None):
    """Start (or update) the server; safe to call for every game. humans_team: the team friends' apps join (team games
    with the bots split unevenly), or None."""
    global _srv
    INFO["mode"], INFO["map"], INFO["melee"] = mode or "", map_key or "", bool(melee)
    INFO["humans_team"] = humans_team if humans_team in ("red", "blue") else None
    STARTED[0] = time.time()
    try:
        os.makedirs(os.path.join(HERE, "state"), exist_ok=True)
        with open(os.path.join(HERE, "state", "hostinfo.json"), "w") as f: json.dump(INFO, f)
    except OSError:
        pass
    # Hash every mod file now, in the background: the zombie skins alone are ~70 MB, and hashing them on the first
    # /manifest.json request made friends' companions time out and join without mods.
    threading.Thread(target=_warm, daemon=True).start()
    _toolkit_cache.clear()
    if _srv: return True
    threading.Thread(target=_discovery, daemon=True).start()
    try:
        _srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    except OSError:
        return False                       # port busy: another copy is already serving
    threading.Thread(target=_srv.serve_forever, daemon=True).start()
    return True


if __name__ == "__main__":
    start(*(sys.argv[1:3]))
    print("serving on port", PORT, INFO)
    while True: time.sleep(3600)
